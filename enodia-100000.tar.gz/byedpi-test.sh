#!/bin/sh












































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}


if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi
command -v bin_path >/dev/null 2>&1 || bin_path() { printf '%s' "$ENODIA_BIN/$1"; }




if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v daemon_wait_port >/dev/null 2>&1 || daemon_wait_port() {
    DAEMON_WAIT_WHY=''; _dwi=0; while [ "$_dwi" -lt "$3" ]; do netstat -ltn 2>/dev/null | grep -q "$4:$5 " && return 0; sleep 1; _dwi=$((_dwi+1)); done
    netstat -ltn 2>/dev/null | grep -q "$4:$5 " && return 0
    DAEMON_WAIT_WHY="не появился за $3 с"; return 1; }
CIADPI=$(bin_path byedpi)
TPLUGIN="$ENODIA_DIR/transport-byedpi.sh"
TEST_PORT=10809                               # отдельно от боевого 10808
SOCKS=127.0.0.1
BYEDPI_UID=65534                              # nobody — его egress ловит owner-RETURN
PIDF=/tmp/enodia-byedpi-test-ciadpi.pid       # pid кандидата ciadpi (НЕ боевого, НЕ run-процесса)
STATE="$ENODIA_STATE/.byedpi-test.state"
RESULT="$ENODIA_STATE/.byedpi-test.json"
CONF="$ENODIA_STATE/.byedpi-test.conf"        # настройки теста (пишет панель: key=value)
LOG=/tmp/enodia-byedpi-test-run.log
RES_DIR=/tmp/enodia-byedpi-test-res           # временные файлы проб (1/0 на пробу)
OWNER_MARK=/tmp/enodia-byedpi-test.owneradded # есть файл = owner-RETURN добавили МЫ (снять на выходе)
POOL_FILE=/tmp/enodia-byedpi-test-pool.lst    # пул доменов ЦЕЛИ (наполняет build_pool)
POOL_CAP=24                                   # кап доменов в пуле (тест по сотням был бы неприлично долгим)
TARGET=0                                      # цель теста: 0 | 2|3|4 | zapret (ставит run)
TARGET_LABEL=""                               # подпись столбца/цели (ставит build_pool)


T_TIMEOUT=5      # таймаут запроса, сек (1..15)
T_REQUESTS=1     # запросов на домен (1..20)
T_PARALLEL=8     # одновременных проб (1..50)
T_DELAY=0        # пауза между стратегиями, сек (0..10)

log() { echo "$*" >> "$LOG" 2>/dev/null; }




target_label() {
    case "$1" in
        0)      echo "Основной десинк" ;;
        zapret) echo "Zapret (nfqws)" ;;
        *)      echo "Выход №$1" ;;
    esac
}
target_known() {
    case "$1" in
        0|2|3|4|zapret) return 0 ;;
        *) return 1 ;;
    esac
}
pool() { cat "$POOL_FILE" 2>/dev/null; }







build_pool() {
    sh "$ENODIA_DIR/slots.sh" domains "$1" "$POOL_CAP" 2>/dev/null > "$POOL_FILE"
    _n=$(wc -l < "$POOL_FILE" 2>/dev/null | tr -d ' '); case "$_n" in ''|*[!0-9]*) _n=0 ;; esac
    echo "$_n"
}


clamp() {  # clamp <val> <min> <max> <default>
    v="$1"; case "$v" in ''|*[!0-9]*) v="$4" ;; esac
    [ "$v" -lt "$2" ] && v="$2"; [ "$v" -gt "$3" ] && v="$3"; echo "$v"
}
load_conf() {
    if [ -s "$CONF" ]; then
        while IFS='=' read -r k v; do


            v=$(printf '%s' "$v" | tr -d '\r\n')
            case "$k" in
                timeout)  T_TIMEOUT=$(printf '%s' "$v" | tr -d ' ') ;;
                requests) T_REQUESTS=$(printf '%s' "$v" | tr -d ' ') ;;
                parallel) T_PARALLEL=$(printf '%s' "$v" | tr -d ' ') ;;
                delay)    T_DELAY=$(printf '%s' "$v" | tr -d ' ') ;;
            esac
        done < "$CONF"
    fi
    T_TIMEOUT=$(clamp "$T_TIMEOUT" 1 15 5)
    T_REQUESTS=$(clamp "$T_REQUESTS" 1 20 1)
    T_PARALLEL=$(clamp "$T_PARALLEL" 1 50 8)
    T_DELAY=$(clamp "$T_DELAY" 0 10 0)
}

cleanup() {
    start-stop-daemon -K -p "$PIDF" 2>/dev/null
    if [ -f "$OWNER_MARK" ]; then





        if [ "$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')" != byedpi ]; then
            iptables -t mangle -D OUTPUT -m owner --uid-owner "$BYEDPI_UID" -j RETURN 2>/dev/null
        fi
        rm -f "$OWNER_MARK" 2>/dev/null   # НЕ `find -delete`: такой опции у busybox нет — см. C39
    fi
    rm -rf "$RES_DIR" 2>/dev/null
}



ensure_owner() {
    iptables -t mangle -C OUTPUT -m owner --uid-owner "$BYEDPI_UID" -j RETURN 2>/dev/null && return 0
    iptables -t mangle -I OUTPUT 1 -m owner --uid-owner "$BYEDPI_UID" -j RETURN && : > "$OWNER_MARK"
}

json_escape() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }


spawn() {
    start-stop-daemon -K -p "$PIDF" 2>/dev/null; sleep 1
    start-stop-daemon -S -b -c nobody -m -p "$PIDF" -x /bin/sh -- -c "exec '$CIADPI' -i $SOCKS -p $TEST_PORT $1 >/dev/null 2>&1"

    daemon_wait_port "$PIDF" byedpi 8 "$SOCKS" "$TEST_PORT"
}


probe() {
    code=$(curl -s -o /dev/null -w '%{http_code}' --max-time "$T_TIMEOUT" --connect-timeout 4 \
        --socks5-hostname "$SOCKS:$TEST_PORT" "https://$1" 2>/dev/null)
    case "$code" in 2*|3*) echo 1 > "$2" ;; *) echo 0 > "$2" ;; esac
}


run_pool() {
    rm -rf "$RES_DIR"; mkdir -p "$RES_DIR"
    idx=0; j=0
    for dom in $(pool); do
        r=1
        while [ "$r" -le "$T_REQUESTS" ]; do
            probe "$dom" "$RES_DIR/$idx" &
            idx=$((idx+1)); j=$((j+1))
            [ "$j" -ge "$T_PARALLEL" ] && { wait; j=0; }
            r=$((r+1))
        done
    done
    wait

    ok=$(cat "$RES_DIR"/* 2>/dev/null | tr -cd '1' | wc -c)
    case "$ok" in ''|*[!0-9]*) ok=0 ;; esac
    echo "$ok"
}


pool_max() { n=$(pool | wc -l); echo $((n * T_REQUESTS)); }

run() {
    TARGET="${1:-0}"   # цель: 0 = основная несущая (деф.) | 2|3|4 = доп-выход | zapret = общий nfqws



    trap 'cleanup' EXIT
    trap 'exit 143' INT TERM
    [ -x "$CIADPI" ] || { echo ERR > "$STATE"; : > "$LOG"; log "нет бинаря ciadpi — установите набор с ByeDPI"; return 1; }
    target_known "$TARGET" || { echo ERR > "$STATE"; : > "$LOG"; log "неизвестная цель «$TARGET» (0|2|3|4|zapret)"; return 1; }
    load_conf
    : > "$LOG"; echo RUNNING > "$STATE"



    TARGET_LABEL=$(target_label "$TARGET")
    _np=$(build_pool "$TARGET")
    case "$_np" in ''|0|*[!0-9]*)
        echo ERR > "$STATE"
        log "через «$TARGET_LABEL» по доменам ничего не едет — заведите доменное правило, группу или доменный гео-сервис для этой цели"
        return 1 ;;
    esac
    log "цель «$TARGET_LABEL»: $_np доменов (кап $POOL_CAP)"


    : > "$RESULT"


    total_max=$(pool_max)
    cats_json="{\"k\":\"$(json_escape "$TARGET")\",\"l\":\"$(json_escape "$TARGET_LABEL")\",\"n\":$total_max}"
    log "макс проб: $total_max; timeout=$T_TIMEOUT requests=$T_REQUESTS parallel=$T_PARALLEL delay=$T_DELAY"
    ensure_owner

    TAB=$(printf '\t')


    defargs=$(sh "$TPLUGIN" defaults 2>/dev/null)

    cand=/tmp/enodia-byedpi-test-cand.lst; : > "$cand"
    sh "$TPLUGIN" presets 2>/dev/null | while IFS='|' read -r lbl args; do
        [ -z "$args" ] && args="$defargs"
        [ -n "$lbl" ] && printf '%s%s%s\n' "$lbl" "$TAB" "$args" >> "$cand"
    done



    _cf="$ENODIA_STATE/.byedpi-args"
    case "$TARGET" in 2|3|4) _cf="$ENODIA_STATE/.byedpi-args-s$TARGET" ;; esac
    cust=$(grep -vE '^[[:space:]]*#' "$_cf" 2>/dev/null | tr '\n' ' ' | sed 's/  */ /g; s/^ //; s/ $//')
    if [ -n "$cust" ] && ! grep -qF "$TAB$cust" "$cand"; then
        printf 'Текущие свои%s%s\n' "$TAB" "$cust" >> "$cand"
    fi
    total=$(wc -l < "$cand" 2>/dev/null); case "$total" in ''|*[!0-9]*) total=0 ;; esac

    out="$RESULT.new"



    _sn="$TARGET"; case "$_sn" in ''|*[!0-9]*) _sn=0 ;; esac
    printf '{"slot":%d,"target":"%s","cats":[%s],"max":%d,"results":[' \
        "$_sn" "$(json_escape "$TARGET")" "$cats_json" "$total_max" > "$out"

    n=0; rfirst=1
    while IFS="$TAB" read -r lbl args; do
        n=$((n+1))


        echo "RUNNING $n/$total $lbl" > "$STATE"
        log "[$n/$total] $lbl  ($args)"
        tot=0; per=0
        if spawn "$args"; then
            tot=$(run_pool); per="$tot"
            log "    $TARGET_LABEL -> $tot"
        else
            log "    ciadpi не поднялся (пропуск)"
        fi
        start-stop-daemon -K -p "$PIDF" 2>/dev/null
        [ $rfirst -eq 1 ] && rfirst=0 || printf ',' >> "$out"
        printf '{"label":"%s","args":"%s","total":%d,"per":[%s]}' \
            "$(json_escape "$lbl")" "$(json_escape "$args")" "$tot" "$per" >> "$out"



        { cat "$out"; printf ']}'; } > "$RESULT.tmp" 2>/dev/null && mv "$RESULT.tmp" "$RESULT" 2>/dev/null
        log "  итог: $tot/$total_max"
        [ "$T_DELAY" -gt 0 ] && sleep "$T_DELAY"
    done < "$cand"

    printf ']}' >> "$out"
    mv "$out" "$RESULT"
    rm -f "$cand" 2>/dev/null             # НЕ `find -delete`: такой опции у busybox нет — см. C39
    echo DONE > "$STATE"
    log "готово: проверено $total стратегий, max $total_max проб"

}




emit_config() {
    load_conf
    av=""
    for t in 0 2 3 4 zapret; do
        _n=$(sh "$ENODIA_DIR/slots.sh" domains "$t" "$POOL_CAP" 2>/dev/null | wc -l | tr -d ' ')
        case "$_n" in ''|*[!0-9]*) _n=0 ;; esac
        av="$av${av:+,}{\"k\":\"$t\",\"l\":\"$(json_escape "$(target_label "$t")")\",\"n\":$_n}"
    done
    printf '{"timeout":%d,"requests":%d,"parallel":%d,"delay":%d,"targets":[%s]}\n' \
        "$T_TIMEOUT" "$T_REQUESTS" "$T_PARALLEL" "$T_DELAY" "$av"
}

case "$1" in
    run)   run "$2" ;;
    stop)


        start-stop-daemon -K -p /tmp/enodia-byedpi-test.pid 2>/dev/null
        i=0; while [ $i -lt 12 ]; do p=$(cat /tmp/enodia-byedpi-test.pid 2>/dev/null | tr -d ' \r\n'); { [ -n "$p" ] && kill -0 "$p" 2>/dev/null; } || break; sleep 1; i=$((i+1)); done
        cleanup; echo STOPPED > "$STATE"; log "прервано пользователем" ;;
    state) cat "$STATE" 2>/dev/null || echo IDLE ;;
    config) emit_config ;;
    *) echo "usage: $0 run [0|2|3|4|zapret]|stop|state|config"; exit 2 ;;
esac
