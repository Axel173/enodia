#!/bin/sh

























ENODIA_DIR=${ENODIA_DIR:-${_cgid:-/data/usr/app/enodia}}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}
ENODIA_BOOT=${ENODIA_BOOT:-/data/usr/app/enodia-boot}







if { [ "$ENODIA_DIR" != /data/usr/app/enodia ] || [ ! -d "$ENODIA_STATE" ]; } \
   && [ -f "$ENODIA_BOOT/boot.sh" ]; then
    _cgp=$(sh "$ENODIA_BOOT/boot.sh" paths 2>/dev/null)
    _cgs=$(printf '%s\n' "$_cgp" | sed -n 's/^state=//p' | tail -1)
    _cgb=$(printf '%s\n' "$_cgp" | sed -n 's/^bin=//p' | tail -1)
    case "$_cgs" in /*) ENODIA_STATE="$_cgs" ;; esac
    case "$_cgb" in /*) ENODIA_BIN="$_cgb" ;; esac
    unset _cgp _cgs _cgb
fi
export ENODIA_DIR ENODIA_STATE ENODIA_BIN ENODIA_BOOT
