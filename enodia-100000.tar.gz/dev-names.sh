#!/bin/sh





























ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
STORE="$ENODIA_STATE/.dev-names"
TAB=$(printf '\t')
NL='
'

if [ -f "$ENODIA_DIR/lease-lib.sh" ]; then . "$ENODIA_DIR/lease-lib.sh"; fi
command -v mac_norm >/dev/null 2>&1 || mac_norm() { printf '%s' "$1" | tr 'A-Z' 'a-z' | tr -d ' \t\r\n'; }
command -v mac_ok   >/dev/null 2>&1 || mac_ok()   { printf '%s' "$1" | grep -qE '^[0-9a-f]{2}(:[0-9a-f]{2}){5}$'; }


if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v pid_runs >/dev/null 2>&1 || pid_runs() { [ -n "$1" ] && [ -r "/proc/$1/cmdline" ] && tr '\000' ' ' 2>/dev/null < "/proc/$1/cmdline" | grep -qE "$2"; }



NAME_MAX=96
LOCK=/tmp/.enodia-dev-names.lock




if [ -f "$ENODIA_DIR/label-lib.sh" ]; then . "$ENODIA_DIR/label-lib.sh"; else
    echo "[dev-names] нет $ENODIA_DIR/label-lib.sh — обновите установку" >&2; exit 1
fi
MAC_RE='^[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]:[0-9a-f][0-9a-f]$'
lock_take() { lbl_lock_take "$LOCK" 'dev-names'; }
lock_drop() { lbl_lock_drop "$LOCK"; }
san_name() { lbl_san "$1"; }
cmd_list() { lbl_list "$STORE" "$MAC_RE" lower; }

cmd_get() {
    _gm=$(mac_norm "$1"); mac_ok "$_gm" || return 1
    cmd_list | awk -F"$TAB" -v m="$_gm" '$1==m { print $2; exit }'
}





store_write() { lbl_write "$STORE" "$1" "$2" "$MAC_RE" lower; }   # $1 = mac, $2 = имя (пусто = снять)

cmd_set() {
    _sm=$(mac_norm "$1")
    mac_ok "$_sm" || { echo "[dev-names] у устройства нет MAC — метку привязать не к чему"; return 1; }
    _sn=$(san_name "$2")


    if [ -z "$_sn" ] && [ -n "$(printf '%s' "$2" | tr -d ' \t\r\n')" ]; then
        echo "[dev-names] в имени нет ни одного допустимого знака — кавычки и обратная косая не сохраняются"; return 1
    fi
    if [ "$(printf '%s' "$_sn" | wc -c)" -gt "$NAME_MAX" ]; then
        echo "[dev-names] имя слишком длинное: до 48 букв кириллицей или 96 латиницей — сократите"; return 1
    fi
    lock_take || { echo "[dev-names] имена сейчас правит другая операция — повторите"; return 1; }
    store_write "$_sm" "$_sn"; _sr=$?
    lock_drop
    [ "$_sr" = 0 ] || { echo "[dev-names] не удалось записать имя (место на разделе?)"; return 1; }

    _su=$(printf '%s' "$_sm" | tr 'a-z' 'A-Z')
    if [ -n "$_sn" ]; then echo "[dev-names] устройство $_su: имя «$_sn»"; else echo "[dev-names] устройство $_su: своё имя снято"; fi
}

case "$1" in
    set)  cmd_set "$2" "$3" ;;
    del)  cmd_set "$2" "" ;;
    get)  cmd_get "$2" ;;
    list) cmd_list; exit 0 ;;
    *) echo "usage: $0 set <mac> <имя> | del <mac> | get <mac> | list"; exit 2 ;;
esac
