#!/bin/sh




















ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
SRC="$ENODIA_STATE/.dns-hosts"
CONFDIR=/tmp/dnsmasq.d
CONF="$CONFDIR/08-dns-hosts.conf"
TAB=$(printf '\t')




reload() {
	if [ -f "$ENODIA_DIR/dns-merge.sh" ]; then
		sh "$ENODIA_DIR/dns-merge.sh" reload >/dev/null 2>&1 && return 0
	fi
	/etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null
}







conf_test() {   # $1 = файл-кандидат
	[ -x /usr/sbin/dnsmasq ] || return 0
	_ct=$(/usr/sbin/dnsmasq --test -C "$1" 2>&1)
	case "$_ct" in
		*"syntax check OK"*) return 0 ;;
		"") return 0 ;;
	esac
	printf '%s' "$_ct" | tail -2 >&2
	return 1
}







valid_domain() { printf '%s' "$1" | grep -qE '^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$'; }









valid_ipv4() {
	printf '%s' "$1" | grep -qE '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || return 1
	_vr="$1"
	for _vi in 1 2 3 4; do
		_vo=${_vr%%.*}; _vr=${_vr#*.}
		[ "$_vo" -ge 0 ] 2>/dev/null && [ "$_vo" -le 255 ] 2>/dev/null || return 1
	done
	return 0
}
valid_ip() {
	valid_ipv4 "$1" && return 0
	case "$1" in *:*) : ;; *) return 1 ;; esac
	printf '%s' "$1" | grep -qE '^[0-9A-Fa-f:]{2,45}$'
}




others_than() { [ -f "$SRC" ] && awk -F"$TAB" -v d="$1" '$1!=d' "$SRC"; }





fam_solo() {
	_fv=$(/usr/sbin/dnsmasq -v 2>/dev/null | sed -n '1s/^Dnsmasq version \([0-9][0-9]*\)\.\([0-9][0-9]*\).*/\1 \2/p')
	[ -n "$_fv" ] || return 1
	set -- $_fv
	[ "$1" -gt 2 ] || { [ "$1" -eq 2 ] && [ "$2" -ge 86 ]; }
}


norm_domain() { printf '%s' "$1" | sed -E 's|^https?://||; s|^www\.||; s|/.*$||' | tr 'A-Z' 'a-z'; }

build() {   # $1 = куда писать; по умолчанию ЖИВОЙ conf
	_bt="${1:-$CONF}"
	mkdir -p "$CONFDIR"
	if [ -s "$SRC" ]; then

		awk -F"$TAB" 'NF>=2 && $1!="" && $2!=""{ printf "address=/%s/%s\n", $1, $2 }' "$SRC" > "$_bt.new" 2>/dev/null
		mv "$_bt.new" "$_bt" 2>/dev/null
	else
		rm -f "$_bt" 2>/dev/null
	fi
}

case "$1" in
	add)
		d=$(norm_domain "$2"); ip="$3"
		valid_domain "$d" || { echo "плохой домен"; exit 1; }
		valid_ip "$ip"    || { echo "плохой IP"; exit 1; }
		mkdir -p "$ENODIA_STATE"




		_dhb=/tmp/.enodia-dns-hosts.bak.$$
		[ -f "$SRC" ] && cp "$SRC" "$_dhb" 2>/dev/null
		{ others_than "$d"; printf '%s\t%s\n' "$d" "$ip"; } > "$SRC.new" 2>/dev/null
		mv "$SRC.new" "$SRC" 2>/dev/null
		_dhc=/tmp/.enodia-dns-hosts.cand.$$
		build "$_dhc"
		if [ -f "$_dhc" ] && ! conf_test "$_dhc"; then
			if [ -f "$_dhb" ]; then mv "$_dhb" "$SRC" 2>/dev/null; else rm -f "$SRC" 2>/dev/null; fi
			rm -f "$_dhc" "$_dhb" 2>/dev/null
			echo "dnsmasq не принял такой адрес — запись откачена, DNS не трогали"
			exit 1
		fi
		rm -f "$_dhc" "$_dhb" 2>/dev/null
		build; reload; echo "ok" ;;
	del)
		d=$(norm_domain "$2")
		[ -n "$d" ] || { echo "нет домена"; exit 1; }



		awk -F"$TAB" -v d="$d" '$1==d{f=1} END{exit !f}' "$SRC" 2>/dev/null || { echo "такого имени нет"; exit 1; }
		if [ -f "$SRC" ]; then others_than "$d" > "$SRC.new" 2>/dev/null; mv "$SRC.new" "$SRC" 2>/dev/null; fi
		build; reload; echo "ok" ;;
	apply) build; reload; echo "ok" ;;
	build) build; echo "ok" ;;
	list)

		solo=false; fam_solo && solo=true
		printf '['
		first=1
		if [ -f "$SRC" ]; then
			while IFS="$TAB" read -r d ip; do
				[ -n "$d" ] || continue
				[ "$first" -eq 1 ] || printf ','
				printf '{"domain":"%s","ip":"%s","solo":%s}' "$d" "$ip" "$solo"
				first=0
			done < "$SRC"
		fi
		printf ']\n' ;;
	*) echo "usage: dns-hosts.sh add <домен> <ip> | del <домен> | list | apply | build" ;;
esac
