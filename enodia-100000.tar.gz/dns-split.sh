#!/bin/sh


























ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
FLAG="$ENODIA_STATE/.split-runet"
CONF=/tmp/dnsmasq.d/09-split-runet.conf

TLDS="ru xn--p1ai su"
R1=77.88.8.8
R2=77.88.8.1

reload() { /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null; }

build() {
	mkdir -p /tmp/dnsmasq.d
	if [ -f "$FLAG" ]; then
		{ for t in $TLDS; do echo "server=/$t/$R1"; echo "server=/$t/$R2"; done; } > "$CONF.new" 2>/dev/null
		mv "$CONF.new" "$CONF" 2>/dev/null
	else
		rm -f "$CONF" 2>/dev/null
	fi
}




conflict() {
	[ -f "$FLAG" ] || { echo 0; return 0; }
	[ -f "$ENODIA_DIR/doh-lib.sh" ] || { echo 0; return 0; }
	( . "$ENODIA_DIR/doh-lib.sh"; doh_want >/dev/null 2>&1 ) && echo 1 || echo 0
}

case "$1" in
	on)     : > "$FLAG"; build; reload; echo ok
	        [ "$(conflict)" = 1 ] && echo "внимание: при включённом «Шифрованном DNS» имена .ru/.рф/.su всё равно резолвятся ОТКРЫТО (server=/tld/ специфичнее общего апстрима)" ;;
	off)    rm -f "$FLAG"; build; reload; echo ok ;;
	apply)  build; reload; echo ok ;;   # для heal.sh на буте
	build)  build; echo ok ;;
	status) [ -f "$FLAG" ] && echo on || echo off ;;
	conflict) conflict ;;               # 1 = сплит рунета и шифрованный DNS включены одновременно
	*)      echo "usage: dns-split.sh on|off|apply|build|status|conflict" ;;
esac
