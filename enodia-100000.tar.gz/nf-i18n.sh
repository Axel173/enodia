#!/bin/sh

























ENODIA_DIR="${ENODIA_DIR:-/data/usr/app/enodia}"
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}


nf_lang() {
	_nl=$(grep '^lang=' "$ENODIA_STATE/.prefs" 2>/dev/null | head -1 | cut -d= -f2- | tr -cd 'a-z')
	[ "$_nl" = en ] && echo en || echo ru
}
