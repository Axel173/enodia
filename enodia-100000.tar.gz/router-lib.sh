#!/bin/sh






















_RL_VER=/usr/share/xiaoqiang/xiaoqiang_version
_RL_MISC=/etc/config/misc


router_label() {
	_rl_dn=$(sed -n "s/.*option displayName '\([^']*\)'.*/\1/p" "$_RL_MISC" 2>/dev/null | head -1)
	_rl_out=""
	if [ -n "$_rl_dn" ]; then
		_rl_out=$(printf '%s' "$_rl_dn" | sed 's/.*[^A-Za-z0-9]//')   # замыкающий ASCII-ран: BE7000
	fi
	if [ -z "$_rl_out" ]; then
		_rl_hw=$(grep -E "option HARDWARE " "$_RL_VER" 2>/dev/null | sed "s/.*'\(.*\)'.*/\1/")
		case "$_rl_hw" in
			R3600) _rl_out="AX3600" ;;
			RC06)  _rl_out="BE7000" ;;
			'')    _rl_out="роутер" ;;
			*)     _rl_out="$_rl_hw" ;;
		esac
	fi
	printf '%s' "$_rl_out" | tr -d '"\\'
}


router_model() {
	_rm_dn=$(sed -n "s/.*option displayName '\([^']*\)'.*/\1/p" "$_RL_MISC" 2>/dev/null | head -1)
	_rm_out=""
	if [ -n "$_rm_dn" ]; then
		_rm_mdl=$(printf '%s' "$_rm_dn" | sed 's/.*[^A-Za-z0-9]//')   # замыкающий ASCII-ран: BE7000
		_rm_brd=$(printf '%s' "$_rm_dn" | sed 's/[^A-Za-z0-9].*//')   # лидирующий ASCII-ран: Xiaomi (пусто на CN-строке)
		[ -z "$_rm_brd" ] && _rm_brd=Xiaomi
		[ "$_rm_brd" = "$_rm_mdl" ] && _rm_brd=Xiaomi
		[ -n "$_rm_mdl" ] && _rm_out="$_rm_brd $_rm_mdl"
	fi
	if [ -z "$_rm_out" ]; then
		_rm_hw=$(grep -E "option HARDWARE " "$_RL_VER" 2>/dev/null | sed "s/.*'\(.*\)'.*/\1/")
		case "$_rm_hw" in
			R3600) _rm_out="Xiaomi AX3600" ;;
			RC06)  _rm_out="Xiaomi BE7000" ;;
			'')    _rm_out="Xiaomi" ;;
			*)     _rm_out="Xiaomi $_rm_hw" ;;
		esac
	fi
	printf '%s' "$_rm_out" | tr -d '"\\'
}








router_relabel() {
	case "$1" in
		BE7000:*|AX3600:*|BE3600:*|BE10000:*)
			printf '%s:%s' "$(router_label)" "${1#*:}" ;;
		*) printf '%s' "$1" ;;
	esac
}


















cpu_busy_pct() {
	set -- $(awk '/^cpu /{s=0;for(i=2;i<=NF;i++)s+=$i; print s, $5+$6; exit}' /proc/stat 2>/dev/null)
	_cb_t0="$1"; _cb_i0="$2"
	sleep 1
	set -- $(awk '/^cpu /{s=0;for(i=2;i<=NF;i++)s+=$i; print s, $5+$6; exit}' /proc/stat 2>/dev/null)
	_cb_t1="$1"; _cb_i1="$2"
	if [ -z "$_cb_t0" ] || [ -z "$_cb_t1" ]; then return 0; fi
	awk -v t0="$_cb_t0" -v i0="$_cb_i0" -v t1="$_cb_t1" -v i1="$_cb_i1" 'BEGIN{
		dt=t1-t0; di=i1-i0;
		if(dt<=0){print 0; exit}
		v=(1-di/dt)*100; if(v<0)v=0; if(v>100)v=100; printf "%d", v+0.5 }'
}
























lan_if() {

	_rl_li=$(uci get network.lan.device 2>/dev/null)
	_rl_li=${_rl_li%% *}
	if [ -n "$_rl_li" ] && [ -d "/sys/class/net/$_rl_li" ]; then
		printf '%s\n' "$_rl_li"; return 0
	fi

	for _rl_p in $(uci get network.lan.ifname 2>/dev/null); do
		[ -d "/sys/class/net/$_rl_p" ] || continue
		if [ -d "/sys/class/net/$_rl_p/bridge" ]; then
			printf '%s\n' "$_rl_p"; return 0
		fi

		if [ -e "/sys/class/net/$_rl_p/master" ]; then
			_rl_m=$(readlink -f "/sys/class/net/$_rl_p/master" 2>/dev/null)
			_rl_m=${_rl_m##*/}
			if [ -n "$_rl_m" ] && [ -d "/sys/class/net/$_rl_m" ]; then
				printf '%s\n' "$_rl_m"; return 0
			fi
		fi
	done
	printf 'br-lan\n'   # lan-lit: владелец сам, дальше спрашивать некого
}
