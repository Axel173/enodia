#!/bin/sh











































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BOOT=${ENODIA_BOOT:-/data/usr/app/enodia-boot}   # для ПОДСКАЗОК в письмах: команду человеку даём только через запускатель
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}




if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi
command -v ct_flush >/dev/null 2>&1 || ct_flush()      { conntrack -F >/dev/null 2>&1 || true; }
CONFIGS_DIR="$ENODIA_STATE/configs"
ACTIVE_CONF="$ENODIA_STATE/awg.conf"
SHALIN_CONF="$ENODIA_STATE/amnezia_for_awg.conf"
AWG0_CONF="$ENODIA_STATE/awg0.conf"
ACTIVE_NAME="$ENODIA_STATE/.active"
BACKUP_CONF="$ENODIA_STATE/.last.bak.conf"
BACKUP_NAME="$ENODIA_STATE/.last.bak.name"
SWITCH_LOCK="/tmp/enodia-switching.lock"
NOTIFY_EVENT="$ENODIA_DIR/notify-event.sh"   # обёртка событийных писем (throttle)
WD_STATE="/tmp/enodia-watchdog.state"   # состояние watchdog (NORMAL/FAILOPEN) — держим синхронным (см. safety_off/apply_routing)
HS_WAIT=25                       # сколько секунд ждать handshake




if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v age_since >/dev/null 2>&1 || age_since() {
    case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
    [ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}



if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi
command -v probe_ext_ip >/dev/null 2>&1 || probe_ext_ip() { curl -s $1 --max-time "${2:-7}" https://api.ipify.org 2>/dev/null; }



if [ -f "$ENODIA_DIR/nf-i18n.sh" ]; then . "$ENODIA_DIR/nf-i18n.sh"; fi
command -v nf_lang >/dev/null 2>&1 || nf_lang() { echo ru; }
NF_LANG=$(nf_lang)






if [ -f "$ENODIA_DIR/doh-lib.sh" ]; then . "$ENODIA_DIR/doh-lib.sh"; fi
command -v doh_apply_dns >/dev/null 2>&1 || doh_apply_dns() { return 1; }


if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v carrier_barred >/dev/null 2>&1 || carrier_barred() { return 1; }

command -v daemon_wait_gone >/dev/null 2>&1 || daemon_wait_gone() { _dwg=0; while [ -d "/proc/$1" ]; do [ "$_dwg" -ge "${2:-5}" ] && return 1; sleep 1; _dwg=$((_dwg+1)); done; return 0; }

command -v fw3_gen >/dev/null 2>&1 || fw3_gen() { cat /proc/sys/kernel/random/uuid 2>/dev/null || echo "$$-$RANDOM-$RANDOM"; }









FW3_WIPED=0




notify_event() {
    [ -f "$NOTIFY_EVENT" ] && sh "$NOTIFY_EVENT" "$1" "$2" "$3" "$4" >/dev/null 2>&1
}

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

mkdir -p "$CONFIGS_DIR"





WG=""
[ -x "$ENODIA_BIN/awg" ] && WG="$ENODIA_BIN/awg"
[ -z "$WG" ] && command -v awg >/dev/null 2>&1 && WG=awg
[ -z "$WG" ] && command -v wg  >/dev/null 2>&1 && WG=wg




SWITCH_LOCK_MINE=0
acquire_lock() {




    [ -e "$SWITCH_LOCK" ] || { : > "$SWITCH_LOCK" 2>/dev/null && SWITCH_LOCK_MINE=1; }

    trap 'release_lock' EXIT
    trap 'exit 1' INT TERM HUP PIPE
}
release_lock() {


    _rc=$?
    [ "$SWITCH_LOCK_MINE" = 1 ] && rm -f "$SWITCH_LOCK" 2>/dev/null
    return $_rc
}




list_configs() {
    printf "${BLUE}Доступные конфиги в $CONFIGS_DIR:${NC}\n"
    found=0
    for f in "$CONFIGS_DIR"/*.conf; do
        [ -f "$f" ] || continue
        name=$(basename "$f" .conf)
        endpoint=$(grep -E "^Endpoint" "$f" | head -1 | awk -F'= *' '{print $2}')
        active=""
        if [ -f "$ACTIVE_NAME" ] && [ "$(cat "$ACTIVE_NAME")" = "$name" ]; then
            active="${GREEN} ← АКТИВНЫЙ${NC}"
        fi
        printf "  ${YELLOW}%-20s${NC} (Endpoint: %s)%s\n" "$name" "$endpoint" "$active"
        found=$((found+1))
    done
    [ $found -eq 0 ] && printf "  ${RED}Конфигов нет.${NC} Положите .conf в %s\n" "$CONFIGS_DIR"
}

show_status() {
    printf "${BLUE}Статус AmneziaWG:${NC}\n"
    if [ -f "$ACTIVE_NAME" ]; then


        _ss_act=$(cat "$ACTIVE_NAME" 2>/dev/null | tr -d '\r')
        printf "  Активный конфиг: ${GREEN}%s${NC}\n" "${_ss_act:-?}"
    fi
    if ip link show awg0 >/dev/null 2>&1; then
        printf "  Интерфейс awg0: ${GREEN}поднят${NC}\n"
        if [ -n "$WG" ]; then
            hs=$($WG show awg0 latest-handshakes 2>/dev/null | awk 'NR==1{print $2}')
            case "$hs" in
                ''|*[!0-9]*) hs=0 ;;
            esac
            if [ "$hs" -gt 0 ]; then
                ago=$(age_since "$hs")
                printf "  Handshake: ${GREEN}%d сек назад${NC}\n" "$ago"
            else
                printf "  Handshake: ${RED}нет${NC}\n"
            fi
        fi


        if [ "$1" = ip ]; then
            ip_vpn=$(probe_ext_ip "--interface awg0" 5)
            [ -n "$ip_vpn" ] && printf "  Внешний IP через VPN: ${GREEN}%s${NC}\n" "$ip_vpn"
        fi
    else
        printf "  Интерфейс awg0: ${RED}не поднят${NC}\n"
    fi
}




wait_for_handshake() {
    [ -z "$WG" ] && return 1
    _whq=1; command -v usleep >/dev/null 2>&1 && _whq=4
    _whi=0
    while [ "$_whi" -lt $((HS_WAIT * _whq)) ]; do
        hs=$($WG show awg0 latest-handshakes 2>/dev/null | awk 'NR==1{print $2}')
        case "$hs" in
            ''|*[!0-9]*) hs=0 ;;
        esac
        if [ "$hs" -gt 0 ]; then
            ago=$(age_since "$hs")
            [ "$ago" -lt 300 ] && return 0
        fi
        if [ "$_whq" = 4 ]; then usleep 250000; else sleep 1; fi
        _whi=$((_whi+1))
        [ $((_whi % _whq)) = 0 ] && printf "."
    done
    return 1
}








alt_back() {
    [ -n "$cur_t" ] && [ "$cur_t" != awg ] || return 1




    if [ ! -f "$ENODIA_DIR/transport.sh" ]; then
        printf "${YELLOW}[возврат]${NC} оркестратора нет — прежнюю несущую (%s) не отпускали, она работает.\n" "$cur_t"
        return 0
    fi

    if carrier_barred; then
        printf "${YELLOW}[возврат]${NC} VPN выключен вручную — прежнюю несущую (%s) не поднимаю.\n" "$cur_t"
        return 0
    fi
    printf "${YELLOW}[возврат]${NC} поднимаю обратно прежнюю несущую (%s)…\n" "$cur_t"
    if sh "$ENODIA_DIR/transport.sh" up "$cur_t" >/dev/null 2>&1; then
        printf "${GREEN}[возврат]${NC} несущая %s вернулась.\n" "$cur_t"








        replay_after_fw3
        return 0
    fi
    printf "${RED}[FAIL]${NC} прежняя несущая (%s) не вернулась — включаю прямой режим.\n" "$cur_t"
    safety_off
    if [ "$NF_LANG" = en ]; then
        notify_event "switch-failopen" 3600 "BE7000: CRIT — VPN did not come up, direct mode" \
"Switching to the config $target did not work out, and the PREVIOUS carrier ($cur_t) did not
come back up either. Direct mode is on (safety_off): internet and DNS work bypassing the VPN,
listed sites are unavailable.
Check free space and the log: df -h; cat /tmp/enodia-switch-vpn-setup.log"
    else
        notify_event "switch-failopen" 3600 "BE7000: КРИТ — VPN не поднялся, прямой режим" \
"Переключение на конфиг $target не удалось, а ПРЕЖНЯЯ несущая ($cur_t) обратно не поднялась.
Включён прямой режим (safety_off): интернет и DNS работают мимо VPN, сайты из списка недоступны.
Проверьте место и лог: df -h; cat /tmp/enodia-switch-vpn-setup.log"
    fi
    return 0
}


















install_config() {
    _ic_src="$1"
    _ic_name="$2"




    _ic_t1="$ACTIVE_CONF.$$.new"
    _ic_t2="$SHALIN_CONF.$$.new"





    rm -f "$_ic_t1" "$_ic_t2" 2>/dev/null



    if ! cp "$_ic_src" "$_ic_t1" 2>/dev/null || [ ! -s "$_ic_t1" ]; then
        rm -f "$_ic_t1" 2>/dev/null
        printf "${RED}[FAIL]${NC} конфиг %s не разложен: не пишется рядом с %s (место на разделе? df)\n" "${_ic_name:-?}" "$ACTIVE_CONF"
        return 1
    fi
    chmod 600 "$_ic_t1" 2>/dev/null




    if grep -qE '^I[1-5][[:space:]]*=[[:space:]]*$' "$_ic_t1"; then
        sed -i '/^I[1-5][[:space:]]*=[[:space:]]*$/d' "$_ic_t1"
    fi




    if [ ! -s "$_ic_t1" ]; then
        rm -f "$_ic_t1" "$_ic_t2" 2>/dev/null
        printf "${RED}[FAIL]${NC} конфиг %s не разложен: после чистки пустых I1..I5 не осталось ничего (обрыв записи или пустой конфиг)\n" "${_ic_name:-?}"
        return 1
    fi



    if ! cp "$_ic_t1" "$_ic_t2" 2>/dev/null || [ ! -s "$_ic_t2" ]; then
        rm -f "$_ic_t1" "$_ic_t2" 2>/dev/null
        printf "${RED}[FAIL]${NC} конфиг %s не разложен: не пишется рядом с %s (место на разделе? df)\n" "${_ic_name:-?}" "$SHALIN_CONF"
        return 1
    fi
    chmod 600 "$_ic_t2" 2>/dev/null
















    rm -f "$AWG0_CONF" 2>/dev/null
    if [ -e "$AWG0_CONF" ]; then
        rm -f "$_ic_t1" "$_ic_t2" 2>/dev/null
        printf "${RED}[FAIL]${NC} конфиг %s не разложен: не снять %s — демон взял бы СТАРЫЕ ключи\n" "${_ic_name:-?}" "$AWG0_CONF"
        return 1
    fi


    if ! mv -f "$_ic_t1" "$ACTIVE_CONF" 2>/dev/null; then
        rm -f "$_ic_t1" "$_ic_t2" 2>/dev/null
        printf "${RED}[FAIL]${NC} конфиг %s не разложен: публикация %s не удалась\n" "${_ic_name:-?}" "$ACTIVE_CONF"
        return 1
    fi
    if ! mv -f "$_ic_t2" "$SHALIN_CONF" 2>/dev/null; then










        if cp "$ACTIVE_CONF" "$SHALIN_CONF" 2>/dev/null && [ -s "$SHALIN_CONF" ] \
           && [ "$(wc -c < "$SHALIN_CONF" 2>/dev/null)" = "$(wc -c < "$ACTIVE_CONF" 2>/dev/null)" ]; then
            chmod 600 "$SHALIN_CONF" 2>/dev/null
            rm -f "$_ic_t2" 2>/dev/null
        else
            rm -f "$_ic_t2" "$SHALIN_CONF" 2>/dev/null




            : > "$ACTIVE_NAME" 2>/dev/null || true
            printf "${RED}[FAIL]${NC} конфиг %s разложен НАПОЛОВИНУ: %s обновлён, а %s записать не вышло (снят, чтобы демон не взял СТАРЫЕ ключи; пересоздаст heal на загрузке при включённом VPN)\n" "${_ic_name:-?}" "$ACTIVE_CONF" "$SHALIN_CONF"
            return 2
        fi
    fi




    if [ -n "$_ic_name" ]; then



        if ! echo "$_ic_name" > "$ACTIVE_NAME" 2>/dev/null; then
            : > "$ACTIVE_NAME" 2>/dev/null || true
            printf "${YELLOW}[warn]${NC} имя активного конфига (%s) не записалось в %s — считаем неизвестным\n" "$_ic_name" "$ACTIVE_NAME"
        fi
    else
        : > "$ACTIVE_NAME" 2>/dev/null || true
    fi
    return 0
}









awg0_daemon_pids() {
    for _p in /proc/[0-9]*; do
        [ -r "$_p/cmdline" ] || continue
        case "$(tr '\0' ' ' 2>/dev/null < "$_p/cmdline") " in
            *"amneziawg-go awg0 "*|*"amnezia-wg awg0 "*|*"wireguard-go awg0 "*) echo "${_p#/proc/}" ;;
        esac
    done
}



kill_awg_processes() {
    _kap=$(awg0_daemon_pids)
    for _pid in $_kap; do kill -TERM "$_pid" 2>/dev/null; done
    for _pid in $_kap; do
        daemon_wait_gone "$_pid" 3 && continue
        kill -KILL "$_pid" 2>/dev/null
        daemon_wait_gone "$_pid" 5
    done
}







awg_installed() { [ -x "$ENODIA_BIN/amneziawg-go" ] && [ -x "$ENODIA_BIN/awg" ]; }





key_busy() {
    KEY_BUSY=""
    [ -f "$ENODIA_DIR/slots.sh" ] || return 1
    KEY_BUSY=$(sh "$ENODIA_DIR/slots.sh" key-holder "$1" main 2>/dev/null) && return 0
    KEY_BUSY=""
    return 1
}






replay_after_fw3() {
    [ "$FW3_WIPED" = 1 ] || return 0
    FW3_WIPED=0
    [ -f "$ENODIA_DIR/vpn-toggle.sh" ] || return 0
    printf "${BLUE}[правила]${NC} переигрываю цепочки после firewall reload...\n"
    sh "$ENODIA_DIR/vpn-toggle.sh" repair >/dev/null 2>&1 || true
}







replay_rules_only() {
    [ "$FW3_WIPED" = 1 ] || return 0
    FW3_WIPED=0


    [ -f "$ENODIA_DIR/vpn-toggle.sh" ] && sh "$ENODIA_DIR/vpn-toggle.sh" rules >/dev/null 2>&1
    return 0
}


bring_up() {
    ip link del awg0 2>/dev/null
    kill_awg_processes      # ждёт смерти демона сам — отдельной паузы после него не нужно

    started=0
    for s in /etc/init.d/awg /etc/init.d/amneziawg /etc/init.d/amnezia; do
        if [ -x "$s" ]; then
            "$s" start >/dev/null 2>&1
            started=1
            break
        fi
    done






    if ! ip link show awg0 >/dev/null 2>&1 && [ -f "$ENODIA_DIR/awg_setup.sh" ]; then
        _bu_gen=$(fw3_gen)
        ( cd "$ENODIA_DIR" && sh ./awg_setup.sh >"/tmp/enodia-switch-vpn-setup.log" 2>&1 )
        [ "$(fw3_gen)" = "$_bu_gen" ] || FW3_WIPED=1
    fi


    for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
        ip link show awg0 >/dev/null 2>&1 && return 0
        sleep 1
    done
    return 1
}

bring_down() {
    for s in /etc/init.d/awg /etc/init.d/amneziawg /etc/init.d/amnezia; do
        [ -x "$s" ] && "$s" stop >/dev/null 2>&1 && break
    done
    ip link set awg0 down 2>/dev/null
    ip link del awg0 2>/dev/null
    kill_awg_processes
}





off_stop() {
    carrier_barred || return 1
    printf "${YELLOW}[стоп]${NC} VPN выключили вручную — %s; несущую не поднимаю (включить: тумблер в панели).\n" "$1"
    bring_down
    replay_rules_only
    return 0
}








apply_routing() {
    [ -f "$ENODIA_DIR/mark-core.sh" ] && sh "$ENODIA_DIR/mark-core.sh" >/dev/null 2>&1
    if [ -f "$ENODIA_DIR/transport-awg.sh" ]; then
        sh "$ENODIA_DIR/transport-awg.sh" up >/dev/null 2>&1
    elif [ -f "$ENODIA_DIR/split-route.sh" ]; then
        sh "$ENODIA_DIR/split-route.sh" >/dev/null 2>&1
    fi







    killall -HUP dnsmasq 2>/dev/null



    echo NORMAL > "$WD_STATE" 2>/dev/null || true


    replay_after_fw3
}













safety_off() {
    printf "${YELLOW}[safety]${NC} убираю маршрут/марку/DNS-привязку к дохлому awg0\n"












    ip route del default dev awg0 table 1000 2>/dev/null
    ip rule del fwmark 0x1 table 1000 2>/dev/null




    iptables -t nat -D POSTROUTING -o awg0 -j MASQUERADE 2>/dev/null






    if doh_apply_dns direct; then


        _dnsmsg="DNS остаётся на шифрованном резолвере (он ходит мимо туннеля, напрямую)"
    elif [ -f /etc/dnsmasq.d/00-upstream.conf ]; then
        _dnsmsg="DNS временно на 1.1.1.1/8.8.8.8"


        cat > /etc/dnsmasq.d/00-upstream.conf <<'DNS_FALLBACK'
# Временный fallback, поставлен switch-vpn.sh safety_off.
# Будет заменён обратно на VPN-DNS при следующем срабатывании heal.sh
# (как только awg0 поднимется). При ребуте overlay /etc сбрасывается.
no-resolv
server=1.1.1.1
server=8.8.8.8
DNS_FALLBACK
    else
        _dnsmsg="DNS не трогали (нет 00-upstream.conf)"
    fi

    VPN_DNS=$(grep -E '^DNS[[:space:]]*=' "$ACTIVE_CONF" 2>/dev/null | head -1 | awk -F'= *' '{print $2}' | awk -F',' '{print $1}' | tr -d ' ')
    [ -n "$VPN_DNS" ] && ip route del "$VPN_DNS/32" dev awg0 2>/dev/null


    /etc/init.d/dnsmasq restart 2>/dev/null || killall -HUP dnsmasq 2>/dev/null




    ct_flush






    echo FAILOPEN > "$WD_STATE" 2>/dev/null || true




    replay_rules_only

    printf "${YELLOW}[safety]${NC} %s, трафик весь напрямую\n" "${_dnsmsg:-DNS не менялся}"
}











switch_to() {
    target="$1"



    if ! awg_installed; then



        printf "${RED}[FAIL]${NC} AmneziaWG не установлен (нет %s/amneziawg-go).\n" "$ENODIA_BIN"
        printf "Активировать awg-конфиг нечем — текущий транспорт НЕ тронут.\n"
        printf "Чтобы получить AmneziaWG: переустановите с ПК (enodia-setup.bat -> Установка),\n"
        printf "выбрав вариант с AmneziaWG (например «AmneziaWG + Hysteria2»).\n"
        exit 1
    fi
    src="$CONFIGS_DIR/${target}.conf"
    if [ ! -f "$src" ]; then
        printf "${RED}[FAIL]${NC} Не найден файл %s\n" "$src"
        printf "Доступные конфиги:\n"
        list_configs
        exit 1
    fi

    if key_busy "$target"; then
        printf "${RED}[FAIL]${NC} %s\n" "$KEY_BUSY"
        printf "Текущий сервер не тронут.\n"
        exit 1
    fi


    if carrier_barred; then
        install_config "$src" "$target" || exit 1
        printf "${GREEN}[OK]${NC} конфиг %s разложен; VPN выключен вручную — поднимется при включении.\n" "$target"
        return 0
    fi

    acquire_lock








    cur_t=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
    case "$cur_t" in
        ''|awg) ;;
        *) if [ -f "$ENODIA_DIR/transport.sh" ]; then
               printf "${BLUE}[транспорт]${NC} отпускаю текущую несущую (%s) — переходим на AmneziaWG\n" "$cur_t"
               sh "$ENODIA_DIR/transport.sh" down "$cur_t" >/dev/null 2>&1 || true
           fi ;;
    esac














    _sw_bak=0
    if [ -f "$ACTIVE_CONF" ]; then
        if cp "$ACTIVE_CONF" "$BACKUP_CONF" 2>/dev/null && [ -s "$BACKUP_CONF" ]; then _sw_bak=1; fi
        if [ -f "$ACTIVE_NAME" ]; then
            cp "$ACTIVE_NAME" "$BACKUP_NAME"
        else
            : > "$BACKUP_NAME"
        fi
        printf "${BLUE}[бэкап]${NC} текущий конфиг сохранён в %s\n" "$BACKUP_CONF"
    fi

    printf "${BLUE}[1/5]${NC} Останавливаю awg0...\n"
    bring_down

    printf "${BLUE}[2/5]${NC} Применяю конфиг ${YELLOW}%s${NC} (awg.conf + amnezia_for_awg.conf + awg0.conf)...\n" "$target"




    install_config "$src" "$target"; _sw_ic=$?



    if [ "$_sw_ic" = 2 ]; then
        printf "${RED}[FAIL]${NC} переключение на %s оборвалось на полпути: конфиги AmneziaWG несогласованы.\n" "$target"




        if [ -n "$cur_t" ] && [ "$cur_t" != awg ]; then



            if [ "$_sw_bak" = 1 ] && [ -s "$BACKUP_CONF" ]; then
                _sw_bakname=$(cat "$BACKUP_NAME" 2>/dev/null)
                if install_config "$BACKUP_CONF" "$_sw_bakname"; then
                    printf "${YELLOW}[возврат]${NC} конфиги AmneziaWG возвращены к снимку (%s).\n" "${_sw_bakname:-?}"
                else
                    printf "${RED}[FAIL]${NC} конфиги AmneziaWG остались несогласованными — их вернёт heal на загрузке.\n"
                fi
            else
                printf "${RED}[FAIL]${NC} снимка этого прогона нет — конфиги AmneziaWG остались несогласованными, их вернёт heal на загрузке.\n"
            fi
            alt_back
            return 1
        fi
        printf "${YELLOW}=> откатываюсь на снимок${NC}\n"
        rollback
        return $?
    fi
    if [ "$_sw_ic" != 0 ]; then
        printf "${RED}[FAIL]${NC} переключение на %s не состоялось: конфиг не разложен.\n" "$target"
        if alt_back; then return 1; fi
        _sw_prev=$(cat "$ACTIVE_NAME" 2>/dev/null)
        off_stop "прежний конфиг (${_sw_prev:-?}) на диске не тронут" && return 1




        if bring_up && wait_for_handshake; then
            apply_routing
            printf "${YELLOW}[возврат]${NC} awg0 снова на прежнем конфиге (%s).\n" "${_sw_prev:-?}"
        else
            printf "${RED}[FAIL]${NC} прежняя несущая тоже не поднялась — включаю прямой режим.\n"
            safety_off



            if [ "$NF_LANG" = en ]; then
                notify_event "switch-failopen" 3600 "BE7000: CRIT — VPN did not come up, direct mode" \
"The config $target could not be laid out (no space, a broken config or a write failure — the exact
reason is in the log), and the PREVIOUS carrier (${_sw_prev:-unknown}) did not come back up either.
Direct mode is on (safety_off): internet and DNS work bypassing the VPN, listed sites are unavailable.
Check the log and free space: cat /tmp/enodia-switch-vpn-setup.log; df -h"
            else
                notify_event "switch-failopen" 3600 "BE7000: КРИТ — VPN не поднялся, прямой режим" \
"Конфиг $target не удалось разложить (место на разделе, битый конфиг или сбой записи — точная
причина в логе), а ПРЕЖНЯЯ несущая (${_sw_prev:-неизвестно}) обратно не поднялась. Включён прямой
режим (safety_off): интернет и DNS работают мимо VPN, сайты из списка недоступны.
Проверьте лог и место: cat /tmp/enodia-switch-vpn-setup.log; df -h"
            fi
        fi
        return 1
    fi

    off_stop "сервер $target разложен, поднимется при включении VPN" && return 1
    printf "${BLUE}[3/5]${NC} Поднимаю awg0...\n"
    if ! bring_up; then
        off_stop "сервер $target разложен, поднимется при включении VPN" && return 1
        printf "${RED}[FAIL]${NC} awg0 не поднялся → автооткат\n"


        if alt_back; then return 1; fi
        rollback
        return $?
    fi

    printf "${BLUE}[4/5]${NC} Жду handshake (до %d сек)" "$HS_WAIT"
    if wait_for_handshake; then
        printf " ${GREEN}есть${NC}\n"
        off_stop "сервер $target разложен, поднимется при включении VPN" && return 1
        printf "${BLUE}[5/5]${NC} Применяю правила маршрутизации...\n"
        apply_routing
        printf "\n${GREEN}[OK]${NC} Переключение на ${YELLOW}%s${NC} успешно.\n\n" "$target"
        show_status


        echo "$target" > "$ENODIA_STATE/.failover-home"
        return 0
    else
        printf " ${RED}нет ответа${NC}\n"
        printf "${RED}[FAIL]${NC} %s не подключается (handshake не пришёл за %d сек)\n" "$target" "$HS_WAIT"
        printf "${YELLOW}=> автооткат на предыдущий конфиг${NC}\n\n"
        if alt_back; then return 1; fi
        rollback
        return $?
    fi
}




rollback() {
    if [ "${_sw_bak:-x}" = 0 ] || [ ! -s "$BACKUP_CONF" ]; then

        _rb_why="бэкапа $BACKUP_CONF нет"
        _rb_whye="there is no backup $BACKUP_CONF"
        if [ -s "$BACKUP_CONF" ]; then
            _rb_why="снимок $BACKUP_CONF остался от ПРОШЛОЙ смены сервера — поднимать по нему чужой конфиг мы не станем"
            _rb_whye="the snapshot $BACKUP_CONF is left over from an EARLIER switch — we will not bring up a config nobody chose now"
        fi
        printf "${RED}[FAIL]${NC} откатываться не на что: %s\n" "$_rb_why"
        off_stop "откат не нужен" && return 1
        safety_off
        if [ "$NF_LANG" = en ]; then
            notify_event "switch-failopen" 3600 "BE7000: CRIT — VPN did not come up, direct mode" \
"The new config did not come up, and there is nothing to roll back to: $_rb_whye.
Direct mode is on (safety_off): internet and DNS work bypassing the VPN,
listed sites are unavailable. awg0 is not active.
Log in via SSH: cat /tmp/enodia-switch-vpn-setup.log; then sh $ENODIA_BOOT/boot.sh heal.sh"
        else
            notify_event "switch-failopen" 3600 "BE7000: КРИТ — VPN не поднялся, прямой режим" \
"Новый конфиг не поднялся, а откатиться не на что: $_rb_why.
Включён прямой режим (safety_off): интернет и DNS работают мимо VPN,
сайты из списка недоступны. awg0 не активен.
Зайдите по SSH: cat /tmp/enodia-switch-vpn-setup.log; затем sh $ENODIA_BOOT/boot.sh heal.sh"
        fi
        return 1
    fi









    prev_name=""
    [ -s "$BACKUP_NAME" ] && prev_name=$(cat "$BACKUP_NAME")
    prev_label="$prev_name"
    [ -n "$prev_label" ] || prev_label="(неизвестно)"

    bring_down



    install_config "$BACKUP_CONF" "$prev_name"; _rb_ic=$?
    off_stop "конфиг $prev_label возвращён на диск" && return 1
    if [ "$_rb_ic" = 0 ] && bring_up && wait_for_handshake; then
        off_stop "конфиг $prev_label возвращён на диск" && return 1
        apply_routing
        printf "\n${GREEN}[ОТКАТ OK]${NC} вернулся на ${YELLOW}%s${NC}\n\n" "$prev_label"
        show_status
        if [ "$NF_LANG" = en ]; then
            notify_event "switch-rollback" 3600 "BE7000: VPN auto-rollback → $prev_label" \
"Switching to the new config failed (the tunnel did not come up or no
handshake arrived). The router automatically rolled back to the previous config: $prev_label —
VPN works on it again. Check the new config and try again."
        else
            notify_event "switch-rollback" 3600 "BE7000: автооткат VPN → $prev_label" \
"Переключение на новый конфиг не удалось (туннель не поднялся или не пришёл
handshake). Роутер автоматически откатился на предыдущий конфиг: $prev_label —
VPN снова работает на нём. Проверьте новый конфиг и попробуйте ещё раз."
        fi
        return 0
    else



        _rb_fail="даже старый конфиг ($prev_label) не поднялся"
        _rb_faile="the ROLLBACK to the old config ($prev_label) also did not bring the tunnel up"
        if [ "$_rb_ic" != 0 ]; then
            _rb_fail="снимок $BACKUP_CONF ($prev_label) не удалось разложить (место на разделе?)"
            _rb_faile="the snapshot $BACKUP_CONF could not be written back (no space on the partition?)"
        fi








        if [ "$_rb_ic" = 1 ] && [ -z "${_sw_bak:-}" ] && bring_up && wait_for_handshake; then
            apply_routing
            printf "\n${YELLOW}[ОТКАТ НЕ ВЫШЕЛ]${NC} %s — но конфиг на диске жив, несущая возвращена на него.\n" "$_rb_fail"
            show_status
            return 1
        fi
        off_stop "конфиг $prev_label возвращён на диск" && return 1
        printf "\n${RED}[ОТКАТ FAIL]${NC} %s\n" "$_rb_fail"
        printf "${RED}Включаю safety_off — чтобы роутер не упёрся в дохлый awg0.${NC}\n"
        safety_off
        if [ "$NF_LANG" = en ]; then
            notify_event "switch-failopen" 3600 "BE7000: CRIT — VPN did not come up, direct mode" \
"The config change failed, and $_rb_faile.
Direct mode is on (safety_off): internet and DNS work
bypassing the VPN, listed sites are unavailable. awg0 is not active.
Investigate via SSH: cat /tmp/enodia-switch-vpn-setup.log; cat /tmp/enodia-startup.log."
        else
            notify_event "switch-failopen" 3600 "BE7000: КРИТ — VPN не поднялся, прямой режим" \
"Смена конфига провалилась: $_rb_fail.
Включён прямой режим (safety_off): интернет и DNS работают
мимо VPN, сайты из списка недоступны. awg0 не активен.
Разбор по SSH: cat /tmp/enodia-switch-vpn-setup.log; cat /tmp/enodia-startup.log."
        fi
        printf "${YELLOW}Что делать:${NC}\n"
        printf "  1) Проверьте awg.conf: cat %s\n" "$ACTIVE_CONF"
        printf "  2) Проверьте интернет на роутере: ping 1.1.1.1\n"
        printf "  3) Запустите heal.sh вручную: %s/heal.sh\n" "$ENODIA_DIR"
        printf "  4) Если не помогло — reboot и SSH-вход, разбор по логам:\n"
        printf "     cat /tmp/enodia-startup.log; cat /tmp/enodia-switch-vpn-setup.log\n"
        return 1
    fi
}



















do_failover() {



    if ! awg_installed; then
        printf "${YELLOW}[failover]${NC} AmneziaWG не установлен — awg-перебор невозможен, пропускаю.\n"
        return 1
    fi

    if carrier_barred; then
        printf "${YELLOW}[failover]${NC} VPN выключен вручную — перебор серверов не начинаю.\n"
        return 1
    fi
    acquire_lock

    cur_name=""
    [ -f "$ACTIVE_NAME" ] && cur_name=$(cat "$ACTIVE_NAME")










    _fo_bak=0
    if [ -f "$ACTIVE_CONF" ]; then
        if cp "$ACTIVE_CONF" "$BACKUP_CONF" 2>/dev/null && [ -s "$BACKUP_CONF" ]; then _fo_bak=1; fi
        if [ -f "$ACTIVE_NAME" ]; then cp "$ACTIVE_NAME" "$BACKUP_NAME"; else : > "$BACKUP_NAME"; fi
    fi

    printf "${BLUE}[failover]${NC} активный сервер ${YELLOW}%s${NC} не отвечает — перебираю резервы\n" "${cur_name:-?}"


    safety_off


    tried=""
    _fo_dirty=0
    _fo_off=0
    for f in "$CONFIGS_DIR"/*.conf; do
        [ -f "$f" ] || continue


        carrier_barred && { _fo_off=1; break; }
        name=$(basename "$f" .conf)
        [ "$name" = "$cur_name" ] && continue   # текущий (дохлый) пропускаем


        if key_busy "$name"; then
            printf "${YELLOW}[failover]${NC} %s пропускаю: ключ занят выходом.\n" "$name"
            continue
        fi

        printf "${BLUE}[failover]${NC} пробую ${YELLOW}%s${NC}...\n" "$name"
        bring_down



        install_config "$f" "$name"; _fo_ic=$?
        if [ "$_fo_ic" != 0 ]; then



            printf "${YELLOW}[failover]${NC} %s пропускаю: конфиг не разложить.\n" "$name"



            [ "$_fo_ic" = 2 ] && _fo_dirty=1
            continue
        fi



        _fo_dirty=0
        if bring_up && wait_for_handshake; then
            carrier_barred && { _fo_off=1; break; }
            apply_routing            # он же вернёт туннельный DNS: плагин + слой DoH
            ip=$(probe_ext_ip "--interface awg0" 5)
            printf "\n${GREEN}[failover OK]${NC} встал на ${YELLOW}%s${NC} (внешний IP: %s)\n" "$name" "${ip:-?}"
            if [ "$NF_LANG" = en ]; then
                notify_event "failover-ok" 1800 "BE7000: VPN failover -> $name" \
"Server ${cur_name:-?} stopped responding. The router automatically switched
to a backup config: $name — VPN works again (handshake received).
External IP now: ${ip:-unknown}.

To return to ${cur_name:-the previous one} manually: panel :8088 -> the VPN card."
            else
                notify_event "failover-ok" 1800 "BE7000: VPN-failover -> $name" \
"Сервер ${cur_name:-?} перестал отвечать. Роутер автоматически переключился
на резервный конфиг: $name — VPN снова работает (handshake получен).
Внешний IP сейчас: ${ip:-неизвестен}.

Вернуться на ${cur_name:-прежний} вручную: панель :8088 -> карточка VPN."
            fi
            return 0
        fi
        tried="$tried $name"
    done



    carrier_barred && _fo_off=1
    if [ "$_fo_off" = 1 ]; then
        if [ "$_fo_bak" = 1 ] && [ -s "$BACKUP_CONF" ]; then
            install_config "$BACKUP_CONF" "$cur_name" || printf "${RED}[FAIL]${NC} исходный конфиг (%s) на диск не вернулся — его вернёт heal на загрузке.\n" "${cur_name:-?}"
        fi
        off_stop "перебор серверов прерван, на диске исходный конфиг (${cur_name:-?})"
        return 1
    fi



    printf "\n${RED}[failover FAIL]${NC} ни один резерв не поднялся (пробовал:%s)\n" "${tried:- нет}"
    bring_down






    _fo_up=-






    if [ "${_fo_dirty:-0}" = 1 ] && { [ "$_fo_bak" != 1 ] || [ ! -s "$BACKUP_CONF" ]; }; then _fo_up=d; fi
    if [ "$_fo_bak" = 1 ] && [ -s "$BACKUP_CONF" ]; then
        if install_config "$BACKUP_CONF" "$cur_name"; then

            if bring_up; then _fo_up=1; else _fo_up=0; fi
        else
            _fo_up=s
        fi
    fi


    replay_rules_only

    off_stop "перебор серверов кончился, на диске исходный конфиг (${cur_name:-?})" && return 1









    _fo_iface=0; ip link show awg0 >/dev/null 2>&1 && _fo_iface=1







    if [ "$_fo_iface" = 1 ]; then
        _fo_head="Сервер ${cur_name:-?} не отвечает"
        _fo_heade="Server ${cur_name:-?} is not responding"
        _fo_tail="awg0 поднят на ${cur_name:-исходном} — мониторинг продолжается: когда любой
сервер оживёт, VPN вернётся автоматически (watchdog повторит перебор резервов)."
        _fo_taile="awg0 is up on ${cur_name:-the original} — monitoring continues: when any
server comes back, VPN returns automatically (the watchdog will retry the backups)."
    elif [ "$_fo_up" = 1 ]; then
        _fo_head="Интерфейс awg0 поднялся и тут же исчез"
        _fo_heade="The awg0 interface came up and vanished right away"
        _fo_tail="awg0 создаётся, но не держится — чаще всего это нехватка ОЗУ (демона унёс OOM)
или занятый флеш; конфиг и ключи тут ни при чём. Панель: :8088 -> «О роутере» (клик по чипам в шапке)."
        _fo_taile="awg0 is created but does not stay up — usually that means low RAM (the daemon was
OOM-killed) or a full flash; the config and keys are not the cause.
Panel: :8088 -> About the router (click the header chips)."
    elif [ "$_fo_up" = d ]; then
        _fo_head="На диске остался конфиг, которого никто не выбирал"
        _fo_heade="A config nobody chose is left on the disk"
        _fo_tail="Перебор успел записать файлы одного из резервов лишь наполовину, а исходного конфига
на роутере не было вовсе — возвращать было не к чему. awg0 не поднят. Освободите место и выберите
сервер заново: панель :8088 -> карточка VPN."
        _fo_taile="The sweep half-wrote the files of one of the backups, and there was no original config
on the router at all — nothing to return to. awg0 is down. Free some space and pick a server
again: panel :8088 -> the VPN card."
    elif [ "$_fo_up" = s ]; then
        _fo_head="Исходный конфиг не удалось разложить"
        _fo_heade="The original config could not be written back"
        _fo_tail="awg0 сейчас не поднят: файлы конфигурации не записались — почти всегда это
кончившееся место на разделе. Панель: :8088 -> «О роутере» (место на флеше), затем повторите выбор сервера."
        _fo_taile="awg0 is down: the config files could not be written — almost always a full
partition. Panel: :8088 -> About the router (flash space), then pick the server again."
    elif [ "$_fo_up" = "-" ]; then



        _fo_head="Возвращаться было не на что: активного конфига нет"
        _fo_heade="There was no active config to return to"
        _fo_tail="awg0 сейчас не поднят: перебор кончился, а исходного сервера на роутере нет.
Выберите сервер в панели: :8088 -> карточка VPN."
        _fo_taile="awg0 is down: the sweep ended and there is no original server on the router.
Pick one in the panel: :8088 -> the VPN card."
    else
        _fo_head="Интерфейс awg0 не удалось создать"
        _fo_heade="The awg0 interface could not be created"
        _fo_tail="awg0 не поднимается вовсе — дело НЕ в том, что сервер молчит: проверьте конфиг
AmneziaWG (ключи, Endpoint), бинари в «Компонентах» и место на флеше."
        _fo_taile="awg0 does not come up at all — the problem is NOT the server being down: check the
AmneziaWG config (keys, Endpoint), the binaries in Components and free flash space."
    fi
    if [ "$NF_LANG" = en ]; then
        notify_event "failover-fail" 3600 "BE7000: VPN down, backups unavailable — direct mode" \
"$_fo_heade, and no backup config came up
(tried:${tried:- none}). The router is in DIRECT mode (safety_off): traffic and DNS
go around the VPN — if the ISP link is alive, the internet works; listed sites are
unavailable.
$_fo_taile"
    else
        notify_event "failover-fail" 3600 "BE7000: VPN упал, резервы недоступны — прямой режим" \
"$_fo_head, и ни один резервный конфиг не поднялся
(пробовал:${tried:- нет}). Роутер в ПРЯМОМ режиме (safety_off): трафик и DNS идут
мимо VPN — если связь с провайдером есть, интернет работает; сайты из списка
недоступны.
$_fo_tail"
    fi
    return 1
}




case "$1" in
    ""|list|ls)
        list_configs
        echo ""
        printf "Использование: %s <имя_конфига>\n" "$0"
        printf "Пример:        %s germany\n" "$0"
        printf "Откат:         %s rollback\n" "$0"
        printf "Текущий:       %s status\n" "$0"
        ;;
    status)
        show_status ip
        ;;
    rollback)




        if ! awg_installed; then
            printf "${YELLOW}[rollback]${NC} AmneziaWG не установлен — откатывать нечем, ничего не трогаю.\n"
            exit 1
        fi
        acquire_lock
        rollback
        ;;
    safety-off|safety_off)




        safety_off
        ;;
    failover)



        do_failover
        ;;
    stage)












        [ -n "$2" ] || { printf "${RED}[FAIL]${NC} укажите имя конфига\n"; exit 1; }
        _st_src="$CONFIGS_DIR/${2}.conf"
        [ -f "$_st_src" ] || { printf "${RED}[FAIL]${NC} Не найден файл %s\n" "$_st_src"; exit 1; }
        if key_busy "$2"; then printf "${RED}[FAIL]${NC} %s\n" "$KEY_BUSY"; exit 1; fi
        install_config "$_st_src" "$2" || exit 1
        printf "${GREEN}[OK]${NC} конфиг %s разложен (awg.conf + amnezia_for_awg.conf). Несущая НЕ тронута.\n" "$2"
        ;;
    *)
        switch_to "$1"
        ;;
esac
