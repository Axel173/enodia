#!/bin/sh














































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}

TOTP_SEC="$ENODIA_STATE/.totp"           # активный секрет: "hex b32 created"
TOTP_PEND="$ENODIA_STATE/.totp-pending"  # секрет в процессе привязки (до подтверждения кодом)
TOTP_REC="$ENODIA_STATE/.totp-recovery"  # sha256 кодов восстановления; использованный помечен '-'
TOTP_SESS="$ENODIA_STATE/.totp-sessions" # sha256(токен)⇥истекает⇥выдан⇥UA⇥адрес⇥уровень (см. «Сессии»)
TOTP_PASS="$ENODIA_STATE/.panel-pass"    # хэш пароля панели, ОДНА строка (см. «Первый фактор»)
TOTP_LEGACY_PASS="$ENODIA_DIR/web/uhttpd.conf"   # прежний файл Basic `/:admin:<хэш>` — только читаем и сносим
TOTP_UHTTPD=${UHTTPD:-/usr/sbin/uhttpd}  # ради `uhttpd -m`: бессолевые хэши старых установок и фолбэк без openssl
TOTP_COOKIE=enodia_session               # имя куки сессии; старую `panel2fa` гейт ещё читает (см. totp_cookie)
TOTP_LAST=/tmp/.enodia-totp-last         # анти-replay: последний ПРИНЯТЫЙ счётчик шагов
TOTP_FAIL=/tmp/.enodia-totp-fail         # "ключ неудач разблокировка отметка" на источник (RAM: ребут = чистый лист)
TOTP_CLOCK=/tmp/.enodia-clock-base   # момент загрузки по часам, какими они были ДО синхронизации (см. totp_sess_clock_fix)

TOTP_STEP=30                          # шаг TOTP, с (RFC 6238; менять нельзя — приложения ждут 30)
TOTP_WINDOW=1                         # ±1 шаг: покрывает расхождение часов телефона до 30 с





TOTP_SESS_TTL=31536000                # год — «запомнить меня» (он же срок по умолчанию: галочка

TOTP_SESS_TTL_SHORT=43200             # 12 часов — галочка снята
TOTP_SESS_MAX=32                      # потолок ЧИСЛА входов в файле (см. totp_sess_trim)
TOTP_REC_N=8                          # кодов восстановления
TOTP_MAX_FAILS=5                      # после стольких неудач подряд включается пауза
TOTP_LOCK_CAP=900                     # потолок паузы, с (15 мин): дальше удваивать бессмысленно
TOTP_LOCK_TTL=900                     # сколько помним источник ПОСЛЕ последней неудачи (см. totp_lock_put)
TOTP_LOCK_MAX=64                      # потолок строк в файле паузы: перебиратель со сменой адреса его не раздует

TOTP_B32A=ABCDEFGHIJKLMNOPQRSTUVWXYZ234567

totp_now() { date +%s 2>/dev/null; }




if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi




command -v uptime_s >/dev/null 2>&1 || uptime_s() { _cl_u=$(awk '{print int($1)}' /proc/uptime 2>/dev/null); case "$_cl_u" in ''|*[!0-9]*) _cl_u=999999999 ;; esac; echo "$_cl_u"; }
command -v clock_sane >/dev/null 2>&1 || clock_sane() { _csn=${1:-$(date +%s 2>/dev/null)}; case "$_csn" in ''|*[!0-9]*) return 1 ;; esac; [ "$_csn" -gt 1700000000 ] 2>/dev/null && [ "$_csn" -lt 4102444800 ] 2>/dev/null; }
totp_clock_ok() { clock_sane "$(totp_now)"; }

totp_enabled() { [ -s "$TOTP_SEC" ]; }





totp_sha256() { printf '%s' "$1" | openssl dgst -sha256 2>/dev/null | sed 's/.*= *//' | tr -cd 'a-f0-9'; echo; }




totp_hmac_hex() {
	_c=$2; _esc=""; _i=8
	while [ "$_i" -gt 0 ]; do
		_b=$((_c % 256)); _c=$((_c / 256))
		_esc="\\$(printf '%03o' "$_b")$_esc"
		_i=$((_i - 1))
	done
	printf "$_esc" | openssl dgst -sha1 -mac HMAC -macopt hexkey:"$1" -hex 2>/dev/null |
		sed 's/.*= *//' | tr -cd 'a-f0-9'
}



totp_code() {
	_h=$(totp_hmac_hex "$1" "$2")
	[ "${#_h}" -eq 40 ] || return 1
	_off=$(( 0x$(printf '%s' "$_h" | cut -c40) * 2 + 1 ))
	_p=$(printf '%s' "$_h" | cut -c"$_off"-$((_off + 7)))
	_v=$(( 0x$_p & 0x7fffffff ))
	printf '%06d' $((_v % 1000000))
}



totp_b32() {
	_h="$1"; _out=""; _i=1
	while [ "$_i" -le 40 ]; do
		_v=$(( 0x$(printf '%s' "$_h" | cut -c"$_i"-$((_i + 4))) ))
		for _s in 15 10 5 0; do
			_n=$(( (_v >> _s) & 31 ))
			_out="$_out$(printf '%s' "$TOTP_B32A" | cut -c$((_n + 1)))"
		done
		_i=$((_i + 5))
	done
	printf '%s' "$_out"
}

totp_secret_hex() { [ -s "$TOTP_SEC" ] || return 1; read _hx _rest < "$TOTP_SEC"; printf '%s' "$_hx"; }
totp_secret_b32() { [ -s "$TOTP_SEC" ] || return 1; read _hx _b3 _rest < "$TOTP_SEC"; printf '%s' "$_b3"; }

































PANEL_USER=admin
pw_user_ok() {                       # pw_user_ok <имя> → 0 если это логин панели (пусто = наш)
	[ -n "$1" ] || return 0



	_pu_u=$(printf '%s' "$1" | tr -cd 'A-Za-z0-9' | tr 'A-Z' 'a-z')
	_pu_o=$(printf '%s' "$PANEL_USER" | tr -cd 'A-Za-z0-9' | tr 'A-Z' 'a-z')
	[ -n "$_pu_o" ] && [ "$_pu_u" = "$_pu_o" ]
}
pw_salt() {                          # pw_salt <длина> — алфавит соли crypt `./0-9A-Za-z`
	_sl=$(dd if=/dev/urandom bs=12 count=1 2>/dev/null | openssl base64 2>/dev/null | tr -d '\n' | tr '+' '.' | cut -c1-"$1")
	case "$_sl" in *[!A-Za-z0-9./]*) _sl="" ;; esac
	[ "${#_sl}" -eq "$1" ] || _sl=""
	printf '%s' "$_sl"
}
pw_hash() {                          # pw_hash <пароль> → хэш (stdout); пусто = не вышло
	_ph_h=""; _ph_s=$(pw_salt 16)
	if [ -n "$_ph_s" ]; then
		_ph_h=$(printf '%s' "$1" | openssl passwd -6 -salt "$_ph_s" -stdin 2>/dev/null)
		case "$_ph_h" in '$6$'*'$'?*) : ;;
			*) _ph_h=$(printf '%s' "$1" | openssl passwd -1 -salt "$(printf '%s' "$_ph_s" | cut -c1-8)" -stdin 2>/dev/null) ;;
		esac
		case "$_ph_h" in '$6$'*'$'?*|'$1$'*'$'?*) : ;; *) _ph_h="" ;; esac
	fi
	[ -n "$_ph_h" ] || _ph_h=$("$TOTP_UHTTPD" -m "$1" 2>/dev/null)
	case "$_ph_h" in '$'?'$'*) printf '%s\n' "$_ph_h" ;; *) return 1 ;; esac
}
pw_stored() {                        # хэш из хранилища (пусто = пароля нет); легаси-файл — фолбэк
	if [ -s "$TOTP_PASS" ]; then head -1 "$TOTP_PASS" | tr -d '\r\n'
	elif [ -s "$TOTP_LEGACY_PASS" ]; then head -1 "$TOTP_LEGACY_PASS" | tr -d '\r\n' | cut -d: -f3-
	fi
}
pw_exists() { [ -n "$(pw_stored)" ]; }
pw_write() {                         # pw_write <хэш> — атомарно, 600
	[ -n "$1" ] || return 1
	mkdir -p "$ENODIA_STATE" 2>/dev/null
	( umask 077; printf '%s\n' "$1" > "$TOTP_PASS.tmp" ) && mv "$TOTP_PASS.tmp" "$TOTP_PASS" || return 1
	chmod 600 "$TOTP_PASS" 2>/dev/null
	return 0
}
pw_set() { pw_write "$(pw_hash "$1")"; }              # pw_set <пароль>






pw_migrate() {                       # легаси uhttpd.conf → .panel-pass (зовёт web-ui.sh start); 0 = есть куда входить
	if [ -s "$TOTP_PASS" ]; then rm -f "$TOTP_LEGACY_PASS" 2>/dev/null; return 0; fi
	[ -s "$TOTP_LEGACY_PASS" ] || return 1
	pw_write "$(pw_stored)" || return 1
	rm -f "$TOTP_LEGACY_PASS" 2>/dev/null
	return 0
}
pw_verify() {                        # pw_verify <пароль> → 0 принят · 1 нет · 2 пароль не задан
	_pv_h=$(pw_stored); [ -n "$_pv_h" ] || return 2
	_pv_c=""
	case "$_pv_h" in
		'$1$$'*) _pv_c=$("$TOTP_UHTTPD" -m "$1" 2>/dev/null) ;;
		'$6$'*)  _pv_s=${_pv_h#\$6\$}; _pv_s=${_pv_s%%\$*}; _pv_c=$(printf '%s' "$1" | openssl passwd -6 -salt "$_pv_s" -stdin 2>/dev/null) ;;
		'$5$'*)  _pv_s=${_pv_h#\$5\$}; _pv_s=${_pv_s%%\$*}; _pv_c=$(printf '%s' "$1" | openssl passwd -5 -salt "$_pv_s" -stdin 2>/dev/null) ;;
		'$1$'*)  _pv_s=${_pv_h#\$1\$}; _pv_s=${_pv_s%%\$*}; _pv_c=$(printf '%s' "$1" | openssl passwd -1 -salt "$_pv_s" -stdin 2>/dev/null) ;;
	esac
	[ -n "$_pv_c" ] && [ "$_pv_c" = "$_pv_h" ]
}




pw_needs_upgrade() { case "$(pw_stored)" in ''|'$6$'*) return 1 ;; esac; return 0; }




pw_upgrade() {                       # pw_upgrade <пароль> — 0 = переписали на $6$
	pw_needs_upgrade || return 1
	_pu_s=$(pw_salt 16); [ -n "$_pu_s" ] || return 1
	_pu_h=$(printf '%s' "$1" | openssl passwd -6 -salt "$_pu_s" -stdin 2>/dev/null)
	case "$_pu_h" in '$6$'*'$'?*) : ;; *) return 1 ;; esac
	pw_write "$_pu_h"
}
























totp_lock_key() {
	_lk=$(printf '%s' "${REMOTE_ADDR:-}" | tr -cd '0-9A-Fa-f.:' | cut -c1-45)
	[ -n "$_lk" ] || _lk=cli
	printf '%s' "$_lk"
}









totp_lock_read() {                    # totp_lock_read <ключ> → "неудач разблокировка отметка"
	_lr_f=0; _lr_u=0; _lr_t=0
	if [ -s "$TOTP_FAIL" ]; then
		while read -r _lr_k _lr_a _lr_b _lr_c _lr_rest; do
			[ "$_lr_k" = "$1" ] || continue
			_lr_f=$_lr_a; _lr_u=$_lr_b; _lr_t=$_lr_c; break
		done < "$TOTP_FAIL"
	fi
	case "$_lr_f" in ''|*[!0-9]*) _lr_f=0 ;; esac
	case "$_lr_u" in ''|*[!0-9]*) _lr_u=0 ;; esac
	case "$_lr_t" in ''|*[!0-9]*) _lr_t=0 ;; esac
	printf '%s %s %s' "$_lr_f" "$_lr_u" "$_lr_t"
}












totp_lock_put() {                     # totp_lock_put <ключ> <неудач> <разблокировка>
	_lp_n=$(totp_now); _lp_n=${_lp_n:-0}
	_lp_t="$TOTP_FAIL.$$"
	{
		[ "${2:-0}" -gt 0 ] 2>/dev/null && printf '%s %s %s %s\n' "$1" "$2" "$3" "$_lp_n"
		if [ -s "$TOTP_FAIL" ]; then








			awk -v k="$1" -v n="$_lp_n" -v ttl="$TOTP_LOCK_TTL" -v cap="$TOTP_LOCK_MAX" \
				'$1!=k && NF>=4 && ($3+0 > n || n - $4 < ttl) {
				   if ($3+0 > n) L[++nl]=$0; else if ($2+0 > 0) P[++np]=$0; else R[++nr]=$0 }
				 END { for(i=1;i<=nl;i++) if(++c < cap) print L[i];
				       for(i=1;i<=np;i++) if(++c < cap) print P[i];
				       for(i=1;i<=nr;i++) if(++c < cap) print R[i] }' "$TOTP_FAIL"
		fi
	} > "$_lp_t" 2>/dev/null && mv "$_lp_t" "$TOTP_FAIL" 2>/dev/null
	rm -f "$_lp_t" 2>/dev/null
	return 0
}

totp_lock_left() {
	_ll_u=$(totp_lock_read "$(totp_lock_key)" | cut -d' ' -f2)
	_n=$(totp_now)
	if [ "$_ll_u" -gt "${_n:-0}" ] 2>/dev/null; then echo $((_ll_u - _n)); else echo 0; fi
}

totp_lock_bump() {
	_lb_k=$(totp_lock_key)
	_lb_f=$(totp_lock_read "$_lb_k" | cut -d' ' -f1)
	_lb_f=$((_lb_f + 1)); _lb_u=0
	if [ "$_lb_f" -ge "$TOTP_MAX_FAILS" ]; then
		_d=60; _k=$((_lb_f - TOTP_MAX_FAILS))
		while [ "$_k" -gt 0 ] && [ "$_d" -lt "$TOTP_LOCK_CAP" ]; do _d=$((_d * 2)); _k=$((_k - 1)); done
		[ "$_d" -gt "$TOTP_LOCK_CAP" ] && _d=$TOTP_LOCK_CAP
		_lb_u=$(( $(totp_now) + _d ))
	fi
	totp_lock_put "$_lb_k" "$_lb_f" "$_lb_u"
}


totp_lock_reset() { totp_lock_put "$(totp_lock_key)" 0 0; return 0; }





totp_check_code() {
	[ "$(totp_lock_left)" -gt 0 ] 2>/dev/null && return 3
	_in=$(totp_rec_norm "$1")




	if [ "${#_in}" -eq 10 ]; then
		if totp_check_recovery "$_in"; then totp_lock_reset; return 0; fi
		totp_lock_bump; return 1
	fi
	_in=$(printf '%s' "$1" | tr -cd '0-9')
	[ "${#_in}" -eq 6 ] || { totp_lock_bump; return 1; }
	totp_clock_ok || return 2
	_hex=$(totp_secret_hex) || return 1
	_base=$(( $(totp_now) / TOTP_STEP ))
	_last=$(cat "$TOTP_LAST" 2>/dev/null)
	case "$_last" in ''|*[!0-9]*) _last=0 ;; esac
	_d=$((0 - TOTP_WINDOW))
	while [ "$_d" -le "$TOTP_WINDOW" ]; do
		_c=$((_base + _d))
		if [ "$_c" -gt "$_last" ] && [ "$(totp_code "$_hex" "$_c")" = "$_in" ]; then
			echo "$_c" > "$TOTP_LAST" 2>/dev/null
			totp_lock_reset
			return 0
		fi
		_d=$((_d + 1))
	done
	totp_lock_bump
	return 1
}


totp_check_pending() {
	[ -s "$TOTP_PEND" ] || return 1
	totp_clock_ok || return 2
	read _hex _rest < "$TOTP_PEND"
	_in=$(printf '%s' "$1" | tr -cd '0-9')
	[ "${#_in}" -eq 6 ] || return 1
	_base=$(( $(totp_now) / TOTP_STEP ))
	_d=$((0 - TOTP_WINDOW))
	while [ "$_d" -le "$TOTP_WINDOW" ]; do
		[ "$(totp_code "$_hex" "$((_base + _d))")" = "$_in" ] && return 0
		_d=$((_d + 1))
	done
	return 1
}









totp_rec_norm() { printf '%s' "$1" | tr 'A-Z' 'a-z' | tr -cd 'a-z0-9'; }

totp_check_recovery() {
	[ -s "$TOTP_REC" ] || return 1
	_n=$(totp_rec_norm "$1")
	[ "${#_n}" -eq 10 ] || return 1
	_h=$(totp_sha256 "$_n")
	grep -q "^$_h\$" "$TOTP_REC" 2>/dev/null || return 1

	sed "s/^$_h\$/-$_h/" "$TOTP_REC" > "$TOTP_REC.tmp" 2>/dev/null &&
		mv "$TOTP_REC.tmp" "$TOTP_REC" 2>/dev/null
	chmod 600 "$TOTP_REC" 2>/dev/null
	return 0
}

totp_rec_left() {
	_c=$(grep -c '^[0-9a-f]' "$TOTP_REC" 2>/dev/null)
	case "$_c" in ''|*[!0-9]*) _c=0 ;; esac
	echo "$_c"
}







totp_rec_gen() {
	_tmp="$TOTP_REC.new"
	: > "$_tmp" 2>/dev/null || return 1
	chmod 600 "$_tmp" 2>/dev/null
	_i=0; _out=""
	while [ "$_i" -lt "$TOTP_REC_N" ]; do
		_c=$(openssl rand -hex 5 2>/dev/null | tr -cd 'a-f0-9' | cut -c1-10)
		[ "${#_c}" -eq 10 ] || { rm -f "$_tmp" 2>/dev/null; return 1; }
		totp_sha256 "$_c" >> "$_tmp" || { rm -f "$_tmp" 2>/dev/null; return 1; }
		_out="$_out $(printf '%s' "$_c" | cut -c1-5)-$(printf '%s' "$_c" | cut -c6-10)"
		_i=$((_i + 1))
	done


	_n=$(grep -c '^[0-9a-f]' "$_tmp" 2>/dev/null); case "$_n" in ''|*[!0-9]*) _n=0 ;; esac
	[ "$_n" -eq "$TOTP_REC_N" ] || { rm -f "$_tmp" 2>/dev/null; return 1; }
	mv "$_tmp" "$TOTP_REC" 2>/dev/null || { rm -f "$_tmp" 2>/dev/null; return 1; }
	chmod 600 "$TOTP_REC" 2>/dev/null
	printf '%s\n' "${_out# }"
}






















totp_sess_ua()   { printf '%s' "$1" | tr -cd 'A-Za-z0-9 ().,;:/_-' | cut -c1-120; }
totp_sess_addr() { printf '%s' "$1" | tr -cd '0-9A-Fa-f.:' | cut -c1-45; }

totp_sess_trim() {                    # оставить последние TOTP_SESS_MAX строк (свежие — внизу)
	[ -s "$TOTP_SESS" ] || return 0
	_tt=$(grep -c . "$TOTP_SESS" 2>/dev/null || true); case "$_tt" in ''|*[!0-9]*) _tt=0 ;; esac
	[ "$_tt" -gt "$TOTP_SESS_MAX" ] 2>/dev/null || return 0
	( umask 077; tail -n "$TOTP_SESS_MAX" "$TOTP_SESS" > "$TOTP_SESS.$$" 2>/dev/null ) &&
		mv "$TOTP_SESS.$$" "$TOTP_SESS" 2>/dev/null || { rm -f "$TOTP_SESS.$$" 2>/dev/null; return 1; }
	chmod 600 "$TOTP_SESS" 2>/dev/null
	return 0
}
totp_sess_gc() {
	[ -s "$TOTP_SESS" ] || return 0




	command -v totp_sess_clock_fix >/dev/null 2>&1 && totp_sess_clock_fix
	_n=$(totp_now)



	awk -F'\t' -v n="${_n:-0}" '$2+0 <= n+0 {f=1} END{exit f?0:1}' "$TOTP_SESS" 2>/dev/null || return 0
	( umask 077; awk -F'\t' -v n="${_n:-0}" '$2+0 > n' "$TOTP_SESS" > "$TOTP_SESS.$$" 2>/dev/null ) &&
		mv "$TOTP_SESS.$$" "$TOTP_SESS" 2>/dev/null || { rm -f "$TOTP_SESS.$$" 2>/dev/null; return 1; }
	chmod 600 "$TOTP_SESS" 2>/dev/null
	return 0
}




















clock_mark_put() {                    # clock_mark_put <база>; 1 = не записали
	( umask 077; printf '%s\n' "$1" > "$TOTP_CLOCK.$$" ) 2>/dev/null &&
		mv "$TOTP_CLOCK.$$" "$TOTP_CLOCK" 2>/dev/null || { rm -f "$TOTP_CLOCK.$$" 2>/dev/null; return 1; }
	return 0
}
totp_clock_base() {                   # «момент загрузки» по ТЕКУЩИМ часам + аптайм; 1 = аптайм неизвестен
	_cb_n=$(totp_now); case "$_cb_n" in ''|*[!0-9]*) _cb_n=0 ;; esac
	_cb_u=$(uptime_s)   # владелец ответа — clock-lib.sh (сорсится в шапке; следит C83)





	case "$_cb_u" in ''|*[!0-9]*|999999999) return 1 ;; esac
	[ "$_cb_u" -gt 0 ] 2>/dev/null || return 1
	printf '%s %s' "$((_cb_n - _cb_u))" "$_cb_u"
}
totp_sess_clock_fix() {               # зовёт web-ui.sh start (cron раз в 5 минут; он же поднимает панель)

	_cf_bu=$(totp_clock_base) || return 0
	_cf_base=${_cf_bu% *}; _cf_up=${_cf_bu#* }
	case "$_cf_up" in ''|*[!0-9]*) return 0 ;; esac
	[ "${_cf_base:-0}" -gt 0 ] 2>/dev/null || return 0
	_cf_old=$(cat "$TOTP_CLOCK" 2>/dev/null)
	case "$_cf_old" in ''|*[!0-9]*) clock_mark_put "$_cf_base"; return 0 ;; esac
	_cf_d=$((_cf_base - _cf_old))




	if [ "$_cf_d" -le 60 ] 2>/dev/null; then
		[ "$_cf_d" -lt 0 ] 2>/dev/null && clock_mark_put "$_cf_base"
		return 0
	fi
	if [ -s "$TOTP_SESS" ]; then


		( umask 077; awk -F'\t' -v OFS='\t' -v lo="$_cf_old" -v hi="$((_cf_old + _cf_up))" -v d="$_cf_d" \
			'$3+0 >= lo && $3+0 <= hi && $2+0 > 0 { $2 = $2 + d; $3 = $3 + d } { print }' "$TOTP_SESS" > "$TOTP_SESS.$$" 2>/dev/null ) &&
			mv "$TOTP_SESS.$$" "$TOTP_SESS" 2>/dev/null || { rm -f "$TOTP_SESS.$$" 2>/dev/null; return 1; }
		chmod 600 "$TOTP_SESS" 2>/dev/null
	fi


	clock_mark_put "$_cf_base"
	return 0
}



totp_sess_ttl() {                     # totp_sess_ttl [1|0] → срок в секундах (stdout)
	case "${1:-}" in 0) printf '%s' "$TOTP_SESS_TTL_SHORT" ;; *) printf '%s' "$TOTP_SESS_TTL" ;; esac
}
totp_sess_new() {                     # totp_sess_new [UA] [адрес] [уровень: 1 пароль · 2 пароль+код] [срок, с]
	_t=$(openssl rand -hex 32 2>/dev/null | tr -cd 'a-f0-9')
	[ "${#_t}" -eq 64 ] || return 1
	_sn_l=${3:-1}; case "$_sn_l" in 1|2) : ;; *) _sn_l=1 ;; esac
	_sn_ttl=${4:-}; case "$_sn_ttl" in ''|*[!0-9]*) _sn_ttl=$TOTP_SESS_TTL ;; esac
	_sn_u=$(totp_sess_ua "${1:-}"); [ -n "$_sn_u" ] || _sn_u=-
	_sn_a=$(totp_sess_addr "${2:-}"); [ -n "$_sn_a" ] || _sn_a=-
	totp_sess_gc
	printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$(totp_sha256 "$_t")" "$(( $(totp_now) + _sn_ttl ))" \
		"$(totp_now)" "$_sn_u" "$_sn_a" "$_sn_l" >> "$TOTP_SESS" || return 1
	chmod 600 "$TOTP_SESS" 2>/dev/null



	totp_sess_check "$_t" || return 1




	totp_sess_trim
	printf '%s\n' "$_t"
}



totp_sess_level() {
	_lv_t=$(printf '%s' "$1" | tr -cd 'a-f0-9')
	[ "${#_lv_t}" -eq 64 ] || return 1
	[ -s "$TOTP_SESS" ] || return 1
	awk -F'\t' -v h="$(totp_sha256 "$_lv_t")" -v n="$(totp_now)" \
		'$1==h && $2+0 > n+0 { l=$6+0; if(l<1) l=2; print l; ok=1; exit } END{ if(!ok) exit 1 }' "$TOTP_SESS"
}



totp_sess_upgrade() {                 # totp_sess_upgrade <токен>
	_up_t=$(printf '%s' "$1" | tr -cd 'a-f0-9')
	totp_sess_check "$_up_t" || return 1
	( umask 077; awk -F'\t' -v OFS='\t' -v h="$(totp_sha256 "$_up_t")" '$1==h { $6=2 } { print }' "$TOTP_SESS" > "$TOTP_SESS.$$" 2>/dev/null ) &&
		mv "$TOTP_SESS.$$" "$TOTP_SESS" 2>/dev/null || { rm -f "$TOTP_SESS.$$" 2>/dev/null; return 1; }
	chmod 600 "$TOTP_SESS" 2>/dev/null
	return 0
}


totp_sess_check() {
	_tg_t=$(printf '%s' "$1" | tr -cd 'a-f0-9')
	[ "${#_tg_t}" -eq 64 ] || return 1
	[ -s "$TOTP_SESS" ] || return 1
	awk -F'\t' -v h="$(totp_sha256 "$_tg_t")" -v n="$(totp_now)" \
		'$1==h && $2+0 > n+0 {ok=1} END{if(ok) exit 0; exit 1}' "$TOTP_SESS"
}

totp_sess_count() {
	totp_sess_gc
	_c=$(grep -c . "$TOTP_SESS" 2>/dev/null)
	case "$_c" in ''|*[!0-9]*) _c=0 ;; esac
	echo "$_c"
}

totp_sess_clear() { : > "$TOTP_SESS" 2>/dev/null; chmod 600 "$TOTP_SESS" 2>/dev/null; return 0; }






totp_sess_list() {                    # totp_sess_list [токен текущей сессии]
	totp_sess_gc
	_sl_h=""
	_sl_t=$(printf '%s' "${1:-}" | tr -cd 'a-f0-9')



	if [ "${#_sl_t}" -eq 64 ]; then _sl_h=$(totp_sha256 "$_sl_t"); fi
	printf '['
	if [ -s "$TOTP_SESS" ]; then
		_sl_first=1


		while IFS="$(printf '\t')" read -r _sl_id _sl_exp _sl_iss _sl_ua _sl_ad _sl_lv; do
			[ -n "$_sl_id" ] || continue
			case "$_sl_exp" in ''|*[!0-9]*) _sl_exp=0 ;; esac
			case "$_sl_iss" in ''|*[!0-9]*) _sl_iss=0 ;; esac
			case "$_sl_lv" in 1|2) : ;; *) _sl_lv=2 ;; esac
			[ "$_sl_ua" = - ] && _sl_ua=""
			[ "$_sl_ad" = - ] && _sl_ad=""
			_sl_cur=false
			if [ -n "$_sl_h" ] && [ "$_sl_id" = "$_sl_h" ]; then _sl_cur=true; fi
			[ "$_sl_first" = 1 ] || printf ','
			_sl_first=0
			printf '{"id":"%s","cur":%s,"issued":%s,"expires":%s,"ua":"%s","addr":"%s","level":%s}' \
				"$_sl_id" "$_sl_cur" "$_sl_iss" "$_sl_exp" "$_sl_ua" "$_sl_ad" "$_sl_lv"
		done < "$TOTP_SESS"
	fi
	printf ']'
}




totp_sess_keep_only() {               # totp_sess_keep_only <токен>
	_ko_t=$(printf '%s' "${1:-}" | tr -cd 'a-f0-9')
	totp_sess_check "$_ko_t" || return 1
	( umask 077; awk -F'\t' -v h="$(totp_sha256 "$_ko_t")" '$1==h' "$TOTP_SESS" > "$TOTP_SESS.$$" 2>/dev/null ) &&
		mv "$TOTP_SESS.$$" "$TOTP_SESS" 2>/dev/null || { rm -f "$TOTP_SESS.$$" 2>/dev/null; return 1; }
	chmod 600 "$TOTP_SESS" 2>/dev/null
	return 0
}



totp_sess_revoke() {                  # totp_sess_revoke <id>
	_rv_i=$(printf '%s' "${1:-}" | tr -cd 'a-f0-9')
	[ "${#_rv_i}" -eq 64 ] || return 1
	[ -s "$TOTP_SESS" ] || return 1


	awk -F'\t' -v h="$_rv_i" '$1==h{f=1} END{exit f?0:1}' "$TOTP_SESS" 2>/dev/null || return 1
	( umask 077; awk -F'\t' -v h="$_rv_i" '$1!=h' "$TOTP_SESS" > "$TOTP_SESS.$$" 2>/dev/null ) &&
		mv "$TOTP_SESS.$$" "$TOTP_SESS" 2>/dev/null || { rm -f "$TOTP_SESS.$$" 2>/dev/null; return 1; }
	chmod 600 "$TOTP_SESS" 2>/dev/null
	return 0
}


totp_sess_id() { totp_sha256 "$(printf '%s' "${1:-}" | tr -cd 'a-f0-9')"; }










totp_cookie() {
	_tc=$(printf '%s' "${HTTP_COOKIE:-}" | tr ';' '\n' | sed 's/^ *//')
	_tc_v=$(printf '%s\n' "$_tc" | grep "^$TOTP_COOKIE=" | head -1 | cut -d= -f2 | tr -cd 'a-f0-9')
	[ -n "$_tc_v" ] || _tc_v=$(printf '%s\n' "$_tc" | grep '^panel2fa=' | head -1 | cut -d= -f2 | tr -cd 'a-f0-9')
	printf '%s' "$_tc_v"
}

totp_cookie_hdr()  {                  # totp_cookie_hdr <токен> [срок, с — ТОТ ЖЕ, что у строки сессии]
	_ch=${2:-}; case "$_ch" in ''|*[!0-9]*) _ch=$TOTP_SESS_TTL ;; esac
	printf '%s=%s; Path=/; Max-Age=%s; HttpOnly; SameSite=Strict' "$TOTP_COOKIE" "$1" "$_ch"
}
totp_cookie_gone() { printf '%s=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict' "$TOTP_COOKIE"; }

totp_has_session() { _hs_c=$(totp_cookie); [ -n "$_hs_c" ] && totp_sess_level "$_hs_c" >/dev/null; }







totp_layout_moving() {
	command -v store_mode_alive >/dev/null 2>&1 || { if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi; }
	command -v store_mode_alive >/dev/null 2>&1 && store_mode_alive
}

totp_gate() {
	_tg_need=login
	_tg_c=$(totp_cookie)
	[ -n "$_tg_c" ] || return 1
	_tg_l=$(totp_sess_level "$_tg_c") || return 1
	_tg_need=2fa
	totp_enabled || return 0
	[ "$_tg_l" -ge 2 ]
}












totp_gate_deny() {
	totp_gate && return 0




	if [ "$_tg_need" = login ] && totp_layout_moving; then
		echo "Status: 503 Service Unavailable"
		echo "Content-Type: application/json; charset=utf-8"
		echo "Cache-Control: no-store"
		echo "Retry-After: 5"
		echo ""
		printf '{"ok":false,"moving":true,"msg":"панель переезжает — повторите через несколько секунд"}\n'
		exit 0
	fi
	echo "Status: 403 Forbidden"
	echo "Content-Type: application/json; charset=utf-8"
	echo "Cache-Control: no-store"
	echo ""
	if [ "$_tg_need" = login ]; then printf '{"ok":false,"need_login":true,"msg":"нужен вход в панель"}\n'
	else printf '{"ok":false,"need2fa":true,"msg":"нужен код подтверждения"}\n'; fi
	exit 0
}



totp_status_json() {
	_on=false; totp_enabled && _on=true
	_pd=false; [ -s "$TOTP_PEND" ] && _pd=true
	_ck=false; totp_clock_ok && _ck=true
	printf '{"engine":true,"on":%s,"pending":%s,"clock":%s,"recovery":%s,"rec_n":%s,"sessions":%s,"lock":%s}\n' \
		"$_on" "$_pd" "$_ck" "$(totp_rec_left)" "$TOTP_REC_N" "$(totp_sess_count)" "$(totp_lock_left)"
}



totp_uri() {
	_b3="$1"
	_lbl=$(command -v router_model >/dev/null 2>&1 && router_model)
	[ -n "$_lbl" ] || _lbl="Xiaomi"
	_lbl=$(printf '%s' "$_lbl" | tr ' ' '-' | tr -cd 'A-Za-z0-9._-')
	printf 'otpauth://totp/%s:admin?secret=%s&issuer=%s&algorithm=SHA1&digits=6&period=30\n' \
		"$_lbl" "$_b3" "$_lbl"
}


cmd_enroll() {
	_hex=$(openssl rand -hex 20 2>/dev/null | tr -cd 'a-f0-9')
	[ "${#_hex}" -eq 40 ] || { echo "не удалось сгенерировать секрет (нет openssl?)"; return 1; }
	_b3=$(totp_b32 "$_hex")
	printf '%s %s %s\n' "$_hex" "$_b3" "$(totp_now)" > "$TOTP_PEND" || return 1
	chmod 600 "$TOTP_PEND" 2>/dev/null
	echo "$_b3"
	totp_uri "$_b3"
}



cmd_enable() {
	[ -s "$TOTP_PEND" ] || { echo "привязка не начата"; return 1; }
	totp_check_pending "$1"; _r=$?
	[ "$_r" = 2 ] && { echo "часы роутера не синхронизированы — подождите минуту и повторите"; return 2; }
	[ "$_r" = 0 ] || { echo "код не подошёл"; return 1; }
	mv "$TOTP_PEND" "$TOTP_SEC" || return 1
	chmod 600 "$TOTP_SEC" 2>/dev/null
	rm -f "$TOTP_LAST" 2>/dev/null
	totp_lock_reset
	cmd_recovery_new_raw
}

cmd_recovery_new_raw() {
	_codes=$(totp_rec_gen) || { echo "не удалось сгенерировать коды восстановления"; return 1; }
	printf '%s\n' "$_codes"
}



totp_code_or_say() {   # $1 — код; 0 — подошёл, иначе печатает причину и возвращает 1|2|3
	totp_check_code "$1"; _tcs=$?
	case "$_tcs" in
		0) return 0 ;;
		3) echo "слишком много неудачных попыток — подождите"; return 3 ;;
		2) echo "часы роутера не синхронизированы"; return 2 ;;
		*) echo "код не подошёл"; return 1 ;;
	esac
}

cmd_disable() {
	case "$1" in
		--force) : ;;                       # аварийный путь с роутера (SSH), см. шапку
		*) totp_enabled || { echo "двухфакторный вход и так выключен"; return 0; }
		   totp_code_or_say "$1" || return $? ;;
	esac
	rm -f "$TOTP_SEC" "$TOTP_PEND" "$TOTP_REC" "$TOTP_LAST" 2>/dev/null



	totp_lock_reset
	echo "двухфакторный вход выключен"
}

case "${TOTP_LIB:-}" in
	"") ;;
	*) return 0 ;;      # sourced из CGI (гейт) — ниже только CLI-диспетчер
esac


if [ -f "$ENODIA_DIR/router-lib.sh" ]; then . "$ENODIA_DIR/router-lib.sh"; fi

case "$1" in
	status)        totp_status_json ;;
	enroll)        cmd_enroll ;;
	enable)        cmd_enable "$2" ;;
	disable|off)   cmd_disable "$2" ;;
	verify)        totp_check_code "$2"; exit $? ;;
	session-new)   totp_sess_new "$2" "$3" "$4" "${5:-}" ;;
	session-level) totp_sess_level "$2"; exit $? ;;

	pass-set)      _p=$(head -1); pw_set "$_p" && echo "пароль панели записан" ;;
	pass-verify)   _p=$(head -1); pw_verify "$_p"; exit $? ;;
	pass-migrate)  pw_migrate && echo "пароль перенесён в .panel-pass" ;;
	session-check) totp_sess_check "$2"; exit $? ;;
	session-list)  totp_sess_list "$2"; echo ;;
	logout-all)    totp_sess_clear; echo "все устройства разлогинены" ;;
	logout-others) totp_sess_keep_only "$2" || { echo "текущая сессия не найдена — выход не сделан"; exit 1; }
	               echo "остальные устройства разлогинены" ;;
	session-del)   totp_sess_revoke "$2" || { echo "нет такой сессии"; exit 1; }
	               echo "устройство отвязано" ;;
	recovery-new)  totp_enabled || { echo "двухфакторный вход выключен"; exit 1; }
	               totp_code_or_say "$2" || exit $?
	               cmd_recovery_new_raw ;;

	enroll-cancel) [ -f "$TOTP_PEND" ] || { echo "привязка не начата"; exit 1; }
	               rm -f "$TOTP_PEND" && echo "привязка отменена" ;;
	uri)           _b=$(totp_secret_b32) && totp_uri "$_b" ;;
	gate)          totp_gate; exit $? ;;
	*) echo "usage: $0 {status|enroll|enable <код>|disable <код>|disable --force|verify <код>|"
	   echo "              recovery-new <код>|enroll-cancel|session-new [UA] [адрес]|session-check <токен>|"
	   echo "              session-list [токен]|session-del <id>|logout-all|logout-others <токен>|uri|gate|"


	   echo "              pass-set|pass-verify|pass-migrate — пароль стдином (штатно: sh ${ENODIA_BOOT:-/data/usr/app/enodia-boot}/boot.sh web-ui.sh setpass — пароль команда спросит сама)}"
	   exit 1 ;;
esac
