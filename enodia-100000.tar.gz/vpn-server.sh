#!/bin/sh























































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}




if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi

command -v ipt_top >/dev/null 2>&1 || ipt_top() { _itc=$1; shift; iptables -C "$_itc" "$@" 2>/dev/null || iptables -I "$_itc" 1 "$@"; }
if ! command -v ct_flush_src >/dev/null 2>&1; then
    ct_flush_src()  { [ -n "$1" ] && conntrack -D --src "$1" >/dev/null 2>&1; return 0; }
    ct_flush_dst()  { [ -n "$1" ] && conntrack -D -d "$1" >/dev/null 2>&1; return 0; }
fi
SRV="$ENODIA_STATE/server"
IFACE=awgs0
PEERS="$SRV/peers.tsv"         # id<TAB>имя_b64<TAB>priv<TAB>pub<TAB>psk<TAB>mode<TAB>lan<TAB>on
ON_FLAG="$SRV/.on"
APPLY_BYPASS="$ENODIA_DIR/apply-bypass.sh"
IFCONF=/tmp/enodia-$IFACE.conf # конфиг для setconf — в RAM: несёт приватные ключи всех пиров
WAN_HOOK=input_wan_rule        # штатный пустой хук fw3 (тот же, что у панели)
WAN_CHAIN=VPNSRV_WAN
IN_CHAIN=VPNSRV_IN
FWD_CHAIN=VPNSRV_FWD
PEER_MAX=8                     # пиры = последний октет 2..9
MTU_PEER=1280                  # клиенту консервативно: его пакеты могут ехать ВТОРЫМ хопом в awg0
MTU_IFACE=1420
KEEPALIVE=25
RATE_NEW=30                    # новых хендшейков в минуту с одного адреса






LAN_PORTS="80 8088 8443"






umask 077





if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi
command -v probe_ext_ip >/dev/null 2>&1 || probe_ext_ip() { curl -s $1 --max-time "${2:-7}" https://api.ipify.org 2>/dev/null; }
command -v is_private_ip >/dev/null 2>&1 || is_private_ip() {
    case "$1" in
        10.*|127.*|169.254.*|192.168.*) return 0 ;;
        172.1[6-9].*|172.2[0-9].*|172.3[0-1].*) return 0 ;;
        100.6[4-9].*|100.[7-9][0-9].*|100.1[0-1][0-9].*|100.12[0-7].*) return 0 ;;
    esac
    return 1
}




if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v age_since >/dev/null 2>&1 || age_since() {
    case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
    [ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}

log() { echo "[vpn-server] $*"; }






peer_conntrack() {   # $1=id
    _cip=$(peer_ip "$1"); [ -n "$_cip" ] || return 0
    ct_flush_src "$_cip"
    ct_flush_dst "$_cip"
    return 0
}

awg_bin() { if [ -x "$ENODIA_BIN/awg" ]; then echo "$ENODIA_BIN/awg"; else command -v awg; fi; }




command -v wan_iface >/dev/null 2>&1 || wan_iface() { ip route show default 2>/dev/null | awk '/^default/{d=""; for(i=1;i<=NF;i++) if($i=="dev") d=$(i+1); if(d!="" && d !~ /^(awg|xtun)/){print d; exit}}'; }
wan_addr()  { ip -4 addr show dev "$(wan_iface)" 2>/dev/null | sed -n 's/.*inet \([0-9.]*\)\/.*/\1/p' | head -1; }

subnet()    { cat "$SRV/subnet" 2>/dev/null || echo 10.77.0; }      # /24, без последнего октета
router_ip() { echo "$(subnet).1"; }
peer_ip()   { echo "$(subnet).$1"; }
srv_port()  { cat "$SRV/port" 2>/dev/null | tr -cd '0-9'; }


endpoint_host() { cat "$SRV/endpoint" 2>/dev/null | tr -d ' \t\r\n' || true; }


EXT_CACHE=/tmp/.enodia-vpnsrv-ext # строка 1 = внешний IPv4 (может быть пустой), строка 2 = отметка
EXT_TTL=600                       # удачную пробу держим 10 мин: конфиг и QR открывают подряд
EXT_TTL_BAD=120                   # неудачную — 2 мин: WAN мог подняться только что




wan_ext_addr() {
    _xc=$(sed -n 1p "$EXT_CACHE" 2>/dev/null | tr -d ' \t\r\n')
    _xs=$(sed -n 2p "$EXT_CACHE" 2>/dev/null | tr -d ' \t\r\n')
    case "$_xs" in ''|*[!0-9]*) _xs=0 ;; esac
    if [ "$_xs" -gt 0 ]; then
        _xt="$EXT_TTL_BAD"; [ -n "$_xc" ] && _xt="$EXT_TTL"


        [ "$(age_since "$_xs")" -lt "$_xt" ] && { printf '%s' "$_xc"; return 0; }
    fi
    _xi=$(wan_iface); [ -n "$_xi" ] || return 0
    _xe=$(probe_ext_ip "--interface $_xi" 5)





    printf '%s' "$_xe" | grep -qE '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || _xe=""
    printf '%s\n%s\n' "$_xe" "$(date +%s)" > "$EXT_CACHE"
    printf '%s' "$_xe"
}












endpoint_auto() {
    _ea=$(wan_addr)
    if [ -n "$_ea" ] && ! is_private_ip "$_ea"; then printf '%s' "$_ea"; return 0; fi
    _ee=$(wan_ext_addr)
    if [ -n "$_ee" ]; then printf '%s' "$_ee"; return 0; fi
    printf '%s' "$_ea"
}



rnd() {   # $1=min $2=max
    _h=$(head -c 16 /dev/urandom 2>/dev/null | md5sum | cut -c1-7)
    [ -n "$_h" ] || _h=$(date +%s | md5sum | cut -c1-7)
    echo $(( $1 + (0x$_h % ($2 - $1 + 1)) ))
}


gen_params() {



    _jc=$(rnd 4 10); _jmin=$(rnd 40 70); _jmax=$(rnd 800 1200)
    _s1=$(rnd 15 150); _s2=$(rnd 15 150)
    [ "$((_s1 + 56))" = "$_s2" ] && _s2=$((_s2 + 1))
    _h1=$(rnd 100000 900000000); _h2=$(rnd 100000 900000000)
    _h3=$(rnd 100000 900000000); _h4=$(rnd 100000 900000000)
    while [ "$_h2" = "$_h1" ]; do _h2=$(rnd 100000 900000000); done
    while [ "$_h3" = "$_h1" ] || [ "$_h3" = "$_h2" ]; do _h3=$(rnd 100000 900000000); done
    while [ "$_h4" = "$_h1" ] || [ "$_h4" = "$_h2" ] || [ "$_h4" = "$_h3" ]; do _h4=$(rnd 100000 900000000); done
    printf 'Jc = %s\nJmin = %s\nJmax = %s\nS1 = %s\nS2 = %s\nH1 = %s\nH2 = %s\nH3 = %s\nH4 = %s\n' \
        "$_jc" "$_jmin" "$_jmax" "$_s1" "$_s2" "$_h1" "$_h2" "$_h3" "$_h4"
}

cmd_init() {
    mkdir -p "$SRV" 2>/dev/null
    chmod 700 "$SRV" 2>/dev/null
    _awg=$(awg_bin)
    [ -x "$ENODIA_BIN/amneziawg-go" ] && [ -n "$_awg" ] || { log "нет бинарей amneziawg-go/awg — сервер не поднять"; return 1; }
    if [ ! -s "$SRV/server.key" ]; then
        "$_awg" genkey > "$SRV/server.key" 2>/dev/null || { log "не удалось сгенерировать ключ"; return 1; }
        chmod 600 "$SRV/server.key"
        "$_awg" pubkey < "$SRV/server.key" > "$SRV/server.pub"
        log "ключ сервера создан"
    fi
    [ -s "$SRV/params" ] || { gen_params > "$SRV/params"; log "параметры обфускации сгенерированы (уникальны для этой установки)"; }
    if [ -z "$(srv_port)" ]; then

        _p=$(rnd 20000 60000)
        while netstat -lun 2>/dev/null | grep -q ":$_p "; do _p=$(rnd 20000 60000); done
        echo "$_p" > "$SRV/port"
        log "порт сервера: $_p"
    fi
    [ -f "$PEERS" ] || : > "$PEERS"
    chmod 600 "$PEERS" 2>/dev/null
    return 0
}


b64()   { printf '%s' "$1" | base64 2>/dev/null | tr -d '\n'; }
unb64() { printf '%s' "$1" | base64 -d 2>/dev/null; }

peer_field() {   # $1=id $2=номер поля -> значение
    awk -F'\t' -v id="$1" -v f="$2" '$1==id {print $f}' "$PEERS" 2>/dev/null | head -1
}
peer_exists() { [ -n "$(peer_field "$1" 1)" ]; }

next_free_id() {
    _i=2
    while [ "$_i" -le $((PEER_MAX + 1)) ]; do
        peer_exists "$_i" || { echo "$_i"; return 0; }
        _i=$((_i + 1))
    done
    return 1
}

peer_del_line() {   # $1=id ; переписываем файл целиком (sed -i по TAB на busybox капризен)
    awk -F'\t' -v id="$1" '$1!=id' "$PEERS" > "$PEERS.tmp" 2>/dev/null && mv "$PEERS.tmp" "$PEERS"
}

cmd_peer_add() {
    cmd_init || return 1
    _name="$1"
    [ -n "$_name" ] || { log "нужно имя устройства"; return 1; }
    _id=$(next_free_id) || { log "достигнут лимит $PEER_MAX устройств"; return 1; }
    _awg=$(awg_bin)
    _priv=$("$_awg" genkey 2>/dev/null)
    _pub=$(printf '%s' "$_priv" | "$_awg" pubkey 2>/dev/null)
    _psk=$("$_awg" genpsk 2>/dev/null)
    [ -n "$_priv" ] && [ -n "$_pub" ] || { log "не удалось сгенерировать ключи пира"; return 1; }
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
        "$_id" "$(b64 "$_name")" "$_priv" "$_pub" "$_psk" "split" "off" "on" >> "$PEERS"

    printf '%s\t%s\n' "$_id" "$(peer_ip "$_id")"
    srv_running && { srv_setconf; srv_rules; }
    return 0
}

cmd_peer_del() {
    _id="$1"; peer_exists "$_id" || { log "нет устройства №$_id"; return 1; }
    peer_mode_apply "$_id" split          # снять вырез/форс, иначе адрес останется в персисте apply-bypass
    peer_del_line "$_id"
    srv_running && { srv_setconf; srv_rules; }
    peer_conntrack "$_id"                 # адрес свободен и достанется СЛЕДУЮЩЕМУ пиру — чужих потоков он унаследовать не должен
    log "устройство №$_id удалено"
}

cmd_peer_list() {
    [ -f "$PEERS" ] || return 0
    while IFS="$(printf '\t')" read -r _id _nb _pv _pb _pk _md _ln _on; do
        [ -n "$_id" ] || continue
        printf '%s\t%s\t%s\t%s\tlan=%s\t%s\n' "$_id" "$(peer_ip "$_id")" "$(unb64 "$_nb")" "$_md" "$_ln" "$_on"
    done < "$PEERS"
}




peer_cur_mode() {   # $1=ip -> split|direct|vpn
    grep -qxF "$1" "$ENODIA_STATE/.bypass-ips" 2>/dev/null && { echo direct; return 0; }
    awk -F'\t' -v want="$1" '$1==want{f=1} END{exit f?0:1}' "$ENODIA_STATE/.fullvpn-ips" 2>/dev/null && { echo vpn; return 0; }
    echo split
}








peer_mode_apply() {   # $1=id $2=mode
    [ -n "$1" ] || return 0            # без id адрес выродился бы в «10.77.0.» — молча не трогаем чужое
    _ip=$(peer_ip "$1")

    [ -f "$APPLY_BYPASS" ] || return 0
    _want="$2"; case "$_want" in vpn|direct) ;; *) _want=split ;; esac
    [ "$(peer_cur_mode "$_ip")" = "$_want" ] && return 0
    case "$2" in
        vpn)    sh "$APPLY_BYPASS" del-ip "$_ip" >/dev/null 2>&1
                sh "$APPLY_BYPASS" force-add-ip "$_ip" >/dev/null 2>&1 ;;
        direct) sh "$APPLY_BYPASS" force-del-ip "$_ip" >/dev/null 2>&1
                sh "$APPLY_BYPASS" add-ip "$_ip" >/dev/null 2>&1 ;;
        *)      sh "$APPLY_BYPASS" del-ip "$_ip" >/dev/null 2>&1
                sh "$APPLY_BYPASS" force-del-ip "$_ip" >/dev/null 2>&1 ;;
    esac
}

peer_set_field() {   # $1=id $2=номер поля $3=значение
    awk -F'\t' -v OFS='\t' -v id="$1" -v f="$2" -v v="$3" '$1==id {$f=v} {print}' "$PEERS" > "$PEERS.tmp" \
        && mv "$PEERS.tmp" "$PEERS"
}

cmd_peer_mode() {
    _id="$1"; peer_exists "$_id" || { log "нет устройства №$_id"; return 1; }
    case "$2" in split|vpn|direct) ;; *) log "режим: split|vpn|direct"; return 1 ;; esac
    peer_set_field "$_id" 6 "$2"




    [ "$(peer_field "$_id" 8)" = on ] && srv_running && peer_mode_apply "$_id" "$2"
    log "устройство №$_id: режим $2"
}

cmd_peer_lan() {
    _id="$1"; peer_exists "$_id" || { log "нет устройства №$_id"; return 1; }
    case "$2" in on|off) ;; *) log "нужно on|off"; return 1 ;; esac
    peer_set_field "$_id" 7 "$2"
    srv_running && srv_rules



    peer_conntrack "$_id"
    log "устройство №$_id: доступ в домашнюю сеть $2"
}

cmd_peer_rename() {
    _id="$1"; peer_exists "$_id" || { log "нет устройства №$_id"; return 1; }
    [ -n "$2" ] || { log "нужно имя"; return 1; }
    peer_set_field "$_id" 2 "$(b64 "$2")"
    log "устройство №$_id переименовано"
}

cmd_peer_toggle() {
    _id="$1"; peer_exists "$_id" || { log "нет устройства №$_id"; return 1; }
    case "$2" in on|off) ;; *) log "нужно on|off"; return 1 ;; esac
    peer_set_field "$_id" 8 "$2"
    [ "$2" = off ] && peer_mode_apply "$_id" split
    [ "$2" = on ] && srv_running && peer_mode_apply "$_id" "$(peer_field "$_id" 6)"
    srv_running && { srv_setconf; srv_rules; }
    peer_conntrack "$_id"    # выключенный пир не должен доигрывать открытые сессии (см. peer_conntrack)
    log "устройство №$_id: $2"
}



cmd_peer_conf() {
    _id="$1"; peer_exists "$_id" || { log "нет устройства №$_id"; return 1; }
    _host=$(endpoint_host); [ -n "$_host" ] || _host=$(endpoint_auto)
    [ -n "$_host" ] || { log "не определён внешний адрес — WAN не настроен?"; return 1; }
    printf '[Interface]\nPrivateKey = %s\nAddress = %s/32\nDNS = %s\nMTU = %s\n' \
        "$(peer_field "$_id" 3)" "$(peer_ip "$_id")" "$(router_ip)" "$MTU_PEER"
    cat "$SRV/params"
    printf '\n[Peer]\nPublicKey = %s\nPresharedKey = %s\nAllowedIPs = 0.0.0.0/0\nEndpoint = %s:%s\nPersistentKeepalive = %s\n' \
        "$(cat "$SRV/server.pub")" "$(peer_field "$_id" 5)" "$_host" "$(srv_port)" "$KEEPALIVE"
}


srv_daemon_pids() {   # матчим по /proc/*/cmdline — killall убил бы awg0 и слот-выходы
    for _p in /proc/[0-9]*; do
        [ -r "$_p/cmdline" ] || continue
        case "$(tr '\0' ' ' 2>/dev/null < "$_p/cmdline") " in
            *"amneziawg-go $IFACE "*) echo "${_p#/proc/}" ;;
        esac
    done
}
srv_kill_daemon() {
    for _pid in $(srv_daemon_pids); do kill "$_pid" 2>/dev/null; done
    _i=0
    while [ -n "$(srv_daemon_pids)" ] && [ "$_i" -lt 8 ]; do
        [ "$_i" = 3 ] && for _pid in $(srv_daemon_pids); do kill -9 "$_pid" 2>/dev/null; done
        sleep 1; _i=$((_i + 1))
    done
    rm -f "/var/run/amneziawg/$IFACE.sock" "/var/run/wireguard/$IFACE.sock" 2>/dev/null
}
srv_running() { ip link show "$IFACE" >/dev/null 2>&1; }








srv_setconf() {
    printf '[Interface]\nPrivateKey = %s\nListenPort = %s\n' "$(cat "$SRV/server.key")" "$(srv_port)" > "$IFCONF"
    cat "$SRV/params" >> "$IFCONF"
    while IFS="$(printf '\t')" read -r _rid _rnb _rpv _rpb _rpk _rmd _rln _ron; do
        [ -n "$_rid" ] || continue
        [ "$_ron" = on ] || continue
        printf '\n[Peer]\nPublicKey = %s\nPresharedKey = %s\nAllowedIPs = %s/32\n' \
            "$_rpb" "$_rpk" "$(peer_ip "$_rid")" >> "$IFCONF"
    done < "$PEERS"
    chmod 600 "$IFCONF" 2>/dev/null
    "$(awg_bin)" setconf "$IFACE" "$IFCONF" 2>&1 | grep -v '^$' || true
}

srv_carrier_up() {
    srv_running && { ip link set "$IFACE" up 2>/dev/null; return 0; }
    srv_kill_daemon




    env $(sh "$ENODIA_DIR/net-tune.sh" memlimit-env 2>/dev/null | grep -E '^GOMEMLIMIT=[0-9]+MiB$') "$ENODIA_BIN/amneziawg-go" "$IFACE" || { log "amneziawg-go $IFACE не стартовал"; return 1; }
    _i=0; while ! srv_running && [ "$_i" -lt 10 ]; do sleep 1; _i=$((_i + 1)); done
    srv_running || { log "$IFACE не появился"; srv_kill_daemon; return 1; }
    srv_setconf
    ip a add "$(router_ip)/24" dev "$IFACE" 2>/dev/null
    ip link set dev "$IFACE" mtu "$MTU_IFACE" 2>/dev/null
    ip link set up "$IFACE"
    return 0
}




srv_rules() {
    _p=$(srv_port); [ -n "$_p" ] || { log "порт не задан"; return 1; }
    _wan=$(wan_iface)
    _sub="$(subnet).0/24"



    iptables -L "$WAN_HOOK" -n >/dev/null 2>&1 || { log "нет цепочки $WAN_HOOK (fw3 не поднят?)"; return 1; }
    iptables -N "$WAN_CHAIN" 2>/dev/null; iptables -F "$WAN_CHAIN" 2>/dev/null
    iptables -A "$WAN_CHAIN" -p udp --dport "$_p" -m conntrack --ctstate NEW -m hashlimit \
        --hashlimit-above "$RATE_NEW/min" --hashlimit-burst 20 --hashlimit-mode srcip \
        --hashlimit-name vpnsrv -j DROP 2>/dev/null
    iptables -A "$WAN_CHAIN" -p udp --dport "$_p" -j ACCEPT || { log "не удалось открыть порт"; return 1; }
    iptables -C "$WAN_HOOK" -j "$WAN_CHAIN" 2>/dev/null || iptables -I "$WAN_HOOK" 1 -j "$WAN_CHAIN"




    iptables -N "$IN_CHAIN" 2>/dev/null; iptables -F "$IN_CHAIN" 2>/dev/null
    iptables -A "$IN_CHAIN" -i "$IFACE" -p udp --dport 53 -j ACCEPT
    iptables -A "$IN_CHAIN" -i "$IFACE" -p tcp --dport 53 -j ACCEPT
    iptables -A "$IN_CHAIN" -i "$IFACE" -p icmp -j ACCEPT
    while IFS="$(printf '\t')" read -r _rid _rnb _rpv _rpb _rpk _rmd _rln _ron; do
        [ -n "$_rid" ] || continue
        [ "$_ron" = on ] && [ "$_rln" = on ] || continue
        for _port in $LAN_PORTS; do
            iptables -A "$IN_CHAIN" -i "$IFACE" -s "$(peer_ip "$_rid")" -p tcp --dport "$_port" -j ACCEPT
        done
    done < "$PEERS"




    iptables -A "$IN_CHAIN" -i "$IFACE" -j DROP
    ipt_top INPUT -j "$IN_CHAIN"




    iptables -N "$FWD_CHAIN" 2>/dev/null; iptables -F "$FWD_CHAIN" 2>/dev/null
    iptables -A "$FWD_CHAIN" -o "$IFACE" -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
    while IFS="$(printf '\t')" read -r _rid _rnb _rpv _rpb _rpk _rmd _rln _ron; do
        [ -n "$_rid" ] || continue
        [ "$_rln" = on ] && continue
        for _net in 192.168.0.0/16 172.16.0.0/12 10.0.0.0/8; do
            iptables -A "$FWD_CHAIN" -i "$IFACE" -s "$(peer_ip "$_rid")" -d "$_net" -j DROP
        done
    done < "$PEERS"
    iptables -A "$FWD_CHAIN" -i "$IFACE" -j ACCEPT
    ipt_top FORWARD -j "$FWD_CHAIN"



    if [ -n "$_wan" ]; then
        iptables -t nat -C POSTROUTING -s "$_sub" -o "$_wan" -j MASQUERADE 2>/dev/null || \
            iptables -t nat -A POSTROUTING -s "$_sub" -o "$_wan" -j MASQUERADE
    fi



    while IFS="$(printf '\t')" read -r _rid _rnb _rpv _rpb _rpk _rmd _rln _ron; do
        [ -n "$_rid" ] || continue
        [ "$_ron" = on ] || continue
        peer_mode_apply "$_rid" "$_rmd"
    done < "$PEERS"
    return 0
}

srv_unrules() {
    while iptables -C "$WAN_HOOK" -j "$WAN_CHAIN" 2>/dev/null; do iptables -D "$WAN_HOOK" -j "$WAN_CHAIN" 2>/dev/null || break; done
    iptables -F "$WAN_CHAIN" 2>/dev/null; iptables -X "$WAN_CHAIN" 2>/dev/null
    while iptables -C INPUT -j "$IN_CHAIN" 2>/dev/null; do iptables -D INPUT -j "$IN_CHAIN" 2>/dev/null || break; done
    iptables -F "$IN_CHAIN" 2>/dev/null; iptables -X "$IN_CHAIN" 2>/dev/null
    while iptables -C FORWARD -j "$FWD_CHAIN" 2>/dev/null; do iptables -D FORWARD -j "$FWD_CHAIN" 2>/dev/null || break; done
    iptables -F "$FWD_CHAIN" 2>/dev/null; iptables -X "$FWD_CHAIN" 2>/dev/null
    _wan=$(wan_iface); _sub="$(subnet).0/24"
    [ -n "$_wan" ] && iptables -t nat -D POSTROUTING -s "$_sub" -o "$_wan" -j MASQUERADE 2>/dev/null
    return 0
}

cmd_up() {
    cmd_init || return 1
    srv_carrier_up || return 1




    srv_rules || { log "правила не встали — снимаю правила и гашу несущую, полуоткрытым сервер не оставляем"; srv_unrules; srv_kill_daemon; return 1; }
    : > "$ON_FLAG"









    [ -f "$ENODIA_DIR/mark-core.sh" ] && sh "$ENODIA_DIR/mark-core.sh" >/dev/null 2>&1 || true



    log "сервер поднят: $IFACE $(router_ip)/24, порт UDP $(srv_port)"
    return 0
}

cmd_down() {

    rm -f "$ON_FLAG" "$SRV/.on-deact"
    srv_unrules


    if [ -f "$PEERS" ]; then
        while IFS="$(printf '\t')" read -r _rid _rnb _rpv _rpb _rpk _rmd _rln _ron; do
            [ -n "$_rid" ] || continue
            peer_mode_apply "$_rid" split
        done < "$PEERS"
    fi
    srv_kill_daemon
    ip link del "$IFACE" 2>/dev/null
    rm -f "$IFCONF"


    ct_flush_src "$(subnet).0/24"
    log "сервер снят"
    return 0
}




cmd_endpoint_set() {
    mkdir -p "$SRV" 2>/dev/null
    _h=$(printf '%s' "$1" | tr -d ' \t\r\n')
    case "$_h" in
        '') rm -f "$SRV/endpoint"; log "адрес для клиентов: автоматически (WAN)" ;;
        *[!A-Za-z0-9.:_-]*) log "недопустимый адрес"; return 1 ;;
        *)  printf '%s\n' "$_h" > "$SRV/endpoint"; log "адрес для клиентов: $_h" ;;
    esac
}




cmd_json() {
    _ready=false
    [ -x "$ENODIA_BIN/amneziawg-go" ] && [ -n "$(awg_bin)" ] && _ready=true
    _run=false;  srv_running && _run=true
    _on=false;   [ -f "$ON_FLAG" ] && _on=true
    _open=false; iptables -C "$WAN_HOOK" -j "$WAN_CHAIN" 2>/dev/null && _open=true
    _man=$(endpoint_host)
    _wan=$(wan_addr)


    _priv=false
    [ -n "$_wan" ] && is_private_ip "$_wan" && _priv=true




    _ext=""
    [ "$_priv" = true ] && _ext=$(wan_ext_addr)
    _host="$_man"; [ -n "$_host" ] || _host=$(endpoint_auto)




    _dump=/tmp/.enodia-vpnsrv-dump.$$
    rm -f "$_dump"
    [ "$_run" = true ] && "$(awg_bin)" show "$IFACE" dump > "$_dump" 2>/dev/null
    _port=$(srv_port); [ -n "$_port" ] || _port=0
    printf '{"engine":true,"ready":%s,"on":%s,"running":%s,"port":%s,"subnet":"%s","max":%s,' \
        "$_ready" "$_on" "$_run" "$_port" "$(subnet)" "$PEER_MAX"
    printf '"endpoint":"%s","endpoint_manual":"%s","wan":"%s","wan_private":%s,"ext":"%s","port_open":%s,"peers":[' \
        "$_host" "$_man" "$_wan" "$_priv" "$_ext" "$_open"
    _first=1; _cnt=0
    if [ -f "$PEERS" ]; then
        while IFS="$(printf '\t')" read -r _id _nb _pv _pb _pk _md _ln _onp; do
            [ -n "$_id" ] || continue
            _cnt=$((_cnt + 1))




            _hs=0; _rx=0; _tx=0
            if [ -s "$_dump" ] && [ -n "$_pb" ]; then
                _line=$(grep -F "$_pb" "$_dump" 2>/dev/null | head -1)
                [ -n "$_line" ] && {
                    _hs=$(printf '%s' "$_line" | cut -f5); _rx=$(printf '%s' "$_line" | cut -f6)
                    _tx=$(printf '%s' "$_line" | cut -f7)
                }
            fi
            case "$_hs" in ''|*[!0-9]*) _hs=0 ;; esac
            case "$_rx" in ''|*[!0-9]*) _rx=0 ;; esac
            case "$_tx" in ''|*[!0-9]*) _tx=0 ;; esac




            if [ "$_hs" -gt 0 ]; then _age=$(age_since "$_hs"); else _age=-1; fi
            [ "$_first" = 1 ] || printf ','
            _first=0
            printf '{"id":%s,"ip":"%s","name_b64":"%s","mode":"%s","lan":%s,"on":%s,"hs":%s,"age":%s,"rx":%s,"tx":%s}' \
                "$_id" "$(peer_ip "$_id")" "$_nb" "$_md" \
                "$([ "$_ln" = on ] && echo true || echo false)" \
                "$([ "$_onp" = on ] && echo true || echo false)" "$_hs" "$_age" "$_rx" "$_tx"
        done < "$PEERS"
    fi
    rm -f "$_dump"
    printf '],"count":%s,"full":%s}\n' "$_cnt" "$([ "$_cnt" -ge "$PEER_MAX" ] && echo true || echo false)"
}

cmd_status() {
    echo "=== VPN-сервер (доступ домой) ==="
    if srv_running; then
        echo "несущая: $IFACE UP, адрес $(router_ip)/24, порт UDP $(srv_port)"
    else
        echo "несущая: не поднята"
    fi



    _host=$(endpoint_host); [ -n "$_host" ] || _host=$(endpoint_auto)
    echo "endpoint для клиентов: $_host:$(srv_port)"


    _swan=$(wan_addr)
    if [ -n "$_swan" ] && is_private_ip "$_swan"; then
        echo "  адрес WAN-интерфейса: $_swan (ПРИВАТНЫЙ — снаружи по нему не подключиться)"
        _sext=$(wan_ext_addr)
        [ -n "$_sext" ] && echo "  реальный внешний адрес: $_sext (нужен проброс порта на вышестоящем роутере либо белый IP)"
    fi
    if iptables -C "$WAN_HOOK" -j "$WAN_CHAIN" 2>/dev/null; then echo "порт наружу: открыт"; else echo "порт наружу: ЗАКРЫТ"; fi
    echo "--- устройства ---"
    cmd_peer_list
    if srv_running; then
        echo "--- рукопожатия ---"
        "$(awg_bin)" show "$IFACE" latest-handshakes 2>/dev/null
    fi
}

case "$1" in
    init)        cmd_init ;;
    up)          cmd_up ;;
    down)        cmd_down ;;
    status)      cmd_status ;;



    rules)       if srv_running; then srv_rules || exit 1
                 else log "несущая не поднята — правила не ставлю"; exit 1; fi ;;
    unrules)     srv_unrules ;;




    wired)       [ -f "$ON_FLAG" ] || exit 0
                 srv_running || exit 2
                 command -v ipt_jump_state >/dev/null 2>&1 || exit 2
                 _vwr=0
                 for _vwj in "$WAN_HOOK $WAN_CHAIN" "INPUT $IN_CHAIN" "FORWARD $FWD_CHAIN"; do

                     ipt_jump_state $_vwj; _vwc=$?
                     [ "$_vwc" = 2 ] && exit 2
                     [ "$_vwc" = 1 ] && _vwr=3
                 done
                 exit "$_vwr" ;;
    peer-add)    cmd_peer_add "$2" ;;
    peer-del)    cmd_peer_del "$2" ;;
    peer-list)   cmd_peer_list ;;
    peer-conf)   cmd_peer_conf "$2" ;;
    peer-mode)   cmd_peer_mode "$2" "$3" ;;
    peer-lan)    cmd_peer_lan "$2" "$3" ;;
    peer-toggle) cmd_peer_toggle "$2" "$3" ;;
    peer-rename) cmd_peer_rename "$2" "$3" ;;
    endpoint-set) cmd_endpoint_set "$2" ;;
    json)        cmd_json ;;
    *) echo "использование: $0 {init|up|down|status|json|rules|unrules|peer-add <имя>|peer-del <id>|peer-list|peer-conf <id>|peer-mode <id> <split|vpn|direct>|peer-lan <id> <on|off>|peer-toggle <id> <on|off>|peer-rename <id> <имя>|endpoint-set [хост]}" ;;
esac
