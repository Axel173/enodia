#!/bin/sh





























































































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}

if [ -f "$ENODIA_DIR/wifi-lib.sh" ]; then . "$ENODIA_DIR/wifi-lib.sh"; fi


if ! command -v wifi_resolve >/dev/null 2>&1; then
    wifi_resolve()  { [ -n "$1" ] && printf '%s\n' "$1"; }
    wifi_ssid_of()  { return 1; }
fi



if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi



if [ -f "$ENODIA_DIR/port-lib.sh" ]; then . "$ENODIA_DIR/port-lib.sh"; fi
if ! command -v ct_flush >/dev/null 2>&1; then
    ct_flush()     { conntrack -F >/dev/null 2>&1 || true; }
    ct_flush_src() { [ -n "$1" ] && conntrack -D --src "$1" >/dev/null 2>&1; return 0; }
    ct_flush_dst() { [ -n "$1" ] && conntrack -D -d    "$1" >/dev/null 2>&1; return 0; }
fi
EXCLUDE_CHAIN=VPN_EXCLUDE
STORE_IPS="$ENODIA_STATE/.bypass-ips"
STORE_DST="$ENODIA_STATE/.bypass-dst"
STORE_IFS="$ENODIA_STATE/.bypass-ifaces"
STORE_GUEST="$ENODIA_STATE/.bypass-guest"
STORE_EP="$ENODIA_STATE/.endpoint-bypass"   # IP endpoint'а активной несущей (авто, анти-петля)
GUEST_SUBNET=192.168.33.0/24
GUEST_PREF=90












FORCE_CHAIN=VPN_FORCE
STORE_FORCE_IPS="$ENODIA_STATE/.fullvpn-ips"     # IP устройств (источник) ЦЕЛИКОМ в VPN (`IP` | `IP<TAB>sN`)
STORE_FORCE_IFS="$ENODIA_STATE/.fullvpn-ifaces"  # Wi-Fi iface (SSID) ЦЕЛИКОМ в VPN
STORE_FORCE_GUEST="$ENODIA_STATE/.fullvpn-guest" # флаг: гостевая ЦЕЛИКОМ в VPN
FULLTUNNEL_FLAG="$ENODIA_STATE/.full-tunnel"     # флаг: ВЕСЬ трафик через VPN
FWMARK=0x1
TAB=$(printf '\t')   # разделитель полей в TSV-хранилищах (.port-rules, .fullvpn-ips)




LOCAL_NETS="10.0.0.0/8 172.16.0.0/12 192.168.0.0/16 169.254.0.0/16 224.0.0.0/4"







BYPASS_SETS="grp_out enodia_bypass geo_out"














































PORTS_CHAIN=VPN_PORTS
STORE_PORTS="$ENODIA_STATE/.port-rules"





























KEEP_CHAIN=VPN_KEEP
STORE_KEEP="$ENODIA_STATE/.keep-vpn-ips"   # IP устройств: «мимо VPN, но ручные правила действуют»
KEEP_SETS="enodia_list enodia_ip_vpn grp_vpn"
























STORE_DESYNC="$ENODIA_STATE/.desync-ips"   # IP устройств: «напрямую + десинк рукопожатий» (nfqws по src)
ZAPRET_SH="$ENODIA_DIR/zapret.sh"



ZAPRET_CHAIN=ENODIA_ZAPRET


























DEV_CHAIN=VPN_DEV















STORE_VPN_DST="$ENODIA_STATE/.vpn-dst"   # IP/подсети назначения ЦЕЛИКОМ в туннель (по строке)
VPN_DST_SET=enodia_ip_vpn              # его метит mark-core.sh тем же циклом, что enodia_list/grp_vpn

























ensure_prerouting_order() {
    for _c in "$ZAPRET_CHAIN" "$FORCE_CHAIN" "$EXCLUDE_CHAIN" "$KEEP_CHAIN" "$DEV_CHAIN" "$PORTS_CHAIN"; do
        iptables -t mangle -C PREROUTING -j "$_c" 2>/dev/null || continue
        iptables -t mangle -D PREROUTING -j "$_c" 2>/dev/null
        iptables -t mangle -I PREROUTING 1 -j "$_c"
    done
    ensure_reply_guard
}






ensure_chain() {
    iptables -t mangle -L "$EXCLUDE_CHAIN" -n >/dev/null 2>&1 || \
        iptables -t mangle -N "$EXCLUDE_CHAIN"
    iptables -t mangle -C PREROUTING -j "$EXCLUDE_CHAIN" 2>/dev/null || \
        iptables -t mangle -I PREROUTING 1 -j "$EXCLUDE_CHAIN"
    iptables -t mangle -D OUTPUT -j "$EXCLUDE_CHAIN" 2>/dev/null
    iptables -t mangle -I OUTPUT 1 -j "$EXCLUDE_CHAIN"
    ensure_prerouting_order
}


store_add() {   # $1 файл, $2 значение
    [ -z "$2" ] && return 0
    touch "$1"


    grep -qxF -- "$2" "$1" 2>/dev/null || printf '%s\n' "$2" >> "$1"
}
store_del() {   # $1 файл, $2 значение
    [ -f "$1" ] || return 0
    grep -vxF -- "$2" "$1" > "$1.tmp" 2>/dev/null
    mv "$1.tmp" "$1"
}


rule_add_ip() {
    iptables -t mangle -C "$EXCLUDE_CHAIN" -s "$1" -j ACCEPT 2>/dev/null || \
        iptables -t mangle -A "$EXCLUDE_CHAIN" -s "$1" -j ACCEPT
}
rule_del_ip() { iptables -t mangle -D "$EXCLUDE_CHAIN" -s "$1" -j ACCEPT 2>/dev/null; }



rule_add_dst() {
    iptables -t mangle -C "$EXCLUDE_CHAIN" -d "$1" -j ACCEPT 2>/dev/null || \
        iptables -t mangle -A "$EXCLUDE_CHAIN" -d "$1" -j ACCEPT
}
rule_del_dst() { iptables -t mangle -D "$EXCLUDE_CHAIN" -d "$1" -j ACCEPT 2>/dev/null; }








rule_add_set_dst() {
    ipset list -n 2>/dev/null | grep -qx "$1" || return 0
    iptables -t mangle -C "$EXCLUDE_CHAIN" -m set --match-set "$1" dst -j ACCEPT 2>/dev/null || \
        iptables -t mangle -A "$EXCLUDE_CHAIN" -m set --match-set "$1" dst -j ACCEPT
}



ensure_vpn_dst_set() {
    ipset list -n 2>/dev/null | grep -qx "$VPN_DST_SET" || \
        ipset create "$VPN_DST_SET" hash:net hashsize 1024 maxelem 65536 2>/dev/null
}





ensure_vpn_dst_mark() {
    iptables -t mangle -C PREROUTING -m set --match-set "$VPN_DST_SET" dst -j MARK --set-mark $FWMARK 2>/dev/null \
        || sh "$ENODIA_DIR/mark-core.sh" >/dev/null 2>&1 || true
}
vpn_dst_add() { ensure_vpn_dst_set; ipset add "$VPN_DST_SET" "$1" 2>/dev/null; ensure_vpn_dst_mark; }
vpn_dst_del() { ipset del "$VPN_DST_SET" "$1" 2>/dev/null; }



if_store_key() { wifi_ssid_of "$1" || printf '%s\n' "$1"; }


rule_add_if() {
    _ain=0
    for _ai in $(wifi_resolve "$1"); do
        iptables -t mangle -C "$EXCLUDE_CHAIN" -m physdev --physdev-in "$_ai" -j ACCEPT 2>/dev/null || \
            iptables -t mangle -A "$EXCLUDE_CHAIN" -m physdev --physdev-in "$_ai" -j ACCEPT || continue
        _ain=$((_ain+1))
    done
    [ "$_ain" -gt 0 ]
}


rule_del_if() {
    for _di in $(wifi_resolve "$1") "$1"; do
        case "$_di" in wl[0-9]*) : ;; *) continue ;; esac
        iptables -t mangle -D "$EXCLUDE_CHAIN" -m physdev --physdev-in "$_di" -j ACCEPT 2>/dev/null
        iptables -t mangle -D "$EXCLUDE_CHAIN" -i "$_di" -j ACCEPT 2>/dev/null   # legacy-формат (-i)
    done
    return 0
}



purge_if_rules() {
    iptables -t mangle -S "$EXCLUDE_CHAIN" 2>/dev/null | \
        sed -n 's/^-A [^ ]* -m physdev --physdev-in \([A-Za-z0-9_-][A-Za-z0-9_-]*\) .*/\1/p' | \
        while IFS= read -r _pi; do
            [ -n "$_pi" ] || continue
            iptables -t mangle -D "$EXCLUDE_CHAIN" -m physdev --physdev-in "$_pi" -j ACCEPT 2>/dev/null
        done
    return 0
}



migrate_if_store() {   # $1 = файл хранилища
    [ -s "$1" ] || return 0
    _mch=0
    : > "$1.tmp" || return 0
    while IFS= read -r _ml || [ -n "$_ml" ]; do
        [ -n "$_ml" ] || continue
        _ms=$(wifi_ssid_of "$_ml") && { _ml="$_ms"; _mch=1; }
        grep -qxF -- "$_ml" "$1.tmp" 2>/dev/null || printf '%s\n' "$_ml" >> "$1.tmp"
    done < "$1"
    if [ "$_mch" = 1 ]; then mv "$1.tmp" "$1"; else rm -f "$1.tmp"; fi
    return 0
}




rebuild_if_rules() {
    migrate_if_store "$STORE_IFS"
    purge_if_rules
    n_if=0
    if [ -f "$STORE_IFS" ]; then
        while IFS= read -r iface || [ -n "$iface" ]; do
            [ -n "$iface" ] && rule_add_if "$iface" && n_if=$((n_if+1))
        done < "$STORE_IFS"
    fi
    return 0
}


if_wired() { iptables -t mangle -S PREROUTING 2>/dev/null | grep -q -- "-j $EXCLUDE_CHAIN\$"; }

if_chain_rules() { iptables -t mangle -S "$EXCLUDE_CHAIN" 2>/dev/null; iptables -t mangle -S "$FORCE_CHAIN" 2>/dev/null; }


if_change_live() {
    _icd=$( { printf '%s\n' "$1"; printf '%s\n' "$2"; } | sort | uniq -u )
    [ -n "$_icd" ] || return 1
    for _ici in $(printf '%s\n' "$_icd" | sed -n 's/.*--physdev-in \([A-Za-z0-9_.-]*\).*/\1/p'); do
        [ -d "/sys/class/net/$_ici" ] && return 0
    done
    printf '%s\n' "$_icd" | grep -v -e '--physdev-in' -e ' -j RETURN' -e '^-N ' | grep -q .
}
guest_rule_add() {
    ip rule show | grep -q "from $GUEST_SUBNET lookup main" || \
        ip rule add from "$GUEST_SUBNET" lookup main pref $GUEST_PREF
}
guest_rule_del() { ip rule del from "$GUEST_SUBNET" lookup main pref $GUEST_PREF 2>/dev/null; }





allow_sync() {
    ipset list -n 2>/dev/null | grep -qx blocklist_allow || return 0
    [ -f "$ENODIA_DIR/lists-update.sh" ] && sh "$ENODIA_DIR/lists-update.sh" allow-sync >/dev/null 2>&1
    return 0
}





endpoint_set() {   # $1 = IPv4 endpoint'а (пусто = снять)
    ensure_chain
    new="$1"






    if [ -f "$STORE_EP" ]; then
        while IFS= read -r old; do
            [ -z "$old" ] && continue
            [ "$old" = "$new" ] && continue
            _ep_needed_elsewhere "$old" "$STORE_EP" && continue
            rule_del_dst "$old"
        done < "$STORE_EP"
    fi
    : > "$STORE_EP"
    [ -z "$new" ] && { echo "[apply-bypass] endpoint-исключение снято"; return 0; }


    echo "$new" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || {
        echo "[apply-bypass] endpoint '$new' не IPv4 — пропуск"; return 0; }
    echo "$new" > "$STORE_EP"
    rule_add_dst "$new"
    allow_sync
    ct_flush_dst "$new"                              # сбросить уже зациклившиеся сессии к VPS
    echo "[apply-bypass] endpoint $new -> мимо VPN (анти-петля)"
}










STORE_EP_SLOT_PREFIX="$ENODIA_STATE/.endpoint-bypass-s"


_ep_needed_elsewhere() {   # $1=ip  $2=свой store (исключить из проверки)
    _ip="$1"; _self="$2"


    [ "$STORE_EP" != "$_self" ] && grep -qxF "$_ip" "$STORE_EP" 2>/dev/null && return 0   # основной endpoint
    grep -qxF "$_ip" "$STORE_DST" 2>/dev/null && return 0     # осознанный юзер-вырез «мимо VPN»


    for _f in "${STORE_EP_SLOT_PREFIX}"*; do
        [ -f "$_f" ] && [ "$_f" != "$_self" ] || continue
        grep -qxF "$_ip" "$_f" 2>/dev/null && return 0        # endpoint другого слота
    done
    return 1
}

endpoint_slot_set() {   # $1 = id слота (2..7); $2 = IPv4 endpoint'а (пусто = снять)
    ensure_chain
    _sid="$1"; new="$2"
    case "$_sid" in [2-7]) ;; *) echo "[apply-bypass] endpoint-slot: id = 2..7"; return 1 ;; esac
    store="${STORE_EP_SLOT_PREFIX}${_sid}"

    if [ -f "$store" ]; then
        old=$(head -1 "$store" 2>/dev/null | tr -d ' \r\n')
        if [ -n "$old" ] && [ "$old" != "$new" ]; then
            _ep_needed_elsewhere "$old" "$store" || rule_del_dst "$old"
        fi
    fi
    : > "$store"
    if [ -z "$new" ]; then rm -f "$store"; echo "[apply-bypass] endpoint слота №$_sid снят"; return 0; fi
    echo "$new" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || {
        rm -f "$store"; echo "[apply-bypass] endpoint слота №$_sid '$new' не IPv4 — пропуск"; return 0; }
    echo "$new" > "$store"
    rule_add_dst "$new"
    allow_sync
    ct_flush_dst "$new"
    echo "[apply-bypass] endpoint слота №$_sid $new -> мимо VPN (анти-петля)"
}














ensure_reply_guard() {
    while iptables -t mangle -D PREROUTING -m addrtype --dst-type LOCAL -j ACCEPT 2>/dev/null; do :; done
    iptables -t mangle -I PREROUTING 1 -m addrtype --dst-type LOCAL -j ACCEPT 2>/dev/null
}




ensure_force_chain() {
    iptables -t mangle -L "$FORCE_CHAIN" -n >/dev/null 2>&1 || \
        iptables -t mangle -N "$FORCE_CHAIN"
    iptables -t mangle -C PREROUTING -j "$FORCE_CHAIN" 2>/dev/null || \
        iptables -t mangle -I PREROUTING 1 -j "$FORCE_CHAIN"
    ensure_prerouting_order
}



force_active() {
    [ -f "$FULLTUNNEL_FLAG" ]   && return 0
    [ -s "$STORE_FORCE_IPS" ]   && return 0
    [ -s "$STORE_FORCE_IFS" ]   && return 0
    [ -f "$STORE_FORCE_GUEST" ] && return 0
    return 1
}







mark_slots() {
    [ -f "$ENODIA_DIR/slots.sh" ] || { printf ' '; return 0; }
    printf ' %s' "$(sh "$ENODIA_DIR/slots.sh" list-enabled 2>/dev/null | awk -F"$TAB" '$2!="zapret"{print $1}' | tr '\n' ' ')"
}




















rebuild_force() {
    if ! force_active; then

        iptables -t mangle -D PREROUTING -j "$FORCE_CHAIN" 2>/dev/null
        iptables -t mangle -F "$FORCE_CHAIN" 2>/dev/null
        echo "[apply-bypass] force(в VPN): выключено (раздельный режим)"
        return 0
    fi
    ensure_chain          # VPN_EXCLUDE должен существовать: порядок цепочек их сводит вместе
    ensure_force_chain
    iptables -t mangle -F "$FORCE_CHAIN"

    for net in $LOCAL_NETS; do
        iptables -t mangle -A "$FORCE_CHAIN" -d "$net" -j RETURN
    done
    iptables -t mangle -A "$FORCE_CHAIN" -d 255.255.255.255 -j RETURN
    n_fip=0; n_fif=0; fg=off; ft=off











    _en_slots=$(mark_slots)
    _fdown=""
    if [ -f "$STORE_FORCE_IPS" ]; then
        while IFS="$TAB" read -r ip fslot; do
            [ -n "$ip" ] || continue


            echo "$ip" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || continue
            _fmk=$FWMARK
            case "$fslot" in
                s[2-7])
                    case "$_en_slots" in
                        *" ${fslot#s} "*) _fmk="0x${fslot#s}" ;;
                        *) _fdown="$_fdown $ip->$fslot" ;;
                    esac ;;
            esac
            iptables -t mangle -A "$FORCE_CHAIN" -s "$ip" -j MARK --set-mark "$_fmk" || continue
            iptables -t mangle -A "$FORCE_CHAIN" -s "$ip" -j ACCEPT
            n_fip=$((n_fip+1))
        done < "$STORE_FORCE_IPS"
    fi




    migrate_if_store "$STORE_FORCE_IFS"
    if [ -f "$STORE_FORCE_IFS" ]; then
        while IFS= read -r iface || [ -n "$iface" ]; do
            [ -n "$iface" ] || continue
            for _ffi in $(wifi_resolve "$iface"); do
                iptables -t mangle -A "$FORCE_CHAIN" -m physdev --physdev-in "$_ffi" -j MARK --set-mark $FWMARK || continue
                iptables -t mangle -A "$FORCE_CHAIN" -m physdev --physdev-in "$_ffi" -j ACCEPT
                n_fif=$((n_fif+1))
            done
        done < "$STORE_FORCE_IFS"
    fi

    if [ -f "$STORE_FORCE_GUEST" ]; then
        iptables -t mangle -A "$FORCE_CHAIN" -s "$GUEST_SUBNET" -j MARK --set-mark $FWMARK
        iptables -t mangle -A "$FORCE_CHAIN" -s "$GUEST_SUBNET" -j ACCEPT
        fg=on
    fi


    if [ -f "$FULLTUNNEL_FLAG" ]; then
        iptables -t mangle -A "$FORCE_CHAIN" -j MARK --set-mark $FWMARK
        iptables -t mangle -A "$FORCE_CHAIN" -j ACCEPT
        ft=on
    fi
    echo "[apply-bypass] force(в VPN): ip=$n_fip, iface=$n_fif, guest=$fg, full-tunnel=$ft${_fdown:+, выход выключен (идут основным):$_fdown}"
}




force_store_set() {   # $1 = IP, $2 = пусто (основной) | sN
    touch "$STORE_FORCE_IPS"
    awk -F"$TAB" -v ip="$1" '$1!=ip' "$STORE_FORCE_IPS" > "$STORE_FORCE_IPS.tmp" 2>/dev/null
    mv "$STORE_FORCE_IPS.tmp" "$STORE_FORCE_IPS"
    if [ -n "$2" ]; then printf '%s\t%s\n' "$1" "$2" >> "$STORE_FORCE_IPS"
    else printf '%s\n' "$1" >> "$STORE_FORCE_IPS"; fi
}
force_store_del() {   # $1 = IP (обе формы строки)
    [ -f "$STORE_FORCE_IPS" ] || return 0
    awk -F"$TAB" -v ip="$1" '$1!=ip' "$STORE_FORCE_IPS" > "$STORE_FORCE_IPS.tmp" 2>/dev/null
    mv "$STORE_FORCE_IPS.tmp" "$STORE_FORCE_IPS"
}

















conntrack_flush() { ct_flush; }



ensure_ports_chain() {
    iptables -t mangle -L "$PORTS_CHAIN" -n >/dev/null 2>&1 || \
        iptables -t mangle -N "$PORTS_CHAIN"
    iptables -t mangle -C PREROUTING -j "$PORTS_CHAIN" 2>/dev/null || \
        iptables -t mangle -I PREROUTING 1 -j "$PORTS_CHAIN"
    ensure_prerouting_order
}








dst_ok()        { echo "$1" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}(/[0-9]{1,2})?$' &&
                  echo "$1" | awk -F'[./]' '{ for (i = 1; i <= NF; i++) if ($i ~ /^0[0-9]/) exit 1
                                             if ($1 > 255 || $2 > 255 || $3 > 255 || $4 > 255 || (NF > 4 && $5 > 32)) exit 1 }'; }



port_rule_add() {
    _s=""; [ "$1" = any ] || _s="-s $1"
    _d=""; [ "$3" = all ] || _d="--dport $(echo "$3" | tr '-' ':')"



    if [ "$4" = block ]; then

        iptables -t mangle -A "$PORTS_CHAIN" $_s -p "$2" $_d -j DROP 2>/dev/null || return 1
        return 0
    fi


    if [ -n "$4" ]; then

        iptables -t mangle -A "$PORTS_CHAIN" $_s -p "$2" $_d -j MARK --set-mark "$4" 2>/dev/null || return 1
    fi
    iptables -t mangle -A "$PORTS_CHAIN" $_s -p "$2" $_d -j ACCEPT 2>/dev/null || return 1
    return 0
}


rebuild_ports() {
    if [ ! -s "$STORE_PORTS" ]; then


        iptables -t mangle -D PREROUTING -j "$PORTS_CHAIN" 2>/dev/null
        iptables -t mangle -F "$PORTS_CHAIN" 2>/dev/null
        echo "[apply-bypass] порт-правила: нет"
        return 0
    fi

    if ! command -v port_rules_in_order >/dev/null 2>&1; then
        echo "[apply-bypass] порт-правила: нет port-lib.sh — прежняя цепочка оставлена"
        return 1
    fi
    ensure_ports_chain
    iptables -t mangle -F "$PORTS_CHAIN"



    for _net in $LOCAL_NETS; do
        iptables -t mangle -A "$PORTS_CHAIN" -d "$_net" -j RETURN
    done
    iptables -t mangle -A "$PORTS_CHAIN" -d 255.255.255.255 -j RETURN
    _n=0; _tab=$(printf '\t')







    _lrows=$(port_rules_in_order "$STORE_PORTS")
    while IFS="$_tab" read -r _lsrc _lpro _lpts _ldir; do
        [ -n "$_ldir" ] || continue
        case "$_ldir" in
            vpn)      _mk=$FWMARK ;;
            s[2-7]) _mk="0x${_ldir#s}" ;;  # марка доп-выхода; ip rule под неё ставит mark-core
            block)    _mk=block ;;           # не выпускать вовсе — DROP вместо MARK+ACCEPT
            *)        _mk="" ;;              # direct — без метки, main-таблица
        esac
        case "$_lpro" in both) _prl="udp tcp" ;; *) _prl="$_lpro" ;; esac
        for _pr in $_prl; do
            for _pt in $(echo "$_lpts" | tr ',' ' '); do
                port_rule_add "$_lsrc" "$_pr" "$_pt" "$_mk" && _n=$((_n+1))
            done
        done
    done <<EOF_PORTS
$_lrows
EOF_PORTS
    echo "[apply-bypass] порт-правила: $_n"
}



ensure_keep_chain() {
    iptables -t mangle -L "$KEEP_CHAIN" -n >/dev/null 2>&1 || \
        iptables -t mangle -N "$KEEP_CHAIN"
    iptables -t mangle -C PREROUTING -j "$KEEP_CHAIN" 2>/dev/null || \
        iptables -t mangle -I PREROUTING 1 -j "$KEEP_CHAIN"
    ensure_prerouting_order
}




rebuild_keep() {
    if [ ! -s "$STORE_KEEP" ]; then
        iptables -t mangle -D PREROUTING -j "$KEEP_CHAIN" 2>/dev/null
        iptables -t mangle -F "$KEEP_CHAIN" 2>/dev/null
        echo "[apply-bypass] исключения из «мимо VPN»: нет"
        return 0
    fi
    ensure_keep_chain
    iptables -t mangle -F "$KEEP_CHAIN"
    _kn=0; _kskip=""
    while IFS= read -r _kip; do
        [ -n "$_kip" ] || continue
        echo "$_kip" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || continue   # в iptables уходит подстановка


        grep -qxF "$_kip" "$STORE_IPS" 2>/dev/null || continue
        for _ks in $KEEP_SETS; do
            ipset list -n 2>/dev/null | grep -qx "$_ks" || { case "$_kskip" in *" $_ks"*) ;; *) _kskip="$_kskip $_ks" ;; esac; continue; }
            iptables -t mangle -A "$KEEP_CHAIN" -s "$_kip" -m set --match-set "$_ks" dst -j MARK --set-mark $FWMARK 2>/dev/null || continue
            iptables -t mangle -A "$KEEP_CHAIN" -s "$_kip" -m set --match-set "$_ks" dst -j ACCEPT 2>/dev/null
            _kn=$((_kn+1))
        done
    done < "$STORE_KEEP"

    echo "[apply-bypass] исключения из «мимо VPN»: правил $_kn${_kskip:+, сетов ещё нет:$_kskip}"
}







rebuild_desync() {
    [ -f "$ZAPRET_SH" ] || { [ -s "$STORE_DESYNC" ] && echo "[apply-bypass] десинк устройств: нет zapret.sh — пропуск"; return 0; }
    _wired=$(sh "$ZAPRET_SH" src-list 2>/dev/null)
    for _old in $_wired; do
        grep -qxF "$_old" "$STORE_DESYNC" 2>/dev/null && continue
        sh "$ZAPRET_SH" src-unwire "$_old" >/dev/null 2>&1




        grep -qxF "$_old" "$STORE_IPS" 2>/dev/null || rule_del_ip "$_old"
    done
    [ -s "$STORE_DESYNC" ] || { echo "[apply-bypass] десинк устройств: нет"; return 0; }
    _dsn=0; _dsfail=""
    while IFS= read -r _dsip; do
        [ -n "$_dsip" ] || continue
        echo "$_dsip" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || continue   # в iptables уходит подстановка


        rule_add_ip "$_dsip"
        if sh "$ZAPRET_SH" src-wire "$_dsip" >/dev/null 2>&1; then _dsn=$((_dsn+1))
        else _dsfail="$_dsfail $_dsip"; fi
    done < "$STORE_DESYNC"


    echo "[apply-bypass] десинк устройств: $_dsn${_dsfail:+, БЕЗ десинка (нет nfqws?):$_dsfail}"
}

desync_drop() {   # $1 = IP
    [ -s "$STORE_DESYNC" ] || return 0
    grep -qxF "$1" "$STORE_DESYNC" 2>/dev/null || return 0
    store_del "$STORE_DESYNC" "$1"
    [ -f "$ZAPRET_SH" ] && sh "$ZAPRET_SH" src-unwire "$1" >/dev/null 2>&1
    return 0
}



ensure_dev_chain() {
    iptables -t mangle -L "$DEV_CHAIN" -n >/dev/null 2>&1 || \
        iptables -t mangle -N "$DEV_CHAIN"
    iptables -t mangle -C PREROUTING -j "$DEV_CHAIN" 2>/dev/null || \
        iptables -t mangle -I PREROUTING 1 -j "$DEV_CHAIN"
    ensure_prerouting_order
}




rebuild_dev() {
    _drules=$(sh "$ENODIA_DIR/groups.sh" dev-rules 2>/dev/null)
    if [ -z "$_drules" ]; then
        iptables -t mangle -D PREROUTING -j "$DEV_CHAIN" 2>/dev/null
        iptables -t mangle -F "$DEV_CHAIN" 2>/dev/null
        echo "[apply-bypass] правила устройств (адреса): нет"
        return 0
    fi
    ensure_dev_chain
    iptables -t mangle -F "$DEV_CHAIN"



    for _net in $LOCAL_NETS; do
        iptables -t mangle -A "$DEV_CHAIN" -d "$_net" -j RETURN
    done
    iptables -t mangle -A "$DEV_CHAIN" -d 255.255.255.255 -j RETURN
    _dn=0; _dskip=""; _ddown=""
    _en_slots=$(mark_slots)


    _dtmp=/tmp/.enodia-dev-rules.$$
    printf '%s\n' "$_drules" > "$_dtmp"
    while IFS="$TAB" read -r _dip _dset _ddir _dslot; do
        [ -n "$_dset" ] || continue
        echo "$_dip" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || continue   # в iptables уходит подстановка


        ipset list -n 2>/dev/null | grep -qx "$_dset" || { case "$_dskip" in *" $_dset"*) ;; *) _dskip="$_dskip $_dset" ;; esac; continue; }
        case "$_ddir" in
            vpn)


                _dmk=$FWMARK
                case "$_dslot" in
                    [2-7]) case "$_en_slots" in
                               *" $_dslot "*) _dmk="0x$_dslot" ;;
                               *) _ddown="$_ddown $_dip->s$_dslot" ;;
                           esac ;;
                esac


                iptables -t mangle -A "$DEV_CHAIN" -s "$_dip" -m set --match-set "$_dset" dst -j MARK --set-mark "$_dmk" 2>/dev/null || continue
                iptables -t mangle -A "$DEV_CHAIN" -s "$_dip" -m set --match-set "$_dset" dst -j ACCEPT 2>/dev/null ;;
            bypass)
                iptables -t mangle -A "$DEV_CHAIN" -s "$_dip" -m set --match-set "$_dset" dst -j ACCEPT 2>/dev/null || continue ;;
            block)
                iptables -t mangle -A "$DEV_CHAIN" -s "$_dip" -m set --match-set "$_dset" dst -j DROP 2>/dev/null || continue ;;
            *)  continue ;;
        esac
        _dn=$((_dn+1))
    done < "$_dtmp"
    rm -f "$_dtmp" 2>/dev/null
    echo "[apply-bypass] правила устройств (адреса): $_dn${_dskip:+, сетов ещё нет:$_dskip}${_ddown:+, выход выключен (идут основным):$_ddown}"
}



ports_conntrack() {
    case "$1" in
        ""|any) conntrack_flush ;;
        *)      ct_flush_src "$1" ;;
    esac
}







ports_store_del() {   # $1 src, $2 proto, $3 ports (нормализованный)
    [ -f "$STORE_PORTS" ] || return 0
    _dt=$(printf '\t')
    : > "$STORE_PORTS.tmp"
    while IFS= read -r _dl || [ -n "$_dl" ]; do



        IFS="$_dt" read -r _ds _dp _dx _dd <<EOF_DEL
$_dl
EOF_DEL
        if [ "$_ds" = "$1" ] && [ "$_dp" = "$2" ] && [ "$(port_list_norm "$_dx")" = "$3" ]; then continue; fi
        printf '%s\n' "$_dl" >> "$STORE_PORTS.tmp"
    done < "$STORE_PORTS"
    mv "$STORE_PORTS.tmp" "$STORE_PORTS"
}


apply_all() {
    ensure_chain
    n_ip=0; n_dst=0; n_if=0; g=off
    if [ -f "$STORE_IPS" ]; then

        while IFS= read -r ip; do
            [ -n "$ip" ] && rule_add_ip "$ip" && n_ip=$((n_ip+1))
        done < "$STORE_IPS"
    fi
    if [ -f "$STORE_DST" ]; then
        while IFS= read -r dst; do
            [ -n "$dst" ] && rule_add_dst "$dst" && n_dst=$((n_dst+1))
        done < "$STORE_DST"
    fi

    rebuild_if_rules



    n_vdst=0
    if [ -s "$STORE_VPN_DST" ]; then
        ensure_vpn_dst_set
        ipset flush "$VPN_DST_SET" 2>/dev/null
        while IFS= read -r vd; do
            [ -n "$vd" ] && ipset add "$VPN_DST_SET" "$vd" 2>/dev/null && n_vdst=$((n_vdst+1))
        done < "$STORE_VPN_DST"
        ensure_vpn_dst_mark
    fi
    [ -f "$STORE_GUEST" ] && { guest_rule_add; g=on; }



    for _s in $BYPASS_SETS; do rule_add_set_dst "$_s"; done


    ep=""
    if [ -s "$STORE_EP" ]; then
        ep=$(head -1 "$STORE_EP" | tr -d ' \r\n')
        [ -n "$ep" ] && rule_add_dst "$ep"
    fi



    eps=""
    for _f in "${STORE_EP_SLOT_PREFIX}"*; do   # stores that exist, whatever the id (see _ep_needed_elsewhere)
        [ -s "$_f" ] || continue
        _e=$(head -1 "$_f" | tr -d ' \r\n')
        [ -n "$_e" ] && { rule_add_dst "$_e"; eps="$eps${eps:+,}$_e"; }
    done
    echo "[apply-bypass] восстановлено: ip=$n_ip, dst=$n_dst, vpn-dst=$n_vdst, iface=$n_if, guest=$g, endpoint=${ep:-нет}${eps:+, слот-endpoint=$eps}"

    rebuild_force


    rebuild_ports


    rebuild_keep


    rebuild_dev


    rebuild_desync
}

case "$1" in
    apply)     apply_all ;;


    set-dst-ensure) [ -z "$2" ] && { echo "нужно имя ipset"; exit 1; }
        _ok=0; for _s in $BYPASS_SETS; do [ "$2" = "$_s" ] && _ok=1; done
        [ "$_ok" = 1 ] || { echo "чужой ipset"; exit 1; }


        ensure_chain; rule_add_set_dst "$2"; rebuild_keep >/dev/null; echo "сет $2 -> мимо VPN (правило в $EXCLUDE_CHAIN)" ;;



    add-ip)    [ -z "$2" ] && { echo "нужен IP";    exit 1; }; ensure_chain; desync_drop "$2"; store_add "$STORE_IPS" "$2"; rule_add_ip "$2"; conntrack_flush; echo "IP $2 -> хранилище + применён" ;;



    del-ip)    [ -z "$2" ] && { echo "нужен IP";    exit 1; }; desync_drop "$2"; store_del "$STORE_IPS" "$2"; rule_del_ip "$2"; store_del "$STORE_KEEP" "$2"; rebuild_keep >/dev/null; conntrack_flush; echo "IP $2 убран из хранилища" ;;
    add-dst)   [ -z "$2" ] && { echo "нужен CIDR";  exit 1; }; dst_ok "$2" || { echo "нужен IPv4 или CIDR"; exit 1; }
        ensure_chain; store_del "$STORE_VPN_DST" "$2"; vpn_dst_del "$2"; store_add "$STORE_DST" "$2"; rule_add_dst "$2"; conntrack_flush; echo "dst $2 -> хранилище + мимо VPN" ;;
    del-dst)   [ -z "$2" ] && { echo "нужен CIDR";  exit 1; }; store_del "$STORE_DST" "$2"; rule_del_dst "$2"; conntrack_flush; echo "dst $2 убран из хранилища" ;;





    add-vpn-dst) [ -z "$2" ] && { echo "нужен CIDR"; exit 1; }; dst_ok "$2" || { echo "нужен IPv4 или CIDR"; exit 1; }
        store_del "$STORE_DST" "$2"; rule_del_dst "$2"; store_add "$STORE_VPN_DST" "$2"; vpn_dst_add "$2"; conntrack_flush; echo "dst $2 -> хранилище + в VPN" ;;
    del-vpn-dst) [ -z "$2" ] && { echo "нужен CIDR"; exit 1; }; store_del "$STORE_VPN_DST" "$2"; vpn_dst_del "$2"; conntrack_flush; echo "dst $2 убран из хранилища (правила нет)" ;;
    endpoint-set) endpoint_set "$2" ;;   # IP endpoint'а несущей мимо VPN (пусто = снять); зовёт transport-*.sh up
    endpoint-slot-set) endpoint_slot_set "$2" "$3" ;;   # <id> <IP|""> endpoint доп-выхода мимо VPN (авто из transport-*.sh slot-up)



    add-if)    [ -z "$2" ] && { echo "нужен iface"; exit 1; }; ensure_chain
        _ifk=$(if_store_key "$2"); store_del "$STORE_IFS" "$2"; store_add "$STORE_IFS" "$_ifk"
        rule_add_if "$_ifk"; conntrack_flush; echo "сеть «$_ifk» -> хранилище + применена" ;;
    del-if)    [ -z "$2" ] && { echo "нужен iface"; exit 1; }
        _ifk=$(if_store_key "$2"); store_del "$STORE_IFS" "$_ifk"; store_del "$STORE_IFS" "$2"
        rule_del_if "$_ifk"; rule_del_if "$2"; conntrack_flush; echo "сеть «$_ifk» убрана из хранилища" ;;
    guest-on)  ensure_chain; touch "$STORE_GUEST"; guest_rule_add; conntrack_flush; echo "гостевая сеть → мимо VPN" ;;
    guest-off) rm -f "$STORE_GUEST"; guest_rule_del; conntrack_flush; echo "гостевая сеть → по правилам" ;;





    force-add-ip)  [ -z "$2" ] && { echo "нужен IP";    exit 1; }


        echo "$2" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || { echo "нужен IPv4"; exit 1; }
        _fs=""; case "$3" in s[2-7]) _fs="$3" ;; ''|0|main) _fs="" ;; *) echo "выход: s2..s7 или пусто"; exit 1 ;; esac


        if [ -n "$_fs" ] && [ -f "$ENODIA_DIR/slots.sh" ] &&
           sh "$ENODIA_DIR/slots.sh" list 2>/dev/null | awk -F"$TAB" -v i="${_fs#s}" '$1==i && $3=="zapret"{f=1} END{exit !f}'; then
            echo "выход №${_fs#s} — десинк (zapret): он работает по адресам назначения, направить в него устройство целиком нельзя"; exit 1
        fi
        desync_drop "$2"
        force_store_set "$2" "$_fs"; rebuild_force; conntrack_flush
        echo "IP $2 -> ЦЕЛИКОМ через VPN${_fs:+ (выход №${_fs#s})} (+хранилище)" ;;
    force-del-ip)  [ -z "$2" ] && { echo "нужен IP";    exit 1; }; force_store_del "$2"; rebuild_force; conntrack_flush; echo "IP $2 -> обычный режим (раздельный)" ;;


    force-rebind)  rebuild_force; conntrack_flush ;;
    force-add-if)  [ -z "$2" ] && { echo "нужен iface"; exit 1; }
        _ifk=$(if_store_key "$2"); store_del "$STORE_FORCE_IFS" "$2"; store_add "$STORE_FORCE_IFS" "$_ifk"
        rebuild_force; conntrack_flush; echo "сеть «$_ifk» -> ЦЕЛИКОМ через VPN" ;;
    force-del-if)  [ -z "$2" ] && { echo "нужен iface"; exit 1; }
        _ifk=$(if_store_key "$2"); store_del "$STORE_FORCE_IFS" "$_ifk"; store_del "$STORE_FORCE_IFS" "$2"
        rebuild_force; conntrack_flush; echo "сеть «$_ifk» -> обычный режим" ;;




    forget-if) [ -n "$2" ] || { echo "нужно имя сети"; exit 1; }
        _fk=0
        grep -qxF -- "$2" "$STORE_IFS" 2>/dev/null && _fk=1
        grep -qxF -- "$2" "$STORE_FORCE_IFS" 2>/dev/null && _fk=1
        [ "$_fk" = 1 ] || { echo "такого правила сети нет"; exit 1; }
        store_del "$STORE_IFS" "$2"; store_del "$STORE_FORCE_IFS" "$2"



        if if_wired; then
            _fb=$(if_chain_rules); rebuild_if_rules; rebuild_force




            if_change_live "$_fb" "$(if_chain_rules)" && conntrack_flush
        fi
        echo "правило сети снято" ;;




    if-states)


        if if_wired; then printf '@wired\t1\n'; else printf '@wired\t0\n'; fi
        command -v wifi_live_ifaces >/dev/null 2>&1 || exit 0
        for _si in $(wifi_live_ifaces); do
            _sk=$(if_store_key "$_si"); _sb=""; _sf=""
            { grep -qxF -- "$_sk" "$STORE_IFS" || grep -qxF -- "$_si" "$STORE_IFS"; } 2>/dev/null && _sb=1
            { grep -qxF -- "$_sk" "$STORE_FORCE_IFS" || grep -qxF -- "$_si" "$STORE_FORCE_IFS"; } 2>/dev/null && _sf=1
            if [ -n "$_sb" ] && [ -n "$_sf" ]; then _ss=both; elif [ -n "$_sb" ]; then _ss=bypass; elif [ -n "$_sf" ]; then _ss=force; else _ss=""; fi
            printf '%s\t%s\n' "$_si" "$_ss"
        done ;;

    force-guest-on)  rm -f "$STORE_GUEST"; guest_rule_del; touch "$STORE_FORCE_GUEST"; rebuild_force; conntrack_flush; echo "гостевая сеть → целиком в VPN" ;;
    force-guest-off) rm -f "$STORE_FORCE_GUEST"; rebuild_force; conntrack_flush; echo "гостевая сеть → по правилам" ;;
    full-tunnel)
        case "$2" in
            on)  touch "$FULLTUNNEL_FLAG"; rebuild_force; conntrack_flush; echo "FULL-TUNNEL ON: весь трафик через VPN (кроме локалки и вырезов)" ;;
            off) rm -f "$FULLTUNNEL_FLAG"; rebuild_force; conntrack_flush; echo "FULL-TUNNEL OFF: вернулся раздельный режим (split по enodia_list/iplist_set)" ;;
            *)   if [ -f "$FULLTUNNEL_FLAG" ]; then echo "full-tunnel: ON"; else echo "full-tunnel: OFF"; fi ;;
        esac ;;



    port-add)
        [ -z "$5" ] && { echo "нужно: port-add <IP|any> <udp|tcp|both> <порты|all> <vpn|direct|block|s2..s7>"; exit 1; }
        command -v port_line_ok >/dev/null 2>&1 || { echo "нет port-lib.sh — обновите скрипты роутера"; exit 1; }
        _src="$2"; _pro="$3"; _pts=$(port_list_norm "$4"); _dir="$5"
        port_src_ok   "$_src" || { echo "src: нужен IPv4 или any"; exit 1; }
        port_proto_ok "$_pro" || { echo "proto: udp|tcp|both"; exit 1; }
        port_list_ok  "$_pts" || { echo "порты: all или список 80,443,40000-65535"; exit 1; }
        port_dir_ok   "$_dir" || { echo "куда: vpn|direct|block|s2..s7"; exit 1; }





        case "$_dir" in
            s[2-7])
                if [ -f "$ENODIA_DIR/slots.sh" ] && \
                   sh "$ENODIA_DIR/slots.sh" list 2>/dev/null | awk -F"$TAB" -v i="${_dir#s}" '$1==i && $3=="zapret"{f=1} END{exit !f}'; then
                    echo "выход №${_dir#s} — десинк (zapret): он работает по адресам назначения, направить в него порты нельзя"; exit 1
                fi ;;
        esac
        ports_store_del "$_src" "$_pro" "$_pts"
        printf '%s\t%s\t%s\t%s\n' "$_src" "$_pro" "$_pts" "$_dir" >> "$STORE_PORTS"
        rebuild_ports; ports_conntrack "$_src"
        echo "порт-правило: $_src $_pro $_pts -> $_dir" ;;
    port-del)
        [ -z "$4" ] && { echo "нужно: port-del <IP|any> <udp|tcp|both> <порты|all>"; exit 1; }
        command -v port_list_norm >/dev/null 2>&1 || { echo "нет port-lib.sh — обновите скрипты роутера"; exit 1; }
        ports_store_del "$2" "$3" "$(port_list_norm "$4")"
        rebuild_ports; ports_conntrack "$2"
        echo "порт-правило снято: $2 $3 $4" ;;
    port-list)   # TSV as-is — читает панель (человеческий текст парсить нельзя)
        if [ -s "$STORE_PORTS" ]; then cat "$STORE_PORTS"; fi ;;



    keep-add-ip)
        [ -z "$2" ] && { echo "нужен IP"; exit 1; }
        echo "$2" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || { echo "нужен IPv4"; exit 1; }
        grep -qxF "$2" "$STORE_IPS" 2>/dev/null || { echo "IP $2 не в списке «мимо VPN» — исключать не из чего"; exit 1; }
        store_add "$STORE_KEEP" "$2"; rebuild_keep; ct_flush_src "$2"
        echo "IP $2 -> мимо VPN, но ручные правила (домены/адреса/группы «в VPN») действуют" ;;
    keep-del-ip)
        [ -z "$2" ] && { echo "нужен IP"; exit 1; }
        store_del "$STORE_KEEP" "$2"; rebuild_keep; ct_flush_src "$2"
        echo "IP $2 -> мимо VPN целиком (исключения сняты)" ;;
    keep-list)   # по строке на IP — читает панель
        if [ -s "$STORE_KEEP" ]; then cat "$STORE_KEEP"; fi ;;




    desync-add-ip)
        [ -z "$2" ] && { echo "нужен IP"; exit 1; }
        echo "$2" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || { echo "нужен IPv4"; exit 1; }
        [ -f "$ZAPRET_SH" ] || { echo "нет zapret.sh — обновите скрипты"; exit 1; }




        sh "$ZAPRET_SH" src-wire "$2" >/dev/null 2>&1 || { echo "десинк недоступен: нет nfqws (поставьте Zapret в «Роутер → Компоненты»)"; exit 1; }
        force_store_del "$2"; rebuild_force >/dev/null
        store_del "$STORE_IPS" "$2"; store_del "$STORE_KEEP" "$2"; rebuild_keep >/dev/null
        ensure_chain; store_add "$STORE_DESYNC" "$2"; rule_add_ip "$2"
        ct_flush_src "$2"
        echo "IP $2 -> напрямую + десинк рукопожатий (nfqws по источнику)" ;;
    desync-del-ip)
        [ -z "$2" ] && { echo "нужен IP"; exit 1; }
        store_del "$STORE_DESYNC" "$2"



        grep -qxF "$2" "$STORE_IPS" 2>/dev/null || rule_del_ip "$2"
        [ -f "$ZAPRET_SH" ] && sh "$ZAPRET_SH" src-unwire "$2" >/dev/null 2>&1
        ct_flush_src "$2"
        echo "IP $2 -> обычный режим (раздельный)" ;;
    desync-list)   # по строке на IP — читает панель
        if [ -s "$STORE_DESYNC" ]; then cat "$STORE_DESYNC"; fi ;;


    desync-rebind) rebuild_desync ;;



    dev-rebind)  rebuild_dev ;;
    order)       ensure_prerouting_order; echo "порядок цепочек в mangle PREROUTING переигран" ;;
    list)
        echo "== .bypass-ips (устройства/источник мимо VPN) =="
        if [ -s "$STORE_IPS" ]; then cat "$STORE_IPS"; else echo "(пусто)"; fi
        echo "== .bypass-dst (сайты-IP/назначение мимо VPN) =="
        if [ -s "$STORE_DST" ]; then cat "$STORE_DST"; else echo "(пусто)"; fi
        echo "== .vpn-dst (сайты-IP/назначение ЦЕЛИКОМ в VPN) =="
        if [ -s "$STORE_VPN_DST" ]; then cat "$STORE_VPN_DST"; else echo "(пусто)"; fi
        echo "== .endpoint-bypass (endpoint несущей мимо VPN — авто, анти-петля) =="
        if [ -s "$STORE_EP" ]; then cat "$STORE_EP"; else echo "(пусто)"; fi
        echo "== .bypass-ifaces (SSID/iface мимо VPN) =="
        if [ -s "$STORE_IFS" ]; then cat "$STORE_IFS"; else echo "(пусто)"; fi
        echo "== ЦЕЛИКОМ через VPN (force) =="
        if [ -f "$FULLTUNNEL_FLAG" ]; then echo "FULL-TUNNEL: ВЕСЬ трафик через VPN (кроме локалки и вырезов выше)"; fi
        echo "-- .fullvpn-ips (устройства целиком в VPN; 2-я колонка = доп-выход) --"
        if [ -s "$STORE_FORCE_IPS" ]; then cat "$STORE_FORCE_IPS"; else echo "(пусто)"; fi
        echo "-- .fullvpn-ifaces (SSID/iface целиком в VPN) --"
        if [ -s "$STORE_FORCE_IFS" ]; then cat "$STORE_FORCE_IFS"; else echo "(пусто)"; fi
        echo "== .port-rules (правила по портам: src / proto / порты / куда) =="
        if [ -s "$STORE_PORTS" ]; then cat "$STORE_PORTS"; else echo "(пусто)"; fi
        echo "== .keep-vpn-ips (мимо VPN, но ручные правила действуют: $KEEP_SETS) =="
        if [ -s "$STORE_KEEP" ]; then cat "$STORE_KEEP"; else echo "(пусто)"; fi
        echo "== .desync-ips (устройства ЦЕЛИКОМ в десинк: напрямую + nfqws по источнику) =="
        if [ -s "$STORE_DESYNC" ]; then cat "$STORE_DESYNC"; else echo "(пусто)"; fi
        echo "-- проводнено в mangle (факт, zapret.sh src-list) --"
        _sl=$([ -f "$ZAPRET_SH" ] && sh "$ZAPRET_SH" src-list 2>/dev/null)
        if [ -n "$_sl" ]; then printf '%s\n' "$_sl"; else echo "(пусто)"; fi
        echo "== правила устройств по адресам (VPN_DEV; хранит groups.sh: ip / значение / куда / выход) =="
        _dl=$(sh "$ENODIA_DIR/groups.sh" dev-list 2>/dev/null)
        if [ -n "$_dl" ]; then printf '%s\n' "$_dl"; else echo "(пусто)"; fi
        echo "== guest =="
        if   [ -f "$STORE_FORCE_GUEST" ]; then echo "ЦЕЛИКОМ через VPN (force)"
        elif [ -f "$STORE_GUEST" ];       then echo "мимо VPN (pref $GUEST_PREF)"
        else echo "раздельный режим (split)"; fi
        ;;
    *)
        echo "Использование: $0 {apply|dev-rebind|desync-add-ip IP|desync-del-ip IP|desync-list|desync-rebind|add-ip IP|del-ip IP|add-dst CIDR|del-dst CIDR|add-vpn-dst CIDR|del-vpn-dst CIDR|endpoint-set IP|endpoint-slot-set ID IP|add-if IFACE|del-if IFACE|guest-on|guest-off|force-add-ip IP [s2..s7]|force-del-ip IP|force-rebind|force-add-if IFACE|force-del-if IFACE|force-guest-on|force-guest-off|forget-if СТРОКА|if-states|full-tunnel on|off|port-add SRC PROTO PORTS vpn|direct|block|sN|port-del SRC PROTO PORTS|port-list|keep-add-ip IP|keep-del-ip IP|keep-list|order|list}"
        exit 1
        ;;
esac
