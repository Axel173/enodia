#!/bin/sh











































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
EV="$ENODIA_STATE/.events"
READ_MARK="$ENODIA_STATE/.events-read"
MUTE="$ENODIA_STATE/.notify-mute"   # выключенные поводы писем, по классу в строке; нет файла — пишем обо всех
LOCK=/tmp/enodia-events.lock
MAX=100            # кольцо: держим последние N событий (≈20 КБ) — панели больше не нужно



if [ -f "$ENODIA_DIR/router-lib.sh" ]; then . "$ENODIA_DIR/router-lib.sh"; fi





if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v age_since >/dev/null 2>&1 || age_since() {
	case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
	[ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}

now=$(date +%s)




lock_take() {
	i=0
	while [ "$i" -lt 30 ]; do
		mkdir "$LOCK" 2>/dev/null && return 0
		i=$((i + 1))
		if [ -d "$LOCK" ]; then




			lt=$(date -r "$LOCK" +%s 2>/dev/null)
			case "$lt" in ''|*[!0-9]*) lt=$now ;; esac
			[ "$(age_since "$lt")" -gt 60 ] && { rm -rf "$LOCK" 2>/dev/null; continue; }
		fi
		sleep 1
	done
	return 1
}
lock_free() { rm -rf "$LOCK" 2>/dev/null; }





level_of() {
	case "$1" in
		*failover-ok|*rollback)   echo warn ;;   # работает, но не штатно (ушли на резерв / откатились)


		failback|failback-server) echo info ;;
		wan-down)                 echo warn ;;   # интернета нет ВООБЩЕ: авария у провайдера, VPN ни при чём



		task-ok-*)                echo info ;;   # the user's task finished (tasks.sh): «fail» is not in it, named for C33 anyway
		*fail*|awg0-down|awg-noraise|subs-nospace) echo err ;;   # task-fail-<id> (tasks.sh) lands here too












		transport-missing|geo-snap-skip|geo-want-snap-skip|doh-auto-off|doh-dot-fallback|subs-active-gone|cross-switch|rule-heal|hev-restart-*|sched-clock|sched-filter) echo warn ;;
		*)                        echo info ;;
	esac
}









CLASSES="down switch wan boot addr subs lists tasks system"
class_of() {
	case "$1" in
		vpn-failopen|switch-failopen|failover-fail|awg0-down|awg-noraise|transport-missing|boot-fail|vpn-restored|slot-fail-*|slot-ok-*) echo down ;;
		cross-switch|cross-rollback|failover-ok|xray-failover-ok|hy2-failover-ok|failback|failback-server|switch-rollback) echo switch ;;
		wan-down|wan-up)          echo wan ;;
		boot-ok)                  echo boot ;;
		panel-wan-ip)             echo addr ;;   # шлёт только открытый «вход снаружи»: в письме — новая ссылка на панель
		subs-*)                   echo subs ;;
		iplist-*|ipblock-*|geo-*) echo lists ;;
		task-*)                   echo tasks ;;   # the user's own tasks (tasks.sh): failure / done — the mail choice is also per task

		rule-heal|clock-step|store-mode-fail|doh-auto-off|doh-enable-failed|doh-dot-fallback|doh-dot-back|hev-restart-*|sched-*) echo system ;;
		*)                        echo system ;;
	esac
}
muted() { grep -q "^$1\$" "$MUTE" 2>/dev/null; }   # $1 — класс из CLASSES (буквы), в регулярке безопасен

cmd_classes() {
	for c in $CLASSES; do
		if muted "$c"; then echo "$c off"; else echo "$c on"; fi
	done
}



cmd_mail_ok() {
	muted "$(class_of "$1")" && return 3




	if [ -f "$ENODIA_STATE/.vpn-off" ]; then
		case "$(class_of "$1")" in down|switch) return 4 ;; esac
	fi
	return 0
}





cmd_mail() {
	case "$1" in ''|*[!a-z]*) echo "неизвестный повод письма: $1"; return 2 ;; esac
	case " $CLASSES " in *" $1 "*) ;; *) echo "неизвестный повод письма: $1"; return 2 ;; esac
	case "$2" in on|off) ;; *) echo "выбор письма — on или off"; return 2 ;; esac
	lock_take || { echo "журнал событий занят — повторите"; return 4; }



	_mn=$(grep -v "^$1\$" "$MUTE" 2>/dev/null; [ "$2" = off ] && echo "$1")
	if [ -n "$_mn" ]; then
		printf '%s\n' "$_mn" > "$MUTE.new" 2>/dev/null && [ "$(cat "$MUTE.new" 2>/dev/null)" = "$_mn" ] && mv "$MUTE.new" "$MUTE" 2>/dev/null
		_mr=$?
	else
		rm -f "$MUTE" 2>/dev/null; [ ! -e "$MUTE" ]; _mr=$?
	fi
	[ "$_mr" = 0 ] || rm -f "$MUTE.new" 2>/dev/null
	lock_free
	[ "$_mr" = 0 ] || { echo "не удалось записать выбор писем"; return 5; }
	return 0
}

b64() { printf '%s' "$1" | base64 2>/dev/null | tr -d '\r\n'; }

cmd_add() {
	key="$1"; dedup="$2"; title="$3"; text="$4"
	[ -n "$key" ] || return 0
	command -v router_relabel >/dev/null 2>&1 && title=$(router_relabel "$title")

	key=$(printf '%s' "$key" | tr -c 'a-zA-Z0-9_-' '_')
	case "$dedup" in ''|*[!0-9]*) dedup=0 ;; esac
	lvl=$(level_of "$key")

	lock_take || return 1
	touch "$EV" 2>/dev/null

	cnt=1
	if [ "$dedup" -gt 0 ]; then


		old=$(awk -F'\t' -v k="$key" '$2==k{l=$0} END{print l}' "$EV" 2>/dev/null)
		if [ -n "$old" ]; then
			old_ts=$(printf '%s' "$old" | cut -f1)
			old_cnt=$(printf '%s' "$old" | cut -f4)
			case "$old_ts"  in ''|*[!0-9]*) old_ts=0 ;; esac
			case "$old_cnt" in ''|*[!0-9]*) old_cnt=1 ;; esac



			if [ "$old_ts" -gt 0 ] && [ "$((now - old_ts))" -lt "$dedup" ]; then
				cnt=$((old_cnt + 1))
				awk -F'\t' -v k="$key" -v t="$old_ts" '!($2==k && $1==t)' "$EV" > "$EV.new" 2>/dev/null
				mv "$EV.new" "$EV" 2>/dev/null
			fi
		fi
	fi

	printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$now" "$key" "$lvl" "$cnt" "$(b64 "$title")" "$(b64 "$text")" >> "$EV"

	if [ "$(wc -l < "$EV" 2>/dev/null || echo 0)" -gt "$MAX" ]; then
		tail -n "$MAX" "$EV" > "$EV.new" 2>/dev/null && mv "$EV.new" "$EV" 2>/dev/null
	fi
	lock_free
}

cmd_list() {
	n="$1"
	case "$n" in ''|*[!0-9]*) n=$MAX ;; esac
	rd=$(cat "$READ_MARK" 2>/dev/null)
	case "$rd" in ''|*[!0-9]*) rd=0 ;; esac


	printf '{"now":%s,"read_at":%s,"events":[' "$now" "$rd"
	if [ -s "$EV" ]; then
		tail -n "$n" "$EV" 2>/dev/null | awk -F'\t' -v OFS='' '
			NF>=6 {
				if (c++) printf ","
				printf "{\"ts\":%s,\"key\":\"%s\",\"level\":\"%s\",\"count\":%s,\"title\":\"%s\",\"text\":\"%s\"}", $1, $2, $3, $4, $5, $6
			}'
	fi
	printf '],"unread":%s}\n' "$(cmd_unread "$rd")"
}




cmd_unread() {
	rd="$1"
	if [ -z "$rd" ]; then
		rd=$(cat "$READ_MARK" 2>/dev/null)
		case "$rd" in ''|*[!0-9]*) rd=0 ;; esac
	fi
	[ -s "$EV" ] || { echo 0; return; }
	awk -F'\t' -v r="$rd" '$1+0>r{n++} END{print n+0}' "$EV" 2>/dev/null || echo 0
}

case "$1" in
	add)        shift; cmd_add "$1" "$2" "$3" "$4" ;;
	list)       cmd_list "$2" ;;
	unread)     cmd_unread ;;






	mark-read)  _rt=$2; case "$_rt" in ''|*[!0-9]*) _rt=$now ;; esac; [ "$_rt" -le "$now" ] || _rt=$now
	            lock_take; _rl=$?
	            _ro=$(cat "$READ_MARK" 2>/dev/null); case "$_ro" in ''|*[!0-9]*) _ro=0 ;; esac; [ "$_ro" -le "$now" ] || _ro=0
	            [ "$_rt" -ge "$_ro" ] || _rt=$_ro
	            echo "$_rt" > "$READ_MARK" 2>/dev/null; _rw=$?; [ "$_rl" = 0 ] && lock_free

	            if [ "$_rw" = 0 ]; then printf '{"ok":true,"read_at":%s}\n' "$_rt"; else printf '{"ok":false}\n'; fi ;;
	clear)      lock_take && { : > "$EV"; echo "$now" > "$READ_MARK"; lock_free; }; printf '{"ok":true}\n' ;;
	class)      class_of "$2" ;;
	classes)    cmd_classes ;;
	mail)       cmd_mail "$2" "$3"; exit $? ;;
	mail-ok)    cmd_mail_ok "$2"; exit $? ;;
	*)          echo "usage: $0 add <key> <dedup_sec> <title> <text> | list [n] | unread | mark-read | clear | class <key> | classes | mail <class> on|off | mail-ok <key>" >&2; exit 1 ;;
esac
