#!/bin/sh


























ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}
SET=iplist_set
TMP=/tmp/enodia-iplist.txt
LOG=/tmp/enodia-iplist-update.log
NOTIFY_EVENT="$ENODIA_DIR/notify-event.sh"
COUNT_FILE="$ENODIA_STATE/.iplist.count"   # прошлое число подсетей (для дельты; переживает ребут)
SNAP_FILE="$ENODIA_STATE/.iplist.snapshot" # последний удачно скачанный список — fallback на boot при мёртвом источнике (переживает ребут)



if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi
command -v probe_ext_ip >/dev/null 2>&1 || probe_ext_ip() { curl -s $1 --max-time "${2:-7}" https://api.ipify.org 2>/dev/null; }




if [ -f "$ENODIA_DIR/dns-lib.sh" ]; then . "$ENODIA_DIR/dns-lib.sh"; fi
command -v doh_ips >/dev/null 2>&1 || doh_ips() { _r=$(curl -s --connect-timeout 3 --max-time 15 $2 "https://1.1.1.1/dns-query?name=$1&type=A" -H 'accept: application/dns-json' 2>/dev/null); [ -n "$_r" ] || _r=$(curl -sk --connect-timeout 3 --max-time 15 $2 "https://1.1.1.1/dns-query?name=$1&type=A" -H 'accept: application/dns-json' 2>/dev/null); printf '%s' "$_r" | grep -o '"data":"[0-9.]*"' | cut -d'"' -f4; }





if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v age_since >/dev/null 2>&1 || age_since() {
    case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
    [ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}

if [ -f "$ENODIA_DIR/nf-i18n.sh" ]; then . "$ENODIA_DIR/nf-i18n.sh"; fi
command -v nf_lang >/dev/null 2>&1 || nf_lang() { echo ru; }
NF_LANG=$(nf_lang)




if [ -f "$ENODIA_DIR/subs-lib.sh" ]; then . "$ENODIA_DIR/subs-lib.sh"; fi
command -v sub_owner_tag >/dev/null 2>&1 || sub_owner_tag() { :; }
command -v sub_label_of  >/dev/null 2>&1 || sub_label_of()  { :; }











IPLIST_BASE='https://iplist.opencck.org/?format=text&data=cidr4'
IPLIST_URL=''
IPLIST_SITES=''
IPLIST_MIN_LINES=10
IPLIST_CUSTOM_MODE=''                        # only|merge|'' — кастомный локальный список (ортогонален источнику скачивания)
IPLIST_CUSTOM_FILE="$ENODIA_STATE/iplist.custom"  # файл кастомного списка (CIDR/IP построчно), переживает ребут
[ -f "$ENODIA_STATE/iplist.conf" ] && . "$ENODIA_STATE/iplist.conf"
case "$IPLIST_MIN_LINES" in ''|*[!0-9]*) IPLIST_MIN_LINES=10 ;; esac   # защита от мусора в конфиге
case "$IPLIST_CUSTOM_MODE" in only|merge) ;; *) IPLIST_CUSTOM_MODE='' ;; esac   # только эти два режима, иначе off
[ -n "$IPLIST_CUSTOM_FILE" ] || IPLIST_CUSTOM_FILE="$ENODIA_STATE/iplist.custom"

if [ -n "$IPLIST_URL" ]; then
    URL="$IPLIST_URL"
elif [ -n "$IPLIST_SITES" ]; then
    URL="$IPLIST_BASE"
    for s in $IPLIST_SITES; do URL="$URL&site=$s"; done
else
    URL="$IPLIST_BASE"
fi








DELEGATED=0
[ -f "$ENODIA_DIR/lists-update.sh" ] && [ -f "$ENODIA_DIR/lists-lib.sh" ] && DELEGATED=1




ipset_count() {  # ipset_count <set> → число (0 если пусто/нет набора)
	_c=$(ipset list "$1" 2>/dev/null | sed -n 's/^Number of entries:[[:space:]]*//p' | head -1)
	case "$_c" in ''|*[!0-9]*) _c=$(ipset list "$1" 2>/dev/null | grep -cE '^[0-9]') ;; esac
	case "$_c" in ''|*[!0-9]*) _c=0 ;; esac
	printf '%s' "$_c"
}







load_set_from_files() {
    ipset list -n 2>/dev/null | grep -qx "$SET" || \
        ipset create "$SET" hash:net hashsize 4096 maxelem 1000000
    ipset destroy "${SET}_new" 2>/dev/null
    ipset create "${SET}_new" hash:net hashsize 4096 maxelem 1000000
    for f in "$@"; do
        [ -f "$f" ] || continue
        while IFS= read -r cidr; do
            case "$cidr" in
                ''|'#'*) continue ;;
            esac
            ipset add "${SET}_new" "$cidr" 2>/dev/null
        done < "$f"
    done
    n=$(ipset_count "${SET}_new")
    if [ "$n" -eq 0 ]; then
        echo "load: 0 валидных записей из [$*] — боевой set НЕ тронут"
        ipset destroy "${SET}_new" 2>/dev/null
        return 1
    fi
    ipset swap "${SET}_new" "$SET"
    ipset destroy "${SET}_new"
    echo "load: $n записей из [$*]"
    return 0
}



















fetch_url() {
    _u="$1"; _o="$2"




    if curl -sfL --max-time 120 "$_u" -o "$_o" && [ -s "$_o" ]; then return 0; fi


    _host=$(printf '%s' "$_u" | sed -e 's|^[a-zA-Z][a-zA-Z0-9+.-]*://||' -e 's|[/?#].*$||' -e 's|^[^@]*@||' -e 's|:.*$||')
    [ -n "$_host" ] || return 1
    case "$_u" in http://*) _port=80 ;; *) _port=443 ;; esac


    _ips=$(doh_ips "$_host" "--max-time 15")
    [ -n "$_ips" ] || return 1
    for _ip in $_ips; do
        case "$_ip" in *.*.*.*) ;; *) continue ;; esac   # только IPv4-вид
        echo "fallback resolve via DoH: $_host -> $_ip"
        if curl -sfL --max-time 120 --resolve "$_host:$_port:$_ip" "$_u" -o "$_o" && [ -s "$_o" ]; then
            return 0
        fi
    done
    return 1
}




NOTIFY=0
REFRESH_LISTS=0
for _a in "$@"; do
    case "$_a" in
        --notify) NOTIFY=1 ;;
        --lists)  REFRESH_LISTS=1 ;;
    esac
done


mail_event() {
    [ "$NOTIFY" = 1 ] && [ -f "$NOTIFY_EVENT" ] && sh "$NOTIFY_EVENT" "$1" "$2" "$3" "$4" >/dev/null 2>&1
}

exec >>"$LOG" 2>&1
echo "===== $(date) (notify=$NOTIFY) ====="
echo "custom mode: ${IPLIST_CUSTOM_MODE:-off} (file: $IPLIST_CUSTOM_FILE)"




USED_FALLBACK=0
LINES=0
SRC_DESC="$URL"   # описание источника для письма-сводки

if [ "$DELEGATED" = 1 ]; then


    echo "delegating fill to lists-update.sh (tunnel-cidr)"
    sh "$ENODIA_DIR/lists-update.sh" update tunnel-cidr
    SRC_DESC="менеджер источников (lists)"
    [ "$NF_LANG" = en ] && SRC_DESC="source manager (lists)"
elif [ "$IPLIST_CUSTOM_MODE" = only ]; then

    SRC_DESC="локальный файл $IPLIST_CUSTOM_FILE (режим only)"
    [ "$NF_LANG" = en ] && SRC_DESC="local file $IPLIST_CUSTOM_FILE (only mode)"
    echo "source: $SRC_DESC"
    if [ -s "$IPLIST_CUSTOM_FILE" ]; then
        LINES=$(wc -l < "$IPLIST_CUSTOM_FILE")
        if ! load_set_from_files "$IPLIST_CUSTOM_FILE"; then
            if [ "$NF_LANG" = en ]; then
                mail_event iplist-fail 0 "BE7000: custom list has no valid subnets" \
"Mode 'only' (local file only), but $IPLIST_CUSTOM_FILE yielded no valid
subnets. Routing was left on the PREVIOUS iplist_set list."
            else
                mail_event iplist-fail 0 "BE7000: кастомный список без валидных подсетей" \
"Режим 'only' (только локальный файл), но $IPLIST_CUSTOM_FILE не дал ни одной
валидной подсети. Маршрутизация оставлена на ПРОШЛОМ списке iplist_set."
            fi
        fi
    else
        echo "only-mode: нет/пуст $IPLIST_CUSTOM_FILE"
        if [ "$NF_LANG" = en ]; then
            mail_event iplist-fail 0 "BE7000: custom list is missing" \
"Mode 'only', but file $IPLIST_CUSTOM_FILE is missing or empty. Put a list into
that file, or switch the sources in the panel («Sites, domains, IP»). The live
set was left untouched."
        else
            mail_event iplist-fail 0 "BE7000: кастомный список отсутствует" \
"Режим 'only', но файла $IPLIST_CUSTOM_FILE нет или он пуст. Положите список в этот
файл либо переключите источники в панели («Сайты, домены, IP»). Боевой set не тронут."
        fi
    fi
else

    echo "source: $URL"
    DOWNLOAD_OK=0
    if fetch_url "$URL" "$TMP"; then
        LINES=$(wc -l < "$TMP")
        echo "downloaded: $LINES lines"
        if [ "$LINES" -ge "$IPLIST_MIN_LINES" ]; then
            DOWNLOAD_OK=1
        else
            echo "suspicious size ($LINES < $IPLIST_MIN_LINES) — reject"
        fi
    else
        echo "download failed"
    fi

    HAVE_CUSTOM=0
    [ "$IPLIST_CUSTOM_MODE" = merge ] && [ -s "$IPLIST_CUSTOM_FILE" ] && HAVE_CUSTOM=1

    if [ "$DOWNLOAD_OK" = 1 ]; then

        if [ "$HAVE_CUSTOM" = 1 ]; then
            SRC_DESC="$URL + локальный файл $IPLIST_CUSTOM_FILE (режим merge)"
            [ "$NF_LANG" = en ] && SRC_DESC="$URL + local file $IPLIST_CUSTOM_FILE (merge mode)"
            load_set_from_files "$TMP" "$IPLIST_CUSTOM_FILE"
        else
            load_set_from_files "$TMP"
        fi
        cp "$TMP" "$SNAP_FILE" 2>/dev/null   # снимок = ТОЛЬКО скачанная часть (на boot домержим custom)
    else

        CUR=$(ipset_count "$SET")
        if [ "$CUR" -gt 0 ]; then

            echo "keep existing set ($CUR entries)"
            if [ "$NF_LANG" = en ]; then
                mail_event iplist-fail 0 "BE7000: IP list did NOT update" \
"Could not update the IP subnet list.
Source: $URL
Routing works on the PREVIOUS list ($CUR subnets) — nothing broke,
no new subnets were added. If this repeats for several
days, check that the source is reachable."
            else
                mail_event iplist-fail 0 "BE7000: НЕ обновился список IP" \
"Не удалось обновить список IP-подсетей.
Источник: $URL
Маршрутизация работает на ПРОШЛОМ списке ($CUR подсетей) — ничего не
сломалось, новых подсетей не добавилось. Если повторяется несколько
дней — проверьте доступность источника."
            fi
            exit 1
        elif [ -s "$SNAP_FILE" ] || [ "$HAVE_CUSTOM" = 1 ]; then


            if [ "$HAVE_CUSTOM" = 1 ]; then
                echo "set empty — loading fallback (snapshot + custom)"
                load_set_from_files "$SNAP_FILE" "$IPLIST_CUSTOM_FILE"
            else
                echo "set empty — loading fallback snapshot $SNAP_FILE"
                load_set_from_files "$SNAP_FILE"
            fi
            USED_FALLBACK=1
        else

            echo "set empty and no snapshot — nothing to load"
            if [ "$NF_LANG" = en ]; then
                mail_event iplist-fail 0 "BE7000: IP list is empty" \
"Source unreachable and no local snapshot yet — ipset iplist_set is empty.
Source: $URL
Runet and domains (enodia_list) work, but CDN subnets from CIDR are temporarily
NOT routed into the VPN. It will fill on the next successful update
(nearest reboot or 5:00)."
            else
                mail_event iplist-fail 0 "BE7000: список IP пуст" \
"Источник недоступен, локального снимка ещё нет — ipset iplist_set пуст.
Источник: $URL
Рунет и домены (enodia_list) работают, но CDN-подсети из CIDR временно НЕ
заворачиваются в VPN. Наполнится при следующем удачном обновлении
(ближайший ребут или 5:00)."
            fi
            exit 1
        fi
    fi
fi

COUNT=$(ipset_count "$SET")
echo "ipset $SET: $COUNT entries (fallback=$USED_FALLBACK)"
[ "$DELEGATED" = 1 ] && LINES=$COUNT   # в делегированном режиме «строк с источника» = итог в set











DELEG_EMPTY=0; DELEG_OFF=0
if [ "$DELEGATED" = 1 ] && [ "$COUNT" = 0 ]; then
    _nen=""
    [ -f "$ENODIA_DIR/lists-lib.sh" ] && _nen=$( . "$ENODIA_DIR/lists-lib.sh" 2>/dev/null; command -v reg_nen >/dev/null 2>&1 && reg_nen tunnel-cidr 2>/dev/null )
    if [ "$_nen" = 0 ]; then
        DELEG_OFF=1
        echo "$SET пуст намеренно: все источники CIDR-списка выключены"
    else
        DELEG_EMPTY=1
        echo "ВНИМАНИЕ: делегированное наполнение дало ПУСТОЙ $SET (источники недоступны, снимка нет)"
    fi
fi







_tcfg=0; [ -f "$ENODIA_DIR/transport.sh" ] && { sh "$ENODIA_DIR/transport.sh" configured >/dev/null 2>&1; [ "$?" = 1 ] && _tcfg=1; }





_voff=0; [ -f "$ENODIA_STATE/.vpn-off" ] && _voff=1
if [ "$_tcfg" = 1 ] || [ "$_voff" = 1 ]; then
    if [ "$_voff" = 1 ]; then
        echo "VPN выключен человеком — правило маркировки не ставлю (вернёт vpn-toggle.sh on)"
    else
        echo "транспорт не настроен (установка «только панель») — правило маркировки не ставлю"
    fi
elif ! iptables -t mangle -C PREROUTING -m set --match-set "$SET" dst -j MARK --set-mark 0x1 2>/dev/null; then
    iptables -t mangle -A PREROUTING -m set --match-set "$SET" dst -j MARK --set-mark 0x1
    echo "mangle rule added for $SET"
fi





if [ "$USED_FALLBACK" = 1 ]; then
    delta="из локального снимка"
    [ "$NF_LANG" = en ] && delta="from local snapshot"
else
    PREV=$(cat "$COUNT_FILE" 2>/dev/null)
    case "$PREV" in ''|*[!0-9]*) PREV="" ;; esac
    echo "$COUNT" > "$COUNT_FILE"
    if [ -n "$PREV" ]; then
        d=$((COUNT - PREV))
        if   [ "$d" -gt 0 ]; then delta="было $PREV, +$d"
        elif [ "$d" -lt 0 ]; then delta="было $PREV, $d"
        else                      delta="без изменений"; fi
        if [ "$NF_LANG" = en ]; then
            if   [ "$d" -gt 0 ]; then delta="was $PREV, +$d"
            elif [ "$d" -lt 0 ]; then delta="was $PREV, $d"
            else                      delta="no change"; fi
        fi
    else
        delta="первое измерение"
        [ "$NF_LANG" = en ] && delta="first measurement"
    fi
fi
echo "delta: $delta"



if [ "$NOTIFY" = 1 ]; then








    dg_t=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
    if [ -z "$dg_t" ]; then
        dg_t=awg                                   # исторический фолбэк: роутер старше флага
        [ "$_tcfg" = 1 ] && dg_t=none
    fi
    dg_label=$(case "$dg_t" in xray) echo "Xray" ;; hy2) echo "Hysteria2" ;; byedpi) echo "ByeDPI" ;; zapret) echo "Zapret" ;; awg) echo "AmneziaWG" ;; none) echo "не выбран" ;; *) echo "$dg_t" ;; esac)


    if [ "$dg_t" = xray ]; then
        _xp=$(grep -oE '"protocol"[[:space:]]*:[[:space:]]*"(vless|vmess|trojan|shadowsocks)"' "$ENODIA_STATE/xray.json" 2>/dev/null | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
        case "$_xp" in vmess) dg_label="Xray · VMESS" ;; trojan) dg_label="Xray · Trojan" ;; shadowsocks) dg_label="Xray · Shadowsocks" ;; esac
    fi
    if [ "$dg_t" = none ]; then


        vpn_state="транспорт не выбран — трафик идёт напрямую"
        [ "$NF_LANG" = en ] && vpn_state="no transport selected — traffic goes direct"
        active=""
    elif [ "$dg_t" = awg ]; then
        WG=""
        command -v wg >/dev/null 2>&1 && WG=wg
        [ -z "$WG" ] && [ -x "$ENODIA_BIN/awg" ] && WG="$ENODIA_BIN/awg"
        vpn_state="awg0 не поднят"
        [ "$NF_LANG" = en ] && vpn_state="awg0 not up"
        if ip link show awg0 >/dev/null 2>&1; then
            vpn_state="awg0 up"
            if [ -n "$WG" ]; then
                hs=$($WG show awg0 latest-handshakes 2>/dev/null | awk 'NR==1{print $2}')
                case "$hs" in ''|*[!0-9]*) hs=0 ;; esac
                if [ "$hs" -gt 0 ]; then
                    vpn_state="awg0 up, handshake $(age_since "$hs") сек назад"
                    [ "$NF_LANG" = en ] && vpn_state="awg0 up, handshake $(age_since "$hs") s ago"
                else
                    vpn_state="awg0 up, handshake ещё нет"
                    [ "$NF_LANG" = en ] && vpn_state="awg0 up, no handshake yet"
                fi
            fi
        fi
        active=$(cat "$ENODIA_STATE/.active" 2>/dev/null)
    else

        if [ -f "$ENODIA_DIR/transport.sh" ] && sh "$ENODIA_DIR/transport.sh" health "$dg_t" >/dev/null 2>&1; then
            vpn_state="$dg_label — связь OK"
            [ "$NF_LANG" = en ] && vpn_state="$dg_label — link OK"
        else
            vpn_state="$dg_label — проба не прошла"
            [ "$NF_LANG" = en ] && vpn_state="$dg_label — probe failed"
        fi
        active=$(cat "$ENODIA_STATE/.$dg_t-active" 2>/dev/null)   # byedpi/zapret не имеют серверного конфига → пусто
    fi



    active_disp="$active"
    case "$active" in
        sub-*)
            TAB=$(printf '\t'); disp=""; lbl=""
            if [ -f "$ENODIA_STATE/.sub-names" ]; then
                while IFS="$TAB" read -r _f _r; do [ "$_f" = "$active" ] && { disp="$_r"; break; }; done < "$ENODIA_STATE/.sub-names"
            fi
            _tag=$(sub_owner_tag "$active")
            [ -n "$_tag" ] && lbl=$(sub_label_of "$_tag")
            [ -n "$disp" ] || disp="$active"
            if [ -n "$lbl" ]; then active_disp="$disp (подписка «$lbl»)"; else active_disp="$disp"; fi
            [ "$NF_LANG" = en ] && [ -n "$lbl" ] && active_disp="$disp (subscription «$lbl»)"
            ;;
    esac
    ip=$(probe_ext_ip "" 5)
    if [ "$NF_LANG" = en ]; then
        BODY=$(printf '%s\n' \
"Morning update of the IP subnet list." \
"" \
"Subnets in iplist_set: $COUNT ($delta)." \
"Source: $SRC_DESC." \
"Lines from source: $LINES." \
"" \
"Transport: $dg_label." \
"VPN: $vpn_state." \
"Active config: ${active_disp:-—}." \
"External IP now: ${ip:-unknown}.")
        subj="BE7000: IP list updated — $COUNT subnets"
        [ "$USED_FALLBACK" = 1 ] && subj="BE7000: IP list restored from snapshot — $COUNT subnets"
    else
        BODY=$(printf '%s\n' \
"Утреннее обновление списка IP-подсетей." \
"" \
"Подсетей в iplist_set: $COUNT ($delta)." \
"Источник: $SRC_DESC." \
"Строк с источника: $LINES." \
"" \
"Транспорт: $dg_label." \
"VPN: $vpn_state." \
"Активный конфиг: ${active_disp:-—}." \
"Внешний IP сейчас: ${ip:-неизвестен}.")
        subj="BE7000: список IP обновлён — $COUNT подсетей"
        [ "$USED_FALLBACK" = 1 ] && subj="BE7000: список IP поднят из снимка — $COUNT подсетей"
    fi



    ev_key=iplist-digest
    if [ "$DELEG_EMPTY" = 1 ]; then
        ev_key=iplist-fail
        if [ "$NF_LANG" = en ]; then
            subj="BE7000: IP list is empty"
            BODY=$(printf '%s\n' \
"Sources are unreachable and there is no local snapshot — ipset iplist_set is EMPTY." \
"Source: $SRC_DESC." \
"" \
"Runet and domains (enodia_list) still work, but CDN subnets from the CIDR list are" \
"temporarily NOT routed into the VPN. It will fill on the next successful update" \
"(nearest reboot or 5:00)." \
"" \
"Transport: $dg_label." \
"VPN: $vpn_state." \
"External IP now: ${ip:-unknown}.")
        else
            subj="BE7000: список IP пуст"
            BODY=$(printf '%s\n' \
"Источники недоступны, локального снимка нет — ipset iplist_set ПУСТ." \
"Источник: $SRC_DESC." \
"" \
"Рунет и домены (enodia_list) работают, но CDN-подсети из CIDR-списка временно НЕ" \
"заворачиваются в VPN. Наполнится при следующем удачном обновлении" \
"(ближайший ребут или 5:00)." \
"" \
"Транспорт: $dg_label." \
"VPN: $vpn_state." \
"Внешний IP сейчас: ${ip:-неизвестен}.")
        fi
    fi


    if [ "$DELEG_OFF" = 1 ]; then
        if [ "$NF_LANG" = en ]; then
            subj="BE7000: IP list is not used — all sources are off"
            BODY=$(printf '%s\n' \
"All sources of the shared IP list (CIDR) are turned off, so iplist_set is empty on purpose." \
"Nothing is broken: domain rules (enodia_list), groups and geo categories work as usual;" \
"only subnets from the CIDR list are not routed into the VPN." \
"To use the list again, turn a source on in «Routing» → «List sources»." \
"" \
"Transport: $dg_label." \
"VPN: $vpn_state." \
"External IP now: ${ip:-unknown}.")
        else
            subj="BE7000: список IP не используется — все источники выключены"
            BODY=$(printf '%s\n' \
"Все источники общего списка IP (CIDR) выключены — поэтому iplist_set пуст намеренно." \
"Ничего не сломано: доменные правила (enodia_list), группы и гео-категории работают как" \
"обычно; не заворачиваются в VPN только подсети из CIDR-списка." \
"Чтобы вернуть список, включите источник в «Маршрутизация» → «Источники списков»." \
"" \
"Транспорт: $dg_label." \
"VPN: $vpn_state." \
"Внешний IP сейчас: ${ip:-неизвестен}.")
        fi
    fi
    mail_event "$ev_key" 0 "$subj" "$BODY"
fi





if [ "$REFRESH_LISTS" = 1 ] && [ -f "$ENODIA_DIR/lists-update.sh" ] && [ -f "$ENODIA_DIR/lists-lib.sh" ]; then

    _optc=$( . "$ENODIA_DIR/lists-lib.sh" 2>/dev/null; ls_opt_cats 2>/dev/null )
    [ -n "$_optc" ] || _optc="adblock ipblock zapret-cidr zapret-dom"   # шим-фолбэк: старый lists-lib.sh
    for _lc in $_optc; do
        echo "refresh other list: $_lc"
        sh "$ENODIA_DIR/lists-update.sh" update "$_lc" >/dev/null 2>&1 || true
    done
fi




if [ "$REFRESH_LISTS" = 1 ] && [ -f "$ENODIA_DIR/geo.sh" ] && [ -s "$ENODIA_STATE/geo/actions.tsv" ]; then
    echo "refresh geo categories"
    sh "$ENODIA_DIR/geo.sh" update >/dev/null 2>&1 || true


elif [ "$REFRESH_LISTS" = 1 ] && [ -f "$ENODIA_DIR/geo.sh" ] && [ -n "$(cat "$ENODIA_STATE"/geo/want/* 2>/dev/null | grep .)" ]; then
    echo "refresh categories wanted by other subsystems"
    sh "$ENODIA_DIR/geo.sh" wanted refresh >/dev/null 2>&1 || true
fi

echo "done"
