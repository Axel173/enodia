#!/bin/sh
































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}


ENODIA_BOOT=${ENODIA_BOOT:-/data/usr/app/enodia-boot}



if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi

if [ -f "$ENODIA_DIR/json-lib.sh" ]; then . "$ENODIA_DIR/json-lib.sh"; fi
if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v pid_runs >/dev/null 2>&1 || pid_runs() { [ -n "$1" ] && [ -d "/proc/$1" ]; }

command -v switch_hold >/dev/null 2>&1 || switch_hold() { ( set -C; echo $$ > "$1" ) 2>/dev/null; }

if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi
command -v carrier_iface >/dev/null 2>&1 || carrier_iface() { ip route show table 1000 2>/dev/null | awk '/^default/{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}'; }
command -v jlines >/dev/null 2>&1 || jlines() { cat >/dev/null; }
command -v bin_path   >/dev/null 2>&1 || bin_path()   { printf '%s' "$ENODIA_BIN/$1"; }
command -v bin_dest   >/dev/null 2>&1 || bin_dest()   { printf '%s' "$ENODIA_BIN/$1"; }
command -v bin_prune  >/dev/null 2>&1 || bin_prune()  { return 0; }
command -v store_ready >/dev/null 2>&1 || store_ready() { return 1; }
command -v store_root  >/dev/null 2>&1 || store_root()  { printf ''; }




command -v fs_anchor  >/dev/null 2>&1 || fs_anchor()  { _fan="${1:-$ENODIA_DIR}"; while [ -n "$_fan" ] && [ ! -e "$_fan" ]; do _fan="${_fan%/*}"; done; printf '%s' "${_fan:-/}"; }
command -v fs_line    >/dev/null 2>&1 || fs_line()    { df -k "$(fs_anchor "$1")" 2>/dev/null | tail -1 | awk '{for(i=NF;i>1;i--) if($i ~ /%$/) break; if(i>=4 && $(i-3) ~ /^[0-9]+$/ && $(i-1) ~ /^[0-9]+$/ && $(i-3)+0>0){m=""; for(j=i+1;j<=NF;j++){ if(j>i+1) m=m " "; m=m $j }; print $(i-3), $(i-1), m}}'; }
command -v fs_free_b  >/dev/null 2>&1 || fs_free_b()  { _fsb=$(fs_line "$1" | awk '{printf "%.0f", $2*1024}'); case "$_fsb" in ''|*[!0-9]*) _fsb=0 ;; esac; printf '%s' "$_fsb"; }
command -v fs_total_b >/dev/null 2>&1 || fs_total_b() { _fst=$(fs_line "$1" | awk '{printf "%.0f", $1*1024}'); case "$_fst" in ''|*[!0-9]*) _fst=0 ;; esac; printf '%s' "$_fst"; }
command -v fs_mount   >/dev/null 2>&1 || fs_mount()   { _fsm=$(fs_line "$1"); printf '%s' "${_fsm#* * }"; }


: "${BIN_DIR:=$ENODIA_DIR}"


: "${DATA_RESERVE_B:=2621440}"
GH="$ENODIA_DIR/gh-update.sh"
STATE="$ENODIA_STATE/.proto-install.state"
LOG="$ENODIA_STATE/.proto-install.log"




PLANF="$ENODIA_STATE/.proto-install.plan"
LOCK=/tmp/enodia-proto-install.lock



BGPID=/tmp/enodia-proto-install.pid
RESERVE_B="$DATA_RESERVE_B"   # 2.5 МБ неснижаемого запаса на /data (единственная цифра — в store-lib.sh)


PKGS="awg xray hy2 byedpi zapret doh tls filter"

log() { printf '[%s] %s\n' "$(date '+%H:%M:%S')" "$*" >> "$LOG"; }





set_state() { echo "$1" > "$STATE.new" && mv -f "$STATE.new" "$STATE"; }

pkg_known()  { case " $PKGS " in *" $1 "*) return 0 ;; esac; return 1; }
pkg_label()  { case "$1" in
        awg) echo "AmneziaWG" ;; xray) echo "Xray" ;; hy2) echo "Hysteria2" ;;
        byedpi) echo "ByeDPI" ;; zapret) echo "Zapret" ;;
        doh) echo "Шифрованный DNS" ;; tls) echo "HTTPS панели" ;; filter) echo "Фильтр по категориям" ;;
    esac; }

pkg_own()    { case "$1" in
        awg) echo "amneziawg-go awg" ;; xray) echo "xray" ;; hy2) echo "hysteria" ;;
        byedpi) echo "byedpi" ;; zapret) echo "nfqws" ;;
        doh) echo "https-dns-proxy dot-proxy" ;; tls) echo "panel-tls" ;; filter) echo "dns-filter" ;;
    esac; }

pkg_shared() { case "$1" in xray|hy2|byedpi) echo "hev" ;; esac; }

pkg_files()  { echo "$(pkg_own "$1") $(pkg_shared "$1")"; }

have_bin() { [ -x "$(bin_path "$1")" ]; }
in_list()  { case " $2 " in *" $1 "*) return 0 ;; esac; return 1; }









BST=""; BST_DONE=0
bst_load() { [ "$BST_DONE" = 1 ] && return 0; BST_DONE=1; [ -f "$GH" ] && BST=$(sh "$GH" bin-status 2>/dev/null); return 0; }
bst_field() { bst_load; printf '%s\n' "$BST" | awk -F'\t' -v n="$1" -v c="$2" '$1 == n { print $c; exit }'; }
bin_outdated() { [ "$(bst_field "$1" 2)" = outdated ]; }



bst_mark_fresh() { BST=$(printf '%s\n' "$BST" | awk -F'\t' -v OFS='\t' -v n="$1" '$1 == n && $2 == "outdated" { $2 = "current" } { print }'); }

pkg_upd_bin() { for b in $(pkg_files "$1"); do have_bin "$b" && bin_outdated "$b" && { echo "$b"; return 0; }; done; return 0; }





bin_needs() { ! have_bin "$2" || { [ "$1" != partial ] && bin_outdated "$2"; }; }

pkg_upd() {
    [ "$(pkg_state "$1")" = installed ] || return 1
    for b in $(pkg_files "$1"); do have_bin "$b" && bin_outdated "$b" && return 0; done
    return 1
}

pkg_run_old() { for b in $(pkg_files "$1"); do [ "$(bst_field "$b" 5)" = old ] && return 0; done; return 1; }

















RST_ORDER="doh zapret filter slot2 slot3 slot4 slot5 slot6 slot7 server warm-awg main tls"   # short cuts first; the main tunnel late, the panel's own HTTPS last

RST_PROC=/proc
RST_PIDDIR=/tmp
RST_HEALTH_TRIES=6
RST_HOLD_WAIT=120   # с: столько ждём, пока несущую ведёт сторож, heal или чужая смена (фон — ждать можно; перебор резервов дольше)
RST_HOLD_GAP=1      # с: пауза перед переспросом тика, уже взяв лок (щель между его гейтом и записью пида — разбор у switch_hold)



RST_OWNER_LOG=/tmp/enodia-pkg-restart.log


rst_slot_of() {   # $1 = id, $2… = транспорты, чей это демон → slot<id> | orphan
    _rsy=$(sh "$ENODIA_DIR/slots.sh" show "$1" 2>/dev/null); _rsyi=$1; shift
    if [ "$(printf '%s\n' "$_rsy" | cut -f6)" = on ]; then
        case " $* " in *" $(printf '%s\n' "$_rsy" | cut -f3) "*) echo "slot$_rsyi"; return 0 ;; esac
    fi
    echo orphan
}
rst_unit() {   # $1 = pid, $2 = бинарь, $3 = активный транспорт → main | warm-awg | slot<N> | server | zapret | doh | tls | orphan | (пусто)
    case "$2" in
        amneziawg-go)
            _rui=$(tr '\000' ' ' 2>/dev/null < "$RST_PROC/$1/cmdline" | awk '{ print $2 }')
            case "$_rui" in



                awg0)     case "$3" in ""|awg) echo main ;; *) echo warm-awg ;; esac ;;
                awg[2-7]) rst_slot_of "${_rui#awg}" awg ;;


                awgs0)    if sh "$ENODIA_DIR/vpn-server.sh" enabled >/dev/null 2>&1; then echo server; else echo orphan; fi ;;
            esac
            return 0 ;;
    esac
    for _ruf in "$RST_PIDDIR"/enodia-*.pid; do
        [ "$(tr -cd '0-9' < "$_ruf" 2>/dev/null)" = "$1" ] || continue
        _run=${_ruf#"$RST_PIDDIR"/enodia-}; _run=${_run%.pid}
        case "$_run" in


            xray|hysteria|byedpi|hev)
                case "$3:$_run" in xray:xray|xray:hev|hy2:hysteria|hy2:hev|byedpi:byedpi|byedpi:hev) echo main ;; *) echo orphan ;; esac ;;
            xray-s[2-7])     rst_slot_of "${_run##*-s}" xray ;;
            hysteria-s[2-7]) rst_slot_of "${_run##*-s}" hy2 ;;
            byedpi-s[2-7])   rst_slot_of "${_run##*-s}" byedpi ;;
            hev-s[2-7])      rst_slot_of "${_run##*-s}" xray hy2 byedpi ;;
            zapret-nfqws)    echo zapret ;;
            doh)             echo doh ;;
            panel-tls)       echo tls ;;
            dns-filter)      echo filter ;;
        esac
        return 0
    done
    return 0
}





RSS=""; RSU=""; RSS_T=""; RSS_DONE=0
rss_load() {
    [ "$RSS_DONE" = 1 ] && return 0; RSS_DONE=1
    RSS=""; [ -f "$GH" ] && RSS=$(sh "$GH" bin-stale 2>/dev/null)
    RSS_T=$(sh "$ENODIA_DIR/transport.sh" active 2>/dev/null)
    RSU=$(printf '%s\n' "$RSS" | while IFS="$(printf '\t')" read -r _rlq _rln; do
        [ -n "$_rlq" ] || continue
        _rlx=$(rst_unit "$_rlq" "$_rln" "$RSS_T"); _rlx=${_rlx:-other}
        case "$_rlx" in orphan|other) _rlk=- ;; *) _rlk=$(rst_comp "$_rlx" "$RSS_T"); _rlk=${_rlk:--} ;; esac
        printf '%s\t%s\t%s\t%s\n' "$_rlq" "$_rln" "$_rlx" "$_rlk"
    done)
    return 0
}




rst_comp() {   # $1 = unit, $2 = активный транспорт → id связки
    case "$1" in
        main)              echo "${2:-awg}" ;;
        warm-awg|server)   echo awg ;;
        slot[2-7])         sh "$ENODIA_DIR/slots.sh" show "${1#slot}" 2>/dev/null | cut -f3 ;;
        *)                 echo "$1" ;;
    esac
}
rst_scan() {   # $@ = связки → RST_UNITS (в порядке RST_ORDER), RST_ORPHAN (pid'ов без живого хозяина), RST_OTHER (не наших)
    RST_UNITS=""; RST_ORPHAN=0; RST_OTHER=0
    rss_load
    [ -n "$RSS" ] || return 0
    _rsc=" $* "
    _rsf=""; for _rsp in "$@"; do _rsf="$_rsf $(pkg_files "$_rsp")"; done


    _rsu=$(printf '%s\n' "$RSU" | while IFS="$(printf '\t')" read -r _rsq _rsn _rsx _rsk; do
        [ -n "$_rsq" ] || continue
        case "$_rsx" in
            orphan|other) case " $_rsf " in *" $_rsn "*) echo "$_rsx" ;; esac ;;
            *)            case "$_rsc" in *" $_rsk "*) echo "$_rsx" ;; esac ;;
        esac
    done)
    for _rso in $RST_ORDER; do
        printf '%s\n' "$_rsu" | grep -qxF "$_rso" && RST_UNITS="$RST_UNITS${RST_UNITS:+ }$_rso"
    done
    RST_ORPHAN=$(printf '%s\n' "$_rsu" | grep -cxF orphan || true)
    RST_OTHER=$(printf '%s\n' "$_rsu" | grep -cxF other || true)
    return 0
}
rst_label() { case "$1" in
        main) echo "основной канал" ;; warm-awg) echo "тёплый резерв AmneziaWG" ;; server) echo "«доступ домой»" ;;
        slot[2-7]) echo "дополнительный выход №${1#slot}" ;; zapret) echo "Zapret (nfqws)" ;;
        doh) echo "шифрованный DNS" ;; tls) echo "HTTPS панели" ;; filter) echo "фильтр по категориям" ;; *) echo "$1" ;;
    esac; }




rst_can() { [ "$1" != main ] || [ -n "$(carrier_iface)" ]; }

rst_slot_iface() { _rsi=$(sh "$ENODIA_DIR/transport.sh" slot-iface "$1" 2>/dev/null); [ -n "$_rsi" ] && ip link show "$_rsi" >/dev/null 2>&1; }











rst_works() {   # $1 = unit
    case "$1" in
        main|slot[2-7])
            _rwn=0
            while [ "$_rwn" -lt "$RST_HEALTH_TRIES" ]; do
                if [ "$1" = main ]; then HEALTH_OWN_LOCK=1 sh "$ENODIA_DIR/transport.sh" health >/dev/null 2>&1; _rwc=$?
                else HEV_CHECK=0 sh "$ENODIA_DIR/transport.sh" slot-health "${1#slot}" >/dev/null 2>&1; _rwc=$?
                     [ "$_rwc" = 2 ] && rst_slot_iface "${1#slot}" && _rwc=0; fi
                [ "$_rwc" = 0 ] && return 0
                sleep 2; _rwn=$((_rwn + 1))
            done
            return 1 ;;
    esac
    return 0
}
rst_one() {   # $1 = unit → код владельца (0 — перезапустил и своё проверил)
    log "Перезапускаю: $(rst_label "$1")…"
    echo "=== $(date '+%H:%M:%S') $1" >> "$RST_OWNER_LOG" 2>/dev/null
    case "$1" in
        doh)       sh "$ENODIA_DIR/doh-lib.sh" restart >> "$RST_OWNER_LOG" 2>&1 ;;
        zapret)    sh "$ENODIA_DIR/zapret.sh" reload >> "$RST_OWNER_LOG" 2>&1 ;;                   # nfqws only: rules and set stay
        slot[2-7]) sh "$ENODIA_DIR/transport.sh" slot-down "${1#slot}" >> "$RST_OWNER_LOG" 2>&1
                   sh "$ENODIA_DIR/transport.sh" slot-up "${1#slot}" >> "$RST_OWNER_LOG" 2>&1 ;;
        server)    sh "$ENODIA_DIR/vpn-server.sh" restart >> "$RST_OWNER_LOG" 2>&1 ;;

        warm-awg)  sh "$ENODIA_DIR/transport.sh" rewarm awg >> "$RST_OWNER_LOG" 2>&1 ;;
        main)      sh "$ENODIA_DIR/transport.sh" restart >> "$RST_OWNER_LOG" 2>&1 ;;
        tls)       sh "$ENODIA_DIR/web-ui.sh" tls-reload >> "$RST_OWNER_LOG" 2>&1 ;;
        filter)    sh "$ENODIA_DIR/access-sched.sh" filter-restart >> "$RST_OWNER_LOG" 2>&1 ;;
        *)         return 1 ;;
    esac
}



rst_agreed() { [ -z "$RST_OK" ] && return 0; case " $RST_OK " in *" $1 "*) return 0 ;; esac; return 1; }
cmd_restart() {   # $1 = связки через запятую («-» = все), [$2 = владельцы, на чей перерыв согласились, через запятую; пусто — все]
    : > "$LOG"; set_state RUNNING; : > "$RST_OWNER_LOG" 2>/dev/null
    _rp=$(printf '%s' "${1:--}" | tr ',' ' ')
    [ "$_rp" = - ] && _rp=$PKGS
    for p in $_rp; do pkg_known "$p" || { set_state FAIL; log "Отказ: неизвестный компонент: $p"; return 1; }; done
    RST_OK=$(printf '%s' "$2" | tr ',' ' ')


    _rpa=""; for p in $_rp; do rst_scan "$p"; [ -n "$RST_UNITS" ] && _rpa="$_rpa${_rpa:+,}$p"; done
    printf -- '-\t-\t-\t%s\n' "${_rpa:-$(printf '%s' "$_rp" | tr ' ' ',')}" > "$PLANF" 2>/dev/null
    rst_scan $_rp
    if [ -n "$RST_UNITS" ]; then


        SWITCH_LOCK=$SWLOCK

        if [ -e "$SWLOCK" ] || { command -v carrier_busy >/dev/null 2>&1 && carrier_busy; }; then
            log "Жду, пока роутер закончит свою работу с туннелем (проверка сторожа, восстановление или другая смена), — до $((RST_HOLD_WAIT / 60)) мин"
        fi
        if ! switch_hold "$SWLOCK" "$RST_HOLD_WAIT" "$RST_HOLD_GAP"; then
            set_state FAIL
            log "Роутер сейчас сам ведёт туннель (проверка сторожа, восстановление или другая смена) — ничего не перезапускал, повторите через пару минут"
            return 1
        fi
        SWMINE=1
        RSS_DONE=0; rst_scan $_rp   # the world may have changed while we waited
    fi
    if [ -z "$RST_UNITS" ]; then
        set_state OK
        if [ "$RST_ORPHAN" -gt 0 ]; then
            log "Без хозяина, на прежней сборке: $RST_ORPHAN (демон выключенного выхода или прежнего транспорта) — уйдёт с перезагрузкой роутера"
        else
            log "Перезапускать нечего: все процессы уже работают на установленных сборках."
        fi
        return 0
    fi


    _rgo=""; _rskip=""; _rhold=""
    for u in $RST_UNITS; do
        if ! rst_can "$u"; then _rhold="$_rhold${_rhold:+, }$(rst_label "$u")"
        elif rst_agreed "$u"; then _rgo="$_rgo${_rgo:+ }$u"
        else _rskip="$_rskip${_rskip:+, }$(rst_label "$u")"; fi
    done
    _rl=""; for u in $_rgo; do _rl="$_rl${_rl:+, }$(rst_label "$u")"; done
    [ -n "$_rl" ] && log "Перезапуск на установленной сборке: $_rl"
    [ "$RST_ORPHAN" -gt 0 ] && log "Без хозяина, на прежней сборке: $RST_ORPHAN (демон выключенного выхода или прежнего транспорта) — уйдёт с перезагрузкой роутера"
    [ "$RST_OTHER" -gt 0 ] && log "Ещё процессов на прежней сборке, не наших: $RST_OTHER (разовая проверка сервера) — закончатся сами"


    _rrc=0; _rbad=""; _rnot=""

    if [ -n "$_rhold" ]; then
        log "Основной канал не трогаю: сейчас он не везёт трафик (прямой режим сторожа или подъём туннеля). Перезапустите, когда туннель вернётся."
        _rrc=1; _rnot=$_rhold
    fi
    if [ -n "$_rskip" ]; then
        log "Не трогаю без вашего согласия: $_rskip — экран о нём не спрашивал; нажмите «Перезапустить» ещё раз"
        _rrc=1; _rnot="$_rnot${_rnot:+, }$_rskip"
    fi
    for u in $_rgo; do
        rst_one "$u"; _rorc=$?

        RSS_DONE=0; rst_scan $_rp
        case " $RST_UNITS " in
            *" $u "*) log "Не вышло: $(rst_label "$u") — всё ещё на прежней сборке"; _rrc=1; _rbad="$_rbad${_rbad:+, }$(rst_label "$u")" ;;
            *) if [ "$_rorc" != 0 ]; then
                   log "Не вышло: $(rst_label "$u") — после перезапуска не работает (подробности — в диагностике роутера)"; _rrc=1; _rbad="$_rbad${_rbad:+, }$(rst_label "$u")"
               elif rst_works "$u"; then log "Готово: $(rst_label "$u") — на установленной сборке"
               else log "Перезапущено, но не отвечает: $(rst_label "$u") — сторож проверит и починит на своём тике"; _rrc=1; _rbad="$_rbad${_rbad:+, }$(rst_label "$u")"; fi ;;
        esac
    done
    _rtail=""; [ -n "$_rnot" ] && _rtail="; не трогал: $_rnot"
    if [ "$_rrc" = 0 ]; then set_state OK; log "Готово: всё перезапущено на установленных сборках."
    elif [ -n "$_rbad" ]; then set_state FAIL; log "Перезапуск не удался: $_rbad$_rtail"
    else set_state FAIL; log "Перезапущено не всё — не трогал: $_rnot"; fi
    return $_rrc
}







pkg_state() {
    _n=0; _h=0
    for b in $(pkg_own "$1");   do _n=$((_n+1)); have_bin "$b" && _h=$((_h+1)); done
    [ "$_h" = 0 ] && { echo absent; return 0; }
    for b in $(pkg_shared "$1"); do _n=$((_n+1)); have_bin "$b" && _h=$((_h+1)); done
    if [ "$_h" = "$_n" ]; then echo installed; else echo partial; fi
}





slot_carriers() { [ -f "$ENODIA_DIR/slots.sh" ] && sh "$ENODIA_DIR/slots.sh" carriers 2>/dev/null; }
slot_uses() { slot_carriers | grep -qx "$1"; }







pkg_hold() {







    if [ "$(pkg_state "$1")" = absent ]; then return 0; fi
    _t=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
    case "$1" in
        awg|xray|hy2|byedpi|zapret)
            [ "$_t" = "$1" ] && { echo "несёт трафик прямо сейчас — сперва переключите транспорт"; return 0; }
            slot_uses "$1" && { echo "несёт дополнительный выход — сперва уберите его в «Дополнительных выходах»"; return 0; }
            ;;
    esac
    case "$1" in
        awg) [ -f "$ENODIA_STATE/server/.on" ] && { echo "нужен для «доступа домой» (сервер awgs0 — тот же демон)"; return 0; } ;;



        zapret) [ -s "$ENODIA_STATE/.desync-ips" ] && { echo "его держат устройства «целиком в десинк» ($(grep -c . "$ENODIA_STATE/.desync-ips" 2>/dev/null)) — сперва верните им обычный режим"; return 0; } ;;
        doh) [ "$(cat "$ENODIA_STATE/.doh-on" 2>/dev/null)" = on ] && { echo "включён шифрованный DNS — сперва выключите"; return 0; }




             [ -f "$ENODIA_DIR/doh-lib.sh" ] && ( . "$ENODIA_DIR/doh-lib.sh"; doh_auto_active ) 2>/dev/null && \
                 { echo "шифрованный DNS сейчас держит DNS сети сам (прямой режим) — сперва выключите «Включать само в прямых режимах»"; return 0; } ;;
        tls) [ -f "$ENODIA_STATE/.panel-tls" ] && { echo "включён HTTPS панели — снимете и потеряете вход"; return 0; } ;;

        filter) if [ -f "$ENODIA_DIR/access-sched.sh" ] && sh "$ENODIA_DIR/access-sched.sh" uses-filter >/dev/null 2>&1; then
                    echo "его держат расписания с «ограничено» — сперва уберите из них «ограничено»"; return 0
                fi ;;
    esac
    return 0
}








pkg_warn() {
    [ "$(pkg_state "$1")" = absent ] && return 0
    case "$1" in
        zapret) [ -f "$ENODIA_DIR/zapret.sh" ] || return 0
                sh "$ENODIA_DIR/zapret.sh" nfq-ok >/dev/null 2>&1 || [ "$?" = 2 ] || \
                    echo "на этом роутере не заработает: ядро без NFQUEUE (десинк без VPS здесь даёт ByeDPI)" ;;
    esac
    return 0
}












pkg_add_b() {       # $1 = связка, $2 = scope (пусто | data)
    _s=0; _pas=$(pkg_state "$1")
    for b in $(pkg_files "$1"); do
        bin_needs "$_pas" "$b" || continue
        if [ "$2" = data ] && [ "$(bin_dest "$b")" != "$ENODIA_BIN/$b" ]; then continue; fi
        _n=$(sh "$GH" bin-size "$b" 2>/dev/null | tr -d ' \r'); case "$_n" in ''|*[!0-9]*) _n=0 ;; esac
        _s=$((_s+_n))
    done
    echo "$_s"
}


pkg_del_b() {       # $1 = связка, $2 = ВЕСЬ список снимаемых (ref-count для hev), $3 = scope,

    _s=0
    for b in $(pkg_own "$1"); do
        _p=$(bin_path "$b"); [ -f "$_p" ] || continue
        if [ "$3" = data ] && [ "$_p" != "$ENODIA_BIN/$b" ]; then continue; fi
        _n=$(stat -c%s "$_p" 2>/dev/null); case "$_n" in ''|*[!0-9]*) _n=0 ;; esac
        _s=$((_s+_n))
    done
    _hp=$(bin_path hev)
    if [ "$4" != 1 ] && [ -n "$(pkg_shared "$1")" ] && [ -f "$_hp" ] && ! hev_needed_after "$2"; then
        if [ "$3" != data ] || [ "$_hp" = "$ENODIA_BIN/hev" ]; then
            _n=$(stat -c%s "$_hp" 2>/dev/null); case "$_n" in ''|*[!0-9]*) _n=0 ;; esac
            _s=$((_s+_n))
        fi
    fi
    echo "$_s"
}

hev_needed_after() {   # $1 = список снимаемых; 0 = hev ещё нужен


    for p in $P_INS; do case "$p" in xray|hy2|byedpi) return 0 ;; esac; done
    for p in xray hy2 byedpi; do
        in_list "$p" "$1" && continue
        for b in $(pkg_own "$p"); do have_bin "$b" && return 0; done
    done
    for c in $(slot_carriers); do
        case "$c" in xray|hy2|byedpi) return 0 ;; esac
    done
    return 1
}






disk_free_b()  { fs_free_b  "$ENODIA_DIR"; }



ram_room_b() {
    _rrt=$(fs_free_b /tmp)
    _rra=$(awk '/^MemAvailable:/{a=$2}/^MemFree:/{f=$2}END{printf "%.0f", (a==""?f:a)*1024}' "${MEMINFO:-/proc/meminfo}" 2>/dev/null)
    case "$_rra" in ''|*[!0-9]*) _rra=0 ;; esac
    [ "$_rra" -lt "$_rrt" ] && _rrt=$_rra
    printf '%s' "$_rrt"
}
PF_MARGIN_B=33554432   # 32 МБ сверх скачиваемого остаются демонам (xray, dnsmasq) и самой установке
disk_total_b() { fs_total_b "$ENODIA_DIR"; }



disk_mount()   { fs_mount "$ENODIA_DIR"; }






disk_on_store() { [ "$(disk_mount)" != "$(fs_mount "$ENODIA_BOOT")" ] && echo true || echo false; }


store_free_b() {
    if store_ready; then fs_free_b "$(store_root)"
    else echo 0; fi
}
STORE_RESERVE_B=16777216

norm_list()    { printf '%s' "$1" | tr ',' ' ' | tr -s ' ' | sed 's/^ *//; s/ *$//; s/^-$//'; }


mb() { _v=${1:-0}; _sg=""; [ "$_v" -lt 0 ] && { _sg="-"; _v=$((0-_v)); }; echo "$_sg$((_v/1048576)).$(( (_v%1048576)*10/1048576 ))"; }




cmd_list_json() {
    bst_load



    _arch=$(sh "$GH" bin-arch 2>/dev/null | tr -cd 'a-z0-9')
    _stgj=$(sh "$GH" bin-staged 2>/dev/null | awk '/^[a-z0-9-]+$/ { printf "%s\"%s\"", s, $0; s="," }')
    printf '{"engine":true,"reserve_b":%s,"free_b":%s,"total_b":%s,"mount":"%s","on_store":%s,"now":%s,"arch":"%s","staged":[%s],"pkgs":[' "$RESERVE_B" "$(disk_free_b)" "$(disk_total_b)" "$(disk_mount)" "$(disk_on_store)" "$(date +%s)" "$_arch" "$_stgj"
    _first=1
    for p in $PKGS; do
        _st=$(pkg_state "$p"); _hold=$(pkg_hold "$p"); _warn=$(pkg_warn "$p")
        _ver=$(sh "$GH" bin-ver "$(pkg_own "$p" | cut -d' ' -f1)" 2>/dev/null | tr -d ' \r')


        _cur=$(bst_field "$(pkg_own "$p" | cut -d' ' -f1)" 3 | tr -d '"\\\r')
        _upd=false; pkg_upd "$p" && _upd=true



        _ub=""; _uc=""; _uv=""
        if [ "$_upd" = true ]; then _ub=$(pkg_upd_bin "$p"); _uc=$(bst_field "$_ub" 3 | tr -d '"\\\r'); _uv=$(bst_field "$_ub" 4 | tr -d '"\\\r'); fi




        _ro=false; _rsj=""
        if [ "$_st" != absent ] && pkg_run_old "$p"; then
            rst_scan "$p"
            if [ -n "$RST_UNITS" ] || [ "$RST_ORPHAN" -gt 0 ] || [ "$RST_OTHER" -gt 0 ]; then _ro=true; fi
            for _rsu1 in $RST_UNITS; do rst_can "$_rsu1" && _rsj="$_rsj${_rsj:+,}\"$_rsu1\""; done
        fi
        _need=""; for b in $(pkg_files "$p"); do bin_needs "$_st" "$b" && _need="$_need${_need:+,}\"$b\""; done
        [ "$_first" = 1 ] || printf ','
        _first=0





        printf '{"id":"%s","label":"%s","state":"%s","ver":"%s","cur":"%s","upd":%s,"ub":"%s","ucur":"%s","uver":"%s","run_old":%s,"rst_units":[%s],"need":[%s],"add_b":%s,"add_data_b":%s,"del_b":%s,"del_data_b":%s,"hold":"%s","warn":"%s"}' \
            "$p" "$(pkg_label "$p")" "$_st" "$_ver" "$_cur" "$_upd" "$_ub" "$_uc" "$_uv" "$_ro" "$_rsj" "$_need" \
            "$(pkg_add_b "$p")" "$(pkg_add_b "$p" data)" \
            "$(pkg_del_b "$p" "$p")" "$(pkg_del_b "$p" "$p" data)" "$_hold" "$_warn"
    done
    printf ']}\n'
}





plan_calc() {       # $1 = ставим, $2 = снимаем
    bst_load
    P_INS=$(norm_list "$1"); P_DEL=$(norm_list "$2")
    P_ERR=""; P_BLOCK=""; P_NEED=0; P_FREED=0; P_UNK=0; P_NEED_ST=0; P_FREED_ST=0; P_TAKES=0; P_SHORT=0; P_UPD=""; P_FILES=""; _pcnt=" "
    for p in $P_INS; do
        pkg_known "$p" || { P_ERR="$P_ERR неизвестный компонент: $p"; continue; }
        in_list "$p" "$P_DEL" && { P_ERR="$P_ERR $p указан и на установку, и на удаление"; continue; }


        _pst=$(pkg_state "$p")
        [ "$_pst" = installed ] && pkg_upd "$p" && P_UPD="$P_UPD${P_UPD:+ }$p"






        for b in $(pkg_files "$p"); do
            bin_needs "$_pst" "$b" || continue
            case "$_pcnt" in *" $b "*) continue ;; esac
            _pcnt="$_pcnt$b "
            _n=$(sh "$GH" bin-size "$b" 2>/dev/null | tr -d ' \r'); case "$_n" in ''|*[!0-9]*) _n=0 ;; esac
            [ "$_n" = 0 ] && P_UNK=1
            if [ "$(bin_dest "$b")" = "$ENODIA_BIN/$b" ]; then P_NEED=$((P_NEED + _n)); else P_NEED_ST=$((P_NEED_ST + _n)); fi
        done
    done



    P_FILES=$_pcnt




    _hevdone=0
    for p in $P_DEL; do
        pkg_known "$p" || { P_ERR="$P_ERR неизвестный компонент: $p"; continue; }
        _h=$(pkg_hold "$p")
        [ -n "$_h" ] && { P_BLOCK="$P_BLOCK|$p: $_h"; continue; }
        _a=$(pkg_del_b "$p" "$P_DEL" "" "$_hevdone"); _d=$(pkg_del_b "$p" "$P_DEL" data "$_hevdone")
        P_FREED=$((P_FREED + _d)); P_FREED_ST=$((P_FREED_ST + _a - _d))
        if [ "$_hevdone" = 0 ] && [ -n "$(pkg_shared "$p")" ] && [ -f "$(bin_path hev)" ] \
           && ! hev_needed_after "$P_DEL"; then _hevdone=1; fi
    done
    P_FREE=$(disk_free_b); case "$P_FREE" in ''|*[!0-9]*) P_FREE=0 ;; esac
    P_LEFT=$((P_FREE + P_FREED - P_NEED))
    P_OK=1
    [ -n "$P_ERR" ] && P_OK=0
    [ -n "$P_BLOCK" ] && P_OK=0







    P_TAKES=$((P_NEED - P_FREED))
    if [ "$P_TAKES" -gt 0 ] && [ "$P_LEFT" -lt "$RESERVE_B" ]; then
        P_OK=0
        P_SHORT=$((RESERVE_B - P_LEFT))
    fi


    P_SFREE=0; P_SLEFT=0
    if [ "$P_NEED_ST" -gt 0 ] || [ "$P_FREED_ST" -gt 0 ]; then
        P_SFREE=$(store_free_b); case "$P_SFREE" in ''|*[!0-9]*) P_SFREE=0 ;; esac
        P_SLEFT=$((P_SFREE + P_FREED_ST - P_NEED_ST))
        if [ "$P_NEED_ST" -gt 0 ] && [ "$P_SLEFT" -lt "$STORE_RESERVE_B" ]; then
            P_ERR="$P_ERR на внешнем накопителе не хватает места"
            P_OK=0
        fi
    fi
}







cmd_plan() {
    plan_calc "$1" "$2"


    printf '{"ok":%s,"free_b":%s,"need_b":%s,"freed_b":%s,"left_b":%s,"reserve_b":%s,"short_b":%s,"mount":"%s","unknown":%s,"upd":"%s"' \
        "$([ "$P_OK" = 1 ] && echo true || echo false)" "$P_FREE" "$P_NEED" "$P_FREED" "$P_LEFT" "$RESERVE_B" \
        "$P_SHORT" "$(disk_mount)" \
        "$([ "$P_UNK" = 1 ] && echo true || echo false)" "$P_UPD"
    printf ',"store":%s,"need_store_b":%s,"freed_store_b":%s,"store_free_b":%s' \
        "$(store_ready && echo true || echo false)" "$P_NEED_ST" "$P_FREED_ST" "$P_SFREE"
    printf ',"errors":['
    [ -n "$P_ERR" ] && printf '"%s"' "$(printf '%s' "$P_ERR" | sed 's/^ *//')"
    printf '],"blocked":['
    _f=1
    if [ -n "$P_BLOCK" ]; then



        printf '%s\n' "$P_BLOCK" | tr '|' '\n' | while IFS= read -r b; do
            [ -n "$b" ] || continue
            [ "$_f" = 1 ] || printf ','
            _f=0
            printf '{"id":"%s","why":"%s"}' "${b%%:*}" "$(printf '%s' "${b#*: }")"
        done
    fi
    printf '],"free_candidates":['
    _f=1
    for p in $PKGS; do
        [ "$(pkg_state "$p")" = absent ] && continue
        [ -n "$(pkg_hold "$p")" ] && continue
        in_list "$p" "$P_DEL" && continue
        in_list "$p" "$P_INS" && continue




        _d=$(pkg_del_b "$p" "$p" data); [ "$_d" -gt 0 ] || continue
        [ "$_f" = 1 ] || printf ','
        _f=0
        printf '{"id":"%s","label":"%s","del_b":%s}' "$p" "$(pkg_label "$p")" "$_d"
    done
    printf ']}\n'
}







pkg_pids() { case "$1" in
        xray) echo /tmp/enodia-xray.pid ;; hy2) echo /tmp/enodia-hysteria.pid ;; byedpi) echo /tmp/enodia-byedpi.pid ;;
        doh) echo /tmp/enodia-doh.pid ;; tls) echo /tmp/enodia-panel-tls.pid ;; filter) echo /tmp/enodia-dns-filter.pid ;;
    esac; }
kill_by_pidfile() { [ -f "$1" ] || return 0; start-stop-daemon -K -p "$1" >/dev/null 2>&1; rm -f "$1"; return 0; }

do_remove() {       # $1 = связка, $2 = весь список снимаемых
    log "Снимаю $(pkg_label "$1")…"




    if [ "$1" = zapret ]; then
        [ -f "$ENODIA_DIR/zapret.sh" ] && sh "$ENODIA_DIR/zapret.sh" remove >> "$LOG" 2>&1
        return 0
    fi
    for _pf in $(pkg_pids "$1"); do kill_by_pidfile "$_pf"; done



    for b in $(pkg_own "$1"); do
        rm -f "$ENODIA_BIN/$b"
        [ "$BIN_DIR" != "$ENODIA_BIN" ] && rm -f "$BIN_DIR/$b"
    done
    if [ -n "$(pkg_shared "$1")" ] && ! hev_needed_after "$2"; then
        log "hev больше никому не нужен — снимаю"
        kill_by_pidfile /tmp/enodia-hev.pid
        rm -f "$ENODIA_BIN/hev"
        [ "$BIN_DIR" != "$ENODIA_BIN" ] && rm -f "$BIN_DIR/hev"
    fi
    return 0
}
do_install() {      # $1 = связка
    if in_list "$1" "$P_UPD"; then log "Обновляю $(pkg_label "$1")…"; else log "Ставлю $(pkg_label "$1")…"; fi
    if [ "$1" = zapret ]; then

        [ -f "$ENODIA_DIR/zapret.sh" ] || { log "нет zapret.sh — обновите скрипты"; I_WHY=${I_WHY:-"нет zapret.sh — обновите скрипты"}; return 1; }



        _zu=""; bin_outdated nfqws && _zu=update
        if ! sh "$ENODIA_DIR/zapret.sh" install $_zu >> "$LOG" 2>&1; then
            _zw=$(grep '^\[zapret\] FAIL: ' "$LOG" 2>/dev/null | tail -n 1 | sed 's/^\[zapret\] FAIL: //')
            log "zapret не установился"; I_WHY=${I_WHY:-${_zw:-"zapret не установился"}}; return 1
        fi



        if in_list zapret "$P_UPD"; then
            bst_mark_fresh nfqws
            _ro=$(sh "$GH" bin-status nfqws 2>/dev/null | awk -F'\t' '$5 == "old" { print $1 }')
            if [ -n "$_ro" ]; then log "Zapret обновлён. Сейчас работает прежняя сборка (nfqws) — новая заработает после перезапуска компонента: кнопка «Перезапустить» в его строке, а где её нет — перезагрузка роутера."
            else log "Zapret обновлён."; fi
            return 0
        fi


        if sh "$ENODIA_DIR/zapret.sh" nfq-ok >/dev/null 2>&1; then log "Zapret установлен. Включить — в «Соединение → Транспорт»."
        else log "Zapret установлен, но ядро роутера без NFQUEUE — включить его здесь нельзя."; fi
        return 0
    fi
    _upd_b=""
    for b in $(pkg_files "$1"); do

        in_list "$b" "$P_FILES" || continue
        { ! have_bin "$b" || bin_outdated "$b"; } || continue
        if have_bin "$b"; then

            _bc=$(bst_field "$b" 3); _ba=$(bst_field "$b" 4)
            log "Обновляю $b: ${_bc:-прежняя сборка} → ${_ba:-свежая сборка}…"; _upd_b="$_upd_b $b"
        elif in_list "$b" "$_stg"; then
            log "Ставлю $b из файла, загруженного с компьютера…"   # «Скачиваю» было бы неправдой: сети этот шаг не касается
        elif [ "$PF_ON" = 1 ] && in_list "$b" "$PF_LIST"; then
            log "Ставлю $b (скачан заранее)…"
        else
            log "Скачиваю $b…"
        fi





        _dst=$(bin_dest "$b")
        mkdir -p "${_dst%/*}" 2>/dev/null


        if ! sh "$GH" fetch-bin "$b" "$_dst" >> "$LOG" 2>&1; then
            _fw=$(grep '^\[fetch-bin\] FAIL: ' "$LOG" 2>/dev/null | tail -n 1 | sed 's/^\[fetch-bin\] FAIL: //')
            log "не скачал $b"; I_WHY=${I_WHY:-${_fw:-"не скачал $b"}}; return 1
        fi
        bin_prune "$b"
        bst_mark_fresh "$b"
        [ "$_dst" = "$ENODIA_BIN/$b" ] || log "  $b лёг на внешний накопитель"
    done



    if [ -n "$_upd_b" ] && [ -f "$GH" ]; then
        _ro=$(sh "$GH" bin-status $_upd_b 2>/dev/null | awk -F'\t' '$5 == "old" { printf "%s%s", s, $1; s=", " }')
        [ -n "$_ro" ] && log "Сейчас работает прежняя сборка ($_ro) — новая заработает после перезапуска компонента: кнопка «Перезапустить» в его строке, а где её нет — перезагрузка роутера."
    fi


    in_list "$1" "$P_UPD" && return 0
    case "$1" in

        awg|xray|hy2) log "$(pkg_label "$1") установлен. Включить — в «Соединение → Транспорт» (нужен активный конфиг)." ;;
        byedpi) log "ByeDPI установлен. Включить — в «Соединение → Транспорт»." ;;
        doh) log "Компоненты шифрованного DNS установлены. Включить — в «Сеть → Шифрованный DNS»." ;;
        tls) log "Компонент HTTPS установлен. Включить — в «Панель → Доступ к панели»." ;;
        filter) log "Фильтр по категориям установлен. Действует в окнах «ограничено» — «Маршрутизация → Расписания доступа»." ;;
    esac
    return 0
}

cmd_apply() {
    : > "$LOG"; set_state RUNNING



    _pu=-
    if [ -f "$PLANF" ]; then
        IFS="$(printf '\t')" read -r _pa _pd _pc < "$PLANF" 2>/dev/null
        [ "$_pa" = "${1:--}" ] && [ "$_pd" = "${2:--}" ] && [ -n "$_pc" ] && _pu=$_pc
    fi
    printf '%s\t%s\t%s\n' "${1:--}" "${2:--}" "$_pu" > "$PLANF" 2>/dev/null
    plan_calc "$1" "$2"


    printf '%s\t%s\t%s\n' "${1:--}" "${2:--}" "$(printf '%s' "${P_UPD:--}" | tr ' ' ',')" > "$PLANF" 2>/dev/null
    log "План: ставим [${P_INS:-—}], снимаем [${P_DEL:-—}]${P_UPD:+, из них обновляем [$P_UPD]}"
    if [ -n "$P_ERR" ]; then set_state FAIL; log "Отказ:$P_ERR"; return 1; fi
    if [ -n "$P_BLOCK" ]; then
        set_state FAIL
        printf '%s\n' "$P_BLOCK" | tr '|' '\n' | while IFS= read -r b; do [ -n "$b" ] && log "Нельзя снять $b"; done
        return 1
    fi
    log "Свободно $(mb "$P_FREE") МБ; освободим $(mb "$P_FREED"), займём $(mb "$P_NEED"), останется $(mb "$P_LEFT") МБ"
    [ "$P_NEED_ST" -gt 0 ] && log "На внешний накопитель уедет $(mb "$P_NEED_ST") МБ (свободно там $(mb "$P_SFREE") МБ) — флеш это не тронет"
    [ "$P_UNK" = 1 ] && log "ВНИМАНИЕ: размеры части файлов неизвестны (нет bin-manifest.txt) — оценка занятого НЕПОЛНАЯ."



    if [ "$P_SHORT" -gt 0 ]; then
        set_state FAIL
        log "Не хватает места: после операции осталось бы $(mb "$P_LEFT") МБ при неснижаемом резерве $(mb "$RESERVE_B") МБ. Снимите что-нибудь ещё."
        return 1
    fi











    _stg=""; [ -f "$GH" ] && _stg=$(sh "$GH" bin-staged 2>/dev/null | tr '\n' ' ')
    _cov=1; for b in $P_FILES; do in_list "$b" "$_stg" || _cov=0; done
    if [ -n "$P_INS" ] && [ -f "$GH" ] && [ "$_cov" = 1 ]; then


        case "$P_FILES" in *[!\ ]*) log "Нужные файлы загружены с компьютера — GitHub не спрашиваю." ;; esac
    elif [ -n "$P_INS" ] && [ -f "$GH" ]; then
        _why=$(sh "$GH" reachable 2>/dev/null)
        if [ "$?" != 0 ]; then
            [ -n "$_why" ] || _why="GitHub недоступен — проверьте интернет"
            set_state FAIL; log "$_why. НИЧЕГО не тронул."; return 1
        fi
    fi







    PF_LIST=""; PF_ON=0   # не `_pf`: так зовётся цикл пидфайлов в do_remove, и снятие затирало бы этот список


    [ -f "$GH" ] && sh "$GH" bin-unprefetch >/dev/null 2>&1
    for b in $P_FILES; do in_list "$b" "$_stg" || PF_LIST="$PF_LIST $b"; done
    if [ -n "$P_INS" ] && [ -f "$GH" ] && [ -n "$PF_LIST" ]; then
        _pfn=0
        for b in $PF_LIST; do _pfs=$(sh "$GH" bin-size "$b" 2>/dev/null | tr -d ' \r'); case "$_pfs" in ''|*[!0-9]*) _pfs=0 ;; esac; _pfn=$((_pfn + _pfs)); done
        _pfr=$(ram_room_b)
        if [ "$_pfr" -lt $((_pfn + PF_MARGIN_B)) ]; then
            log "Заранее не скачать: в ОЗУ свободно $(mb "$_pfr") МБ, нужно $(mb "$_pfn") МБ и запас — качаю по ходу установки, как прежде."
        else
            PF_ON=1
            for b in $PF_LIST; do
                log "Скачиваю заранее: $b…"
                if ! sh "$GH" bin-prefetch "$b" >> "$LOG" 2>&1; then
                    _fw=$(grep '^\[fetch-bin\] FAIL: ' "$LOG" 2>/dev/null | tail -n 1 | sed 's/^\[fetch-bin\] FAIL: //')
                    set_state FAIL; log "Не скачал $b: ${_fw:-причина в журнале операции}. НИЧЕГО не тронул."; return 1
                fi
            done
            log "Всё нужное скачано — меняю набор."
        fi
    fi
    for p in $P_DEL; do do_remove "$p" "$P_DEL"; done
    [ -n "$P_DEL" ] && sync 2>/dev/null
    _rc=0; I_WHY=""
    for p in $P_INS; do do_install "$p" || _rc=1; done
    if [ "$_rc" = 0 ]; then
        set_state OK; log "Готово. Свободно $(mb "$(disk_free_b)") МБ."
    else


        set_state FAIL; log "Часть компонентов не установилась: ${I_WHY:-причина в журнале операции}"
    fi
    return $_rc
}







pkg_pid_ours() { pid_runs "$1" 'packages\.sh|proto-install\.sh'; }
busy_calc() {
    _bs=$(cat "$STATE" 2>/dev/null | tr -cd 'A-Z'); [ -n "$_bs" ] || _bs=IDLE
    _bp=$(cat "$LOCK/pid" 2>/dev/null | tr -cd '0-9')


    pkg_pid_ours "$_bp" || _bp=$(cat "$BGPID" 2>/dev/null | tr -cd '0-9')
    _br=false
    [ "$_bs" = RUNNING ] && pkg_pid_ours "$_bp" && _br=true


    _bi=""; _bd=""; _bu=""; _brs=""
    if [ -f "$PLANF" ]; then
        IFS="$(printf '\t')" read -r _bi _bd _bu _brs < "$PLANF" 2>/dev/null
        _bi=$(printf '%s' "$_bi" | tr ',' ' ' | tr -cd 'a-z0-9 -'); _bd=$(printf '%s' "$_bd" | tr ',' ' ' | tr -cd 'a-z0-9 -')
        _bu=$(printf '%s' "$_bu" | tr ',' ' ' | tr -cd 'a-z0-9 -'); _brs=$(printf '%s' "$_brs" | tr ',' ' ' | tr -cd 'a-z0-9 -')
    fi
    return 0
}




cmd_op_json() {
    busy_calc
    _at=$(stat -c %Y "$LOG" 2>/dev/null); case "$_at" in ''|*[!0-9]*) _at=0 ;; esac
    printf '{"running":%s,"state":"%s","ins":"%s","del":"%s","upd":"%s","rst":"%s","at":%s,"now":%s,"log":[' "$_br" "$_bs" "$_bi" "$_bd" "$_bu" "$_brs" "$_at" "$(date +%s)"


    [ -f "$LOG" ] && tail -n 40 "$LOG" 2>/dev/null | jlines 600
    printf ']}\n'
}

case "$1" in
    list-json) cmd_list_json ;;
    plan)      cmd_plan "$2" "$3" ;;







    plan-ok)   BST_DONE=1; BST=""; plan_calc "$2" "$3"; [ "$P_OK" = 1 ] && [ "$P_UNK" = 0 ] && exit 0; exit 1 ;;






    apply|install|remove|restart)
               if ! mkdir "$LOCK" 2>/dev/null; then







                   _pl=$(cat "$LOCK/pid" 2>/dev/null | tr -cd '0-9')
                   [ -n "$_pl" ] || { sleep 1; _pl=$(cat "$LOCK/pid" 2>/dev/null | tr -cd '0-9'); }

                   if pid_runs "$_pl" 'packages\.sh|proto-install\.sh'; then echo "уже выполняется"; exit 1; fi
                   rm -rf "$LOCK" 2>/dev/null
                   mkdir "$LOCK" 2>/dev/null || { echo "уже выполняется"; exit 1; }
               fi
               echo $$ > "$LOCK/pid" 2>/dev/null




               if { command -v pkg_install_alive >/dev/null 2>&1 && pkg_install_alive; } || { [ -f "$GH" ] && sh "$GH" upd-busy >/dev/null 2>&1; }; then
                   : > "$LOG"; set_state FAIL; log "Идёт обновление системы — компоненты не трогал; дождитесь его конца и повторите"
                   rm -rf "$LOCK" 2>/dev/null; exit 1
               fi
               SWLOCK=/tmp/enodia-switching.lock; SWMINE=0

               [ "$1" = restart ] || [ -e "$SWLOCK" ] || { : > "$SWLOCK" 2>/dev/null && SWMINE=1; }





               pkg_exit() {
                   [ -f "$GH" ] && sh "$GH" bin-unprefetch >/dev/null 2>&1
                   rm -rf "$LOCK" 2>/dev/null; [ "$SWMINE" = 1 ] && rm -f "$SWLOCK" 2>/dev/null
                   return 0
               }
               trap pkg_exit EXIT
               trap 'exit 1' INT TERM HUP PIPE
               case "$1" in
                   apply)   cmd_apply "$2" "$3" ;;
                   install) cmd_apply "$2" "" ;;
                   remove)  cmd_apply "" "$2" ;;
                   restart) cmd_restart "$2" "$3" ;;
               esac ;;
    state)     cat "$STATE" 2>/dev/null || echo IDLE ;;







    busy)      busy_calc


               _bm=false
               [ -n "$2" ] && case " $_bi " in *" $2 "*) _bm=true ;; esac
               printf '{"running":%s,"state":"%s","pid":%s,"ins":"%s","del":"%s","upd":"%s","rst":"%s","mine":%s}\n' "$_br" "$_bs" "${_bp:-0}" "$_bi" "$_bd" "$_bu" "$_brs" "$_bm"
               [ "$_br" = true ] && exit 0
               exit 1 ;;



    op-json)   cmd_op_json ;;



    pkg-state) pkg_known "$2" || { echo "неизвестный компонент: $2" >&2; exit 2; }
               pkg_state "$2" ;;
    *) echo "usage: $0 list-json | plan <ставим> <снимаем> | plan-ok <ставим> <снимаем> | apply <ставим> <снимаем> | install <список> | remove <список> | restart <список|-> [владельцы] | state | busy [компонент] | op-json | pkg-state <компонент>"; echo "       списки через запятую, «-» = пусто; компоненты: $PKGS"; exit 2 ;;
esac
