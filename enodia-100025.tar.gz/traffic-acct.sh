#!/bin/sh














ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
LAST="$ENODIA_STATE/.traffic-last"      # сырой прошлый замер: "vif vrx vtx wrx wtx wif" (wif дописан








DAILY="$ENODIA_STATE/.traffic-daily"    # посуточно: "epoch YYYY-MM-DD vrx vtx wrx wtx" (+ доп-выходы:



LOCK=/tmp/enodia-traffic-acct.lock
KEEP=400                           # сколько последних дней хранить (>1 года)




LOCK_STALE=${LOCK_STALE:-3600}



if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v clock_sane >/dev/null 2>&1 || clock_sane() { _csn=${1:-$(date +%s 2>/dev/null)}; case "$_csn" in ''|*[!0-9]*) return 1 ;; esac; [ "$_csn" -gt 1700000000 ] 2>/dev/null && [ "$_csn" -lt 4102444800 ] 2>/dev/null; }

if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi
command -v wan_iface >/dev/null 2>&1 || wan_iface() { ip route show default 2>/dev/null | awk '/^default/{d=""; for(i=1;i<=NF;i++) if($i=="dev") d=$(i+1); if(d!="" && d !~ /^(awg|xtun)/){print d; exit}}'; }
command -v age_since >/dev/null 2>&1 || age_since() {
    case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
    [ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}
if [ -e "$LOCK" ]; then
    _lt=$(cat "$LOCK" 2>/dev/null); case "$_lt" in ''|*[!0-9]*) _lt=0 ;; esac
    [ "$(age_since "$_lt")" -lt "$LOCK_STALE" ] && exit 0
fi
date +%s > "$LOCK"; trap 'rm -f "$LOCK"' EXIT; trap 'exit 1' INT TERM HUP PIPE






clock_sane || exit 0




if [ -f "$ENODIA_DIR/traffic-dev.sh" ]; then sh "$ENODIA_DIR/traffic-dev.sh" tick </dev/null >/dev/null 2>&1; fi




t=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')



if [ -z "$t" ]; then
    t=awg
    if [ -f "$ENODIA_DIR/transport.sh" ]; then
        sh "$ENODIA_DIR/transport.sh" configured >/dev/null 2>&1
        [ "$?" = 1 ] && t=none
    fi
fi






case "$t" in none|zapret) vif="-" ;; awg) vif=awg0 ;; *) vif=xtun ;; esac
wan_if=$(wan_iface)   # владелец имени — ip-lib.sh (та же строка у читателя cgi-bin/traffic)



devbytes() { sed 's/:/ /' /proc/net/dev 2>/dev/null | awk -v i="$1" '$1==i{print $2" "$10; f=1} END{if(!f)print "0 0"}'; }
set -- $(devbytes "$vif");          vrx=${1:-0}; vtx=${2:-0}
set -- $(devbytes "${wan_if:-_}");  wrx=${1:-0}; wtx=${2:-0}














SLOTS_FILE="$ENODIA_STATE/.slots"
TAB=$(printf '\t')


SLOT_IDS="2 3 4 5 6 7"
for _k in $SLOT_IDS; do eval "sif$_k=''; s${_k}rx=0; s${_k}tx=0; ls${_k}if=''; ls${_k}rx=0; ls${_k}tx=0"; _kmax=$_k; done
if [ -s "$SLOTS_FILE" ] && [ -f "$ENODIA_DIR/transport.sh" ]; then


    while IFS="$TAB" read -r _sid _snb _stp _scfg _sfb _sen; do
        [ "$_sen" = on ] || continue




        _sif=$(sh "$ENODIA_DIR/transport.sh" slot-iface "$_sid" </dev/null 2>/dev/null) || _sif=""
        [ -n "$_sif" ] || continue
        case "$_sid" in [2-7]) eval "sif$_sid=\$_sif" ;; esac
    done < "$SLOTS_FILE"
fi
for _k in $SLOT_IDS; do
    eval "_sif=\$sif$_k"; [ -n "$_sif" ] || continue
    set -- $(devbytes "$_sif"); eval "s${_k}rx=\${1:-0}; s${_k}tx=\${2:-0}"
done


lvif=""; lvrx=0; lvtx=0; lwrx=0; lwtx=0; lwif=""
[ -f "$LAST" ] && read lvif lvrx lvtx lwrx lwtx lwif < "$LAST"
for n in lvrx lvtx lwrx lwtx; do eval "x=\$$n"; case "$x" in ''|*[!0-9]*) eval "$n=0";; esac; done


if [ -f "$LAST" ]; then
    while read -r _k _i _r _t; do
        case "$_k" in s[2-7]) _n=${_k#s}; eval "ls${_n}if=\$_i; ls${_n}rx=\$_r; ls${_n}tx=\$_t" ;; esac
    done < "$LAST"
fi
for _k in $SLOT_IDS; do
    for n in ls${_k}rx ls${_k}tx; do eval "x=\$$n"; case "$x" in ''|*[!0-9]*) eval "$n=0";; esac; done
done








if [ -z "$wan_if" ]; then
    wan_if="$lwif"; wrx=$lwrx; wtx=$lwtx
fi

had_last=0; [ -f "$LAST" ] && had_last=1
{                                                          # для следующей дельты
    printf '%s %s %s %s %s %s\n' "$vif" "$vrx" "$vtx" "$wrx" "$wtx" "${wan_if:-?}"



    for _k in $SLOT_IDS; do
        eval "_sif=\$sif$_k; _r=\$s${_k}rx; _t=\$s${_k}tx"
        [ -n "$_sif" ] && printf 's%s %s %s %s\n' "$_k" "$_sif" "$_r" "$_t"
    done
    :          # группа не кончается на `[ ] && …`: rc-страж, а не украшение (класс Б5-9)
} > "$LAST.tmp" && mv "$LAST.tmp" "$LAST"






[ "$had_last" = 0 ] && exit 0




deltas=$(awk -v vif="$vif" -v lvif="$lvif" -v vrx="$vrx" -v vtx="$vtx" -v wrx="$wrx" -v wtx="$wtx" \
             -v lvrx="$lvrx" -v lvtx="$lvtx" -v lwrx="$lwrx" -v lwtx="$lwtx" \
             -v wif="$wan_if" -v lwif="$lwif" 'BEGIN{
    OFMT="%.0f"; CONVFMT="%.0f";
    wsame=(lwif=="" || wif==lwif);   # lwif пуст = файл СТАРОГО формата: судим только по счётчику
    wunk=(lwif=="?");                # в прошлый замер WAN-iface не существовало и истории нет:
                                     # сравнивать не с чем ⇒ ЧЕСТНЕЕ пропустить интервал (0), чем
                                     # засчитать «сегодня» весь кумулятивный счётчик с буста
    # СМЕНИЛСЯ IFACE ⇒ интервал ПРОПУСКАЕМ (0), а не заряжаем весь счётчик нового имени. Счётчик
    # интерфейса кумулятивен с его СОЗДАНИЯ, а старый iface при смене остаётся жив: awg0 при
    # активном xray — «тёплый резерв», eth0 — под pppoe-wan. Возврат на него (ручное переключение,
    # cross-failover, редозвон) заряжал в «сегодня» ВСЁ, что уже учли до отхода. Замерено на
    # импорте бэкапа BE7000 (AX3600, 17.08.2026): за 08-14 «через VPN» 64.5 ГБ против 31.6 ГБ
    # «через WAN» — физически невозможно, VPN всегда ПОДМНОЖЕСТВО WAN, и панель печатала
    # «через VPN 60.2 ГБ · напрямую 0 Б · всего 29.5 ГБ». Истории под новым именем у нас нет ⇒
    # честнее потерять один пятиминутный интервал (та же логика, что у wunk выше).
    # ЧИТАТЕЛЬ (web/cgi-bin/traffic, «незаписанная дельта») так считает С САМОГО НАЧАЛА — это
    # ВТОРОЙ случай, когда писатель отстал от читателя в ОДНОМ контракте (первый — вилка `none`
    # выше). Правя одну сторону, сверяй обе.
    dvrx=(vif==lvif && vrx>=lvrx)?vrx-lvrx:(vif==lvif?vrx:0);
    dvtx=(vif==lvif && vtx>=lvtx)?vtx-lvtx:(vif==lvif?vtx:0);
    dwrx=wunk?0:((wsame && wrx>=lwrx)?wrx-lwrx:(wsame?wrx:0));
    dwtx=wunk?0:((wsame && wtx>=lwtx)?wtx-lwtx:(wsame?wtx:0));
    printf "%.0f %.0f %.0f %.0f", dvrx,dvtx,dwrx,dwtx
}')
set -- $deltas; dvrx=${1:-0}; dvtx=${2:-0}; dwrx=${3:-0}; dwtx=${4:-0}









slot_delta() {   # <iface> <rx> <tx> <прошлый iface> <прошлый rx> <прошлый tx> -> "drx dtx"
    [ -n "$1" ] || { echo "0 0"; return; }
    awk -v i="$1" -v r="$2" -v t="$3" -v li="$4" -v lr="$5" -v lt="$6" 'BEGIN{
        OFMT="%.0f"; CONVFMT="%.0f";
        printf "%.0f %.0f", (i==li&&r>=lr)?r-lr:(i==li?r:0), (i==li&&t>=lt)?t-lt:(i==li?t:0) }'
}






nslot=0
for _k in $SLOT_IDS; do
    eval "_i=\$sif$_k; _r=\$s${_k}rx; _t=\$s${_k}tx; _li=\$ls${_k}if; _lr=\$ls${_k}rx; _lt=\$ls${_k}tx"
    _d="0 0"; [ -n "$_i" ] && { _d=$(slot_delta "$_i" "$_r" "$_t" "$_li" "$_lr" "$_lt"); nslot=1; }
    set -- $_d; export "TA_D${_k}R=${1:-0}" "TA_D${_k}T=${2:-0}"
done

now=$(date +%s); today=$(date +%F)
[ -f "$DAILY" ] || : > "$DAILY"








awk -v today="$today" -v now="$now" -v a="$dvrx" -v b="$dvtx" -v c="$dwrx" -v d="$dwtx" -v ns="$nslot" \
    -v km="$_kmax" 'BEGIN{OFMT="%.0f";CONVFMT="%.0f"}
  $2==today { $3+=a; $4+=b; $5+=c; $6+=d
              if(ns) for(k=2;k<=km;k++){ f=2*k+3; $f+=ENVIRON["TA_D" k "R"]; $(f+1)+=ENVIRON["TA_D" k "T"] }
              seen=1 }
  { print }
  END { if(!seen){ printf "%.0f %s %.0f %.0f %.0f %.0f", now, today, a, b, c, d
                   if(ns) for(k=2;k<=km;k++) printf " %.0f %.0f", ENVIRON["TA_D" k "R"]+0, ENVIRON["TA_D" k "T"]+0
                   printf "\n" } }
' "$DAILY" > "$DAILY.tmp" && mv "$DAILY.tmp" "$DAILY"


lines=$(wc -l < "$DAILY" 2>/dev/null); case "$lines" in ''|*[!0-9]*) lines=0;; esac
[ "$lines" -gt "$KEEP" ] && { tail -n "$KEEP" "$DAILY" > "$DAILY.tmp" && mv "$DAILY.tmp" "$DAILY"; }
exit 0
