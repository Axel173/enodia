#!/bin/sh





















































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}




ENODIA_BOOT=${ENODIA_BOOT:-/data/usr/app/enodia-boot}





SWITCH_LOCK=/tmp/enodia-switching.lock
_mvsw=$ENODIA_MOVE_SW; unset ENODIA_MOVE_SW
case "$_mvsw" in 1) ENODIA_MOVE_SW=1 ;; *) ENODIA_MOVE_SW=0 ;; esac
move_release() { [ "$ENODIA_MOVE_SW" = 1 ] && rm -f "$SWITCH_LOCK" 2>/dev/null; ENODIA_MOVE_SW=0; return 0; }




set_traps() { trap "$1" EXIT; trap 'exit 1' INT TERM HUP; trap '' PIPE; }
[ "$ENODIA_MOVE_SW" = 1 ] && set_traps 'move_release'






if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi




if ! command -v bin_dest >/dev/null 2>&1 || ! command -v bin_pinned >/dev/null 2>&1 \
   || ! command -v store_is_ours >/dev/null 2>&1 || ! command -v store_state >/dev/null 2>&1 \
   || [ -z "$STORE_SUB" ] || [ -z "$STORE_MNT" ] || [ -z "$DATA_RESERVE_B" ] || [ -z "$KEEP_MARK" ]; then
    echo "нет store-lib.sh (или он старый) — обновите скрипты" >&2
    exit 1
fi





if [ -f "$ENODIA_DIR/mount-lib.sh" ]; then . "$ENODIA_DIR/mount-lib.sh"; fi
if ! command -v store_locate >/dev/null 2>&1 || ! command -v try_mount >/dev/null 2>&1; then
    echo "нет mount-lib.sh (или он старый) — обновите скрипты" >&2
    exit 1
fi










if ! command -v fs_keeps_perms >/dev/null 2>&1; then
    fs_keeps_perms() { return 1; }
fi








if ! command -v harden_perms >/dev/null 2>&1; then
    harden_perms() {
        echo "ВНИМАНИЕ: store-lib.sh старый (нет harden_perms) — права на каталоги НЕ выставлены;" >&2
        echo "          обновите скрипты и повторите переезд, иначе на флеше могут остаться права 0777 с накопителя" >&2
        return 0
    }
fi








MISS_STAMP=/tmp/enodia-usb-missing     # «уже говорили, что накопителя нет» — /tmp=RAM, живёт до ребута
DEDUP_STAMP=/tmp/enodia-usb-dedup      # «дубли уже разбирали в эту загрузку» (см. resolve_dups)








USB_LOCK=/tmp/enodia-usb.lock








PKG_LOCK=/tmp/enodia-proto-install.lock






STORE_SEEN="$STORE_MARK-seen"







num()        { case "$1" in ''|*[!0-9]*) printf '0' ;; *) printf '%s' "$1" ;; esac; }




df_free_b()  { num "$(fs_free_b "$1")"; }
df_total_b() { num "$(fs_total_b "$1")"; }



our_mp()     { _omp=$(fs_mount "$ENODIA_DIR"); printf '%s' "${_omp:-/data}"; }
size_b()     { _n=$(stat -c%s "$1" 2>/dev/null); case "$_n" in ''|*[!0-9]*) _n=0 ;; esac; printf '%s' "$_n"; }
mb()         { _v=${1:-0}; echo "$((_v/1048576)).$(( (_v%1048576)*10/1048576 ))"; }






du_b() {
    _k=$(du -xsk "$1" 2>/dev/null | awk 'NR==1{print $1}')
    case "$_k" in ''|*[!0-9]*) _k=0 ;; esac
    printf '%s' "$((_k * 1024))"
}











mark_write() {
    printf '%s\n' "$1" > "$STORE_MARK"
    if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
    store_ready
}


mark_drop()  { rm -f "$STORE_MARK" "$STORE_SEEN"; if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi; }









seen_note() {
    store_ready || return 0
    _ssn=
    for _ssb in $STORE_MOVABLE; do
        if [ -f "$BIN_DIR/$_ssb" ]; then _ssn="${_ssn:+$_ssn }$_ssb"; fi
    done
    if [ -f "$STORE_SEEN" ]; then
        _sso=
        read -r _sso < "$STORE_SEEN" 2>/dev/null || :
        if [ "$_sso" = "$_ssn" ]; then unset _ssn _ssb _sso; return 0; fi
    fi
    _sst="${STORE_SEEN%/*}/bin-store-seen.new"
    if printf '%s\n' "$_ssn" > "$_sst" 2>/dev/null && mv -f "$_sst" "$STORE_SEEN" 2>/dev/null; then :; else rm -f "$_sst" 2>/dev/null; fi
    unset _ssn _ssb _sso _sst
    return 0
}



seen_read() {
    SEEN_NAMES=
    [ -f "$STORE_SEEN" ] || return 1
    _srr=
    read -r _srr < "$STORE_SEEN" 2>/dev/null || :
    set -f
    for _srx in $_srr; do
        case "$_srx" in ''|*[!a-z0-9-]*) ;; *) SEEN_NAMES="${SEEN_NAMES:+$SEEN_NAMES }$_srx" ;; esac
    done
    set +f
    unset _srr _srx
    return 0
}











keep_write() {      # $1 = имена через пробел; пустой список = файл снимаем
    set -f
    _kn=0
    for _kw in $1; do case "$_kw" in ''|*[!a-z0-9-]*) continue ;; esac; _kn=1; break; done
    if [ "$_kn" = 0 ]; then
        rm -f "$KEEP_MARK" 2>/dev/null
    else
        mkdir -p "${KEEP_MARK%/*}" 2>/dev/null





        _kt="${KEEP_MARK%/*}/bin-keep.new"
        rm -f "$_kt" 2>/dev/null
        for _kw in $1; do
            case "$_kw" in ''|*[!a-z0-9-]*) continue ;; esac
            echo "$_kw" >> "$_kt"
        done
        if ! mv -f "$_kt" "$KEEP_MARK" 2>/dev/null; then
            rm -f "$_kt" 2>/dev/null; unset _kn _kw _kt; set +f; return 1
        fi
        unset _kt
    fi
    unset _kn _kw
    set +f
    if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
    return 0
}
keep_add() { _ka="$BIN_KEEP"; for _kx in "$@"; do if ! bin_pinned "$_kx"; then _ka="$_ka $_kx"; fi; done; keep_write "$_ka"; _kr=$?; unset _ka _kx; return "$_kr"; }
keep_del() { _kd=; for _kx in $BIN_KEEP; do if [ "$_kx" != "$1" ]; then _kd="$_kd $_kx"; fi; done; keep_write "$_kd"; _kr=$?; unset _kd _kx; return "$_kr"; }





need_router_b() {
    _nb=0
    if [ "$BIN_DIR" != "$ENODIA_BIN" ]; then
        for _nx in "$1" $(bin_deps "$1"); do
            if [ -f "$BIN_DIR/$_nx" ]; then _nb=$((_nb + $(size_b "$BIN_DIR/$_nx"))); fi
        done
    fi
    printf '%s' "$_nb"
    unset _nx
}


fits_router() {
    _fr=$(df_free_b "$ENODIA_DIR")
    _fn=$(need_router_b "$1")
    [ "$((_fr - _fn))" -ge "$DATA_RESERVE_B" ]
}















exec_ok() {
    ( cd /tmp 2>/dev/null && timeout -t 3 "$1" --enodia-exec-probe >/dev/null 2>&1 )
    _rc=$?
    [ "$_rc" != 126 ] && [ "$_rc" != 127 ]
}





is_program() {
    _ipm=$(head -c 4 "$1" 2>/dev/null)
    case "$_ipm" in "$(printf '\177ELF')"|'#!'*) return 0 ;; esac
    return 1
}

md5_of() { md5sum "$1" 2>/dev/null | cut -d' ' -f1; }






drop_stale_new() {
    for _sn in $STORE_MOVABLE; do
        rm -f "$ENODIA_BIN/$_sn.new" 2>/dev/null
        [ "$BIN_DIR" != "$ENODIA_BIN" ] && rm -f "$BIN_DIR/$_sn.new" 2>/dev/null
    done
    return 0
}




move_verified() {   # $1 = откуда, $2 = куда, $3 = имя для лога












    _mvid=$(stat -c '%d:%i' "$1" 2>/dev/null)
    if [ "$1" = "$2" ] || { [ -n "$_mvid" ] && [ "$_mvid" = "$(stat -c '%d:%i' "$2" 2>/dev/null)" ]; }; then
        echo "  $3: источник и цель — ОДИН файл ($2), хранилище не опознано — не двигаю"
        return 1
    fi
    _sz=$(size_b "$1")
    _dstdir=${2%/*}
    mkdir -p "$_dstdir" 2>/dev/null
    _free=$(df_free_b "$_dstdir"); case "$_free" in ''|*[!0-9]*) _free=0 ;; esac
    if [ "$_free" -lt "$((_sz + 262144))" ]; then
        echo "  $3: не хватает места в $_dstdir ($(mb "$_free") МБ) — пропускаю"
        return 1
    fi
    rm -f "$2.new" 2>/dev/null
    if ! cp "$1" "$2.new" 2>/dev/null; then
        echo "  $3: не скопировался — пропускаю"; rm -f "$2.new" 2>/dev/null; return 1
    fi
    chmod +x "$2.new" 2>/dev/null      # на exFAT/NTFS права даёт монтирование, chmod там no-op
    sync
    if [ "$(md5_of "$1")" != "$(md5_of "$2.new")" ]; then
        echo "  $3: копия не сошлась по md5 — оставляю на месте"; rm -f "$2.new" 2>/dev/null; return 1
    fi
    if is_program "$1" && ! exec_ok "$2.new"; then
        echo "  $3: с этой ФС не запускается (noexec?) — оставляю на месте"; rm -f "$2.new" 2>/dev/null; return 1
    fi
    if ! mv -f "$2.new" "$2" 2>/dev/null; then
        echo "  $3: не встал на место — оставляю на месте"; rm -f "$2.new" 2>/dev/null; return 1
    fi
    rm -f "$1" 2>/dev/null
    sync
    echo "  $3: $(mb "$_sz") МБ → $_dstdir"
    return 0
}










old_place_names() {    # $1 = drive | пусто
    _opr="${ENODIA_BOOT%/*}/"
    exe_deleted | while read -r _opp _opf; do
        _opn=${_opf##*/}
        case "$_opn" in ''|*[!a-z0-9-]*) continue ;; esac
        if [ "$1" = drive ]; then case "$_opf" in "$_opr"*) continue ;; esac; fi
        _opc=$(bin_path "$_opn")
        [ -f "$_opc" ] && [ "$_opc" != "$_opf" ] && echo "$_opn"
    done | sort -u | tr '\n' ' ' | sed 's/ $//'
}




free_line() {    # $1 = drive | пусто
    _flo=$(old_place_names)
    _fld=""; [ "$1" = drive ] && _fld=$(old_place_names drive)
    printf 'Свободно на %s: %s МБ' "$(our_mp)" "$(mb "$(df_free_b "$ENODIA_DIR")")"
    if [ -n "$_fld" ]; then
        printf '. До перезапуска с накопителя работают: %s — не вынимайте его до перезапуска (проще всего — перезагрузить роутер)' "$_fld"
    elif [ -n "$_flo" ]; then
        printf '. До перезапуска с прежнего места работают: %s — оно освободится после перезапуска (проще всего — перезагрузить роутер)' "$_flo"
    fi
    echo
}
















resolve_dups() {
    [ "$BIN_DIR" != "$ENODIA_BIN" ] || return 0        # хранилища нет — дублей не бывает по определению
    [ -f "$DEDUP_STAMP" ] && return 0
    _any=0
    for _b in $STORE_MOVABLE; do
        if [ -f "$ENODIA_BIN/$_b" ] && [ -f "$BIN_DIR/$_b" ]; then _any=1; break; fi
    done
    [ "$_any" = 0 ] && return 0
    : > "$DEDUP_STAMP" 2>/dev/null
    for _b in $STORE_MOVABLE; do
        [ -f "$ENODIA_BIN/$_b" ] || continue
        [ -f "$BIN_DIR/$_b" ] || continue




        if bin_pinned "$_b"; then




            chmod +x "$ENODIA_BIN/$_b" 2>/dev/null
            if exec_ok "$ENODIA_BIN/$_b"; then
                rm -f "$BIN_DIR/$_b" 2>/dev/null
                echo "usb-offload: $_b закреплён за роутером — копия в хранилище снята"
            else
                echo "usb-offload: $_b закреплён, но резидентная копия не запускается — копию в хранилище ОСТАВЛЯЮ"
            fi
            continue
        fi
        if [ "$(md5_of "$ENODIA_BIN/$_b")" = "$(md5_of "$BIN_DIR/$_b")" ]; then
            rm -f "$ENODIA_BIN/$_b" 2>/dev/null
            echo "usb-offload: $_b — лишняя копия на флеше роутера снята (файлы идентичны)"
        else
            echo "usb-offload: $_b на флеше роутера отличается от копии в хранилище — переношу свежую"
            if ! move_verified "$ENODIA_BIN/$_b" "$BIN_DIR/$_b" "$_b" >/dev/null 2>&1; then
                echo "usb-offload: $_b перенести не вышло — в хранилище остаётся СТАРАЯ копия, она и запускается"
            fi
        fi
    done
    return 0
}






cmd_detect() {




    _seen=""
    while read -r _d _m _t _rest; do
        case "$_d" in /dev/sd*) ;; *) continue ;; esac
        _o=no; [ -n "$(store_of_mount "$_m")" ] && _o=yes
        _n=${_d#/dev/}
        case "$_n" in sd[a-z][0-9]*) _seen="$_seen ${_n%%[0-9]*}" ;; esac
        printf '%s\t%s\t%s\t%s\n' "$_d" "$_t" "$_m" "$_o"
    done < "$MOUNTS"
    for _dev in $(mount_candidates); do
        _n=${_dev#/dev/}
        case "$_n" in
            sd[a-z]) case " $_seen " in *" $_n "*) continue ;; esac ;;
            *)       _seen="$_seen ${_n%%[0-9]*}" ;;
        esac
        printf '%s\t?\t-\t?\n' "$_dev"
    done
}















usb_lock() {
    _ulw=${1:-0}; _uli=0; _ule=0; _ulb=0
    while :; do
        if mkdir "$USB_LOCK" 2>/dev/null; then printf '%s' "$$" > "$USB_LOCK/pid" 2>/dev/null; return 0; fi
        _ulp=$(cat "$USB_LOCK/pid" 2>/dev/null)
        case "$_ulp" in


            ''|*[!0-9]*)
                _ule=$((_ule + 1))
                if [ "$_ule" -ge 3 ] && [ "$_ulb" -lt 3 ]; then
                    rm -rf "$USB_LOCK" 2>/dev/null; _ulb=$((_ulb + 1)); _ule=0; continue
                fi ;;

            *)
                _ule=0
                if [ ! -d "/proc/$_ulp" ] && [ "$_ulb" -lt 3 ]; then
                    rm -rf "$USB_LOCK" 2>/dev/null; _ulb=$((_ulb + 1)); continue
                fi ;;
        esac
        [ "$_uli" -ge "$_ulw" ] && return 1
        _uli=$((_uli + 1)); sleep 1
    done
}
usb_unlock() { rm -rf "$USB_LOCK" 2>/dev/null; }



usb_unlock_mine() {
    _ulm=
    [ -f "$USB_LOCK/pid" ] && read -r _ulm < "$USB_LOCK/pid" 2>/dev/null
    [ "$_ulm" = "$$" ] && rm -rf "$USB_LOCK" 2>/dev/null
    return 0
}












MOVE_TICK_WAIT=${MOVE_TICK_WAIT:-30}
MOVE_MODE_WAIT=${MOVE_MODE_WAIT:-300}         # смена раскладки — фоном, ей ждать можно дольше (cmd_mode)
MOVE_GAP_WAIT=${MOVE_GAP_WAIT:-1}
MOVE_LISTS_WAIT=${MOVE_LISTS_WAIT:-300}       # смена раскладки ждёт сборку списков/гео (cmd_mode; разбор там)
if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v lists_work_alive >/dev/null 2>&1 || lists_work_alive() { return 1; }   # старая библиотека — не ждём, как раньше
command -v wd_tick_alive >/dev/null 2>&1 || wd_tick_alive() { return 1; }   # старая библиотека — тика не ждём, как раньше
command -v heal_alive >/dev/null 2>&1 || heal_alive() { return 1; }
command -v pkg_install_alive >/dev/null 2>&1 || pkg_install_alive() {   # старая библиотека — та же строка владельца
    _pia=$(cat /tmp/enodia-pkg-install.lock/pid 2>/dev/null | tr -cd '0-9'); [ -n "$_pia" ] && [ -r "/proc/$_pia/cmdline" ] \
        && tr '\000' ' ' 2>/dev/null < "/proc/$_pia/cmdline" | grep -q 'pkg-install\.sh'; }
command -v exe_deleted >/dev/null 2>&1 || exe_deleted() { ls -l /proc/[0-9]*/exe 2>/dev/null | sed -n 's#^.* /proc/\([0-9][0-9]*\)/exe -> \(.*\) (deleted)$#\1 \2#p'; }
command -v store_mode_alive >/dev/null 2>&1 || store_mode_alive() {   # старая библиотека — прежнее «жив ли pid»
    _sma=$(cat /tmp/enodia-store-mode.pid 2>/dev/null | tr -cd '0-9'); [ -n "$_sma" ] && [ -d "/proc/$_sma" ]; }


command -v carrier_busy >/dev/null 2>&1 || carrier_busy() { wd_tick_alive || heal_alive; }   # старая библиотека — тот же ответ
move_hold() {
    [ "$ENODIA_MOVE_SW" = 1 ] && return 0          # продолжение смены раскладки: лок уже наш
    _mhw=0
    while :; do
        if ! carrier_busy && ( set -C; : > "$SWITCH_LOCK" ) 2>/dev/null; then
            ENODIA_MOVE_SW=1
            sleep "$MOVE_GAP_WAIT"
            while carrier_busy && [ "$_mhw" -lt "$MOVE_TICK_WAIT" ]; do sleep 1; _mhw=$((_mhw + 1)); done
            carrier_busy || break
            move_release
        fi
        if [ "$_mhw" -ge "$MOVE_TICK_WAIT" ]; then
            echo "роутер сейчас проверяет или поднимает туннель — ничего не переносил, повторите через минуту" >&2
            return 1
        fi
        sleep 1; _mhw=$((_mhw + 1))
    done

    if [ -d "$PKG_LOCK" ]; then
        move_release
        echo "идёт установка компонентов — дождитесь её окончания (экран «Компоненты») и повторите" >&2
        return 1
    fi




    if pkg_install_alive || { [ -f "$ENODIA_DIR/gh-update.sh" ] && sh "$ENODIA_DIR/gh-update.sh" upd-busy >/dev/null 2>&1; }; then
        move_release
        echo "идёт обновление кода — дождитесь его окончания и повторите" >&2
        return 1
    fi
    return 0
}









store_rejected() {
    if [ ! -f "$MISS_STAMP" ]; then
        : > "$MISS_STAMP" 2>/dev/null
        echo "usb-offload: каталог $1 больше не опознаётся как хранилище — бинари ищутся на флеше роутера"
    fi
    return 1
}




cmd_mount_ensure() {
    [ -f "$STORE_MARK" ] || return 1        # маркера нет ⇒ накопитель не наш сценарий, no-op
    store_ready && { rm -f "$MISS_STAMP" 2>/dev/null; resolve_dups; seen_note; return 0; }   # уже на месте




    if store_locate; then
        [ -n "$STORE_FOUND_WARN" ] && echo "usb-offload: $STORE_FOUND_WARN"
        mark_write "$STORE_FOUND" || { store_rejected "$STORE_FOUND"; return 1; }
        rm -f "$MISS_STAMP" 2>/dev/null
        if [ "$STORE_FOUND_HOW" = system ]; then
            echo "usb-offload: хранилище $STORE_FOUND (смонтировано системой)"
        else
            echo "usb-offload: хранилище $STORE_FOUND ($STORE_FOUND_HOW, $(fs_of_mount "$MNT"))"
        fi
        resolve_dups
        seen_note
        return 0
    fi
    [ -n "$STORE_FOUND_WARN" ] && echo "usb-offload: $STORE_FOUND_WARN"





    if [ ! -f "$MISS_STAMP" ]; then
        : > "$MISS_STAMP" 2>/dev/null
        echo "usb-offload: накопитель с хранилищем не найден — бинари ищутся на флеше роутера"
    fi
    return 1
}




prepare_store() {   # $1 = /dev/sdX1 | точка монтирования | пусто
    _mp=""
    if [ -n "$1" ]; then
        case "$1" in
            /dev/*) _dev="$1" ;;
            /*)     [ -d "$1" ] || { echo "нет такого каталога: $1" >&2; return 1; }
                    _mp="$1"; _dev="" ;;
            *)      _dev="/dev/$1" ;;
        esac
        if [ -n "$_dev" ]; then
            [ -b "$_dev" ] || { echo "нет такого устройства: $_dev" >&2; return 1; }
            _mp=""
            while read -r _d _m _t _rest; do
                [ "$_d" = "$_dev" ] && { _mp="$_m"; break; }
            done < "$MOUNTS"
            if [ -z "$_mp" ]; then
                mkdir -p "$MNT" 2>/dev/null
                try_mount "$_dev" "$MNT" || { echo "не смонтировался $_dev (ФС не опознана?)" >&2; return 1; }
                _mp="$MNT"
            fi
        fi
    else



        _n=0; _disks=""; _cand=""
        while read -r _d _m _t _rest; do
            case "$_d" in /dev/sd*) ;; *) continue ;; esac
            _dsk=${_d#/dev/}; _dsk=${_dsk%%[0-9]*}
            case " $_disks " in *" $_dsk "*) ;; *) _disks="$_disks $_dsk"; _n=$((_n+1)) ;; esac
            [ -z "$_mp" ] && _mp="$_m"     # смонтированное предпочтительнее: второй монтаж того же не нужен
        done < "$MOUNTS"
        for _dev in $(mount_candidates); do
            _dsk=${_dev#/dev/}; _dsk=${_dsk%%[0-9]*}
            case " $_disks " in *" $_dsk "*) ;; *) _disks="$_disks $_dsk"; _n=$((_n+1)) ;; esac
            [ -z "$_cand" ] && _cand="$_dev"
        done
        if [ "$_n" = 0 ]; then
            echo "накопитель не найден: воткните флешку в USB-порт роутера" >&2; return 1
        fi
        if [ "$_n" -gt 1 ]; then
            echo "накопителей несколько — укажите нужный явно (usb-offload.sh enable /dev/sdX1):" >&2
            cmd_detect >&2
            return 1
        fi
        if [ -z "$_mp" ]; then
            mkdir -p "$MNT" 2>/dev/null
            try_mount "$_cand" "$MNT" || { echo "не смонтировался $_cand (ФС не опознана?)" >&2; return 1; }
            _mp="$MNT"
        fi
    fi


    mkdir -p "$_mp/$STORE_SUB/bin" 2>/dev/null


    printf 'enodia bin store\n' > "$_mp/$STORE_SUB/$STORE_SENTINEL" 2>/dev/null   # sentinel-write:
    if [ ! -f "$_mp/$STORE_SUB/$STORE_SENTINEL" ] || [ ! -d "$_mp/$STORE_SUB/bin" ]; then   # sentinel-write:
        echo "на накопителе не пишется ($_mp) — смонтирован только для чтения?" >&2; return 1
    fi
    printf '%s' "$_mp/$STORE_SUB"
    return 0
}

cmd_enable() {
    if ! store_ready; then cmd_mount_ensure >/dev/null 2>&1; fi
    if store_ready; then
        _store=$(store_root)
        echo "Хранилище: $_store (уже подготовлено)"
    else



        _store=$(find_mounted_store) || _store=""
        if [ -n "$_store" ] && [ -z "$1" ]; then
            mark_write "$_store"
            echo "Хранилище: $_store (найдено на накопителе)"
        else
            _store=$(prepare_store "$1") || return 1
            mark_write "$_store"
            echo "Хранилище: $_store (создано)"
        fi



        store_ready || { echo "хранилище $_store не опознано (нет сентинела или каталога bin?) — ничего не переношу" >&2; return 1; }
    fi
    drop_stale_new
    echo "Переселяю тяжёлые бинари:"
    _moved=0; _failed=0; _had=0; _kept=0; _back=0
    for _b in $STORE_MOVABLE; do



        if bin_pinned "$_b"; then









            if [ "$BIN_DIR" != "$ENODIA_BIN" ] && [ -f "$BIN_DIR/$_b" ] && [ ! -f "$ENODIA_BIN/$_b" ]; then
                if fits_router "$_b" && move_verified "$BIN_DIR/$_b" "$ENODIA_BIN/$_b" "$_b"; then
                    _back=$((_back+1))
                else
                    echo "  $_b: закреплён, но забрать с накопителя не вышло (место? битая копия?) — остаётся там"
                    _failed=$((_failed+1))
                fi
            elif [ -f "$ENODIA_BIN/$_b" ]; then
                echo "  $_b: закреплён за роутером — оставляю на месте"
            fi
            _kept=$((_kept+1)); continue
        fi
        [ -f "$ENODIA_BIN/$_b" ] || continue
        _had=$((_had+1))
        if move_verified "$ENODIA_BIN/$_b" "$BIN_DIR/$_b" "$_b"; then _moved=$((_moved+1)); else _failed=$((_failed+1)); fi
    done
    if [ "$_had" = 0 ] && [ "$_kept" = 0 ]; then echo "  (переселять нечего — тяжёлых бинарей на флеше роутера нет)"; fi


    seen_note
    echo "Переселено: $_moved, забрано обратно: $_back, не вышло: $_failed, закреплено за роутером: $_kept"
    free_line




    if [ "$_failed" -gt 0 ]; then



        echo "Не переехало файлов: $_failed — причина у каждого строкой выше (место? битая копия? не запускается с этой ФС?)" >&2
        return 1
    fi
    return 0
}

cmd_disable() {
    if ! store_ready; then
        cmd_mount_ensure >/dev/null 2>&1
        if ! store_ready; then




            if seen_read && [ -z "$SEEN_NAMES" ]; then cmd_forget; return $?; fi
            echo "хранилище недоступно — воткните накопитель, иначе возвращать нечего; если он потерян насовсем — забудьте его (usb-offload.sh forget)" >&2
            return 1
        fi
    fi
    _store=$(store_root)
    drop_stale_new      # ДО гарда места: хвост прошлого прогона на /data сам по себе решал бы «не влезет»


    _need=0
    for _b in $STORE_MOVABLE; do
        [ -f "$BIN_DIR/$_b" ] && _need=$((_need + $(size_b "$BIN_DIR/$_b")))
    done
    _free=$(df_free_b "$ENODIA_DIR"); case "$_free" in ''|*[!0-9]*) _free=0 ;; esac
    if [ "$((_free - _need))" -lt "$DATA_RESERVE_B" ]; then
        echo "не влезет: вернуть надо $(mb "$_need") МБ, свободно $(mb "$_free") МБ при резерве $(mb "$DATA_RESERVE_B") МБ." >&2
        echo "Снимите лишние компоненты в «Компонентах» и повторите." >&2
        return 1
    fi
    echo "Возвращаю бинари на роутер:"
    _moved=0; _failed=0
    for _b in $STORE_MOVABLE; do
        [ -f "$BIN_DIR/$_b" ] || continue
        if move_verified "$BIN_DIR/$_b" "$ENODIA_BIN/$_b" "$_b"; then _moved=$((_moved+1)); else _failed=$((_failed+1)); fi
    done
    if [ "$_failed" -gt 0 ]; then
        echo "Часть бинарей осталась на накопителе — маркер НЕ снимаю (иначе они стали бы недоступны)." >&2
        return 1
    fi
    _mp="$_store"
    mark_drop


    if [ -n "$(old_place_names)" ]; then echo "Переселено обратно: $_moved."
    else echo "Переселено обратно: $_moved. Накопитель больше не используется."; fi
    free_line drive

    case "$_mp" in "$MNT"/*) umount "$MNT" 2>/dev/null ;; esac
    return 0
}


















cmd_forget() {
    if [ ! -f "$STORE_MARK" ]; then echo "Накопитель и так не используется — забывать нечего."; return 0; fi
    if mode_load 2>/dev/null && [ "$M_MODE" = full ]; then
        echo "в раскладке «всё на накопителе» забыть его нельзя: там код и настройки" >&2
        return 1
    fi
    if ! store_ready; then cmd_mount_ensure >/dev/null 2>&1; fi
    if store_ready; then
        echo "накопитель на месте ($(store_root)) — забывать его незачем; чтобы перестать им пользоваться, верните бинари на роутер (usb-offload.sh disable)" >&2
        return 1
    fi
    _fw=
    read -r _fw < "$STORE_MARK" 2>/dev/null || :
    if seen_read; then _fk=1; else _fk=0; fi
    _fj=
    for _fx in $SEEN_NAMES; do _fj="${_fj:+$_fj, }$_fx"; done
    mark_drop
    rm -f "$MISS_STAMP" 2>/dev/null


    case "$_fw" in "$MNT"/*) umount "$MNT" 2>/dev/null ;; esac
    echo "Снят маркер хранилища: ${_fw:-?}"
    if [ "$_fk" = 0 ]; then
        echo "Накопитель забыт. Что на нём лежало, роутер не знает — сверьте «Компоненты»."
    elif [ -z "$_fj" ]; then
        echo "Накопитель забыт. Нашего на нём не было — терять нечего."
    else
        echo "Накопитель забыт. Не установлено то, что лежало на нём: $_fj. Поставьте заново в «Компонентах»."
    fi
    unset _fw _fk _fj _fx
    return 0
}













cmd_place() {
    _pn="$1"; _pt="$2"
    if [ -z "$_pn" ] || [ -z "$_pt" ]; then echo "usage: $0 place <имя> router|store" >&2; return 2; fi
    case "$_pt" in router|store) ;; *) echo "куда: router или store" >&2; return 2 ;; esac
    if ! store_movable "$_pn"; then
        echo "«$_pn» резидентен по замыслу проекта, на накопитель не селится (можно: $STORE_MOVABLE)" >&2
        return 2
    fi


    if ! store_ready; then cmd_mount_ensure >/dev/null 2>&1; fi

    if [ "$_pt" = router ]; then







        _pset="$_pn $(bin_deps "$_pn")"


        if store_ready && ! fits_router "$_pn"; then
            echo "не влезет: вернуть надо $(mb "$(need_router_b "$_pn")") МБ, свободно $(mb "$(df_free_b "$ENODIA_DIR")") МБ при резерве $(mb "$DATA_RESERVE_B") МБ." >&2
            echo "Снимите лишние компоненты в «Компонентах» или оставьте этот бинарь на накопителе." >&2
            return 1
        fi
        if ! keep_add $_pset; then echo "не смог записать закрепление" >&2; return 1; fi
        printf 'Закреплено за роутером:'
        for _px in $_pset; do printf ' %s' "$_px"; done
        echo
        _pfail=0
        if store_ready; then
            for _px in $_pset; do
                if [ -f "$BIN_DIR/$_px" ]; then
                    if ! move_verified "$BIN_DIR/$_px" "$ENODIA_BIN/$_px" "$_px"; then _pfail=$((_pfail+1)); fi
                fi
            done
        fi
        if [ "$_pfail" -gt 0 ]; then
            echo "Часть файлов осталась в хранилище — закрепление записано, но запускается пока копия оттуда." >&2
            return 1
        fi
        if ! store_ready; then
            echo "Накопителя сейчас нет — переносить нечего, закрепление учтётся при его включении."
        fi
    else


        _pblk=
        for _px in $STORE_MOVABLE; do
            if [ "$_px" = "$_pn" ]; then continue; fi
            if ! bin_pinned "$_px"; then continue; fi
            case " $(bin_deps "$_px") " in *" $_pn "*) _pblk="$_pblk $_px" ;; esac
        done
        if [ -n "$_pblk" ]; then
            echo "«$_pn» держат закреплённые:$_pblk — сперва отпустите их" >&2
            return 1
        fi
        if ! keep_del "$_pn"; then echo "не смог снять закрепление" >&2; return 1; fi


        if store_ready && [ -f "$ENODIA_BIN/$_pn" ]; then
            if ! move_verified "$ENODIA_BIN/$_pn" "$BIN_DIR/$_pn" "$_pn"; then
                echo "Перенести не вышло — файл пока остаётся на роутере." >&2
                return 1
            fi
            echo "Отпущен на накопитель: $_pn"
        elif store_ready; then
            echo "Закрепление снято: $_pn (на роутере такого файла нет — переносить нечего)"
        else
            echo "Закрепление снято: $_pn. Накопителя сейчас нет — файл уедет на него, когда он появится."
        fi
    fi
    seen_note
    if [ "$_pt" = router ]; then free_line drive; else free_line; fi
    return 0
}

cmd_status() {
    if store_ready; then
        _store=$(store_root)
        _mp=$(store_mp "$_store")
        echo "Внешний накопитель: ВКЛЮЧЁН"
        echo "  хранилище: $_store"
        echo "  ФС: $(fs_of_mount "$_mp" || echo '?'), свободно $(mb "$(df_free_b "$_store")") МБ из $(mb "$(df_total_b "$_store")")"
        echo "  занимаем: $(mb "$(du_b "$_store")") МБ (остальное занятое на накопителе — не наше)"
    elif [ -f "$STORE_MARK" ]; then
        echo "Внешний накопитель: ВКЛЮЧЁН, но НЕДОСТУПЕН (маркер есть, хранилища нет)"
        echo "  ожидался: $(cat "$STORE_MARK" 2>/dev/null)"
        if seen_read; then echo "  лежало на нём: ${SEEN_NAMES:-ничего нашего}"; else echo "  что лежало на нём — неизвестно (снимка нет)"; fi
        echo "  бинари ищутся на флеше роутера; транспорт, чей бинарь уехал, считается неустановленным."
        echo "  потерян насовсем — забыть его: usb-offload.sh forget"
    else
        echo "Внешний накопитель: выключен (всё на флеше роутера)"
    fi
    echo "  $(our_mp): свободно $(mb "$(df_free_b "$ENODIA_DIR")") МБ из $(mb "$(df_total_b "$ENODIA_DIR")") МБ"
    echo "Тяжёлые бинари:"
    for _b in $STORE_MOVABLE; do
        _w=$(bin_where "$_b")



        if [ -n "$_w" ] && bin_on_store "$_b"; then _w=store; fi
        if bin_pinned "$_b"; then _p='  <- закреплён за роутером'; else _p=''; fi
        case "$_w" in
            store)  printf '  %-12s накопитель  %s МБ%s\n' "$_b" "$(mb "$(size_b "$(bin_path "$_b")")")" "$_p" ;;
            router) printf '  %-12s роутер      %s МБ%s\n' "$_b" "$(mb "$(size_b "$(bin_path "$_b")")")" "$_p" ;;
            *)      printf '  %-12s не установлен%s\n' "$_b" "$_p" ;;
        esac
    done
}


cmd_json() {
    _store=$(store_root)
    _mp=$(store_mp "$_store")





    _jm=
    if mode_load 2>/dev/null; then _jm="$M_MODE"; fi



    _jb=false
    store_mode_alive && _jb=true
    printf '{"mode":"%s","switching":%s,' "$_jm" "$_jb"










    _jfs=$([ -n "$_store" ] && fs_of_mount "$_mp")




    printf '"on":%s,"ready":%s,"state":"%s","store":"%s","fs":"%s","fs_perm":%s,"store_free_b":%s,"store_total_b":%s,"store_used_b":%s,"data_free_b":%s,"data_total_b":%s' \
        "$([ -f "$STORE_MARK" ] && echo true || echo false)" \
        "$(store_ready && echo true || echo false)" \
        "$(store_state)" \
        "$_store" "$_jfs" \
        "$(fs_keeps_perms "$_jfs" && echo true || echo false)" \
        "$([ -n "$_store" ] && df_free_b "$_store" || echo 0)" \
        "$([ -n "$_store" ] && df_total_b "$_store" || echo 0)" \
        "$([ -n "$_store" ] && du_b "$_store" || echo 0)" \
        "$(df_free_b "$ENODIA_BOOT")" "$(df_total_b "$ENODIA_BOOT")"




    if seen_read; then printf ',"seen_known":true,"seen":"%s"' "$SEEN_NAMES"
    else printf ',"seen_known":false,"seen":""'; fi



    printf ',"old_place":"%s"' "$(old_place_names)"
    printf ',"bins":['
    _f=1
    for _b in $STORE_MOVABLE; do
        [ "$_f" = 1 ] || printf ','
        _f=0





        printf '{"name":"%s","where":"%s","on_store":%s,"size_b":%s,"pinned":%s,"deps":"%s","fits_router":%s}' \
            "$_b" "$(bin_where "$_b")" \
            "$(bin_on_store "$_b" && echo true || echo false)" \
            "$(size_b "$(bin_path "$_b")")" \
            "$(bin_pinned "$_b" && echo true || echo false)" \
            "$(bin_deps "$_b")" \
            "$(fits_router "$_b" && echo true || echo false)"
    done
    printf '],"cands":['
    _f=1




    cmd_detect | while IFS="$(printf '\t')" read -r _d _t _m _o; do
        [ "$_f" = 1 ] || printf ','
        _f=0



        printf '{"dev":"%s","fs":"%s","perm":%s,"mnt":"%s","ours":%s,"free_b":%s,"total_b":%s}' \
            "$_d" "$_t" "$(fs_keeps_perms "$_t" && echo true || echo false)" \
            "$_m" "$([ "$_o" = yes ] && echo true || echo false)" \
            "$([ -d "$_m" ] && df_free_b "$_m" || echo 0)" \
            "$([ -d "$_m" ] && df_total_b "$_m" || echo 0)"
    done
    printf ']}\n'
}






















CRON=/etc/crontabs/root
PATHS_TMP=/tmp/enodia-usb-paths.$$
FIND_TMP=/tmp/enodia-usb-files.$$      # список файлов дерева: `for f in $(find …)` рвёт путь с пробелом




mode_load() {
    M_MODE=; M_DIR=; M_STATE=; M_BIN=; M_STORE=; M_DDIR=; M_DSTATE=; M_DBIN=
    if [ ! -f "$ENODIA_BOOT/boot.sh" ]; then
        echo "нет $ENODIA_BOOT/boot.sh — бутстрап не собран, режимы недоступны (обновите скрипты)" >&2
        return 1
    fi
    sh "$ENODIA_BOOT/boot.sh" paths > "$PATHS_TMP" 2>/dev/null
    while IFS='=' read -r _mk _mv; do
        case "$_mk" in
            mode)       M_MODE="$_mv" ;;
            dir)        M_DIR="$_mv" ;;
            state)      M_STATE="$_mv" ;;
            bin)        M_BIN="$_mv" ;;
            store)      M_STORE="$_mv" ;;
            data_dir)   M_DDIR="$_mv" ;;
            data_state) M_DSTATE="$_mv" ;;
            data_bin)   M_DBIN="$_mv" ;;
        esac
    done < "$PATHS_TMP"
    rm -f "$PATHS_TMP" 2>/dev/null
    [ -n "$M_MODE" ] && [ -n "$M_DDIR" ]
}











tree_bytes() {      # $1 = каталог
    _tb=$(tar cf - -C "${1%/*}" "${1##*/}" 2>/dev/null | wc -c)
    case "$_tb" in ''|*[!0-9]*) _tb=0 ;; esac
    printf '%s' "$_tb"
}





copy_tree_verified() {
    rm -rf "$2" 2>/dev/null
    mkdir -p "$2" 2>/dev/null || { echo "  не создался $2" >&2; return 1; }


    cp -rp "$1/." "$2/" 2>/dev/null || cp -r "$1/." "$2/" 2>/dev/null || true
    sync
    _ctv_n=0; _ctv_bad=0; _ctv_moving=0; _ctv_gone=0





    find "$1" -type f 2>/dev/null > "$FIND_TMP"
    while IFS= read -r _ctv_f || [ -n "$_ctv_f" ]; do
        [ -n "$_ctv_f" ] || continue
        _ctv_r=${_ctv_f#"$1"/}
        _ctv_n=$((_ctv_n+1))




        if [ ! -e "$_ctv_f" ]; then
            _ctv_gone=$((_ctv_gone+1))
            _ctv_n=$((_ctv_n-1))
            continue
        fi
        if [ "$(md5_of "$_ctv_f")" != "$(md5_of "$2/$_ctv_r")" ]; then











            _ctv_try=0
            while [ "$_ctv_try" -lt 3 ]; do
                _ctv_try=$((_ctv_try+1))
                _ctv_was=$(md5_of "$_ctv_f")
                cp -p "$_ctv_f" "$2/$_ctv_r" 2>/dev/null || cp "$_ctv_f" "$2/$_ctv_r" 2>/dev/null
                sync
                [ "$(md5_of "$2/$_ctv_r")" = "$_ctv_was" ] && break
            done
            if [ "$(md5_of "$2/$_ctv_r")" = "$_ctv_was" ]; then
                :   # копия сошлась с источником на момент копии — файл доехал целым
            elif [ "$(md5_of "$_ctv_f")" != "$_ctv_was" ]; then
                _ctv_moving=$((_ctv_moving+1))
                [ "$_ctv_moving" -le 3 ] && echo "  меняется на ходу, взята последняя версия: $_ctv_r" >&2
            else
                _ctv_bad=$((_ctv_bad+1))
                [ "$_ctv_bad" -le 3 ] && echo "  не сошёлся: $_ctv_r" >&2
            fi
        fi
    done < "$FIND_TMP"
    rm -f "$FIND_TMP" 2>/dev/null
    if [ "$_ctv_n" = 0 ]; then echo "  нечего копировать из $1" >&2; return 1; fi
    if [ "$_ctv_bad" != 0 ]; then echo "  файлов не сошлось: $_ctv_bad из $_ctv_n" >&2; return 1; fi



    if [ "$_ctv_moving" != 0 ]; then echo "  менялись во время копии, взята последняя версия: $_ctv_moving" >&2; fi

    if [ "$_ctv_gone" != 0 ]; then echo "  исчезли во время копии (временные, копировать нечего): $_ctv_gone" >&2; fi
    echo "  скопировано и сверено файлов: $_ctv_n"
    return 0
}




swap_in() {
    if [ -d "$2" ]; then
        rm -rf "$2.old" 2>/dev/null
        mv "$2" "$2.old" 2>/dev/null || { echo "  не отодвинулся прежний $2" >&2; return 1; }
    fi
    if ! mv "$1" "$2" 2>/dev/null; then
        [ -d "$2.old" ] && mv "$2.old" "$2" 2>/dev/null      # вернуть как было
        echo "  не встал на место $2" >&2; return 1
    fi
    sync
    rm -rf "$2.old" 2>/dev/null
    return 0
}





exec_probe_store() {
    _eps="$1/.enodia-exec-probe"
    printf '#!/bin/sh\nexit 0\n' > "$_eps" 2>/dev/null || return 1
    chmod +x "$_eps" 2>/dev/null
    sync
    if [ ! -x "$_eps" ]; then rm -f "$_eps" 2>/dev/null; return 1; fi
    ( "$_eps" >/dev/null 2>&1 )
    _eprc=$?
    rm -f "$_eps" 2>/dev/null
    [ "$_eprc" = 0 ]
}












bins_carry() {      # $1 = откуда, $2 = куда
    [ -d "$1" ] || return 0
    [ "$1" = "$2" ] && return 0
    mkdir -p "$2" 2>/dev/null
    _bc_n=0; _bc_bad=0
    for _bc_f in "$1"/*; do
        [ -f "$_bc_f" ] || continue          # пустой каталог даёт саму маску — её отсекает -f
        case "${_bc_f##*/}" in *.new) continue ;; esac   # ступень прерванного переезда — не бинарь
        _bc_b=${_bc_f##*/}
        if move_verified "$_bc_f" "$2/$_bc_b" "$_bc_b"; then _bc_n=$((_bc_n+1)); else _bc_bad=$((_bc_bad+1)); fi
    done
    [ "$_bc_n" != 0 ] && echo "Бинарей перенесено: $_bc_n"
    [ "$_bc_bad" = 0 ]
}






bins_carry_home() {
    [ -d "$1" ] || return 0
    [ "$1" = "$2" ] && return 0
    mkdir -p "$2" 2>/dev/null
    _bh_n=0; _bh_bad=0
    for _bh_f in "$1"/*; do
        [ -f "$_bh_f" ] || continue
        case "${_bh_f##*/}" in *.new) continue ;; esac   # ступень прерванного переезда — не бинарь
        _bh_b=${_bh_f##*/}
        if store_movable "$_bh_b" && ! bin_pinned "$_bh_b"; then continue; fi


        is_program "$_bh_f" || continue
        if move_verified "$_bh_f" "$2/$_bh_b" "$_bh_b"; then _bh_n=$((_bh_n+1)); else _bh_bad=$((_bh_bad+1)); fi
    done
    [ "$_bh_n" != 0 ] && echo "Бинарей возвращено на роутер: $_bh_n"
    [ "$_bh_bad" = 0 ]
}










mode_event_fail() {     # $1 = режим, в который не переехали
    [ -f "$ENODIA_DIR/notify-event.sh" ] || return 0
    if [ -f "$ENODIA_DIR/nf-i18n.sh" ]; then . "$ENODIA_DIR/nf-i18n.sh"; fi
    if command -v nf_lang >/dev/null 2>&1; then _mef_l=$(nf_lang); else _mef_l=ru; fi
    if [ "$_mef_l" = en ]; then
        sh "$ENODIA_DIR/notify-event.sh" store-mode-fail 0 \
            "Storage layout switch failed" \
            "Switching to the «$1» layout did not go through; the layout is unchanged. Details: /tmp/enodia-store-mode.log (it is also in the diagnostics archive)." >/dev/null 2>&1
    else
        sh "$ENODIA_DIR/notify-event.sh" store-mode-fail 0 \
            "Смена раскладки не удалась" \
            "Переезд в режим «$1» не прошёл, раскладка осталась прежней. Подробности — /tmp/enodia-store-mode.log (он же лежит в диагностическом архиве)." >/dev/null 2>&1
    fi
    return 0
}

cmd_mode() {        # $1 = пусто (показать) | data | bins | full; $2 = устройство (как у enable)
    mode_load || return 1
    if [ -z "$1" ]; then
        case "$M_MODE" in
            data) echo "Режим: data — всё на флеше роутера" ;;
            bins) echo "Режим: bins — тяжёлые бинари на накопителе, код и настройки на флеше роутера" ;;
            full) echo "Режим: full — код, настройки и бинари на накопителе ($M_STORE)" ;;
            *)    echo "Режим: full, но накопитель НЕ НАЙДЕН — панели нет, поднята заглушка" ;;
        esac
        return 0
    fi
    case "$1" in data|bins|full) ;; *) echo "режим бывает data, bins или full" >&2; return 2 ;; esac
    [ "$1" = "$M_MODE" ] && { echo "Режим уже $1 — ничего не делаю"; return 0; }
    [ "$M_MODE" = none ] && { echo "накопитель с кодом не найден — сперва верните флешку, потом меняйте режим" >&2; return 1; }


    _mtw=$MOVE_TICK_WAIT; MOVE_TICK_WAIT=$MOVE_MODE_WAIT
    move_hold; _mhr=$?; MOVE_TICK_WAIT=$_mtw
    [ "$_mhr" = 0 ] || { mode_event_fail "$1"; return 1; }



    _mlw=0
    while lists_work_alive && [ "$_mlw" -lt "$MOVE_LISTS_WAIT" ]; do sleep 1; _mlw=$((_mlw + 1)); done
    if lists_work_alive; then
        move_release
        echo "идёт сборка списков или гео-категорий — раскладку не меняю, повторите, когда она закончится" >&2
        mode_event_fail "$1"; return 1
    fi
    case "$1" in
        full)      mode_to_full "$2" ;;
        data|bins) mode_to_router "$1" ;;
    esac



    _cm_rc=$?
    [ "$_cm_rc" = 0 ] || mode_event_fail "$1"
    return "$_cm_rc"
}

mode_to_full() {   # $1 = устройство/точка (как у enable), необязательно





    if grep -q "$M_DDIR/" "$CRON" 2>/dev/null; then
        sh "$ENODIA_BOOT/boot.sh" sync "$M_DIR" >/dev/null 2>&1
    fi
    if grep -q "$M_DDIR/" "$CRON" 2>/dev/null; then
        echo "cron всё ещё зовёт код напрямую ($M_DDIR/…) — после переезда роутер не поднимется" >&2
        echo "обновите установку (панель → «Обновление» либо установщик с ПК) и повторите" >&2
        return 1
    fi




    cmd_enable "$1" || { echo "накопитель не подготовлен — режим не меняю" >&2; return 1; }
    store_ready || { echo "хранилище не опознано — режим не меняю" >&2; return 1; }
    _mf_store=$(store_root)
    echo "Переезд кода и настроек на накопитель: $_mf_store"


    if ! exec_probe_store "$_mf_store"; then
        echo "с этого накопителя скрипты не запускаются (смонтирован noexec или не хранит права) — режим full невозможен" >&2
        echo "раскладка осталась прежней: бинари на накопителе, код и настройки на флеше (режим bins)" >&2
        return 1
    fi

    _mf_need=$(( $(tree_bytes "$M_DIR") + $(tree_bytes "$M_STATE") ))
    _mf_free=$(df_free_b "$_mf_store")
    if [ "$_mf_free" -lt "$((_mf_need + 1048576))" ]; then
        echo "на накопителе не хватает места: нужно $(mb "$_mf_need") МБ + запас, свободно $(mb "$_mf_free") МБ" >&2
        return 1
    fi

    echo "Копирую код:"
    copy_tree_verified "$M_DIR" "$_mf_store/enodia.new" || { rm -rf "$_mf_store/enodia.new" 2>/dev/null; return 1; }
    echo "Копирую настройки:"
    copy_tree_verified "$M_STATE" "$_mf_store/enodia-state.new" || { rm -rf "$_mf_store/enodia.new" "$_mf_store/enodia-state.new" 2>/dev/null; return 1; }
    swap_in "$_mf_store/enodia-state.new" "$_mf_store/enodia-state" || return 1
    swap_in "$_mf_store/enodia.new" "$_mf_store/enodia" || return 1



    harden_perms "$_mf_store/enodia" "$_mf_store/enodia-state" "$_mf_store/bin"

    sh "$_mf_store/enodia/boot.sh" sync "$_mf_store/enodia" >/dev/null 2>&1 \
        || echo "ВНИМАНИЕ: бутстрап не пересобрался — проверьте $ENODIA_BOOT" >&2

    echo "Убираю копию с флеша роутера…"
    ENODIA_DIR="$_mf_store/enodia" ENODIA_STATE="$_mf_store/enodia-state" ENODIA_BIN="$_mf_store/bin" ENODIA_MOVE_SW="$ENODIA_MOVE_SW" \
        exec sh "$_mf_store/enodia/usb-offload.sh" mode-drop-router
}




cmd_mode_drop_router() {



    set_traps 'usb_unlock_mine; move_release'
    mode_load || return 1



    [ -n "$M_DDIR" ] || { echo "бутстрап не сказал, где флеш роутера — ничего не трогаю" >&2; return 1; }
    [ "$ENODIA_DIR" != "$M_DDIR" ] || { echo "исполняемся с флеша роутера — сносить его нельзя" >&2; return 1; }
    store_ready || { echo "хранилище недоступно — раскладку на флеше НЕ трогаю" >&2; return 1; }
    [ "$ENODIA_DIR" = "$(store_root)/enodia" ] || { echo "исполняемся не из копии на накопителе ($ENODIA_DIR) — ничего не трогаю" >&2; return 1; }


    for _dr in heal.sh web-ui.sh totp.sh transport.sh VERSION store-lib.sh boot.sh; do
        [ -f "$ENODIA_DIR/$_dr" ] || { echo "в копии на накопителе нет $_dr — раскладку на флеше НЕ трогаю" >&2; return 1; }
    done
    [ -d "$ENODIA_STATE" ] || { echo "на накопителе нет копии настроек — раскладку на флеше НЕ трогаю" >&2; return 1; }

    bins_carry "$M_DBIN" "$ENODIA_BIN" || {
        echo "часть бинарей с флеша не переехала — раскладку на флеше НЕ трогаю (причина строкой выше)" >&2
        return 1
    }




    [ -f "$ENODIA_DIR/web-ui.sh" ] && sh "$ENODIA_DIR/web-ui.sh" stop >/dev/null 2>&1
    _dr_n=0
    for _dr in "$M_DSTATE" "$M_DBIN" "$M_DDIR"; do
        [ -d "$_dr" ] || continue
        rm -rf "$_dr" 2>/dev/null
        if [ -d "$_dr" ]; then echo "ВНИМАНИЕ: $_dr удалить не вышло (занят?) — уберите руками" >&2; else _dr_n=$((_dr_n+1)); fi
    done
    sync
    if [ -f "$ENODIA_DIR/web-ui.sh" ]; then
        sh "$ENODIA_DIR/web-ui.sh" start >/dev/null 2>&1 \
            || echo "ВНИМАНИЕ: панель не поднялась с накопителя — поднимите вручную: sh $ENODIA_BOOT/boot.sh web-ui.sh start" >&2
    fi
    echo "Готово: режим full. С флеша убрано каталогов: $_dr_n, остался только бутстрап ($ENODIA_BOOT)."
    return 0
}

mode_to_router() {   # $1 = data (забрать и бинари) | bins (бинари оставить на накопителе)
    if [ "$M_MODE" != full ]; then

        case "$1" in
            data) cmd_disable; return $? ;;
            bins) cmd_enable;  return $? ;;
        esac
    fi
    echo "Возврат кода на флеш роутера (режим $1)"


    _mr_need=$(( $(tree_bytes "$M_DIR") + $(tree_bytes "$M_STATE") ))
    _mr_free=$(df_free_b "$M_DDIR")
    if [ "$_mr_free" -lt "$((_mr_need + DATA_RESERVE_B))" ]; then
        echo "на флеше роутера не хватает места: нужно $(mb "$_mr_need") МБ + резерв $(mb "$DATA_RESERVE_B") МБ, свободно $(mb "$_mr_free") МБ" >&2
        echo "освободите место (экран «Компоненты» → снять лишние протоколы) и повторите" >&2
        return 1
    fi
    echo "Копирую код:"
    copy_tree_verified "$M_DIR" "$M_DDIR.new" || { rm -rf "$M_DDIR.new" 2>/dev/null; return 1; }
    echo "Копирую настройки:"
    copy_tree_verified "$M_STATE" "$M_DSTATE.new" || { rm -rf "$M_DDIR.new" "$M_DSTATE.new" 2>/dev/null; return 1; }
    swap_in "$M_DSTATE.new" "$M_DSTATE" || return 1
    swap_in "$M_DDIR.new" "$M_DDIR" || return 1



    harden_perms "$M_DDIR" "$M_DSTATE" "$M_DBIN"

    sh "$M_DDIR/boot.sh" sync "$M_DDIR" >/dev/null 2>&1 \
        || echo "ВНИМАНИЕ: бутстрап не пересобрался — проверьте $ENODIA_BOOT" >&2
    echo "Убираю копию с накопителя…"
    ENODIA_DIR="$M_DDIR" ENODIA_STATE="$M_DSTATE" ENODIA_BIN="$M_DBIN" ENODIA_MOVE_SW="$ENODIA_MOVE_SW" \
        exec sh "$M_DDIR/usb-offload.sh" mode-drop-store "$1"
}


cmd_mode_drop_store() {
    set_traps 'usb_unlock_mine; move_release'
    mode_load || return 1


    [ -n "$M_DDIR" ] || { echo "бутстрап не сказал, где флеш роутера — ничего не трогаю" >&2; return 1; }
    [ "$ENODIA_DIR" = "$M_DDIR" ] || { echo "код не вернулся на флеш — с накопителя ничего не сношу" >&2; return 1; }


    for _ds in heal.sh web-ui.sh totp.sh transport.sh VERSION store-lib.sh boot.sh; do
        [ -f "$M_DDIR/$_ds" ] || { echo "на флеше нет $_ds — с накопителя ничего не сношу" >&2; return 1; }
    done


    [ -d "$M_DSTATE" ] || { echo "на флеше роутера нет копии настроек — накопитель НЕ трогаю" >&2; return 1; }


    [ -f "$M_DDIR/web-ui.sh" ] && sh "$M_DDIR/web-ui.sh" stop >/dev/null 2>&1
    if ! store_ready; then cmd_mount_ensure >/dev/null 2>&1; fi
    if store_ready; then
        _ds_s=$(store_root)





        bins_carry_home "$_ds_s/bin" "$M_DBIN" \
            || echo "часть бинарей осталась на накопителе (причина выше) — воткните его и повторите смену режима" >&2
        rm -rf "$_ds_s/enodia" "$_ds_s/enodia-state" 2>/dev/null
        sync
    else
        echo "ВНИМАНИЕ: накопителя нет — бинари остались на нём. Воткните его и повторите смену режима." >&2
    fi

    if [ "$1" = data ]; then
        cmd_disable || echo "код вернулся, а бинари остались на накопителе — повторите «выключить накопитель»" >&2
    fi
    if [ -f "$M_DDIR/web-ui.sh" ]; then
        sh "$M_DDIR/web-ui.sh" start >/dev/null 2>&1 \
            || echo "ВНИМАНИЕ: панель не поднялась с флеша — поднимите вручную: sh $M_DDIR/web-ui.sh start" >&2
    fi
    echo "Готово: режим ${1:-bins}. Код и настройки снова на флеше роутера."
    return 0
}








case "$1" in
    mount-ensure|enable|disable|forget|place|mode)


        if [ -d "$PKG_LOCK" ]; then
            [ "$1" = mount-ensure ] && exit 1
            echo "идёт установка компонентов — дождитесь её окончания (экран «Компоненты») и повторите" >&2
            exit 1
        fi






        [ "$1" = mount-ensure ] && [ ! -f "$STORE_MARK" ] && exit 1
        [ "$1" = mode ] && [ -z "$2" ] && { cmd_mode; exit $?; }







        case "$1" in mount-ensure) _uw=8 ;; *) _uw=20 ;; esac
        if ! usb_lock "$_uw"; then
            [ "$1" = mount-ensure ] && exit 1        # молча: перенос идёт, тик повторится через 2 минуты
            echo "накопитель занят другой операцией (идёт перенос) — повторите через минуту" >&2
            exit 1
        fi
        set_traps 'usb_unlock; move_release'


        case "$1" in enable|disable|place) move_hold || exit 1 ;; esac
        ;;
esac
case "$1" in
    detect)       cmd_detect ;;
    mount-ensure) cmd_mount_ensure ;;
    enable)       cmd_enable "$2" ;;
    disable)      cmd_disable ;;
    forget)       cmd_forget ;;
    place)        cmd_place "$2" "$3" ;;
    mode)             cmd_mode "$2" "$3" ;;


    mode-drop-router) cmd_mode_drop_router; _drc=$?; [ "$_drc" = 0 ] || mode_event_fail full; exit "$_drc" ;;
    mode-drop-store)  cmd_mode_drop_store "$2"; _drc=$?; [ "$_drc" = 0 ] || mode_event_fail "${2:-bins}"; exit "$_drc" ;;
    status|"")    cmd_status ;;
    json)         cmd_json ;;
    *) echo "usage: $0 detect | mount-ensure | enable [dev|точка] | disable | forget | place <имя> router|store | mode [data|bins|full] | status | json"; exit 2 ;;
esac
