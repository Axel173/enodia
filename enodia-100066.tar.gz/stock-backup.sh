#!/bin/sh




































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
SB_VOL=${ENODIA_SB_VOL:-/data/sec_cfg/data.vol}             # the live container
SB_DIR=${ENODIA_SB_DIR:-/data/usr/sec_cfg}                  # the stock's copy of it
SB_SCRIPT=${ENODIA_SB_SCRIPT:-/usr/sbin/sec_cfg_bak.sh}     # the stock's copier (CGI's PATH may lack /usr/sbin — by path)
SB_LOCK=${ENODIA_SB_LOCK:-/var/run/sec_cfg_bak.lock}        # the copier's own flock
SB_MOUNTS=${ENODIA_SB_MOUNTS:-/proc/mounts}
SB_FREE_WAIT=${ENODIA_SB_FREE_WAIT:-10}                     # seconds UBIFS may take to give freed blocks back
SB_MARK="$ENODIA_STATE/.stock-backup-off"
SB_EST=${ENODIA_SB_EST:-/tmp/enodia-stock-backup.est}      # RAM: the copy's estimated weight per (file, size, mtime)
SB_RESERVE_B=1048576                                        # free space left over after a fresh copy



SB_MKSTATE=${ENODIA_SB_MKSTATE:-0}

if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
if [ -f "$ENODIA_DIR/label-lib.sh" ]; then . "$ENODIA_DIR/label-lib.sh"; fi
if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi

command -v fs_anchor >/dev/null 2>&1 || fs_anchor() { _fan="${1:-$ENODIA_DIR}"; while [ -n "$_fan" ] && [ ! -e "$_fan" ]; do _fan="${_fan%/*}"; done; printf '%s' "${_fan:-/}"; }
command -v fs_line   >/dev/null 2>&1 || fs_line()   { df -k "$(fs_anchor "$1")" 2>/dev/null | tail -1 | awk '{for(i=NF;i>1;i--) if($i ~ /%$/) break; if(i>=4 && $(i-3) ~ /^[0-9]+$/ && $(i-1) ~ /^[0-9]+$/ && $(i-3)+0>0){m=""; for(j=i+1;j<=NF;j++){ if(j>i+1) m=m " "; m=m $j }; print $(i-3), $(i-1), m}}'; }
command -v fs_mount  >/dev/null 2>&1 || fs_mount()  { _fsm=$(fs_line "$1"); printf '%s' "${_fsm#* * }"; }
command -v fs_free_b >/dev/null 2>&1 || fs_free_b() { _fsb=$(fs_line "$1" | awk '{printf "%.0f", $2*1024}'); case "$_fsb" in ''|*[!0-9]*) _fsb=0 ;; esac; printf '%s' "$_fsb"; }
command -v clock_sane >/dev/null 2>&1 || clock_sane() { _csn=${1:-$(date +%s 2>/dev/null)}; case "$_csn" in ''|*[!0-9]*) return 1 ;; esac; [ "$_csn" -gt 1700000000 ] 2>/dev/null && [ "$_csn" -lt 4102444800 ] 2>/dev/null; }
command -v lbl_commit >/dev/null 2>&1 || lbl_commit() { if [ -z "$2" ]; then rm -f "$1"; return $?; fi; _lblt="$1.$$"; if printf '%s\n' "$2" > "$_lblt" 2>/dev/null && [ "$(cat "$_lblt" 2>/dev/null)" = "$2" ]; then mv "$_lblt" "$1" && return 0; fi; rm -f "$_lblt"; return 1; }

num() { case "$1" in ''|*[!0-9]*) echo 0 ;; *) echo "$1" ;; esac; }
tf()  { if "$@"; then echo true; else echo false; fi; }

no()  {
	case "$1" in
		absent)  _nom="у этой прошивки нет копии настроек" ;;
		nolive)  _nom="хранилище настроек роутера не открылось при загрузке — копию не трогаю: она может быть единственной целой" ;;
		busy)    _nom="прошивка как раз делает копию — повторите через минуту" ;;
		nothing) _nom="копия настроек прошивки уже выключена" ;;
		space)   _nom="на флеше не хватит места на новую копию — сперва освободите место" ;;
		uci)     _nom="прошивка не приняла смену настройки" ;;
		rm)      _nom="копию выключил, но удалить её не вышло — место не освободилось" ;;
		nostate) _nom="каталог настроек системы недоступен (накопитель с системой не найден?) — выключать не стану: выбор негде запомнить" ;;
		*)       _nom="копию выключали не через панель — включить её отсюда нельзя" ;;
	esac
	printf '{"ok":false,"why":"%s","msg":"%s"}\n' "$1" "$_nom"; return 1
}
hum() { awk -v b="${1:-0}" 'BEGIN { k = b / 1024; if (k < 1024) printf "%d КБ", k; else printf "%.1f МБ", k / 1024 }'; }


sb_flag() { _sbf=$(uci -q get misc.features.sec_cfg_bak 2>/dev/null); case "$_sbf" in 0|1) echo "$_sbf" ;; *) echo "" ;; esac; }


sb_set()  {
	if uci set "misc.features.sec_cfg_bak=$1" 2>/dev/null && uci commit misc 2>/dev/null && [ "$(sb_flag)" = "$1" ]; then return 0; fi
	uci -q revert misc.features.sec_cfg_bak 2>/dev/null; return 1
}
sb_present() { [ -f "$SB_SCRIPT" ] && [ -f "$SB_VOL" ]; }
sb_copy()    { [ -e "$SB_DIR" ]; }


sb_live() { awk '$1 == "/dev/mapper/sec_cfg" && $2 == "/etc/config" { f = 1 } END { exit !f }' "$SB_MOUNTS" 2>/dev/null; }

sb_busy() { [ -d "${SB_LOCK%/*}" ] || return 1; ! sb_try 9<>"$SB_LOCK"; }
sb_try()  { flock -n 9; }
sb_mark() { sed -n "s/^$1=//p" "$SB_MARK" 2>/dev/null | head -n 1; }
sb_size_b() { _sbs=0; for _sbz in "$@"; do [ -f "$_sbz" ] && _sbs=$((_sbs + $(num "$(stat -c %s "$_sbz" 2>/dev/null)"))); done; echo "$_sbs"; }


sb_need_b() { echo $(( $(sb_size_b "$SB_VOL") + SB_RESERVE_B )); }




sb_est_b() {
	_seT=0; _seC=""
	for _sef in "$SB_DIR"/*; do
		[ -f "$_sef" ] || continue
		_sek="$_sef $(stat -c '%s %Y' "$_sef" 2>/dev/null)"
		_sev=$(awk -v k="$_sek" '($1 " " $2 " " $3) == k { print $4; exit }' "$SB_EST" 2>/dev/null)
		[ -n "$_sev" ] || _sev=$(gzip -c "$_sef" 2>/dev/null | wc -c)
		_sev=$(num "$(echo $_sev)")
		_seT=$((_seT + _sev)); _seC="${_seC:+$_seC
}$_sek $_sev"
	done
	lbl_commit "$SB_EST" "$_seC" 2>/dev/null
	echo "$_seT"
}

sb_status() {
	_ssP=false; sb_present && _ssP=true
	_ssF=$(sb_flag)
	_ssC=false; _ssCb=0; _ssEb=0
	if sb_copy; then _ssC=true; _ssCb=$(sb_size_b "$SB_DIR"/*); _ssEb=$(sb_est_b); fi
	_ssL=$(tf sb_live)
	_ssB=false; [ "$_ssP" = true ] && sb_busy && _ssB=true
	_ssM=false; [ -f "$SB_MARK" ] && _ssM=true
	_ssFree=$(fs_free_b "$SB_DIR")
	_ssNeed=$(sb_need_b)
	_ssMp=$(fs_mount "$SB_DIR" | tr -d '"\\')




	_ssO=false; _ssOw=""
	if [ "$_ssF" = 1 ] || [ "$_ssC" = true ]; then
		if [ "$_ssP" != true ]; then _ssOw=absent; elif [ "$_ssL" != true ]; then _ssOw=nolive; else _ssO=true; fi
	fi
	_ssMo=false; [ "$_ssM" = true ] && [ "$_ssF" != 1 ] && [ "$_ssC" != true ] && _ssMo=true
	_ssOn=false; _ssOnw=""
	if [ "$_ssP" != true ]; then _ssOnw=absent; elif [ "$_ssL" != true ]; then _ssOnw=nolive; elif [ "$_ssM" != true ]; then _ssOnw=notmine
	elif [ "$_ssF" = 1 ]; then _ssOnw=on; elif [ "$_ssFree" -lt "$_ssNeed" ]; then _ssOnw=space; else _ssOn=true; fi
	printf '{"present":%s,"flag":"%s","copy":%s,"copy_b":%s,"est_b":%s,"live":%s,"busy":%s,"mine":%s,"at":%s,"freed_b":%s,"free_b":%s,"need_b":%s,"mp":"%s","offer":%s,"off_why":"%s","off_mine":%s,"can_on":%s,"on_why":"%s"}\n' \
		"$_ssP" "$_ssF" "$_ssC" "$_ssCb" "$_ssEb" "$_ssL" "$_ssB" "$_ssM" "$(num "$(sb_mark at)")" "$(num "$(sb_mark freed)")" \
		"$_ssFree" "$_ssNeed" "$_ssMp" "$_ssO" "$_ssOw" "$_ssMo" "$_ssOn" "$_ssOnw"
}



sb_freed() {
	_sfm=0; _sfi=0; _sfs=0
	while [ "$_sfi" -lt "$SB_FREE_WAIT" ]; do
		_sfd=$(( $(fs_free_b "$SB_DIR") - $1 ))
		if [ "$_sfd" -gt "$_sfm" ]; then _sfm=$_sfd; _sfs=0
		else _sfs=$((_sfs + 1)); [ "$_sfs" -ge 2 ] && [ "$_sfm" -gt 0 ] && break; fi
		_sfi=$((_sfi + 1)); sleep 1
	done
	echo "$_sfm"
}

sb_now() {   # the moment for the marker; 0 while the clock is not trusted (the panel then shows no date)
	if command -v clock_sane >/dev/null 2>&1 && ! clock_sane; then echo 0; else num "$(date +%s 2>/dev/null)"; fi
}


sb_off_locked() {
	sb_try || { no busy; return 1; }
	_soW=$(sb_flag)
	_soHad=false; sb_copy && _soHad=true
	[ "$_soW" = 1 ] || [ "$_soHad" = true ] || { no nothing; return 1; }



	_soNew=1; [ -f "$SB_MARK" ] && _soNew=0
	_soWas=$(sb_mark was); [ "$_soNew" = 1 ] && _soWas=$_soW
	[ "$_soW" = 1 ] && _soWas=1

	_soAt=$(sb_mark at); [ "$_soNew" = 1 ] && _soAt=$(sb_now)



	_soDone=$(sb_mark done); [ "$_soNew" = 1 ] && _soDone=0

	[ "$_soNew" = 0 ] && ! grep -q '^done=' "$SB_MARK" 2>/dev/null && _soDone=1
	_soFrP=$(num "$(sb_mark freed)"); [ "$_soNew" = 1 ] && _soFrP=0
	_soF0=$(fs_free_b "$SB_DIR")








	_soFull=0
	if [ ! -d "$ENODIA_STATE" ]; then
		[ "$SB_MKSTATE" = 1 ] || { no nostate; return 1; }   # only the wizard (before the install) may make it
		_soPe=$(mkdir -p "$ENODIA_STATE" 2>&1) || case "$_soPe" in *'No space'*|*'space left'*) _soFull=1 ;; *) no nostate; return 1 ;; esac
	fi
	if [ "$_soFull" = 0 ]; then
		_soPr="$ENODIA_STATE/.stock-backup-probe.$$"
		if ! _soPe=$(touch "$_soPr" 2>&1); then
			case "$_soPe" in *'No space'*|*'space left'*) _soFull=1 ;; *) no nostate; return 1 ;; esac
		fi
		rm -f "$_soPr" 2>/dev/null
	fi
	lbl_commit "$SB_MARK" "$(printf 'was=%s\nat=%s\nfreed=%s\ndone=%s' "$_soWas" "$_soAt" "$_soFrP" "$_soDone")" 2>/dev/null
	if [ "$_soW" = 1 ] && ! sb_set 0; then
		[ "$_soNew" = 1 ] && lbl_commit "$SB_MARK" "" 2>/dev/null   # refused: no intent left behind
		no uci; return 1
	fi
	rm -rf "$SB_DIR" 2>/dev/null; sync

	sb_copy && { no rm; return 1; }

	_soFr=0; [ "$_soHad" = true ] && _soFr=$(sb_freed "$_soF0")
	_soFrM=$_soFr; [ "$_soDone" = 1 ] && _soFrM=$_soFrP
	[ -d "$ENODIA_STATE" ] || mkdir -p "$ENODIA_STATE" 2>/dev/null   # a full flash that took no dir before the removal has room now
	lbl_commit "$SB_MARK" "$(printf 'was=%s\nat=%s\nfreed=%s\ndone=1' "$_soWas" "$_soAt" "$_soFrM")" 2>/dev/null


	if [ "$1" = heal ] && [ "$_soW" = 1 ] && [ "$_soDone" = 1 ] && [ -f "$ENODIA_DIR/events.sh" ]; then
		if [ "$_soHad" = true ]; then _soEv="Вы её выключали — выключил снова: освобождено $((_soFr / 1024)) КБ."
		else _soEv="Вы её выключали — выключил снова, пока она не успела сделать новую копию."; fi
		sh "$ENODIA_DIR/events.sh" add stockbak-reoff 0 "Прошивка снова включила копию своих настроек" \
			"$_soEv Обычно так бывает после обновления прошивки." >/dev/null 2>&1
	fi
	if [ "$_soHad" != true ]; then _som="копия настроек прошивки выключена: копии ещё не было — прошивка её не сделает"
	elif [ "$_soFr" -gt 0 ]; then _som="копия настроек прошивки выключена: освобождено $(hum "$_soFr") на флеше"
	else _som="копия настроек прошивки выключена; место флеш отдаст чуть позже"; fi


	_soMk=$(tf test -f "$SB_MARK")
	[ "$_soMk" = true ] || _som="$_som; выбор не запомнился — после обновления прошивки копия может вернуться, а включить её обратно можно только вручную: uci set misc.features.sec_cfg_bak=1; uci commit misc"
	printf '{"ok":true,"freed_b":%s,"had":%s,"marked":%s,"msg":"%s"}\n' "$_soFr" "$_soHad" "$_soMk" "$_som"
}
sb_off() {
	sb_present || { no absent; return 1; }
	sb_live || { no nolive; return 1; }
	mkdir -p "${SB_LOCK%/*}" 2>/dev/null
	_sbo=$(sb_off_locked "$1" 9<>"$SB_LOCK" 2>/dev/null)
	[ -n "$_sbo" ] || _sbo=$(no busy)   # the lock's fd could not even be opened: the same words as a held lock
	printf '%s\n' "$_sbo"
	case "$_sbo" in *'"ok":true'*) return 0 ;; esac; return 1
}




sb_on_locked() {
	sb_try || { no busy; return 1; }
	[ -f "$SB_MARK" ] || { no notmine; return 1; }


	[ -w "$ENODIA_STATE" ] || { no nostate; return 1; }


	if [ "$(sb_flag)" = 1 ]; then lbl_commit "$SB_MARK" "" 2>/dev/null || { no nostate; return 1; }; echo already; return 0; fi
	[ "$(fs_free_b "$SB_DIR")" -ge "$(sb_need_b)" ] || { no space; return 1; }
	sb_set 1 || { no uci; return 1; }
	lbl_commit "$SB_MARK" "" 2>/dev/null || { sb_set 0; no nostate; return 1; }
	echo set
}
sb_on() {
	sb_present || { no absent; return 1; }
	sb_live || { no nolive; return 1; }
	mkdir -p "${SB_LOCK%/*}" 2>/dev/null
	_sbn=$(sb_on_locked 9<>"$SB_LOCK" 2>/dev/null)
	case "$_sbn" in
		already) printf '{"ok":true,"copy":%s,"msg":"%s"}\n' "$(tf sb_copy)" "копия настроек прошивки уже включена прошивкой"; return 0 ;;
		set) ;;
		'') no busy; return 1 ;;
		*) printf '%s\n' "$_sbn"; return 1 ;;
	esac


	sh "$SB_SCRIPT" >/dev/null 2>&1
	if sb_copy; then _som="копия настроек прошивки включена и сделана"
	else _som="копия настроек прошивки включена — прошивка сделает её при следующем проходе"; fi
	printf '{"ok":true,"copy":%s,"msg":"%s"}\n' "$(tf sb_copy)" "$_som"
}

sb_heal() {
	[ -f "$SB_MARK" ] || return 0
	sb_present || return 0
	[ "$(sb_flag)" = 1 ] || sb_copy || return 0


	_shi=0
	while :; do
		_sho=$(sb_off heal)
		case "$_sho" in *'"why":"busy"'*) ;; *) break ;; esac
		_shi=$((_shi + 1)); [ "$_shi" -lt 30 ] || break
		sleep 2
	done
	printf '%s\n' "$_sho"
}







sb_uninstall() {
	[ -f "$SB_MARK" ] || return 0
	_suW=$(sb_mark was)
	if [ "$_suW" = 1 ]; then
		if sb_present; then
			[ "$(sb_flag)" = 1 ] || sb_set 1 || { echo "fail-flag 1"; return 1; }
			_suR=restored
		else _suR=kept-absent; fi
	else _suR=kept; fi
	lbl_commit "$SB_MARK" "" || { echo "fail-mark $_suR"; return 1; }
	echo "$_suR"
}

case "${1:-}" in
	status)    sb_status ;;
	off)       sb_off user ;;
	on)        sb_on ;;
	heal)      sb_heal ;;
	uninstall) sb_uninstall ;;
	*)         echo "usage: stock-backup.sh status|off|on|heal|uninstall" >&2; exit 2 ;;
esac
