#!/bin/sh















































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}
TRANSPORT_FLAG="$ENODIA_STATE/.transport"
MARK_CORE="$ENODIA_DIR/mark-core.sh"








SWITCH_LOCK=/tmp/enodia-switching.lock



if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
command -v bin_path >/dev/null 2>&1 || bin_path() { printf '%s' "$ENODIA_BIN/$1"; }





REGISTRY="awg xray hy2 byedpi"








SELECTABLE="$REGISTRY zapret"










MARKING="awg xray hy2 byedpi"
cmd_marking() {
    [ -n "$1" ] || return 1
    for _mk in $MARKING; do [ "$_mk" = "$1" ] && return 0; done
    return 1
}












plugin_for() {
    case "$1" in
        awg)    echo "$ENODIA_DIR/transport-awg.sh" ;;
        xray)   echo "$ENODIA_DIR/xray-transport.sh" ;;
        hy2)    echo "$ENODIA_DIR/transport-hy2.sh" ;;
        byedpi) echo "$ENODIA_DIR/transport-byedpi.sh" ;;


        zapret) echo "$ENODIA_DIR/zapret.sh" ;;
        *)      echo "" ;;
    esac
}


transport_ready() {
    p=$(plugin_for "$1"); [ -n "$p" ] && [ -f "$p" ] || return 1
    transport_installed "$1" || return 1
    case "$1" in

        awg)  [ -f "$ENODIA_STATE/awg.conf" ] ;;


        xray) [ -s "$ENODIA_STATE/xray.json" ] ;;
        hy2)  [ -s "$ENODIA_STATE/hysteria.yaml" ] ;;


        byedpi) : ;;





        zapret) _zp=$(plugin_for zapret)
                if [ -f "$_zp" ]; then sh "$_zp" nfq-ok >/dev/null 2>&1 || [ "$?" = 2 ]; else :; fi ;;
        *)    return 1 ;;
    esac
}









transport_installed() {
    case "$1" in







        awg)    [ -x "$ENODIA_BIN/amneziawg-go" ] && [ -x "$ENODIA_BIN/awg" ] ;;


        xray)   [ -x "$(bin_path xray)" ] ;;
        hy2)    [ -x "$(bin_path hysteria)" ] ;;

        byedpi) [ -x "$(bin_path byedpi)" ] && [ -x "$(bin_path hev)" ] ;;




        zapret) [ -x "$(bin_path nfqws)" ] || return 1
                [ ! -f "$ENODIA_DIR/nfq-platform.sh" ] || sh "$ENODIA_DIR/nfq-platform.sh" ready >/dev/null 2>&1 ;;
        *)      return 1 ;;
    esac
}

active() { cat "$TRANSPORT_FLAG" 2>/dev/null | tr -d ' \r\n'; }


implied() { _imt=$(active); [ -n "$_imt" ] || { [ -f "$ENODIA_STATE/awg.conf" ] && _imt=awg; }; echo "$_imt"; }
apply_marking() { [ -f "$MARK_CORE" ] && sh "$MARK_CORE" >/dev/null 2>&1; }















cmd_configured() {
    [ -n "$(active)" ] && return 0
    [ -f "$ENODIA_STATE/awg.conf" ] && return 0
    return 1
}










cmd_ready() {
    _rt="${1:-$(active)}"
    [ -n "$_rt" ] || return 1          # транспорт не выбран вовсе — подниматься нечему
    transport_ready "$_rt"
}







cmd_list() { for t in $SELECTABLE; do transport_ready "$t" && echo "$t"; done; return 0; }


cmd_label() {
    case "$1" in
        awg) echo AmneziaWG ;; xray) echo Xray ;; hy2) echo Hysteria2 ;; byedpi) echo ByeDPI ;; zapret) echo Zapret ;;
        *) echo "$1" ;;
    esac
}






cmd_installed() {
    if [ -n "$1" ]; then transport_installed "$1"; return $?; fi
    for t in $SELECTABLE; do transport_installed "$t" && echo "$t"; done
    return 0            # ПЕРЕЧИСЛЕНИЕ — код 0 всегда (та же грабля, что у cmd_list выше)
}



cmd_names() { for t in $SELECTABLE; do echo "$t"; done; }










SLOT_CAPABLE="zapret awg byedpi xray hy2"
slot_ready() {
    case " $SLOT_CAPABLE " in *" $1 "*) ;; *) return 1 ;; esac
    p=$(plugin_for "$1"); [ -n "$p" ] && [ -f "$p" ] || return 1
    case "$1" in
        awg)    [ -x "$ENODIA_BIN/amneziawg-go" ] && [ -x "$ENODIA_BIN/awg" ] && ls "$ENODIA_STATE"/configs/*.conf     >/dev/null 2>&1 ;;
        xray)   [ -x "$(bin_path xray)" ]     && [ -x "$(bin_path hev)" ] && ls "$ENODIA_STATE"/xray-configs/*.json >/dev/null 2>&1 ;;
        hy2)    [ -x "$(bin_path hysteria)" ] && [ -x "$(bin_path hev)" ] && ls "$ENODIA_STATE"/hy2-configs/*.yaml  >/dev/null 2>&1 ;;
        byedpi) [ -x "$(bin_path byedpi)" ]   && [ -x "$(bin_path hev)" ] ;;   # десинк без сервера








        zapret) transport_installed zapret || return 1
                _szp=$(plugin_for zapret)
                sh "$_szp" nfq-ok >/dev/null 2>&1 || [ "$?" = 2 ] ;;
        *)      return 1 ;;
    esac
}
cmd_slot_list() { for t in $SLOT_CAPABLE; do slot_ready "$t" && echo "$t"; done; return 0; }   # rc всегда 0: пустой список ≠ ошибка (вызывающий отличает старый скрипт по rc=2 usage)





cmd_next() {
    [ "$1" = zapret ] && return 1
    for t in $REGISTRY; do
        [ "$t" = "$1" ] && continue
        transport_ready "$t" && { echo "$t"; return 0; }
    done
    return 1
}


cmd_up() {






    t="${1:-$(implied)}"
    [ -n "$t" ] || { echo "[transport] транспорт не настроен — поднимать нечего"; return 1; }
    p=$(plugin_for "$t"); [ -f "$p" ] || { echo "[transport] нет плагина для '$t'"; return 1; }
    apply_marking
    sh "$p" up
}
















SWITCH_LOCK_MINE=0
take_switch_lock() {
    [ -e "$SWITCH_LOCK" ] && return 0
    : > "$SWITCH_LOCK" 2>/dev/null && SWITCH_LOCK_MINE=1

    trap 'drop_switch_lock' EXIT
    trap 'exit 1' INT TERM HUP PIPE
    return 0
}
drop_switch_lock() {
    _slrc=$?
    [ "$SWITCH_LOCK_MINE" = 1 ] && rm -f "$SWITCH_LOCK" 2>/dev/null
    return $_slrc
}






vpn_off_won() {
    [ -f "$ENODIA_STATE/.vpn-off" ] || return 1
    echo "[transport] VPN выключили вручную, пока поднимался '$1' — довожу выключение"
    if [ -f "$ENODIA_DIR/vpn-toggle.sh" ]; then


        OFF_SETTLE=1 sh "$ENODIA_DIR/vpn-toggle.sh" off >/dev/null 2>&1
    else
        _vwp=$(plugin_for "$1"); [ -f "$_vwp" ] && sh "$_vwp" down >/dev/null 2>&1
    fi
    return 0
}

cmd_switch() {
    new="$1"





    _home_pick=0; [ "$2" = "--home" ] && _home_pick=1



    transport_ready "$new" || {
        _why="нет плагина/конфига"
        if [ "$new" = zapret ] && [ -x "$(bin_path nfqws)" ]; then
            _zp2=$(plugin_for zapret)
            if [ -f "$_zp2" ]; then
                if ! { sh "$_zp2" nfq-ok >/dev/null 2>&1 || [ "$?" = 2 ]; }; then
                    _why="сборка iptables на этом роутере не умеет NFQUEUE — десинк здесь невозможен"

                elif ! { sh "$_zp2" installed >/dev/null 2>&1 || [ "$?" = 2 ]; }; then
                    _why="не установлен пакет поддержки ядра — Роутер → Компоненты → Zapret"
                fi
            fi
        fi
        echo "[transport] '$new' не готов ($_why)"; return 1
    }






    if [ "$_home_pick" != 1 ] && [ -f "$ENODIA_STATE/.vpn-off" ]; then
        echo "[transport] VPN выключен вручную — автоматическая смена на '$new' не выполняется"; return 1
    fi
    take_switch_lock         # сторож/heal на время переключения не вмешиваются (см. SWITCH_LOCK)
    cur=$(active)





    [ "$SWITCH_RESTART" = 1 ] && [ -z "$cur" ] && cur=$new
    if [ -n "$cur" ] && { [ "$cur" != "$new" ] || [ "$SWITCH_RESTART" = 1 ]; }; then
        cp=$(plugin_for "$cur")
        if [ -f "$cp" ] && ! sh "$cp" down; then
            echo "[transport] прежний транспорт '$cur' не снят — смена отменена"
            return 1
        fi
        [ "$SWITCH_RESTART" = 1 ] && [ -f "$cp" ] && sh "$cp" cold
    fi





    if [ "$_home_pick" = 1 ]; then


        _fc=2
        if [ -f "$ENODIA_DIR/vpn-toggle.sh" ]; then
            sh "$ENODIA_DIR/vpn-toggle.sh" flag-clear; _fc=$?
        fi
        case "$_fc" in
            0) : ;;
            2) rm -f "$ENODIA_STATE/.vpn-off" 2>/dev/null ;;   # flag-fallback: old owner without this verb.
            *) echo "[transport] выключение ещё завершается — '$new' не поднимаю"; return 1 ;;
        esac
    elif [ -f "$ENODIA_STATE/.vpn-off" ]; then
        echo "[transport] VPN выключили вручную посреди автоматической смены — '$new' не поднимаю"; return 1
    fi



    _redeact=0; [ -s "$ENODIA_STATE/.cron-saved" ] && _redeact=1
    if [ -f "$ENODIA_DIR/uninstall.sh" ]; then sh "$ENODIA_DIR/uninstall.sh" cron-restore >/dev/null 2>&1 || true; fi
    apply_marking            # гарантируем ядро (на случай прихода из safety_off, где маркировка снята)
    echo "$new" > "$TRANSPORT_FLAG"
    np=$(plugin_for "$new"); [ -f "$np" ] || { echo "[transport] нет плагина для '$new'"; return 1; }
    if sh "$np" up; then
        vpn_off_won "$new" && return 1






        [ "$_home_pick" = 1 ] && echo "$new" > "$ENODIA_STATE/.transport-home"
        redeact_replay
        return 0
    fi





    echo "[transport] '$new' up НЕ удался → откат на '${cur:-—}'"
    if [ -n "$cur" ] && [ "$cur" != "$new" ] && transport_ready "$cur"; then
        echo "$cur" > "$TRANSPORT_FLAG"

        if [ ! -f "$ENODIA_STATE/.vpn-off" ]; then
            cp2=$(plugin_for "$cur"); [ -f "$cp2" ] && sh "$cp2" up >/dev/null 2>&1
        fi
    fi



    vpn_off_won "$(active)" >/dev/null


    redeact_replay
    return 1
}






redeact_replay() {
    [ "$_redeact" = 1 ] && [ -f "$ENODIA_DIR/heal.sh" ] || return 0
    _rph=held
    if [ "$SWITCH_LOCK_MINE" = 1 ]; then rm -f "$SWITCH_LOCK" 2>/dev/null; SWITCH_LOCK_MINE=0; _rph=""; fi


    sh "$ENODIA_DIR/heal.sh" replay $_rph >/dev/null 2>&1; _rpc=$?
    [ "$_rpc" = 0 ] || echo "[transport] ВНИМАНИЕ: подсистемы после деактивации НЕ переиграны (код $_rpc) — группы, гео, списки и «доступ домой» вернутся, если выключить и включить VPN или перезагрузить роутер"
    _redeact=0
}




cmd_down()     { t="${1:-$(active)}"; p=$(plugin_for "$t"); [ -f "$p" ] && sh "$p" down; }








cmd_cold() {
    if [ -n "${1:-}" ]; then
        p=$(plugin_for "$1"); [ -f "$p" ] && sh "$p" cold
        return 0
    fi
    for t in $REGISTRY; do
        p=$(plugin_for "$t"); [ -f "$p" ] && sh "$p" cold
    done
    return 0
}





cmd_live() {
    ip rule show 2>/dev/null | grep -qE 'fwmark 0x[1-7] lookup (1000|100[2-7])' && return 0
    ip rule show 2>/dev/null | grep -qE '^8[2-7]:' && return 0   # roads to servers (road.sh) — «off» removes them too
    for _lt in 1000 1002 1003 1004 1005 1006 1007; do [ -n "$(ip route show table "$_lt" 2>/dev/null)" ] && return 0; done   # not-wan: таблицы НЕСУЩИХ, про аплинк отвечает ip-lib.sh
    ip link show awg0 >/dev/null 2>&1 && return 0
    [ -f "$ENODIA_STATE/.zapret-on" ] && return 0
    return 1
}
cmd_health()   { t="${1:-$(active)}"; p=$(plugin_for "$t"); [ -f "$p" ] && sh "$p" health; }
cmd_failover() { t="${1:-$(active)}"; p=$(plugin_for "$t"); [ -f "$p" ] && sh "$p" failover; }







cmd_dns() {
    t="${1:-$(active)}"
    if [ -f "$ENODIA_DIR/doh-lib.sh" ]; then . "$ENODIA_DIR/doh-lib.sh"; fi
    if [ -n "$t" ]; then








        case "$t" in awg)
            if [ ! -f "$ENODIA_STATE/.vpn-off" ] && command -v carrier_iface >/dev/null 2>&1 && [ -z "$(carrier_iface)" ]; then
                command -v doh_apply_dns >/dev/null 2>&1 && doh_apply_dns direct && return 0
                command -v doh_restore_plain_dns >/dev/null 2>&1 && doh_restore_plain_dns
                return 0
            fi ;;
        esac
        p=$(plugin_for "$t"); [ -f "$p" ] && { sh "$p" dns; return $?; }
    fi
    if command -v doh_apply_dns >/dev/null 2>&1 && doh_apply_dns direct; then return 0; fi





    command -v doh_release_upstream >/dev/null 2>&1 && doh_release_upstream
    return 0
}









SLOTS_SH="$ENODIA_DIR/slots.sh"
TAB=$(printf '\t')





_slot_dispatch() {
    sverb="$1"; sid="$2"
    sline=$([ -f "$SLOTS_SH" ] && sh "$SLOTS_SH" show "$sid" 2>/dev/null)
    [ -n "$sline" ] || { echo "[transport] нет слота №$sid"; return 1; }
    [ "$(echo "$sline" | cut -f6)" = on ] || { echo "[transport] слот №$sid выключен"; return 1; }
    st=$(echo "$sline" | cut -f3); scfg=$(echo "$sline" | cut -f4)
    sp=$(plugin_for "$st")
    if [ ! -f "$sp" ]; then
        echo "[transport] нет плагина для '$st'"
        [ "$sverb" = slot-down ] && return 2
        return 1
    fi
    sout=$(sh "$sp" "$sverb" "$sid" "$scfg" 2>&1); src=$?
    if [ "$src" = 2 ]; then
        echo "[transport] '$st' пока не умеет слоты — выход №$sid живёт по fallback-политике"
    else
        [ -n "$sout" ] && printf '%s\n' "$sout"
    fi
    return $src
}

cmd_slot_up()   { _slot_dispatch slot-up "$1";   src=$?; apply_marking; return $src; }
cmd_slot_down() { _slot_dispatch slot-down "$1"; src=$?; apply_marking; return $src; }





cmd_slot_health() { _slot_dispatch slot-health "$1"; }




cmd_slot_probe() { _slot_dispatch slot-probe "$1"; src=$?; [ "$src" = 0 ] && apply_marking; return $src; }









cmd_slot_iface() {
    _sifo=$(_slot_dispatch slot-iface "$1" 2>/dev/null); _sifr=$?
    [ "$_sifr" = 0 ] || return "$_sifr"


    printf '%s\n' "$_sifo" | head -n1 | tr -d ' \t\r'
}




cmd_slot_age() {
    _sago=$(_slot_dispatch slot-age "$1" 2>/dev/null); _sagr=$?
    [ "$_sagr" = 0 ] || return "$_sagr"
    printf '%s\n' "$_sago" | head -n1 | tr -d ' \t\r'
}




cmd_slots_up() {
    [ -f "$SLOTS_SH" ] || return 0
    sids=$(sh "$SLOTS_SH" list-enabled 2>/dev/null | cut -f1)
    [ -n "$sids" ] || return 0
    for sid in $sids; do _slot_dispatch slot-up "$sid"; done
    apply_marking
    return 0
}











cmd_slots_down() {
    [ -f "$SLOTS_SH" ] || return 0
    sids=$(sh "$SLOTS_SH" list-enabled 2>/dev/null | cut -f1)
    [ -n "$sids" ] || return 0
    _sd_fail=0
    for sid in $sids; do _slot_dispatch slot-down "$sid" || [ "$?" = 2 ] || _sd_fail=1; done   # 2 = nothing to take down
    apply_marking
    return "$_sd_fail"
}







case "$1" in
    active)   active; echo ;;
    configured) cmd_configured ;;
    ready)    cmd_ready "$2" ;;
    marking)  cmd_marking "$2" ;;   # машинно: везёт ли транспорт по марке (0 да · 1 нет · 2 старая копия)
    names)    cmd_names ;;
    list)     cmd_list ;;
    label)    cmd_label "$2" ;;
    installed) cmd_installed "$2" ;;
    next)     cmd_next "$2" ;;
    up)       cmd_up "$2" ;;
    down)     cmd_down "$2" ;;
    cold)     cmd_cold "$2" ;;      # «выключили VPN»: погасить и ТЁПЛЫЕ резервы (без аргумента — все)


    rewarm)   p=$(plugin_for "$2"); [ -f "$p" ] || { echo "[transport] нет плагина для '$2'"; exit 1; }
              sh "$p" rewarm ;;
    switch)   cmd_switch "$2" "$3" ;;   # $3 = --home («выбрал человек»), см. cmd_switch


    restart)  _rst=$(implied)
              case "$_rst" in ""|none) echo "[transport] активного транспорта нет — перезапускать нечего"; exit 1 ;; esac
              SWITCH_RESTART=1; cmd_switch "$_rst" ;;
    health)   cmd_health "$2" ;;
    live)     cmd_live ;;           # машинно: живо ли что-то из снимаемого «Отключить VPN» (доводчик выключения)
    failover) cmd_failover "$2" ;;
    dns)      cmd_dns "$2" ;;
    slots-up) cmd_slots_up ;;
    slots-down) cmd_slots_down ;;
    slot-up)   cmd_slot_up "$2" ;;
    slot-down) cmd_slot_down "$2" ;;
    slot-health) cmd_slot_health "$2" ;;
    slot-probe) cmd_slot_probe "$2" ;;   # снятый выход: проба сервера без перепроводки, ответил — вернуть (сторож)
    slot-iface) cmd_slot_iface "$2" ;;   # имя несущей выхода №N (учёт трафика); пусто = считать нечем
    slot-age)  cmd_slot_age "$2" ;;       # how old the exit's carrier is, s (the watchdog); nothing = unknown
    slot-list) cmd_slot_list ;;      # транспорты, готовые нести ДОП-ВЫХОД (пикер в панели; ≠ list)
    *) echo "usage: $0 active|configured|ready [t]|marking <t>|names|list|installed [t]|next <t>|up [t]|down [t]|cold [t]|rewarm <t>|switch <t> [--home]|restart|health [t]|live|failover [t]|dns [t]|slots-up|slots-down|slot-up <id>|slot-down <id>|slot-health <id>|slot-probe <id>|slot-iface <id>|slot-age <id>|slot-list"; exit 2 ;;
esac
