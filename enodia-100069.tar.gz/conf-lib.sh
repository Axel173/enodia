#!/bin/sh














_CL_BL=" $(printf '\t')"



conf_load() {
	[ -f "$1" ] || return 1
	_clf=$1; shift
	for _clk in "$@"; do
		case "$_clk" in ''|[0-9]*|*[!A-Za-z0-9_]*) continue ;; esac

		_clv=$(sed -n "s/^[$_CL_BL]*\(export[$_CL_BL][$_CL_BL]*\)\{0,1\}$_clk=/=/p" "$_clf" 2>/dev/null | tr -d '\r' | tail -n 1)
		[ -n "$_clv" ] || continue
		_clv=${_clv#=}
		case "$_clv" in
			\'*) _clv=${_clv#\'}; _clv=${_clv%%\'*} ;;
			\"*) _clv=${_clv#\"}; _clv=${_clv%%\"*} ;;
			*)   _clv=${_clv%%[$_CL_BL]*} ;;
		esac
		eval "$_clk=\$_clv"   # the name is checked above; the value goes by reference — eval never parses it
	done
	return 0
}
