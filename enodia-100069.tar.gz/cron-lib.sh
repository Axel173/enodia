#!/bin/sh



















CRON_LOCK=${CRON_LOCK:-/tmp/enodia-cron.lock}
CRON_LOCK_WAIT=${CRON_LOCK_WAIT:-30}
CRON_LOCK_NOPID=3
CRON_HELD=0
CRON_DEPTH=0
CRON_LOCK_AT=""



cron_lock_of() { case "${1:-/etc/crontabs/root}" in /etc/crontabs/root) printf '%s' "$CRON_LOCK" ;; *) printf '%s' "$1.enodia-lock" ;; esac; }



cron_pid_live() {
	[ -d "/proc/$1" ] || return 1
	case "$(sed -n 's/^State:[[:space:]]*\(.\).*/\1/p' "/proc/$1/status" 2>/dev/null)" in Z) return 1 ;; esac
	return 0
}




cron_hold() {
	if [ "$CRON_HELD" = 1 ]; then CRON_DEPTH=$((CRON_DEPTH + 1)); return 0; fi
	CRON_HELD=0; CRON_LOCK_AT=$(cron_lock_of "${1:-}")
	_chp=$(cat "$CRON_LOCK_AT/pid" 2>/dev/null) || _chp=""
	if [ -n "${ENODIA_CRON_HOLDER:-}" ] && [ "$_chp" = "$ENODIA_CRON_HOLDER" ]; then return 0; fi
	_chw=0; _chn=0



	[ -d "${CRON_LOCK_AT%/*}" ] || mkdir -p "${CRON_LOCK_AT%/*}" 2>/dev/null
	until mkdir "$CRON_LOCK_AT" 2>/dev/null; do
		if [ ! -e "$CRON_LOCK_AT" ]; then
			mkdir "$CRON_LOCK_AT" 2>/dev/null && break
			[ -e "$CRON_LOCK_AT" ] || { echo "cron-lib: cannot make the crontab lock $CRON_LOCK_AT — writing without it" >&2; return 0; }
		fi
		_chp=$(cat "$CRON_LOCK_AT/pid" 2>/dev/null) || _chp=""


		if [ -n "$_chp" ]; then
			_chn=0
			if ! cron_pid_live "$_chp" && [ "$(cat "$CRON_LOCK_AT/pid" 2>/dev/null)" = "$_chp" ] && rm -rf "$CRON_LOCK_AT" 2>/dev/null; then
				continue   # removed — try again at once; a failed removal waits like a live holder (no busy loop)
			fi
		else
			_chn=$((_chn + 1))
			if [ "$_chn" -gt "$CRON_LOCK_NOPID" ] && [ ! -s "$CRON_LOCK_AT/pid" ] && rm -rf "$CRON_LOCK_AT" 2>/dev/null; then
				_chn=0; continue
			fi
		fi
		_chw=$((_chw + 1))
		if [ "$_chw" -gt "$CRON_LOCK_WAIT" ]; then
			echo "cron-lib: the crontab lock is held by ${_chp:-?} for over $CRON_LOCK_WAIT s — writing without it" >&2
			return 0
		fi
		sleep 1
	done


	if ! { echo "$$" > "$CRON_LOCK_AT/pid"; } 2>/dev/null || [ "$(cat "$CRON_LOCK_AT/pid" 2>/dev/null)" != "$$" ]; then
		rm -rf "$CRON_LOCK_AT" 2>/dev/null
		echo "cron-lib: the crontab lock's pid did not land in $CRON_LOCK_AT — writing without it" >&2
		return 0
	fi
	CRON_HELD=1
	ENODIA_CRON_HOLDER=$$; export ENODIA_CRON_HOLDER
	return 0
}




cron_drop() {
	[ "$CRON_HELD" = 1 ] || return 0
	[ "${1:-}" = all ] && CRON_DEPTH=0
	if [ "$CRON_DEPTH" -gt 0 ]; then CRON_DEPTH=$((CRON_DEPTH - 1)); return 0; fi
	[ "$(cat "$CRON_LOCK_AT/pid" 2>/dev/null)" = "$$" ] && rm -rf "$CRON_LOCK_AT"
	CRON_HELD=0
	unset ENODIA_CRON_HOLDER
	return 0
}
