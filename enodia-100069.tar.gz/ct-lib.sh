#!/bin/sh































CT_ECM_DEFUNCT=/sys/kernel/debug/ecm/ecm_db/defunct_all   # ручка ускорителя (debugfs, root, 0644)
CT_PROC=/proc/net/nf_conntrack                            # таблица соединений — читается и без утилиты

_ct_have_tool() { command -v conntrack >/dev/null 2>&1; }



_ct_ecm_defunct() {
	[ -w "$CT_ECM_DEFUNCT" ] || return 1
	echo 1 > "$CT_ECM_DEFUNCT" 2>/dev/null || return 1
}


ct_flush() {
	if _ct_have_tool; then conntrack -F >/dev/null 2>&1 || true; return 0; fi
	_ct_ecm_defunct || true
	return 0
}





















CT_MARK_MASK=0xff


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi
CT_SAVE_CHAIN=POSTROUTING
CT_SAVE_SPEC="-m conntrack --ctdir ORIGINAL -m comment --comment enodia-ctmark -j CONNMARK --save-mark --nfmask $CT_MARK_MASK --ctmask $CT_MARK_MASK"





ct_mark_save() {
	case "$1" in
		on)    case "$(iptables -t mangle -S "$CT_SAVE_CHAIN" 2>/dev/null | sed -n 2p)" in *"--comment enodia-ctmark "*) return 0 ;; esac
		       while iptables -t mangle -D "$CT_SAVE_CHAIN" $CT_SAVE_SPEC 2>/dev/null; do :; done
		       iptables -t mangle -I "$CT_SAVE_CHAIN" 1 $CT_SAVE_SPEC 2>/dev/null ;;
		off)   while iptables -t mangle -D "$CT_SAVE_CHAIN" $CT_SAVE_SPEC 2>/dev/null; do :; done; return 0 ;;
		check) iptables -t mangle -C "$CT_SAVE_CHAIN" $CT_SAVE_SPEC 2>/dev/null ;;
		*)     return 1 ;;
	esac
}


ct_flush_mark() {
	[ -n "$1" ] || return 0
	if _ct_have_tool; then conntrack -D --mark "$1/$CT_MARK_MASK" >/dev/null 2>&1 || true; return 0; fi
	_ct_ecm_defunct || true
	return 0
}




ct_flush_route() {
	if ! _ct_have_tool || ! ct_mark_save check; then ct_flush; return 0; fi
	ct_flush_mark "$1"
	[ -n "$2" ] || return 0
	ip rule show 2>/dev/null | awk -v t="$2" '{
		l = ""; m = ""; d = ""
		for (i = 1; i < NF; i++) {
			if ($i == "lookup" || $i == "table") l = $(i + 1)
			if ($i == "fwmark") m = $(i + 1)
			if ($i == "to") d = $(i + 1)
		}
		if (l != t) next
		if (m != "") print "m " m; else if (d != "") print "d " d
	}' | while read -r _ctk _ctv; do
		case "$_ctk" in
			m) ct_flush_mark "${_ctv%%/*}" ;;
			d) ct_flush_dst "${_ctv%/32}" ;;
		esac
	done
	return 0
}



ct_flush_slot() {
	case "$1" in ''|*[!0-9]*) ct_flush; return 0 ;; esac
	ct_flush_route "0x$1" "100$1"
}



ct_flush_src() {
	[ -n "$1" ] || return 0
	if _ct_have_tool; then conntrack -D --src "$1" >/dev/null 2>&1 || true; return 0; fi
	_ct_ecm_defunct || true
	return 0
}





ct_flush_src_n() {
	[ -n "$1" ] || return 0
	if _ct_have_tool; then conntrack -D --src "$1" 2>/dev/null | wc -l; return 0; fi
	_ct_ecm_defunct || true
	return 0
}



ct_flush_dst() {
	[ -n "$1" ] || return 0
	if _ct_have_tool; then
		if [ -n "$2" ]; then conntrack -D -p tcp -d "$1" --dport "$2" >/dev/null 2>&1 || true
		else                 conntrack -D -d "$1" >/dev/null 2>&1 || true; fi
		return 0
	fi
	_ct_ecm_defunct || true
	return 0
}



ct_flush_dport() {
	[ -n "$1" ] || return 0
	if _ct_have_tool; then conntrack -D -p tcp --dport "$1" >/dev/null 2>&1 || true; return 0; fi
	_ct_ecm_defunct || true
	return 0
}









ct_list_src() {
	[ -n "$1" ] || return 0
	if _ct_have_tool; then conntrack -L -s "$1" 2>/dev/null; return 0; fi
	[ -r "$CT_PROC" ] || return 0
	awk -v ip="$1" '{ for(i=1;i<=NF;i++) if (substr($i,1,4)=="src=") { if (substr($i,5)==ip) print; break } }' \
		"$CT_PROC" 2>/dev/null
	return 0
}





ct_list_all() {
	if _ct_have_tool; then conntrack -L 2>/dev/null; return 0; fi
	[ -r "$CT_PROC" ] || return 0
	cat "$CT_PROC" 2>/dev/null
	return 0
}




ct_tool() {
	if _ct_have_tool; then echo conntrack
	elif [ -w "$CT_ECM_DEFUNCT" ]; then echo ecm
	else echo none; fi
}
