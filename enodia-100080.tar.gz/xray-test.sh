#!/bin/sh














ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}


if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
command -v bin_path >/dev/null 2>&1 || bin_path() { printf '%s' "$ENODIA_BIN/$1"; }




if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v daemon_wait_port >/dev/null 2>&1 || daemon_wait_port() {
    DAEMON_WAIT_WHY=''; _dwi=0; while [ "$_dwi" -lt "$3" ]; do netstat -ltn 2>/dev/null | grep -q "$4:$5 " && return 0; sleep 1; _dwi=$((_dwi+1)); done
    netstat -ltn 2>/dev/null | grep -q "$4:$5 " && return 0
    DAEMON_WAIT_WHY="не появился за $3 с"; return 1; }
command -v daemon_ram_room >/dev/null 2>&1 || { daemon_ram_room() { return 0; }; DAEMON_GO_NEED_KB=0; }   # old library: no RAM guard
command -v daemon_wait_gone >/dev/null 2>&1 || daemon_wait_gone() { _dwg=0; while [ -d "/proc/$1" ]; do [ "$_dwg" -ge "${2:-5}" ] && return 1; sleep 1; _dwg=$((_dwg+1)); done; return 0; }
XRAY=$(bin_path xray)




if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi
IP_PROBE_TRACE="${IP_PROBE_TRACE:-https://1.1.1.1/cdn-cgi/trace}"








MODE=egress
case "$1" in speed) MODE=speed; shift ;; egress) shift ;; esac
name="$1"





TPORT="$2"; case "$TPORT" in 1081[2-9]) : ;; *) TPORT=10812 ;; esac



STREAMS="$3"; case "$STREAMS" in ''|*[!0-9]*) STREAMS=4 ;; esac
[ "$STREAMS" -lt 1 ] 2>/dev/null && STREAMS=1; [ "$STREAMS" -gt 8 ] 2>/dev/null && STREAMS=8
DUR="$4"; case "$DUR" in ''|*[!0-9]*) DUR=12 ;; esac
[ "$DUR" -lt 5 ] 2>/dev/null && DUR=5; [ "$DUR" -gt 30 ] 2>/dev/null && DUR=30
TCONF=/tmp/enodia-xray-test.$TPORT.json
TPID=/tmp/enodia-xray-test.$TPORT.pid
TLOG=/tmp/xray-test.$TPORT.log
TOUT=/tmp/enodia-xray-test.$TPORT.out
TACC=/tmp/xray-test.$TPORT.access.log

TLOCK=/tmp/enodia-xray-test.$TPORT.lock

emit() { printf '%s\n' "$1"; }




_lk=0




command -v pid_runs >/dev/null 2>&1 || pid_runs() { [ -n "$1" ] && [ -r "/proc/$1/cmdline" ] && tr '\000' ' ' 2>/dev/null < "/proc/$1/cmdline" | grep -qE "$2"; }
xt_lock() {   # $1 = lock dir, $2 = who may hold it alive (regex, default a test run) → 0 taken (our pid in it); 1 held by a live run
	mkdir "$1" 2>/dev/null && { echo $$ > "$1/pid"; return 0; }
	_lp=$(cat "$1/pid" 2>/dev/null | tr -cd '0-9')
	[ -n "$_lp" ] || { sleep 1; _lp=$(cat "$1/pid" 2>/dev/null | tr -cd '0-9'); }
	if [ -n "$_lp" ] && pid_runs "$_lp" "${2:-xray-test}"; then return 1; fi
	mv "$1" "$1.stale.$$" 2>/dev/null && rm -rf "$1.stale.$$" 2>/dev/null
	mkdir "$1" 2>/dev/null && { echo $$ > "$1/pid"; return 0; }
	return 1
}
lock_take() { xt_lock "$TLOCK" && _lk=1; }






XT_ADMIT=/tmp/enodia-xray-test.admit
XT_ADMIT_MAX=${XT_ADMIT_MAX:-60}
_adm=0; XT_ADMIT_WHY=''; XT_ADMIT_MEM=0



XT_ADMIT_HOLDERS='xray-test|packages\.sh'



xt_others() {   # another run's test xray is alive → 0
	for _xo in /tmp/enodia-xray-test.1081[2-9].pid; do
		[ -f "$_xo" ] && [ "$_xo" != "$TPID" ] || continue
		_xop=$(cat "$_xo" 2>/dev/null | tr -cd '0-9')
		[ -n "$_xop" ] && pid_runs "$_xop" 'xray' && return 0
	done
	return 1
}
xt_admit() {
	_xai=0
	while :; do
		if xt_lock "$XT_ADMIT" "$XT_ADMIT_HOLDERS"; then
			_adm=1
			daemon_ram_room "$DAEMON_GO_NEED_KB" && return 0
			rm -rf "$XT_ADMIT" 2>/dev/null; _adm=0; XT_ADMIT_MEM=1
			xt_others || { XT_ADMIT_WHY="мало свободной памяти ($DAEMON_RAM_WHY): ещё один xray уронил бы туннель — проверка не начата"; return 1; }
		fi


		if [ "$_xai" -ge "$XT_ADMIT_MAX" ]; then
			if [ "$XT_ADMIT_MEM" = 1 ]; then XT_ADMIT_WHY="мало свободной памяти ($DAEMON_RAM_WHY), идут другие проверки — повторите, когда они кончатся"
			else XT_ADMIT_WHY="идут другие проверки — повторите, когда они кончатся"; fi
			return 1
		fi
		sleep 1; _xai=$((_xai + 1))
	done
}
xt_admit_drop() { [ "$_adm" = 1 ] && rm -rf "$XT_ADMIT" 2>/dev/null; _adm=0; return 0; }
cleanup() {
	[ "$_lk" = 1 ] || return 0



	_xp=$(cat "$TPID" 2>/dev/null | tr -cd '0-9')
	if [ -n "$_xp" ]; then
		kill "$_xp" 2>/dev/null
		if ! daemon_wait_gone "$_xp" 3; then
			pid_runs "$_xp" xray && { kill -9 "$_xp" 2>/dev/null; daemon_wait_gone "$_xp" 2; }
		fi
	fi
	rm -f "$TPID" "$TCONF" "$TOUT" "$TOUT".* "$TACC" 2>/dev/null
	return 0
}


xt_done() { cleanup; xt_admit_drop; [ "$_lk" = 1 ] && rm -rf "$TLOCK" 2>/dev/null; _lk=0; return 0; }
trap xt_done EXIT
trap 'exit 1' INT TERM HUP PIPE

[ -n "$name" ] || { emit '{"ok":false,"msg":"не задано имя конфига"}'; exit 0; }
src="$ENODIA_STATE/xray-configs/$name.json"


case "${XRAY_TEST_SRC:-}" in /*) src=$XRAY_TEST_SRC ;; esac



xt_swap_live() { _xsp=$(cut -d' ' -f1 /tmp/enodia-pkg-inplace 2>/dev/null | tr -cd '0-9'); [ -n "$_xsp" ] && pid_runs "$_xsp" 'packages\.sh'; }
xt_swap_live && { emit '{"ok":false,"busy":true,"msg":"идёт замена программы на месте — повторите через минуту"}'; exit 0; }


XT_NOBIN='{"ok":false,"nobin":true,"msg":"xray не установлен на роутере"}'
[ -x "$XRAY" ] || { emit "$XT_NOBIN"; exit 0; }
[ -s "$src" ]  || { emit '{"ok":false,"msg":"конфиг не найден"}'; exit 0; }

lock_take || { emit "{\"ok\":false,\"busy\":true,\"msg\":\"на временном порту $TPORT идёт другая проверка — повторите, когда она кончится\"}"; exit 0; }
cleanup   # снять возможный прошлый тест (замок наш — значит, прежний держатель мёртв)









( umask 077; rm -f "$TCONF"; set -C
  sed -e "s/\"port\"[[:space:]]*:[[:space:]]*10808/\"port\": $TPORT/" \
      -e "s#/tmp/xray-access.log#none#g" \
      -e "s#/tmp/xray\.log#$TLOG#g" \
      "$src" > "$TCONF" ) 2>/dev/null
[ -s "$TCONF" ] || { emit '{"ok":false,"msg":"не удалось подготовить тест-конфиг"}'; exit 0; }

: > "$TLOG" 2>/dev/null


_tgc=$(sh "$ENODIA_DIR/net-tune.sh" memlimit-env 2>/dev/null | grep -E '^GOMEMLIMIT=[0-9]+MiB$')


xt_admit || { _xm=',"queue":true'; [ "$XT_ADMIT_MEM" = 1 ] && _xm=',"mem":true'; emit "{\"ok\":false,\"busy\":true$_xm,\"msg\":\"$XT_ADMIT_WHY\"}"; exit 0; }

[ -x "$XRAY" ] || { emit "$XT_NOBIN"; exit 0; }
start-stop-daemon -S -b -m -p "$TPID" -x /bin/sh -- -c "exec ${_tgc:+env $_tgc }'$XRAY' run -c '$TCONF' >>'$TLOG' 2>&1"





if ! daemon_wait_port "$TPID" xray 8 127.0.0.1 "$TPORT"; then
	err=$(tail -n 4 "$TLOG" 2>/dev/null | tr -d '\r\033' | sed 's/\[[0-9;]*m//g' | tr '\n' ' ' | sed 's/\\/\\\\/g; s/"/\\"/g' | cut -c1-300)
	emit "{\"ok\":false,\"msg\":\"xray не поднялся с этим конфигом: ${err:-$DAEMON_WAIT_WHY}\"}"
	exit 0
fi
xt_admit_drop   # loaded and listening: the next test asks the memory left after this one





if [ "$MODE" = speed ]; then




	CHUNK=$((75*1024*1024))
	rm -f "$TOUT".* 2>/dev/null
	t0=$(date +%s); deadline=$((t0+DUR)); k=0
	while [ "$k" -lt "$STREAMS" ]; do
		( tot=0
		  while now=$(date +%s); [ "$now" -lt "$deadline" ]; do
			rem=$((deadline-now)); [ "$rem" -lt 1 ] && break


			got=$(curl -s -k --max-time "$rem" -o /dev/null --socks5-hostname "127.0.0.1:$TPORT" \
			      -w '%{size_download}' "https://speed.cloudflare.com/__down?bytes=$CHUNK" 2>/dev/null)
			got=${got%.*}; case "$got" in ''|*[!0-9]*) got=0 ;; esac
			tot=$((tot+got))
		  done
		  echo "$tot" > "$TOUT.$k" ) &
		k=$((k+1))
	done
	wait


	t1=$(date +%s); el=$((t1-t0)); [ "$el" -lt 1 ] && el=1
	total=$(cat "$TOUT".* 2>/dev/null | awk '{s=s+$1} END{printf "%.0f", s+0}')
	rm -f "$TOUT".* 2>/dev/null
	if [ "${total:-0}" -gt 0 ] 2>/dev/null; then
		mbps=$(awk -v b="$total" -v t="$el" 'BEGIN{ if(t>0) printf "%.1f", b*8/t/1000000 }')
		emit "{\"ok\":true,\"mbps\":${mbps:-0},\"bytes\":$total,\"streams\":$STREAMS,\"secs\":$el}"
	else
		emit '{"ok":false,"msg":"скачивание через этот сервер не пошло"}'
	fi
	exit 0
fi




out=$(curl -s -k --max-time 12 --socks5-hostname "127.0.0.1:$TPORT" -w '|%{time_total}' "$IP_PROBE_TRACE" 2>/dev/null)
tt=${out##*|}; body=${out%|*}
ip=$(printf '%s\n' "$body" | sed -n 's/^ip=\([0-9.]*\).*/\1/p' | head -1)
if echo "$ip" | grep -Eq '^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$'; then
	ms=$(awk -v t="$tt" 'BEGIN{ if(t+0>0) printf "%.0f", t*1000 }')
	emit "{\"ok\":true,\"ip\":\"$ip\",\"ms\":${ms:-0}}"
else
	emit '{"ok":false,"msg":"нет реального выхода через этот сервер (пинг не значит рабочий)"}'
fi
exit 0
