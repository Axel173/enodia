#!/bin/sh



























: "${ENODIA_DIR:=/data/usr/app/enodia}"
: "${ENODIA_BIN:=/data/usr/app/enodia-bin}"
: "${ENODIA_STATE:=/data/usr/app/enodia-state}"



if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
command -v bin_path >/dev/null 2>&1 || bin_path() { printf '%s' "$ENODIA_BIN/$1"; }




if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v daemon_wait_uport >/dev/null 2>&1 || daemon_wait_uport() {
    DAEMON_WAIT_WHY=''; _dwi=0; while [ "$_dwi" -lt "$3" ]; do
        netstat -lnu 2>/dev/null | grep -q "$4:$5 " && return 0
        _dwp=$(cat "$1" 2>/dev/null); [ -d "/proc/${_dwp:-none}" ] || break
        sleep 1; _dwi=$((_dwi+1))
    done
    DAEMON_WAIT_WHY="порт $5 не появился за $_dwi с (или процесс умер)"; return 1; }







if [ -f "$ENODIA_DIR/dns-lib.sh" ]; then . "$ENODIA_DIR/dns-lib.sh"; fi
if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi


if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi
command -v carrier_iface >/dev/null 2>&1 || carrier_iface() { ip route show table 1000 2>/dev/null | awk '/^default/{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}'; }
command -v age_since >/dev/null 2>&1 || age_since() {
	case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
	[ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}
command -v clock_sane >/dev/null 2>&1 || clock_sane() { _csn=${1:-$(date +%s 2>/dev/null)}; case "$_csn" in ''|*[!0-9]*) return 1 ;; esac; [ "$_csn" -gt 1700000000 ] 2>/dev/null && [ "$_csn" -lt 4102444800 ] 2>/dev/null; }
DOH_BIN=$(bin_path https-dns-proxy)  # рантайм-бинарь https-dns-proxy (стейдж bin/https-dns-proxy.user)
DOT_BIN=$(bin_path dot-proxy)        # DoT-альтернатива (наш mbedTLS-статик, RFC 7858; стейдж bin/dot-proxy.user)


QUIC_BIN=$(bin_path quic-dns-proxy)
DOH_ADDR="127.0.0.1"
DOH_PORT="5053"
DOH_PID="/tmp/enodia-doh.pid"      # /tmp=RAM ⇒ демон переигрывается heal-ом на буте (как прочие альты)
DOH_LOG="/tmp/enodia-doh.log"
DOH_LOG_MAX=524288                 # порог ротации, байт (см. doh_log_rotate)
DOH_LOG_KEEP=131072                # сколько ХВОСТА оставляем при ротации
DOH_UPSTREAM="$DOH_ADDR#$DOH_PORT" # токен для dnsmasq `server=` (зовёт step-B dns_set_upstream)





















DOH_AUTO_STAMP="/tmp/.enodia-doh-auto-on"
DOH_HEALTH_STAMP="/tmp/.enodia-doh-health.stamp"
DOH_HEALTH_MISS="/tmp/.enodia-doh-health.miss"
DOH_AUTO_COOLDOWN="/tmp/.enodia-doh-auto-cooldown"
DOH_HEALTH_EVERY=${DOH_HEALTH_EVERY:-600}         # как часто щупаем авто-DoH (сек)
DOH_HEALTH_MISS_MAX=${DOH_HEALTH_MISS_MAX:-2}     # столько промахов ПОДРЯД = деградация, откат
DOH_COOLDOWN_SEC=${DOH_COOLDOWN_SEC:-3600}        # на сколько после отката запрещаем авто-режим
DOH_PLAIN_DNS1=${DOH_PLAIN_DNS1:-1.1.1.1}         # открытый upstream прямого режима (как в safety_off)
DOH_PLAIN_DNS2=${DOH_PLAIN_DNS2:-8.8.8.8}














DOH_DOT_FALLBACK="/tmp/.enodia-dot-fallback.stamp"
DOH_ODOH_FALLBACK="/tmp/.enodia-odoh-fallback.stamp"
DOH_QUIC_FALLBACK="/tmp/.enodia-quic-fallback.stamp"   # «<epoch> <rung>»: the QUIC level moved the proxy down to <rung> (dot|doh)
doh_proto() {
	case "$(cat "$ENODIA_STATE/.doh-proto" 2>/dev/null)" in dot) echo dot ;; odoh) echo odoh ;; doq) echo doq ;; doh3) echo doh3 ;; *) echo doh ;; esac
}
doh_proto_now() {
	case "$(doh_proto)" in
		dot)  [ -f "$DOH_DOT_FALLBACK" ] && [ -x "$DOH_BIN" ] && { echo doh; return 0; }; echo dot ;;
		odoh) [ -f "$DOH_ODOH_FALLBACK" ] && { echo doh; return 0; }; echo odoh ;;
		doq|doh3)


			[ -f "$DOH_QUIC_FALLBACK" ] || { doh_proto; return 0; }
			_dpnr=$(awk '{print $2; exit}' "$DOH_QUIC_FALLBACK" 2>/dev/null); _dpnl=$(doh_lv_rungs quic)
			case " $_dpnl " in *" $_dpnr "*) [ -n "$_dpnr" ] && { echo "$_dpnr"; return 0; } ;; esac
			[ -n "$_dpnl" ] && { echo "${_dpnl%% *}"; return 0; }
			doh_proto ;;
		*)    echo doh ;;
	esac
}
doh_bin_for() {
	case "${1:-$(doh_proto_now)}" in dot) echo "$DOT_BIN" ;; doq|doh3) echo "$QUIC_BIN" ;; *) echo "$DOH_BIN" ;; esac
}

doh_wire_l4() { case "${1:-$(doh_proto_now)}" in doq|doh3) echo udp ;; *) echo tcp ;; esac; }



doh_eff() { [ "$(doh_proto)" = odoh ] && echo odoh || doh_resolver_name; }







doh_url_port() {
	_dup=${1#https://}; _dup=${_dup%%/*}
	case "$_dup" in *:*) _dup=${_dup##*:} ;; *) _dup=443 ;; esac
	case "$_dup" in ''|*[!0-9]*) echo 443 ;; *) echo "$_dup" ;; esac
}
doh_url_host() { _duh=${1#https://}; _duh=${_duh%%/*}; printf '%s\n' "${_duh%%:*}"; }
doh_proto_port() {


	if [ "$1" = odoh ]; then doh_url_port "$(doh_odoh_relay_url)"; return 0; fi


	if [ "$1" = dot ] || [ "$1" = doq ]; then
		if [ "${2:-$(doh_eff)}" = custom ]; then
			_dpp=$(cat "$ENODIA_STATE/.doh-custom-dot-port" 2>/dev/null | tr -cd '0-9')
			[ -n "$_dpp" ] && { echo "$_dpp"; return 0; }
		fi
		echo 853; return 0
	fi
	_dpps=$(doh_resolver_spec "$2"); doh_url_port "${_dpps%%$(printf '\t')*}"
}


doh_proto_sni() {
	if [ "$1" = dot ] || [ "$1" = doq ]; then dot_resolver_sni "$2"; return 0; fi


	if [ "$1" = doh3 ]; then
		_dpsn=$(doh_resolver_spec "$2"); _dpsn=$(doh_url_host "${_dpsn%%$(printf '\t')*}")
		case "$_dpsn" in *[!0-9.]*) printf '%s\n' "$_dpsn" ;; *) dot_resolver_sni "$2" ;; esac
		return 0
	fi
	if [ "$1" = odoh ]; then _dpsn=$(doh_url_host "$(doh_odoh_relay_url)"); case "$_dpsn" in *[!0-9.]*) printf '%s\n' "$_dpsn" ;; esac; return 0; fi
	_dpsn=$(doh_resolver_spec "$2"); _dpsn=$(doh_url_host "${_dpsn%%$(printf '\t')*}")
	case "$_dpsn" in *[!0-9.]*) printf '%s\n' "$_dpsn" ;; esac
	return 0
}

doh_quic_path() {
	_dqp=$(doh_resolver_spec "$1"); _dqp=${_dqp%%$(printf '\t')*}; _dqp=${_dqp#https://}
	case "$_dqp" in */*) printf '/%s\n' "${_dqp#*/}" ;; *) echo /dns-query ;; esac
}





doh_quic_can() {
	_dqcr=${2:-$(doh_resolver_name)}
	case "$1" in doq|doh3) : ;; *) return 1 ;; esac
	case "$_dqcr" in
		odoh)   return 1 ;;
		custom) [ -n "$(doh_custom_host)" ]; return $? ;;
	esac
	return 0
}

doh_wire_port() { doh_proto_port "$(doh_proto_now)"; }


doh_all_ports() { printf '%s\n' 443 853 "$(doh_proto_port doh "$1")" "$(doh_proto_port dot "$1")" | sort -u | tr '\n' ' '; }




doh_installed() {
	[ -x "$(doh_bin_for)" ] || return 1
	[ "$(doh_proto_now)" != odoh ] || doh_odoh_capable
}


doh_on_intent() { [ "$(cat "$ENODIA_STATE/.doh-on" 2>/dev/null)" = on ]; }
doh_enabled()   { doh_on_intent && doh_installed; }
doh_upstream()  { echo "$DOH_UPSTREAM"; }











DNS_RELOAD_MARK=${DNS_RELOAD_MARK:-/tmp/enodia-dns-reload}
dns_upstream_put() {
	_dup=$( { echo no-resolv; for _dua in "$@"; do echo "server=$_dua"; done; } )
	if [ ! -e "$DNS_RELOAD_MARK" ] && [ "$(cat /etc/dnsmasq.d/00-upstream.conf 2>/dev/null)" = "$_dup" ] \
	   && [ "$(cat /tmp/dnsmasq.d/00-upstream.conf 2>/dev/null)" = "$_dup" ] && pidof dnsmasq >/dev/null 2>&1; then
		killall -HUP dnsmasq 2>/dev/null   # кэш прежнего пути — сбросить (дёшево: демон не встаёт заново)
		return 0
	fi
	rm -f "$DNS_RELOAD_MARK" 2>/dev/null
	mkdir -p /etc/dnsmasq.d
	printf '%s\n' "$_dup" > /etc/dnsmasq.d/00-upstream.conf
	/etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null
}











dns_now() {
	_dnsrc=stock; _dnadr=""; _dnupf=""
	for _dnf in /tmp/dnsmasq.d/00-upstream.conf /etc/dnsmasq.d/00-upstream.conf; do
		if [ -f "$_dnf" ]; then _dnupf="$_dnf"; break; fi
	done
	if [ -n "$_dnupf" ]; then
		_dnsrc=ours
		_dnadr=$(sed -n 's/^server=//p' "$_dnupf" | grep -v '^/' | tr '\n' ' ' | sed 's/ *$//')

		case "$_dnadr" in *127.0.0.1#*) _dnsrc=doh ;; esac
	else
		for _dnf in /tmp/resolv.conf.auto /tmp/resolv.conf.d/resolv.conf.auto; do
			if [ -f "$_dnf" ]; then
				_dnadr=$(sed -n 's/^nameserver *//p' "$_dnf" | tr '\n' ' ' | sed 's/ *$//'); break
			fi
		done
	fi






	_dnvia=tunnel
	if [ "$_dnsrc" = stock ] || doh_direct_regime; then _dnvia=direct
	elif [ "$_dnsrc" = doh ] && [ -f "$DOH_UNTUNNELED" ]; then _dnvia=direct; fi
	printf 'src=%s\naddr=%s\nvia=%s\n' "$_dnsrc" "$_dnadr" "$_dnvia"
}









doh_clock_ok() { clock_sane; }




doh_auto_cooling() {
	_dcu=$(cat "$DOH_AUTO_COOLDOWN" 2>/dev/null | tr -cd '0-9')
	[ -n "$_dcu" ] || return 1
	doh_clock_ok || return 0
	[ "$(date +%s)" -lt "$_dcu" ] && return 0
	rm -f "$DOH_AUTO_COOLDOWN" 2>/dev/null
	return 1
}
doh_auto() {
	[ "$(cat "$ENODIA_STATE/.doh-auto" 2>/dev/null)" != off ] || return 1
	doh_auto_cooling && return 1
	doh_installed
}
doh_auto_active() { [ -f "$DOH_AUTO_STAMP" ]; }

doh_want()        { doh_enabled || doh_auto_active; }

















DOH_CATALOG='cloudflare|Cloudflare (1.1.1.1)||US|https://1.1.1.1/dns-query|1.1.1.1 1.0.0.1|cloudflare-dns.com|1.1.1.1
google|Google (dns.google)||US|https://dns.google/dns-query|8.8.8.8 8.8.4.4|dns.google|8.8.8.8
quad9|Quad9 (9.9.9.9)||CH|https://dns.quad9.net/dns-query|9.9.9.9 149.112.112.112|dns.quad9.net|9.9.9.9
adguard|AdGuard DNS||CY|https://dns.adguard-dns.com/dns-query|94.140.14.14 94.140.15.15|dns.adguard-dns.com|94.140.14.14
controld|Control D||CA|https://freedns.controld.com/p0|76.76.2.11|p0.freedns.controld.com|1.1.1.1
dnssb|DNS.SB|xTom|DE|https://doh.dns.sb/dns-query|185.222.222.222 45.11.45.11|dot.sb|185.222.222.222
mullvad|Mullvad DNS||SE|https://dns.mullvad.net/dns-query|194.242.2.2|dns.mullvad.net|1.1.1.1
wikimedia|Wikimedia DNS||US|https://wikimedia-dns.org/dns-query|185.71.138.138|wikimedia-dns.org|1.1.1.1
dns4eu|DNS4EU|Whalebone|CZ|https://unfiltered.joindns4.eu/dns-query|86.54.11.100 86.54.11.200|unfiltered.joindns4.eu|86.54.11.100
opendns|OpenDNS|Cisco|US|https://doh.opendns.com/dns-query|208.67.222.222 208.67.220.220|dns.opendns.com|208.67.222.222
appliedprivacy|Applied Privacy||AT|https://doh.applied-privacy.net/query|146.255.56.98|dot1.applied-privacy.net|1.1.1.1
libredns|LibreDNS|LibreOps|GR|https://doh.libredns.gr/dns-query|116.202.176.26|dot.libredns.gr|1.1.1.1
nextdns|NextDNS||US|https://dns.nextdns.io/|45.90.28.0 45.90.30.0|dns.nextdns.io|45.90.28.0
custom|||||||'


doh_tab() { printf '%s\n' "$1" | awk -F'|' -v k="$2" -v f="$3" '($1 "") == (k "") { print $f; exit }'; }   # <таблица> <ключ> <поле>
doh_cat() { doh_tab "$DOH_CATALOG" "$1" "$2"; }

doh_tab_keys() { printf '%s\n' "$1" | awk -F'|' 'NF > 1 && ($1 "") != "custom" { printf "%s%s", (n++ ? " " : ""), $1 } END { print "" }'; }

doh_resolver_list() { printf '%s\n' "$DOH_CATALOG" | awk -F'|' 'NF > 1 { printf "%s%s", (n++ ? " " : ""), $1 } END { print "" }'; }















doh_custom_parse() {







	case "$1" in *"
"*) return 1 ;; esac
	_dcp=$(printf '%s' "$1" | tr -d '\r' | sed 's#^[[:space:]]*##; s#[[:space:]]*$##')
	[ -n "$_dcp" ] || return 1


	echo "$_dcp" | grep -qE '^(https://|tls://)?[A-Za-z0-9]([A-Za-z0-9._-]{0,251}[A-Za-z0-9])?(:[0-9]{1,5})?(/[A-Za-z0-9._~%/-]*)?$' || return 1



	_dch=$(printf '%s' "$_dcp" | sed 's#^https://##; s#^tls://##; s#/.*$##; s#:[0-9][0-9]*$##')
	[ -n "$_dch" ] || return 1

	_dcr=${_dcp#https://}; _dcr=${_dcr#tls://}; _dcr=${_dcr%%/*}; _dcpt=''
	case "$_dcr" in *:*) _dcpt=${_dcr##*:} ;; esac

	case "$_dcpt" in '') : ;; *) [ "$_dcpt" -ge 1 ] 2>/dev/null && [ "$_dcpt" -le 65535 ] 2>/dev/null || return 1 ;; esac



	case "$_dcpt" in 0*) return 1 ;; esac
	_dcdp=''
	case "$_dcp" in
		https://*) _dcu="$_dcp" ;;
		tls://*)   _dcu="https://$_dch/dns-query"; _dcdp=$_dcpt ;;
		*/*)       _dcu="https://$_dcp" ;;
		*)         _dcu="https://$_dch/dns-query"; _dcdp=$_dcpt ;;
	esac

	[ "$_dcdp" = 853 ] && _dcdp=''


	if command -v is_ipv4 >/dev/null 2>&1 && is_ipv4 "$_dch"; then _dcs=""; else _dcs="$_dch"; fi



	printf '%s\t%s\t%s\t%s\n' "$_dcu" "$_dcs" "$_dch" "$_dcdp"
}


doh_custom_host() { cat "$ENODIA_STATE/.doh-custom-sni" 2>/dev/null | tr -d ' \r\n'; }

doh_resolver_name() {
	n=$(cat "$ENODIA_STATE/.doh-resolver" 2>/dev/null)
	case " $(doh_resolver_list) " in *" $n "*) echo "$n" ;; *) echo cloudflare ;; esac
}



doh_resolver_spec() {
	name="${1:-$(doh_eff)}"
	case "$name" in

		odoh)    printf '%s\t%s\n' "$(doh_odoh_target_url)" '1.1.1.1' ;;
		nextdns)
			id=$(cat "$ENODIA_STATE/.doh-nextdns-id" 2>/dev/null | tr -cd 'a-f0-9')
			printf '%s%s\t%s\n' "$(doh_cat nextdns 5)" "$id" "$(doh_cat nextdns 8)" ;;
		custom)




			curl_url=$(cat "$ENODIA_STATE/.doh-custom-url" 2>/dev/null | tr -d ' \r\n')
			[ -n "$curl_url" ] || { printf '%s\t%s\n' 'https://1.1.1.1/dns-query' '1.1.1.1'; return 0; }



			cboot=$(doh_resolver_ips custom | awk '{print $1; exit}')
			[ -n "$cboot" ] || cboot=1.1.1.1
			printf '%s\t%s\n' "$curl_url" "$cboot" ;;
		*)

			_drsn=$name; [ -n "$(doh_cat "$_drsn" 5)" ] || _drsn=cloudflare
			printf '%s\t%s\n' "$(doh_cat "$_drsn" 5)" "$(doh_cat "$_drsn" 8)" ;;
	esac
}







doh_resolver_ips() {
	case "${1:-$(doh_eff)}" in

		odoh)    doh_odoh_ips ;;







		custom)  cat "$ENODIA_STATE/.doh-custom-ips" 2>/dev/null | tr -s '\r\n\t ' '    ' | sed 's/^ //; s/ $//' ;;
		*)
			_drik=${1:-$(doh_eff)}; _drii=$(doh_cat "$_drik" 6)
			[ -n "$_drii" ] || _drii=$(doh_cat cloudflare 6)   # нет такого ключа — как у doh_resolver_spec: cloudflare
			echo "$_drii" ;;
	esac
}














DOH_CUSTOM_STAMP="/tmp/.enodia-doh-custom.stamp"
DOH_CUSTOM_EVERY=${DOH_CUSTOM_EVERY:-3600}   # как часто перерезолвим в тике сторожа (сек)









doh_anchor_ips() {
	command -v doh_ips >/dev/null 2>&1 || return 1
	doh_ips "$1" "" 2>/dev/null | grep -E '^([0-9]{1,3}\.){3}[0-9]{1,3}$' | sort -u | head -4
}

doh_custom_refresh() {

	if [ "$(doh_proto)" = odoh ]; then doh_odoh_refresh "$1"; return 0; fi
	[ "$(doh_resolver_name)" = custom ] || return 0
	_dcr_h=$(doh_custom_host)
	[ -n "$_dcr_h" ] || return 0          # IP-литерал: якорь известен из самого URL, дрейфа нет



	if [ "$1" != force ]; then
		_dcr_t=$(cat "$DOH_CUSTOM_STAMP" 2>/dev/null | tr -cd '0-9')
		[ -n "$_dcr_t" ] && [ "$(age_since "$_dcr_t")" -lt "$DOH_CUSTOM_EVERY" ] && return 0
	fi


	_dcr_new=$(doh_anchor_ips "$_dcr_h")
	[ -n "$_dcr_new" ] || return 0
	doh_clock_ok && date +%s > "$DOH_CUSTOM_STAMP" 2>/dev/null








	_dcr_old=$(cat "$ENODIA_STATE/.doh-custom-ips" 2>/dev/null | sort -u)
	[ "$_dcr_new" = "$_dcr_old" ] && return 0





	if doh_want; then
		doh_resolver_mark del; doh_resolver_bypass del
		echo "$_dcr_new" > "$ENODIA_STATE/.doh-custom-ips"
		doh_anchor_apply


		doh_pin_hosts





		case "$(doh_proto_now)" in dot|doq|doh3) doh_running && doh_restart ;; esac
	else
		echo "$_dcr_new" > "$ENODIA_STATE/.doh-custom-ips"
	fi
	return 0
}




dot_resolver_sni() {
	case "${1:-$(doh_eff)}" in
		odoh)    return 0 ;;   # у ODoH DoT нет
		nextdns) _id=$(cat "$ENODIA_STATE/.doh-nextdns-id" 2>/dev/null | tr -cd 'a-f0-9')
		         [ -n "$_id" ] && echo "$_id.$(doh_cat nextdns 7)" ;;


		custom)  doh_custom_host ;;
		*)
			_drsk=${1:-$(doh_eff)}; _drss=$(doh_cat "$_drsk" 7)
			[ -n "$_drss" ] || _drss=$(doh_cat cloudflare 7)   # нет такого ключа — cloudflare, как у соседей
			echo "$_drss" ;;
	esac
}









DOH_ODOH_TARGETS='cloudflare|Cloudflare||US|https://odoh.cloudflare-dns.com/dns-query|162.159.62.1 172.64.42.1
dnscryptpt|dnscry.pt||DE|https://fra01.dnscry.pt/dns-query|45.82.120.61
custom|||||'
DOH_ODOH_RELAYS='fastly|crypto.sx|Fastly|US|https://odoh-relay.edgecompute.app/|151.101.1.51 151.101.65.51 151.101.129.51 151.101.193.51
numa|numa||DE|https://odoh-relay.numa.rs/relay|178.104.229.30
custom|||||'
DOH_ODOH_RELAY_NOW="/tmp/.enodia-odoh-relay"       # через какой ретранслятор списка идём СЕЙЧАС (лестница doh_odoh_rescue)
DOH_ODOH_TRY="/tmp/.enodia-odoh-try.stamp"         # когда в последний раз пробовали вернуться с отката на ODoH (эпоха)
DOH_ODOH_STAMP="/tmp/.enodia-doh-odoh.stamp"       # когда перерезолвили якоря (троттл, как у своего резолвера)
DOH_ODOH_CAP="/tmp/.enodia-doh-odoh-cap"           # «размер mtime да|нет»: умеет ли ODoH программа DoH (doh_odoh_capable)
DOH_ODOH_RETRY=${DOH_ODOH_RETRY:-900}              # через сколько с отката пробовать ретрансляторы снова (сек)…
DOH_ODOH_RETRY_MAX=${DOH_ODOH_RETRY_MAX:-3600}     # …а после каждой неудачной попытки — вдвое дольше, не больше этого
DOH_ODOH_TRIES="/tmp/.enodia-odoh-tries"          # неудачных попыток возврата подряд (счёт, не эпоха — потому не *.stamp)
DOH_ODOH_RESCUE="/tmp/.enodia-odoh-rescue.stamp"  # when the ladder last found nothing alive (epoch): not climbed again before DOH_ODOH_RETRY
DOH_PIN_RELAY=enodia-doh-relay                     # владельцы закрепления имён ретрансляторов: …1, …2 (doh_pin_hosts)

doh_odoh_target() {
	_dot=$(cat "$ENODIA_STATE/.doh-odoh-target" 2>/dev/null | tr -d ' \r\n')
	[ -n "$_dot" ] && { [ "$_dot" = custom ] || [ -n "$(doh_tab "$DOH_ODOH_TARGETS" "$_dot" 5)" ]; } && { echo "$_dot"; return 0; }
	echo cloudflare
}


doh_named() { if [ "$(doh_proto)" = odoh ]; then doh_odoh_target; else doh_resolver_name; fi; }

doh_odoh_relay_pick() {
	_dor=$(cat "$ENODIA_STATE/.doh-odoh-relay" 2>/dev/null | tr -d ' \r\n')
	case "$_dor" in ''|auto) echo auto; return 0 ;; custom) echo custom; return 0 ;; esac
	[ -n "$(doh_tab "$DOH_ODOH_RELAYS" "$_dor" 5)" ] && echo "$_dor" || echo auto
}

doh_odoh_relays() { _dorp=$(doh_odoh_relay_pick); if [ "$_dorp" = auto ]; then doh_tab_keys "$DOH_ODOH_RELAYS"; else echo "$_dorp"; fi; }
doh_odoh_relay_now() {
	_drn=$(cat "$DOH_ODOH_RELAY_NOW" 2>/dev/null | tr -d ' \r\n')
	for _drk in $(doh_odoh_relays); do [ "$_drk" = "$_drn" ] && { echo "$_drk"; return 0; }; done
	doh_odoh_relays | awk '{print $1}'
}

doh_odoh_url() {
	if [ "$2" = custom ]; then cat "$ENODIA_STATE/.doh-odoh-custom-$1" 2>/dev/null | tr -d ' \r\n'; return 0; fi
	if [ "$1" = relay ]; then doh_tab "$DOH_ODOH_RELAYS" "$2" 5; else doh_tab "$DOH_ODOH_TARGETS" "$2" 5; fi
}
doh_odoh_target_url() { doh_odoh_url target "$(doh_odoh_target)"; }
doh_odoh_relay_url()  { doh_odoh_url relay "${1:-$(doh_odoh_relay_now)}"; }

doh_odoh_config_sig() {
    [ "$(doh_proto)" = odoh ] || return 0
    printf '%s\n%s\n' "$(doh_odoh_target_url)" "$(doh_odoh_relay_url)" | md5sum | cut -d' ' -f1
}


doh_odoh_host_ips() {
	case "$1" in '') return 0 ;; *[!0-9.]*) : ;; *) echo "$1"; return 0 ;; esac
	_dhi=$(awk -v h="$1" '($1 "") == (h "") { $1 = ""; sub(/^ +/, ""); print; exit }' "$ENODIA_STATE/.doh-odoh-ips" 2>/dev/null)
	[ -n "$_dhi" ] && { echo "$_dhi"; return 0; }
	printf '%s\n%s\n' "$DOH_ODOH_TARGETS" "$DOH_ODOH_RELAYS" | \
		awk -F'|' -v h="$1" '{ u = $5; sub(/^https:\/\//, "", u); sub(/[:\/].*$/, "", u) } (u "") == (h "") && $6 != "" { print $6; exit }'
}

doh_odoh_hosts() {
	for _dok in $(doh_odoh_relays); do doh_url_host "$(doh_odoh_relay_url "$_dok")"; done
	doh_url_host "$(doh_odoh_target_url)"
}

doh_odoh_ips() {
	for _doh in $(doh_odoh_hosts); do doh_odoh_host_ips "$_doh"; done | tr ' ' '\n' | \
		grep -E '^([0-9]{1,3}\.){3}[0-9]{1,3}$' | sort -u | tr '\n' ' ' | sed 's/ $//'
}




doh_odoh_parse_url() {
	case "$1" in *"
"*) return 1 ;; esac
	_dpu=$(printf '%s' "$1" | tr -d '\r' | sed 's#^[[:space:]]*##; s#[[:space:]]*$##')
	echo "$_dpu" | grep -qE '^https://[A-Za-z0-9]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?(/[A-Za-z0-9._~/-]*)?$' || return 1
	_dpuh=$(doh_url_host "$_dpu")
	case "$_dpuh" in *.*) : ;; *) return 1 ;; esac
	case "$_dpuh" in *[!0-9.]*) : ;; *) return 1 ;; esac
	case "$_dpu" in
		https://*/?*) printf '%s\n' "$_dpu" ;;
		*) _dpu=${_dpu%/}; if [ "$2" = target ]; then printf '%s/dns-query\n' "$_dpu"; else printf '%s/\n' "$_dpu"; fi ;;
	esac
}




doh_odoh_owner() {
	doh_url_host "$1" | tr 'A-Z' 'a-z' | awk -F. 'NF >= 3 && length($NF) == 2 && length($(NF-1)) <= 3 { print $(NF-2) "." $(NF-1) "." $NF; next }
		NF >= 2 { print $(NF-1) "." $NF }'
}
doh_odoh_same_owner() {
	_dsa=$(doh_odoh_owner "$1"); _dsb=$(doh_odoh_owner "$2")
	[ -n "$_dsa" ] && [ "$_dsa" = "$_dsb" ]
}


doh_odoh_capable() {
	[ -x "$DOH_BIN" ] || return 1
	_doc_k=$(stat -c '%s %Y' "$DOH_BIN" 2>/dev/null)
	_doc_c=$(cat "$DOH_ODOH_CAP" 2>/dev/null)
	if [ -n "$_doc_k" ] && [ "${_doc_c% *}" = "$_doc_k" ]; then [ "${_doc_c##* }" = yes ]; return $?; fi


	_doc_h=$("$DOH_BIN" -h 2>&1)
	case "$_doc_h" in
		*'-O odoh_target_url'*) _doc_v=yes ;;
		*'-r resolver_url'*)    _doc_v=no ;;
		*)                      return 1 ;;
	esac
	[ -n "$_doc_k" ] && echo "$_doc_k $_doc_v" > "$DOH_ODOH_CAP" 2>/dev/null
	[ "$_doc_v" = yes ]
}




doh_odoh_refresh() {
	[ "$(doh_proto)" = odoh ] || return 0




	if [ "$1" = force ]; then
		_dorf_miss=0
		for _dorf_h in $(doh_odoh_hosts); do [ -n "$(doh_odoh_host_ips "$_dorf_h")" ] || { _dorf_miss=1; break; }; done
		[ "$_dorf_miss" = 1 ] || return 0
	else
		_dorf_t=$(cat "$DOH_ODOH_STAMP" 2>/dev/null | tr -cd '0-9')
		[ -n "$_dorf_t" ] && [ "$(age_since "$_dorf_t")" -lt "$DOH_CUSTOM_EVERY" ] && return 0
	fi
	_dorf_new=''
	for _dorf_h in $(doh_odoh_hosts); do
		case "$_dorf_h" in *[!0-9.]*) : ;; *) continue ;; esac
		_dorf_i=$(doh_anchor_ips "$_dorf_h" | tr '\n' ' ' | sed 's/ $//')
		[ -n "$_dorf_i" ] || _dorf_i=$(awk -v h="$_dorf_h" '($1 "") == (h "") { $1 = ""; sub(/^ +/, ""); print; exit }' "$ENODIA_STATE/.doh-odoh-ips" 2>/dev/null)
		[ -n "$_dorf_i" ] && _dorf_new="$_dorf_new$_dorf_h $_dorf_i
"
	done
	_dorf_new=$(printf '%s' "$_dorf_new" | sort -u)
	[ -n "$_dorf_new" ] || return 0
	doh_clock_ok && date +%s > "$DOH_ODOH_STAMP" 2>/dev/null
	[ "$_dorf_new" = "$(cat "$ENODIA_STATE/.doh-odoh-ips" 2>/dev/null)" ] && return 0
	if doh_want; then
		doh_resolver_mark del; doh_resolver_bypass del
		printf '%s\n' "$_dorf_new" > "$ENODIA_STATE/.doh-odoh-ips"
		doh_anchor_apply
		doh_pin_hosts
		if [ "$(doh_proto_now)" = odoh ] && doh_running; then doh_restart; fi
	else
		printf '%s\n' "$_dorf_new" > "$ENODIA_STATE/.doh-odoh-ips"
	fi
	return 0
}

doh_running() {
	p=$(cat "$DOH_PID" 2>/dev/null)
	[ -n "$p" ] && [ -d "/proc/$p" ]
}







doh_ca_file() {
	for f in /etc/ssl/certs/ca-certificates.crt /etc/ssl/cert.pem \
	         /etc/ssl/ca-bundle.pem /usr/share/ca-certificates/ca-certificates.crt; do
		[ -f "$f" ] && { echo "$f"; return 0; }
	done
	return 1
}








doh_reap_stray() {
	_left=
	for _p in $(pidof https-dns-proxy 2>/dev/null) $(pidof dot-proxy 2>/dev/null) $(pidof quic-dns-proxy 2>/dev/null); do
		[ -n "$1" ] && [ "$_p" = "$1" ] && continue



		case " $(tr '\000' ' ' 2>/dev/null < "/proc/$_p/cmdline") " in *" -Q "*) continue ;; esac
		kill "$_p" 2>/dev/null && _left="$_left $_p"
	done
	[ -n "$_left" ] || return 0
	sleep 1
	for _p in $_left; do [ -d "/proc/$_p" ] && kill -9 "$_p" 2>/dev/null; done
	return 0
}
















doh_log_rotate() {
	_sz=$(stat -c%s "$DOH_LOG" 2>/dev/null)
	case "$_sz" in ''|*[!0-9]*) return 0 ;; esac
	[ "$_sz" -gt "$DOH_LOG_MAX" ] || return 0
	if tail -c "$DOH_LOG_KEEP" "$DOH_LOG" > "$DOH_LOG.tmp" 2>/dev/null && [ -s "$DOH_LOG.tmp" ]; then
		cat "$DOH_LOG.tmp" > "$DOH_LOG" 2>/dev/null
	else
		: > "$DOH_LOG" 2>/dev/null   # нет `tail -c` в этой сборке busybox — лучше пустой лог, чем ОЗУ
	fi
	rm -f "$DOH_LOG.tmp" 2>/dev/null
	return 0
}
















DOH_PIN_OWNER=enodia-doh-resolver



doh_pin_relays() {   # $1 = put | clear
	_dpr_n=0
	if [ "$1" = put ]; then
		for _dpr_k in $(doh_odoh_relays); do
			_dpr_n=$((_dpr_n + 1)); _dpr_h=$(doh_url_host "$(doh_odoh_relay_url "$_dpr_k")")
			case "$_dpr_h" in
				*[!0-9.]*) seed_hosts_put "$_dpr_h" "$(doh_odoh_host_ips "$_dpr_h")" "$DOH_PIN_RELAY$_dpr_n" ;;
				*)         seed_hosts_clear "$DOH_PIN_RELAY$_dpr_n" >/dev/null 2>&1 ;;
			esac
		done
	fi
	while [ "$_dpr_n" -lt 2 ]; do _dpr_n=$((_dpr_n + 1)); seed_hosts_clear "$DOH_PIN_RELAY$_dpr_n" >/dev/null 2>&1; done
	return 0
}
doh_pin_hosts() {
	command -v seed_hosts_put >/dev/null 2>&1 || return 0
	if [ "$(doh_proto)" = odoh ]; then
		doh_pin_relays put
		_dph_h=$(doh_url_host "$(doh_odoh_target_url)")
		case "$_dph_h" in
			*[!0-9.]*) seed_hosts_put "$_dph_h" "$(doh_odoh_host_ips "$_dph_h")" "$DOH_PIN_OWNER" ;;
			*)         seed_hosts_clear "$DOH_PIN_OWNER" >/dev/null 2>&1 ;;
		esac
		return 0
	fi
	doh_pin_relays clear

	_dph_h=''; [ "$(doh_proto_now)" = dot ] || _dph_h=$(doh_proto_sni doh)
	case "$(doh_proto_now)" in doq|doh3) _dph_h='' ;; esac
	_dph_i=$(doh_resolver_ips)
	if [ -n "$_dph_h" ] && [ -n "$(printf '%s' "$_dph_i" | tr -d ' ')" ]; then
		seed_hosts_put "$_dph_h" "$_dph_i" "$DOH_PIN_OWNER"
	else
		seed_hosts_clear "$DOH_PIN_OWNER" >/dev/null 2>&1
	fi
	return 0
}








doh_start() {
	doh_log_rotate            # первым делом: сюда приходят и бут, и смена резолвера
	doh_want || return 0
	doh_installed || return 0
	doh_running && return 0



	doh_custom_refresh force
	doh_reap_stray            # порт держит неучтённый экземпляр ⇒ иначе наш старт упадёт «Address in use»
	if [ "$(doh_proto_now)" = dot ]; then


		_ips=$(doh_resolver_ips | tr ' ' ',')
		_sni=$(dot_resolver_sni)
		_ca=$(doh_ca_file) || return 1
		[ -n "$_ips" ] && [ -n "$_sni" ] || return 1

		doh_pin_hosts

		start-stop-daemon -S -b -m -p "$DOH_PID" -x "$DOT_BIN" -- \
			-a "$DOH_ADDR" -p "$DOH_PORT" -r "$_ips" -P "$(doh_proto_port dot)" -s "$_sni" -C "$_ca" -l "$DOH_LOG"
		return $?
	fi
	case "$(doh_proto_now)" in doq|doh3)


		_dsq_p=$(doh_proto_now)
		_ips=$(doh_resolver_ips | tr ' ' ',')
		_sni=$(doh_proto_sni "$_dsq_p")
		_ca=$(doh_ca_file) || return 1
		[ -n "$_ips" ] && [ -n "$_sni" ] || return 1
		doh_pin_hosts
		if [ "$_dsq_p" = doq ]; then set -- -m doq; else set -- -m h3 -u "$(doh_quic_path)"; fi
		start-stop-daemon -S -b -m -p "$DOH_PID" -x "$QUIC_BIN" -- "$@" \
			-a "$DOH_ADDR" -p "$DOH_PORT" -r "$_ips" -P "$(doh_proto_port "$_dsq_p")" -s "$_sni" -C "$_ca" -l "$DOH_LOG"
		return $? ;;
	esac
	if [ "$(doh_proto_now)" = odoh ]; then




		_dso_r=$(doh_odoh_relay_url); _dso_t=$(doh_odoh_target_url)
		[ -n "$_dso_r" ] && [ -n "$_dso_t" ] || return 1
		_dso_ca=$(doh_ca_file) || return 1
		doh_pin_hosts
		set -- -C "$_dso_ca"
		_dso_i=$(doh_odoh_host_ips "$(doh_url_host "$_dso_r")" | awk '{$1=$1; gsub(/ /,","); print}'); [ -n "$_dso_i" ] && set -- "$@" -R "$_dso_i"
		_dso_i=$(doh_odoh_host_ips "$(doh_url_host "$_dso_t")" | awk '{$1=$1; gsub(/ /,","); print}'); [ -n "$_dso_i" ] && set -- "$@" -W "$_dso_i"
		start-stop-daemon -S -b -m -p "$DOH_PID" -x "$DOH_BIN" -- \
			-a "$DOH_ADDR" -p "$DOH_PORT" -4 -v -v -r "$_dso_r" -O "$_dso_t" -b 1.1.1.1 -l "$DOH_LOG" "$@"
		return $?
	fi
	spec=$(doh_resolver_spec)
	url=$(printf '%s' "$spec" | cut -f1)
	boot=$(printf '%s' "$spec" | cut -f2)
	[ -n "$url" ] || return 1
	ca=$(doh_ca_file) || return 1   # без CA статик-сборка не проверит сертификат ⇒ старт бессмыслен
	doh_pin_hosts                   # имя резолвера → его якоря, ДО старта: первый же резолв c-ares читает hosts
	set -- -C "$ca"
	start-stop-daemon -S -b -m -p "$DOH_PID" -x "$DOH_BIN" -- \
		-a "$DOH_ADDR" -p "$DOH_PORT" -4 -v -v -r "$url" -b "$boot" -l "$DOH_LOG" "$@"
}

doh_stop() {
	start-stop-daemon -K -p "$DOH_PID" >/dev/null 2>&1
	rm -f "$DOH_PID" 2>/dev/null
	doh_reap_stray            # добить всё, что не описано pidfile'ом: «выключил, а порт занят» недопустимо
}


doh_restart() { doh_stop; doh_start; }












doh_wait_listen() {
	_dwlb=$(doh_bin_for)
	daemon_wait_uport "$DOH_PID" "${_dwlb##*/}" "${1:-45}" "$DOH_ADDR" "$DOH_PORT"
}




doh_restart_wait() {   # $1 — потолок ожидания порта, с (пусто — как у doh_wait_listen)
	doh_restart
	doh_wait_listen "$1" && return 0
	doh_running && return 1
	doh_start
	doh_wait_listen "$1"
}










DOH_MARK=0x1                       # та же метка «в table 1000», что FWMARK транспортов







doh_resolver_mark() {
	_drmp=$(doh_wire_port); _drma=$(doh_all_ports "$2"); _drml=$(doh_wire_l4)
	for _ip in $(doh_resolver_ips "$2"); do
		case "$1" in
			add) _prt=$_drmp
				iptables -t mangle -C OUTPUT -d "$_ip" -p "$_drml" --dport "$_prt" -j MARK --set-mark $DOH_MARK 2>/dev/null || \
				iptables -t mangle -A OUTPUT -d "$_ip" -p "$_drml" --dport "$_prt" -j MARK --set-mark $DOH_MARK ;;
			del) for _prt in $_drma; do for _drmq in tcp udp; do
				while iptables -t mangle -C OUTPUT -d "$_ip" -p "$_drmq" --dport "$_prt" -j MARK --set-mark $DOH_MARK 2>/dev/null; do
					iptables -t mangle -D OUTPUT -d "$_ip" -p "$_drmq" --dport "$_prt" -j MARK --set-mark $DOH_MARK 2>/dev/null || break
				done
			done; done ;;
		esac
	done
}









doh_bootstrap_ip() {
	[ "$2" != any ] && [ "$(doh_proto_now)" = dot ] && return 0
	[ "$2" != any ] && case "$(doh_proto_now)" in doq|doh3) return 0 ;; esac   # the QUIC program: IP literals, as DoT
	[ "${1:-$(doh_eff)}" = odoh ] && return 0   # ODoH: адреса — аргументами и закреплением, bootstrap не спрашивается
	_dbs=$(doh_resolver_spec "$1")
	_dbu=${_dbs%%$(printf '\t')*}; _dbi=${_dbs#*$(printf '\t')}
	_dbh=${_dbu#https://}; _dbh=${_dbh%%/*}; _dbh=${_dbh%%:*}
	case "$_dbh" in *[!0-9.]*) printf '%s' "$_dbi" ;; esac
}








doh_resolver_bypass() {
	_drbp=$(doh_wire_port); _drba=$(doh_all_ports "$2"); _drbl=$(doh_wire_l4)
	for _ip in $(doh_resolver_ips "$2"); do
		case "$1" in
			add) _prt=$_drbp
				iptables -t mangle -C OUTPUT -d "$_ip" -p "$_drbl" --dport "$_prt" -j RETURN 2>/dev/null || \
				iptables -t mangle -I OUTPUT 1 -d "$_ip" -p "$_drbl" --dport "$_prt" -j RETURN ;;
			del) for _prt in $_drba; do for _drbq in tcp udp; do
				while iptables -t mangle -C OUTPUT -d "$_ip" -p "$_drbq" --dport "$_prt" -j RETURN 2>/dev/null; do
					iptables -t mangle -D OUTPUT -d "$_ip" -p "$_drbq" --dport "$_prt" -j RETURN 2>/dev/null || break
				done
			done; done ;;
		esac
	done
	if [ "$1" = del ]; then _dbp=$(doh_bootstrap_ip "$2" any); else _dbp=$(doh_bootstrap_ip "$2"); fi
	[ -n "$_dbp" ] || return 0
	for _pro in udp tcp; do
		case "$1" in
			add) iptables -t mangle -C OUTPUT -d "$_dbp" -p "$_pro" --dport 53 -j RETURN 2>/dev/null || \
			     iptables -t mangle -I OUTPUT 1 -d "$_dbp" -p "$_pro" --dport 53 -j RETURN ;;
			del) while iptables -t mangle -C OUTPUT -d "$_dbp" -p "$_pro" --dport 53 -j RETURN 2>/dev/null; do
			         iptables -t mangle -D OUTPUT -d "$_dbp" -p "$_pro" --dport 53 -j RETURN 2>/dev/null || break
			     done ;;
		esac
	done
}











doh_anchor_state() {
	_das_ip=$(doh_resolver_ips "$1" | awk '{print $1; exit}')
	[ -n "$_das_ip" ] || { echo none; return 0; }
	_das_act=$(doh_wire_port); _das_l=$(doh_wire_l4)

	for _das_q in "$_das_l" tcp udp; do
		for _das_p in "$_das_act" $(doh_all_ports "$1"); do
			iptables -t mangle -C OUTPUT -d "$_das_ip" -p "$_das_q" --dport "$_das_p" -j RETURN 2>/dev/null && { echo bypass; return 0; }
			iptables -t mangle -C OUTPUT -d "$_das_ip" -p "$_das_q" --dport "$_das_p" -j MARK --set-mark $DOH_MARK 2>/dev/null && { echo mark; return 0; }
		done
	done
	echo none
}
















doh_anchor_apply() {
	if doh_direct_regime || [ -f "$DOH_UNTUNNELED" ]; then
		doh_resolver_mark del; doh_resolver_bypass add
	else
		doh_resolver_bypass del; doh_resolver_mark add
	fi
}















DOH_UNTUNNELED="/tmp/.enodia-doh-untunneled.stamp"



DOH_RETUNNEL_STAMP="/tmp/enodia-doh-retunnel.stamp"
DOH_RETUNNEL_BACKOFF=${DOH_RETUNNEL_BACKOFF:-1800}
















doh_untunnel_apply() {
	date +%s > "$DOH_UNTUNNELED" 2>/dev/null || : > "$DOH_UNTUNNELED"   # содержимое = эпоха увода (дамп печатает возраст)
	doh_anchor_apply
	doh_restart; sleep 1
	doh_running || doh_start
	[ "$1" = nowait ] && { doh_running; return $?; }
	doh_wait_listen
}


doh_untunnel() {
	doh_want || return 1                     # DNS держит не DoH — уводить нечего





	doh_direct_regime && return 1
	[ -f "$DOH_UNTUNNELED" ] && return 1     # уже уведён
	doh_untunnel_apply nowait                # пробы за уводом нет ⇒ и ждать порта незачем: не жжём тик
	return 0
}




doh_retunnel() {
	[ -f "$DOH_UNTUNNELED" ] || return 1



	doh_want || return 1
	[ "$(age_since "$(cat "$DOH_RETUNNEL_STAMP" 2>/dev/null | tr -cd '0-9')")" -ge "$DOH_RETUNNEL_BACKOFF" ] || return 1







	doh_direct_by_name || [ -n "$(carrier_iface)" ] || return 1
	rm -f "$DOH_UNTUNNELED" 2>/dev/null



	doh_anchor_apply
	if ! doh_direct_regime; then







		doh_restart_wait
















		if ! doh_wire_ok || ! doh_names_ok 3; then



			if doh_dot_rescue || doh_odoh_rescue || doh_quic_rescue; then rm -f "$DOH_RETUNNEL_STAMP" 2>/dev/null; return 0; fi




			doh_untunnel_apply nowait || echo "$(date '+%Y-%m-%d %H:%M:%S') [doh] возврат не удался: прокси после увода обратно не слушает — DNS молчит до следующего тика" >> "$DOH_LOG" 2>/dev/null


			date +%s > "$DOH_RETUNNEL_STAMP" 2>/dev/null || : > "$DOH_RETUNNEL_STAMP" 2>/dev/null
			return 2
		fi
	fi
	rm -f "$DOH_RETUNNEL_STAMP" 2>/dev/null
	return 0
}









doh_dns_bailout() {
	doh_resolver_mark del
	doh_resolver_bypass del
	doh_stop


	rm -f "$DOH_UNTUNNELED" "$DOH_RETUNNEL_STAMP" 2>/dev/null

	command -v seed_hosts_clear >/dev/null 2>&1 && { seed_hosts_clear "$DOH_PIN_OWNER" >/dev/null 2>&1; doh_pin_relays clear; }
	return 0
}

doh_auto_rollback() {
	rm -f "$DOH_AUTO_STAMP" 2>/dev/null
	doh_dns_bailout
}










DOH_BAIL_STAMP="/tmp/.enodia-doh-bail.stamp"
DOH_BAIL_BACKOFF=${DOH_BAIL_BACKOFF:-900}


doh_apply_fail() {
	doh_quic_preset_settle fail   # a provisional rung that never gave names goes (doh_quic_preset)
	if [ "$_doh_auto" = 1 ]; then doh_auto_rollback; return 0; fi
	doh_dns_bailout




	if command -v wan_up >/dev/null 2>&1 && ! wan_up; then return 0; fi
	date +%s > "$DOH_BAIL_STAMP" 2>/dev/null
	return 0
}





doh_bail_forget() { rm -f "$DOH_BAIL_STAMP" 2>/dev/null; return 0; }

doh_rearm_due() {
	[ -f "$DOH_BAIL_STAMP" ] || return 0
	[ "$(age_since "$(cat "$DOH_BAIL_STAMP" 2>/dev/null | tr -cd '0-9')")" -ge "$DOH_BAIL_BACKOFF" ]
}






















doh_probe() {
	_pn=${1:-2}; _pi=0
	while [ "$_pi" -lt "$_pn" ]; do
		_pi=$((_pi+1))
		_po=$(timeout -t 4 nslookup "$(doh_probe_name)" 2>&1); _prc=$?
		case "$_po" in *'Name does not resolve'*|*'Name or service not known'*|*'Name has no usable address'*|*NXDOMAIN*) return 0 ;; esac

		[ "$_prc" = 0 ] && printf '%s\n' "$_po" | awk '/^Name:/ { n = 1; next } n && /^Address/ && $NF != "0.0.0.0" && $NF != "::" { f = 1 } END { exit !f }' && return 0
		[ "$_pi" -lt "$_pn" ] && sleep 2
	done
	return 1
}


doh_probe_name() {
	_pnr=$(cut -c1-13 /proc/sys/kernel/random/uuid 2>/dev/null | tr -d '-')
	[ -n "$_pnr" ] || _pnr="$$$(date +%s)"
	echo "p$_pnr.example.com"
}













































DOH_WIRE_TIMEOUT=${DOH_WIRE_TIMEOUT:-10}
DOH_PROBE_SPORTS=${DOH_PROBE_SPORTS:-40000:40099}   # `--sport` правила пробы; curl получает тот же диапазон через «-»
doh_wire_ok() {
	_dwpr=${1:-$(doh_proto_now)}



	_dwk=''
	if [ "$(doh_eff)" = odoh ]; then case "$_dwpr" in odoh|doh) : ;; *) _dwk=$(doh_resolver_name) ;; esac; fi

	_dwp=$(doh_proto_port "$_dwpr" $_dwk); _dwsn=$(doh_proto_sni "$_dwpr" $_dwk)
	_dwt=''; _dwl=''; _dwips=$(doh_resolver_ips $_dwk)


	if [ -z "$_dwk" ] && [ "$(doh_eff)" = odoh ]; then
		case "$_dwpr" in
			odoh) _dwips=$(doh_odoh_host_ips "$(doh_url_host "$(doh_odoh_relay_url)")") ;;
			doh)  _dwips=$(doh_odoh_host_ips "$(doh_url_host "$(doh_odoh_target_url)")") ;;
		esac
	fi

	_dwq=$(doh_wire_l4 "$_dwpr")
	if [ -n "${2:-}" ] || [ "$_dwp" != "$(doh_wire_port)" ] || [ "$_dwq" != "$(doh_wire_l4)" ]; then
		_dwt=${2:-$(doh_anchor_state)}
		case "$_dwt" in
			mark|bypass) doh_probe_rule add "$_dwt" "$_dwp" "$_dwips" "$_dwq"; _dwl="--local-port ${DOH_PROBE_SPORTS%:*}-${DOH_PROBE_SPORTS#*:}" ;;
			*)           _dwt='' ;;
		esac
	fi
	_dwj=''


	case "$_dwpr" in doq|doh3)

		_dwca=$(doh_ca_file) && [ -n "$_dwsn" ] || { [ -n "$_dwt" ] && doh_probe_rule del "$_dwt" "$_dwp" "$_dwips" "$_dwq"; return 1; }
		_dwm=doq; [ "$_dwpr" = doh3 ] && _dwm=h3



		_dwlq=''
		if [ -n "$_dwl" ]; then
			_dwlo=${DOH_PROBE_SPORTS%:*}; _dwhi=${DOH_PROBE_SPORTS#*:}; _dwsp=$((_dwhi - _dwlo - 7)); [ "$_dwsp" -gt 0 ] || _dwsp=1
			_dwrn=$(tr -cd 1-9 < /proc/sys/kernel/random/uuid 2>/dev/null | cut -c1-4); _dwrn=${_dwrn:-$$}   # 1-9: no octal
			_dwlq="-L $((_dwlo + _dwrn % _dwsp)):$_dwhi"
		fi
		for _dwi in $_dwips; do

			"$QUIC_BIN" -Q -m "$_dwm" -r "$_dwi" -s "$_dwsn" -P "$_dwp" -T $((DOH_WIRE_TIMEOUT * 1000)) $_dwlq -C "$_dwca" >/dev/null 2>&1 &
			_dwj="$_dwj $!"
		done
		_dwr=1
		for _dwk in $_dwj; do wait "$_dwk" && _dwr=0; done
		[ -n "$_dwt" ] && doh_probe_rule del "$_dwt" "$_dwp" "$_dwips" "$_dwq"
		return $_dwr ;;
	esac
	for _dwi in $_dwips; do
		if [ -n "$_dwsn" ]; then _dwu="https://$_dwsn:$_dwp/"; _dwrs="--resolve $_dwsn:$_dwp:$_dwi"; else _dwu="https://$_dwi:$_dwp/"; _dwrs=''; fi


		( _dwa=$(curl -s -k -o /dev/null $_dwl $_dwrs -w '%{time_appconnect}' --connect-timeout "$DOH_WIRE_TIMEOUT" \
		         --max-time "$DOH_WIRE_TIMEOUT" --speed-time 2 --speed-limit 1 "$_dwu" 2>/dev/null)
		  awk -v a="$_dwa" 'BEGIN{exit !(a+0 > 0)}' ) &
		_dwj="$_dwj $!"
	done
	_dwr=1
	for _dwk in $_dwj; do wait "$_dwk" && _dwr=0; done
	[ -n "$_dwt" ] && doh_probe_rule del "$_dwt" "$_dwp" "$_dwips" "$_dwq"
	return $_dwr
}





doh_probe_rule() {
	case "$2" in mark) _dprj="MARK --set-mark $DOH_MARK"; _dpra="-A OUTPUT" ;; bypass) _dprj=RETURN; _dpra="-I OUTPUT 1" ;; *) return 0 ;; esac
	_dprq=${5:-tcp}
	for _dpri in ${4:-$(doh_resolver_ips)}; do

		if [ "$1" = add ]; then
			iptables -t mangle -C OUTPUT -d "$_dpri" -p "$_dprq" --dport "$3" --sport "$DOH_PROBE_SPORTS" -j $_dprj 2>/dev/null || \
			iptables -t mangle $_dpra -d "$_dpri" -p "$_dprq" --dport "$3" --sport "$DOH_PROBE_SPORTS" -j $_dprj
		else
			while iptables -t mangle -C OUTPUT -d "$_dpri" -p "$_dprq" --dport "$3" --sport "$DOH_PROBE_SPORTS" -j $_dprj 2>/dev/null; do
				iptables -t mangle -D OUTPUT -d "$_dpri" -p "$_dprq" --dport "$3" --sport "$DOH_PROBE_SPORTS" -j $_dprj 2>/dev/null || break
			done
		fi
	done
}














DOH_DOT_RETRY=${DOH_DOT_RETRY:-3600}   # через сколько после переезда (или прошлой попытки) снова щупать DoT (сек)




DOH_PORT_EVERY=${DOH_PORT_EVERY:-90}
DOH_PORT_STAMP="/tmp/.enodia-doh-port.stamp"


DOH_DOT_TRY="/tmp/.enodia-dot-try.stamp"





DOH_DOT_PATH="/tmp/.enodia-dot-path"
doh_dot_path_id() { printf '%s %s\n' "$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')" "$1"; }










DOH_QUIC_RETRY=${DOH_QUIC_RETRY:-3600}   # how long after a move (or the last try) the QUIC protocol is tried again (sec)
DOH_QUIC_TRY="/tmp/.enodia-quic-try.stamp"
DOH_QUIC_DOWN="/tmp/.enodia-quic-down.stamp"
DOH_QUIC_PATH="/tmp/.enodia-quic-path"


DOH_QUIC_UP="/tmp/.enodia-quic-up.stamp"
doh_lv_climb_ok() { _dlc=$(cat "$DOH_QUIC_UP" 2>/dev/null | tr -cd '0-9'); [ -z "$_dlc" ] || [ "$(age_since "$_dlc")" -ge "$DOH_QUIC_RETRY" ]; }
doh_lv() {   # <level> → _lvf (flag) _lvt (last try back) _lvd (last failed move) _lvp (path of the verdict) _lvr (retry, sec)
	case "$1" in
		quic) _lvf=$DOH_QUIC_FALLBACK; _lvt=$DOH_QUIC_TRY; _lvd=$DOH_QUIC_DOWN; _lvp=$DOH_QUIC_PATH; _lvr=$DOH_QUIC_RETRY ;;
		*)    _lvf=$DOH_DOT_FALLBACK;  _lvt=$DOH_DOT_TRY;  _lvd=$DOH_DOT_TRY;   _lvp=$DOH_DOT_PATH;  _lvr=$DOH_DOT_RETRY ;;
	esac
}

doh_lv_of() { case "$(doh_proto)" in dot) echo dot ;; doq|doh3) echo quic ;; esac; }

doh_lv_rungs() {
	_dlg=''
	case "$1" in
		quic) case "$(doh_proto)" in
			doq)  [ -x "$DOT_BIN" ] && _dlg=dot; [ -x "$DOH_BIN" ] && _dlg="${_dlg:+$_dlg }doh" ;;
			doh3) [ -x "$DOH_BIN" ] && _dlg=doh ;;
		esac ;;
		*) [ -x "$DOH_BIN" ] && _dlg=doh ;;
	esac
	printf '%s\n' "$_dlg"
}

doh_lv_rung() { doh_lv "$1"; [ -f "$_lvf" ] || return 0; [ "$1" = quic ] || { echo doh; return 0; }; doh_proto_now; }

doh_lv_live() {
	_dll_c=$(doh_lv_rung "$1"); _dll_o=''; _dll_s=1; [ -n "$_dll_c" ] || _dll_s=0
	for _dll_r in $(doh_lv_rungs "$1"); do
		if [ "$_dll_s" = 1 ]; then [ "$_dll_r" = "$_dll_c" ] && _dll_s=0; continue; fi
		doh_wire_ok "$_dll_r" && _dll_o="${_dll_o:+$_dll_o }$_dll_r"
	done
	printf '%s\n' "$_dll_o"
}



doh_lv_up() {
	_dlu_c=$(doh_lv_rung "$1"); _dlu_o=''
	if [ -n "$_dlu_c" ]; then
		for _dlu_r in $(doh_lv_rungs "$1"); do
			[ "$_dlu_r" = "$_dlu_c" ] && break
			doh_wire_ok "$_dlu_r" && _dlu_o="${_dlu_o:+$_dlu_o }$_dlu_r"
		done
	fi
	printf '%s\n' "$_dlu_o"
}

doh_lv_path_stale() {
	doh_lv "$1"
	[ -f "$_lvf" ] && [ -f "$_lvp" ] || return 1
	[ "$(cat "$_lvp" 2>/dev/null)" != "$(doh_dot_path_id "$2")" ]
}
doh_dot_path_stale() { doh_lv_path_stale dot "$1"; }



doh_port_move() {
	doh_resolver_mark del; doh_resolver_bypass del
	case "$1" in mark) doh_resolver_mark add ;; bypass) doh_resolver_bypass add ;; esac
	doh_restart   # ДРУГОЙ бинарь: без рестарта прежний протокол жил бы под правилами нового порта
	sleep 1; doh_running || doh_start
}










doh_names_ok() {
	doh_dhcp_script_set || killall -HUP dnsmasq 2>/dev/null
	doh_probe "${1:-2}"
}









doh_dhcp_script_set() {
	for _dds_p in $(pidof dnsmasq 2>/dev/null); do
		tr '\0' '\n' 2>/dev/null < "/proc/$_dds_p/cmdline" | grep -qE '^(-6|--dhcp-script|--dhcp-luascript)' && return 0
	done


	if command -v dnsmasq_conf_files >/dev/null 2>&1; then
		dnsmasq_conf_files | while IFS= read -r _dds_f; do cat "$_dds_f"; done 2>/dev/null | grep -qE '^[[:space:]]*dhcp-(lua)?script'
	else
		cat /var/etc/dnsmasq.conf* /etc/dnsmasq.conf 2>/dev/null | grep -qE '^[[:space:]]*dhcp-(lua)?script'
	fi
}











doh_dot_troubled() {
	doh_wire_ok || return 0
	case "$1" in ''|*[!0-9]*) return 0 ;; esac









	awk -v t="$1" '$2+0 < t {next}
		$1=="[E]" && ($3=="handshake" || $3=="connect") {bad=1}
		$1=="[E]" && $3=="inflight" {inf=1}
		$1=="[E]" && ($3=="status" || $3=="content-type" || $3=="reset" || $3=="send") {inf=1}
		$1=="[E]" && $3=="silent" {sil=1}
		$1=="[I]" && $3=="connected" {bad=0}
		$1=="[I]" && ($3=="answering" || $3=="dot-proxy" || $3=="quic-dns-proxy") {sil=0}
		END{exit !(bad || inf || sil)}' "$DOH_LOG" 2>/dev/null
}


doh_dot_event() {
	[ -n "$ENODIA_DIR" ] && [ -f "$ENODIA_DIR/events.sh" ] || return 0
	case "$2" in mark) _dde_via='через туннель' ;; bypass) _dde_via='напрямую через провайдера' ;; *) _dde_via='текущий' ;; esac
	if [ "$1" = fallback ]; then
		sh "$ENODIA_DIR/events.sh" add doh-dot-fallback 86400 "DoT не работает — DNS шифруется по DoH" \
"Резолвер $(doh_resolver_name) не отвечает по DoT (путь: $_dde_via), а по DoH того же резолвера отвечает: порт 853 закрыт по дороге или рукопожатие DoT не укладывается в срок. Роутер перевёл шифрованный DNS на DoH: запросы по-прежнему шифруются, выбор DoT сохранён. Раз в $((DOH_DOT_RETRY / 60)) мин роутер проверяет DoT и вернётся на него сам, когда тот заработает." >/dev/null 2>&1 || true
	else
		sh "$ENODIA_DIR/events.sh" add doh-dot-back 86400 "DoT снова работает" \
"Резолвер $(doh_resolver_name) снова отвечает по DoT (путь: $_dde_via) — шифрованный DNS вернулся с DoH на выбранный DoT." >/dev/null 2>&1 || true
	fi
	return 0
}



doh_quic_event() {
	[ -n "$ENODIA_DIR" ] && [ -f "$ENODIA_DIR/events.sh" ] || return 0
	case "$2" in mark) _dqe_via='через туннель' ;; bypass) _dqe_via='напрямую через провайдера' ;; *) _dqe_via='текущий' ;; esac
	_dqe_p=$(doh_proto_label "$(doh_proto)")
	if [ "$1" = fallback ] && [ -n "$4" ]; then
		_dqe_r=$(doh_proto_label "$3"); _dqe_o=$(doh_proto_label "$4")
		sh "$ENODIA_DIR/events.sh" add doh-quic-fallback 86400 "$_dqe_p и $_dqe_o не работают — DNS шифруется по $_dqe_r" \
"Резолвер $(doh_resolver_name) не отвечает ни по $_dqe_p, ни по $_dqe_o (путь: $_dqe_via), а по $_dqe_r того же резолвера отвечает. Роутер перевёл шифрованный DNS на $_dqe_r: запросы по-прежнему шифруются, выбор $_dqe_p сохранён. Раз в $((DOH_QUIC_RETRY / 60)) мин роутер проверяет $_dqe_p и вернётся на него сам, когда тот заработает." >/dev/null 2>&1 || true
	elif [ "$1" = fallback ]; then
		_dqe_r=$(doh_proto_label "$3")
		sh "$ENODIA_DIR/events.sh" add doh-quic-fallback 86400 "$_dqe_p не работает — DNS шифруется по $_dqe_r" \
"Резолвер $(doh_resolver_name) не отвечает по $_dqe_p (путь: $_dqe_via), а по $_dqe_r того же резолвера отвечает: QUIC режут по дороге или его порт закрыт. Роутер перевёл шифрованный DNS на $_dqe_r: запросы по-прежнему шифруются, выбор $_dqe_p сохранён. Раз в $((DOH_QUIC_RETRY / 60)) мин роутер проверяет $_dqe_p и вернётся на него сам, когда тот заработает." >/dev/null 2>&1 || true
	else
		sh "$ENODIA_DIR/events.sh" add doh-quic-back 86400 "$_dqe_p снова работает" \
"Резолвер $(doh_resolver_name) снова отвечает по $_dqe_p (путь: $_dqe_via) — шифрованный DNS вернулся на выбранный $_dqe_p." >/dev/null 2>&1 || true
	fi
	return 0
}

doh_proto_label() { case "$1" in dot) echo DoT ;; doq) echo DoQ ;; doh3) echo DoH3 ;; odoh) echo ODoH ;; *) echo DoH ;; esac; }


doh_lv_names() { if [ "$1" = quic ]; then doh_probe 3; else doh_names_ok; fi; }
doh_lv_event() { if [ "$1" = quic ]; then doh_quic_event "$2" "$3" "$4" "$5"; else doh_dot_event "$2" "$3"; fi; }














doh_lv_fallback() {
	_dlf_l=$1; doh_lv "$_dlf_l"
	_ddf_f=$(doh_anchor_state)
	_dlf_was=$(cat "$_lvf" 2>/dev/null)


	case "${3:-}" in up|climb) date +%s > "$DOH_QUIC_UP" 2>/dev/null ;; esac


	_dlf_try=''; [ "$_lvt" = "$_lvd" ] || _dlf_try=$(cat "$_lvt" 2>/dev/null)

	DOH_LV_FROM=''; [ "$_dlf_l" = quic ] && [ -n "$_dlf_was" ] && [ "${3:-}" != climb ] && DOH_LV_FROM=$(printf '%s\n' "$_dlf_was" | awk '{print $2; exit}')
	for _dlf_r in $2; do
		doh_lv "$_dlf_l"
		{ echo "$(date +%s) $_dlf_r" > "$_lvf"; } 2>/dev/null || : > "$_lvf"
		rm -f "$_lvt" 2>/dev/null
		doh_port_move "$_ddf_f"
		if doh_wait_listen && doh_lv_names "$_dlf_l"; then
			doh_lv "$_dlf_l"
			rm -f "$_lvd" 2>/dev/null
			doh_dot_path_id "$_ddf_f" > "$_lvp" 2>/dev/null   # вердикт — про ЭТОТ путь (см. DOH_DOT_PATH)
			doh_lv_event "$_dlf_l" fallback "$_ddf_f" "$_dlf_r" "$DOH_LV_FROM"
			return 0
		fi
	done
	doh_lv "$_dlf_l"
	if [ -n "$_dlf_was" ]; then printf '%s\n' "$_dlf_was" > "$_lvf" 2>/dev/null; else rm -f "$_lvf" "$_lvp" 2>/dev/null; fi
	[ -n "$_dlf_try" ] && printf '%s\n' "$_dlf_try" > "$_lvt" 2>/dev/null
	doh_port_move "$(doh_anchor_state)"
	doh_wait_listen
	return 1
}
doh_dot_fallback() { doh_lv_fallback dot doh; }




doh_lv_back() {
	_dlb_l=$1; doh_lv "$_dlb_l"
	_ddb_f=$(doh_anchor_state)
	_ddb_t=$(cat "$_lvf" 2>/dev/null)
	rm -f "$_lvf" "$_lvt" "$_lvp" 2>/dev/null
	doh_port_move "$_ddb_f"
	if doh_wait_listen && doh_lv_names "$_dlb_l"; then
		doh_lv "$_dlb_l"; rm -f "$_lvd" 2>/dev/null
		doh_lv_event "$_dlb_l" back "$_ddb_f"
		return 0
	fi
	doh_lv "$_dlb_l"
	if [ -n "$_ddb_t" ]; then printf '%s\n' "$_ddb_t" > "$_lvf" 2>/dev/null; else date +%s > "$_lvf" 2>/dev/null; fi
	date +%s > "$_lvt" 2>/dev/null
	doh_dot_path_id "$_ddb_f" > "$_lvp" 2>/dev/null   # вердикт подтверждён на ЭТОМ пути
	doh_port_move "$(doh_anchor_state)"
	doh_wait_listen
	return 1
}
doh_dot_back() { doh_lv_back dot; }







doh_lv_forget() {
	doh_lv "$1"
	[ "$1" = quic ] && rm -f "$DOH_QUIC_UP" 2>/dev/null   # a new intent: the climb limit was about the old verdict
	[ -f "$_lvf" ] || { rm -f "$_lvt" "$_lvd" "$_lvp" 2>/dev/null; return 1; }
	rm -f "$_lvf" "$_lvt" "$_lvd" "$_lvp" 2>/dev/null
	return 0
}
doh_dot_forget() { doh_lv_forget dot; }




DOH_LV_SNAP=${DOH_LV_SNAP:-${DOH_QUIC_FALLBACK%/*}/.enodia-doh-lvsnap}
doh_lv_save() {
	_dlsd="$DOH_LV_SNAP.$$"; rm -rf "$_dlsd"; mkdir -p "$_dlsd" || return 1
	for _dlsl in dot quic; do
		doh_lv "$_dlsl"
		for _dlsf in "$_lvf" "$_lvt" "$_lvd" "$_lvp"; do [ -f "$_dlsf" ] && cp -p "$_dlsf" "$_dlsd/${_dlsf##*/}"; done
	done
	[ -f "$DOH_QUIC_UP" ] && cp -p "$DOH_QUIC_UP" "$_dlsd/${DOH_QUIC_UP##*/}"
	return 0
}
doh_lv_restore() {
	_dlrd="$DOH_LV_SNAP.$$"; [ -d "$_dlrd" ] || return 1
	for _dlrl in dot quic; do
		doh_lv "$_dlrl"
		for _dlrf in "$_lvf" "$_lvt" "$_lvd" "$_lvp"; do
			rm -f "$_dlrf"; [ -f "$_dlrd/${_dlrf##*/}" ] && cp -p "$_dlrd/${_dlrf##*/}" "$_dlrf"
		done
	done
	rm -f "$DOH_QUIC_UP"; [ -f "$_dlrd/${DOH_QUIC_UP##*/}" ] && cp -p "$_dlrd/${DOH_QUIC_UP##*/}" "$DOH_QUIC_UP"
	rm -rf "$_dlrd"
	return 0
}
doh_lv_drop() { rm -rf "$DOH_LV_SNAP.$$"; }

doh_fb_forget() { _dff=1; doh_lv_forget dot && _dff=0; doh_lv_forget quic && _dff=0; return $_dff; }













doh_lv_rescue() {
	[ -n "$1" ] && [ "$(doh_lv_of)" = "$1" ] || return 1     # выбран протокол без этого уровня — менять нечего
	_dlr_l=$1; doh_lv "$_dlr_l"
	if [ -f "$_lvf" ] && doh_wire_ok "$(doh_proto)"; then
		doh_lv_back "$_dlr_l" && return 0
	fi
	_dlr_c=$(doh_lv_live "$_dlr_l"); _dlr_m=''
	[ -n "$_dlr_c" ] || { _dlr_c=$(doh_lv_up "$_dlr_l"); _dlr_m=up; }   # nothing alive below — a middle rung above may live again
	[ -n "$_dlr_c" ] || return 1                  # переезжать некуда, или путь мёртв целиком — не порт
	doh_lv_fallback "$_dlr_l" "$_dlr_c" "$_dlr_m"
}
doh_dot_rescue() { doh_lv_rescue dot; }
doh_quic_rescue() { doh_lv_rescue quic; }






doh_rewire_form() {
	if [ -f "$ENODIA_STATE/.vpn-off" ] || doh_direct_by_name; then echo bypass; return 0; fi
	case "$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')" in
		''|awg) if [ -n "$(carrier_iface)" ]; then echo mark; else echo bypass; fi ;;
		*)      echo mark ;;
	esac
}





doh_wire_via() {
	doh_wire_ok "$1" "$2" && return 0
	[ "$2" = mark ] && [ -f "$DOH_UNTUNNELED" ] && doh_wire_ok "$1" bypass
}
















DOH_QUIC_PRESET="/tmp/.enodia-quic-preset"
doh_quic_preset() {
	case "$(doh_proto)" in doq|doh3) : ;; *) return 1 ;; esac
	case "$1" in mark|bypass) : ;; *) return 1 ;; esac
	[ -f "$DOH_QUIC_FALLBACK" ] && return 1
	[ -x "$QUIC_BIN" ] && doh_quic_can "$(doh_proto)" || return 1
	if command -v wan_up >/dev/null 2>&1 && ! wan_up; then return 1; fi
	if [ "$1" = mark ] && [ "$(age_since "$(cat "${CARRIER_UP_STAMP:-/tmp/.enodia-carrier-up.stamp}" 2>/dev/null | tr -cd '0-9')")" -lt 60 ]; then
		return 1
	fi
	doh_wire_ok "$(doh_proto)" "$1" && return 1
	for _dqps in $(doh_lv_rungs quic); do
		doh_wire_ok "$_dqps" "$1" || continue
		doh_lv quic
		{ echo "$(date +%s) $_dqps" > "$_lvf"; } 2>/dev/null || : > "$_lvf"
		rm -f "$_lvt" "$_lvd" 2>/dev/null
		doh_dot_path_id "$1" > "$_lvp" 2>/dev/null   # the verdict is about THIS path (DOH_DOT_PATH)
		echo "$_dqps" > "$DOH_QUIC_PRESET" 2>/dev/null
		return 0
	done
	return 1
}




doh_quic_preset_settle() {
	[ -f "$DOH_QUIC_PRESET" ] || return 0
	_dqss=$(cat "$DOH_QUIC_PRESET" 2>/dev/null); rm -f "$DOH_QUIC_PRESET" 2>/dev/null
	doh_lv quic
	[ -n "$_dqss" ] && [ -f "$_lvf" ] && [ "$(awk '{print $2; exit}' "$_lvf" 2>/dev/null)" = "$_dqss" ] || return 0
	case "$1" in
		ok)   doh_lv_event quic fallback "$(awk '{print $NF; exit}' "$_lvp" 2>/dev/null)" "$_dqss" ;;   # «<transport> <form>», transport may be empty
		fail) rm -f "$_lvf" "$_lvp" 2>/dev/null ;;
	esac
	return 0
}










doh_odoh_event() {
	[ -n "$ENODIA_DIR" ] && [ -f "$ENODIA_DIR/events.sh" ] || return 0
	_doe_t=$(doh_odoh_target); _doe_tn=$(doh_tab "$DOH_ODOH_TARGETS" "$_doe_t" 2); [ -n "$_doe_tn" ] || _doe_tn=$(doh_url_host "$(doh_odoh_target_url)")
	_doe_rn=''; [ -n "$2" ] && { _doe_rn=$(doh_tab "$DOH_ODOH_RELAYS" "$2" 2); [ -n "$_doe_rn" ] || _doe_rn=$(doh_url_host "$(doh_odoh_relay_url "$2")"); }
	case "$1" in
		relay)
			sh "$ENODIA_DIR/events.sh" add odoh-relay 86400 "ODoH идёт через другой ретранслятор" \
"Прежний ретранслятор не ответил — запросы к $_doe_tn идут через $_doe_rn. Цель по-прежнему не видит адреса роутера." >/dev/null 2>&1 || true ;;
		fallback)
			sh "$ENODIA_DIR/events.sh" add odoh-fallback 86400 "ODoH не работает — DNS шифруется по DoH напрямую к $_doe_tn" \
"Ни один ретранслятор не ответил. Роутер перевёл шифрованный DNS на обычный DoH к той же цели ($_doe_tn): запросы по-прежнему шифруются, но цель видит адрес роутера (в туннеле — адрес сервера VPN). Через $((DOH_ODOH_RETRY / 60)) мин роутер проверит ретрансляторы (не ответят — дальше реже, до раза в час) и вернётся на ODoH сам." >/dev/null 2>&1 || true ;;
		back)
			sh "$ENODIA_DIR/events.sh" add odoh-back 86400 "ODoH снова работает" \
"Ретранслятор $_doe_rn снова отвечает — шифрованный DNS к $_doe_tn вернулся на ODoH." >/dev/null 2>&1 || true ;;
	esac
	return 0
}





doh_odoh_step_ok() { doh_restart_wait && doh_probe 3; }





doh_odoh_retry_wait() {
	_dorw_n=$(cat "$DOH_ODOH_TRIES" 2>/dev/null | tr -cd '0-9'); _dorw_w=$DOH_ODOH_RETRY
	while [ "${_dorw_n:-0}" -gt 0 ] && [ "$_dorw_w" -lt "$DOH_ODOH_RETRY_MAX" ]; do _dorw_w=$((_dorw_w * 2)); _dorw_n=$((_dorw_n - 1)); done
	[ "$_dorw_w" -le "$DOH_ODOH_RETRY_MAX" ] || [ "$_dorw_w" = "$DOH_ODOH_RETRY" ] || _dorw_w=$DOH_ODOH_RETRY_MAX
	echo "$_dorw_w"
}



doh_odoh_rescue() {
	[ "$(doh_proto)" = odoh ] || return 1
	doh_odoh_capable || return 1
	if [ "$(doh_proto_now)" = doh ]; then

		doh_odoh_back
		return $?
	fi



	_dor_cur=$(doh_odoh_relay_now); _dor_tried=0
	for _dor_k in $(doh_odoh_relays); do
		[ "$_dor_k" = "$_dor_cur" ] && continue
		echo "$_dor_k" > "$DOH_ODOH_RELAY_NOW" 2>/dev/null
		doh_wire_ok odoh || continue          # провод к нему не встаёт — перезапускать под ним прокси незачем
		_dor_tried=1
		if doh_odoh_step_ok; then doh_odoh_event relay "$_dor_k"; return 0; fi
	done
	echo "$_dor_cur" > "$DOH_ODOH_RELAY_NOW" 2>/dev/null

	if doh_wire_ok doh; then
		date +%s > "$DOH_ODOH_FALLBACK" 2>/dev/null || : > "$DOH_ODOH_FALLBACK"
		rm -f "$DOH_ODOH_TRY" "$DOH_ODOH_TRIES" 2>/dev/null
		if doh_odoh_step_ok; then doh_odoh_event fallback; return 0; fi
		rm -f "$DOH_ODOH_FALLBACK" 2>/dev/null
		_dor_tried=1
	fi

	[ "$_dor_tried" = 1 ] && doh_odoh_step_ok >/dev/null 2>&1
	return 1
}



doh_odoh_back() {
	_dob_t=$(cat "$DOH_ODOH_FALLBACK" 2>/dev/null | tr -cd '0-9'); _dob_tried=0
	rm -f "$DOH_ODOH_FALLBACK" "$DOH_ODOH_RELAY_NOW" 2>/dev/null
	for _dob_k in $(doh_odoh_relays); do
		echo "$_dob_k" > "$DOH_ODOH_RELAY_NOW" 2>/dev/null
		doh_wire_ok odoh || continue
		_dob_tried=1
		if doh_odoh_step_ok; then rm -f "$DOH_ODOH_TRY" "$DOH_ODOH_TRIES" 2>/dev/null; doh_odoh_event back "$_dob_k"; return 0; fi
	done
	rm -f "$DOH_ODOH_RELAY_NOW" 2>/dev/null
	if [ -n "$_dob_t" ]; then echo "$_dob_t" > "$DOH_ODOH_FALLBACK" 2>/dev/null; else date +%s > "$DOH_ODOH_FALLBACK" 2>/dev/null; fi
	date +%s > "$DOH_ODOH_TRY" 2>/dev/null
	if [ "$_dob_tried" = 1 ]; then
		_dob_n=$(cat "$DOH_ODOH_TRIES" 2>/dev/null | tr -cd '0-9'); echo $(( ${_dob_n:-0} + 1 )) > "$DOH_ODOH_TRIES" 2>/dev/null
		doh_odoh_step_ok >/dev/null 2>&1
	fi
	return 1
}


doh_odoh_forget() { rm -f "$DOH_ODOH_FALLBACK" "$DOH_ODOH_TRY" "$DOH_ODOH_TRIES" "$DOH_ODOH_RELAY_NOW" "$DOH_ODOH_RESCUE" 2>/dev/null; return 0; }








doh_odoh_troubled() {
	case "$1" in ''|*[!0-9]*) return 0 ;; esac
	awk -v t="$1" '$2+0 < t {next}
		($1 == "[W]" || $1 == "[E]") && /target key not loaded|no usable target key|did not open|refused the sealed query|curl request failed|No response|Request was aborted|Invalid response Content-Type|curl response code: [013-9]/ {bad = 1}
		$1 == "[I]" && /curl request failed|no response was sent back|Response was faulty/ {bad = 1}
		END {exit !bad}' "$DOH_LOG" 2>/dev/null
}







DOH_ODOH_TICK_STAMP="/tmp/.enodia-odoh-tick.stamp"
doh_odoh_tick() {
	if [ "$(doh_proto)" != odoh ]; then doh_odoh_forget; return 0; fi
	doh_want && doh_running || return 0
	doh_upstream_set || return 0
	doh_odoh_capable || return 0
	doh_clock_ok || return 0
	_dotk=$(cat "$DOH_ODOH_TICK_STAMP" 2>/dev/null | tr -cd '0-9'); [ -n "$_dotk" ] || _dotk=0
	[ "$(age_since "$_dotk")" -ge "$DOH_PORT_EVERY" ] || return 0
	date +%s > "$DOH_ODOH_TICK_STAMP"
	if [ -f "$DOH_ODOH_FALLBACK" ]; then
		_dotl=$(cat "$DOH_ODOH_TRY" 2>/dev/null | tr -cd '0-9')
		[ -n "$_dotl" ] || _dotl=$(cat "$DOH_ODOH_FALLBACK" 2>/dev/null | tr -cd '0-9')
		[ "$(age_since "$_dotl")" -ge "$(doh_odoh_retry_wait)" ] || return 0


		doh_odoh_back && return 4
		return 0
	fi
	doh_odoh_troubled "$_dotk" || return 0


	_dotr=$(cat "$DOH_ODOH_RESCUE" 2>/dev/null | tr -cd '0-9')
	[ -z "$_dotr" ] || [ "$(age_since "$_dotr")" -ge "$DOH_ODOH_RETRY" ] || return 6


	doh_probe && return 0
	if [ -n "$1" ] && ! "$1"; then return 0; fi
	if doh_odoh_rescue; then rm -f "$DOH_ODOH_RESCUE" 2>/dev/null; return 3; fi
	date +%s > "$DOH_ODOH_RESCUE" 2>/dev/null
	return 5
}

















doh_lv_sweep() {
	_dls_l=$1; _dls_k=0; [ "$_dls_l" = quic ] && _dls_k=3
	doh_lv "$_dls_l"
	if [ -f "$_lvf" ]; then


		_dpl=$(cat "$_lvt" 2>/dev/null | tr -cd '0-9')
		[ -n "$_dpl" ] || _dpl=$(cat "$_lvf" 2>/dev/null | tr -cd '0-9')
		if [ "$(age_since "$_dpl")" -ge "$_lvr" ] || doh_lv_path_stale "$_dls_l" "$(doh_anchor_state)"; then
			if doh_wire_ok "$(doh_proto)"; then
				doh_lv_back "$_dls_l" && return $((4 + _dls_k))
			else


				doh_lv "$_dls_l"
				date +%s > "$_lvt" 2>/dev/null
				[ -f "$_lvp" ] && doh_dot_path_id "$(doh_anchor_state)" > "$_lvp" 2>/dev/null




				_dls_u=$(doh_lv_up "$_dls_l")
				if [ -n "$_dls_u" ] && doh_lv_climb_ok; then doh_lv_fallback "$_dls_l" "$_dls_u" climb && return $((3 + _dls_k)); fi
			fi
		fi


		[ "$_dls_l" = quic ] || return 0
	fi
	doh_dot_troubled "$2" || return 0  # провод встаёт и прокси не жаловался — кэш не трогаем, протокол здоров




	doh_lv "$_dls_l"
	_dpl=$(cat "$_lvd" 2>/dev/null | tr -cd '0-9')
	[ -z "$_dpl" ] || [ "$(age_since "$_dpl")" -ge "$_lvr" ] || return 0


	_dls_c=$(doh_lv_live "$_dls_l"); _dls_m=''

	[ -n "$_dls_c" ] || ! doh_lv_climb_ok || { _dls_c=$(doh_lv_up "$_dls_l"); _dls_m=up; }
	[ -n "$_dls_c" ] || return 0          # мертвы все ступени этим путём — это путь, его чинят несущая и увод
	doh_lv_names "$_dls_l" && return 0
	if [ -n "$3" ] && ! "$3"; then return 0; fi
	doh_lv_fallback "$_dls_l" "$_dls_c" "$_dls_m" && return $((3 + _dls_k))
	doh_lv "$_dls_l"; date +%s > "$_lvd" 2>/dev/null
	return $((5 + _dls_k))
}
doh_port_tick() {

	[ "$(doh_lv_of)" = dot ] || rm -f "$DOH_DOT_FALLBACK" "$DOH_DOT_TRY" "$DOH_DOT_PATH" 2>/dev/null
	[ "$(doh_lv_of)" = quic ] || rm -f "$DOH_QUIC_FALLBACK" "$DOH_QUIC_TRY" "$DOH_QUIC_DOWN" "$DOH_QUIC_PATH" "$DOH_QUIC_UP" 2>/dev/null
	_dpk=$(doh_lv_of); [ -n "$_dpk" ] || return 0
	doh_want && doh_running || return 0
	doh_upstream_set || return 0          # DNS идёт мимо прокси — порт прокси ни на что не влияет
	[ -n "$(doh_lv_rungs "$_dpk")" ] || return 0   # переезжать не на что
	doh_clock_ok || return 0

	_dpt=$(cat "$DOH_PORT_STAMP" 2>/dev/null | tr -cd '0-9'); [ -n "$_dpt" ] || _dpt=0
	[ "$(age_since "$_dpt")" -ge "$DOH_PORT_EVERY" ] || return 0
	date +%s > "$DOH_PORT_STAMP"      # $_dpt остаётся эпохой ПРОШЛОЙ сверки — с неё doh_dot_troubled читает лог
	doh_lv_sweep "$_dpk" "$_dpt" "$1"
}











doh_direct_by_name() {
	case "$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')" in
		byedpi|zapret) return 0 ;;
	esac
	return 1
}
doh_plugin_direct_dns() {
	doh_direct_by_name || return 1
	[ -f "$ENODIA_DIR/transport.sh" ] || return 1
	sh "$ENODIA_DIR/transport.sh" dns >/dev/null 2>&1
}




doh_direct_regime() {
	doh_direct_by_name && return 0
	[ -z "$(carrier_iface)" ]
}











doh_restore_plain_dns() {
	doh_plugin_direct_dns && return 0
	dns_upstream_put "$DOH_PLAIN_DNS1" "$DOH_PLAIN_DNS2"
}




doh_upstream_set() {
	for _dus in /etc/dnsmasq.d/00-upstream.conf /tmp/dnsmasq.d/00-upstream.conf; do
		grep -q "server=$DOH_ADDR#$DOH_PORT" "$_dus" 2>/dev/null && return 0
	done
	return 1
}














doh_release_upstream() {
	doh_upstream_set || return 1
	rm -f /etc/dnsmasq.d/00-upstream.conf /tmp/dnsmasq.d/00-upstream.conf 2>/dev/null
	/etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null
	return 0
}













doh_rearm_after_cooldown() {
	[ -f "$DOH_AUTO_COOLDOWN" ] || return 1
	_drc=$(cat "$DOH_AUTO_COOLDOWN" 2>/dev/null | tr -cd '0-9')
	[ -n "$_drc" ] || { rm -f "$DOH_AUTO_COOLDOWN" 2>/dev/null; return 1; }
	doh_clock_ok || return 1                     # часы не выставлены — судить о сроке нечем
	[ "$(date +%s)" -ge "$_drc" ] || return 1    # карантин ещё держится
	doh_installed || return 1
	[ "$(cat "$ENODIA_STATE/.doh-auto" 2>/dev/null)" != off ] || return 1
	doh_enabled && return 1                      # DNS держит тумблер — авто-режим тут ни при чём
	doh_direct_regime || return 1                # успели уйти в туннель — авто-режим там не живёт
	if [ -n "$1" ] && ! "$1"; then return 1; fi  # аплинка нет — карантин НЕ снимаем, попробуем позже
	rm -f "$DOH_AUTO_COOLDOWN" 2>/dev/null       # ДО попытки: иначе doh_auto её же и запретит



	if ! doh_plugin_direct_dns; then
		doh_apply_dns direct || doh_restore_plain_dns
	fi
	doh_auto_active
}

















doh_health_tick() {


	if ! doh_auto_active; then
		rm -f "$DOH_HEALTH_MISS" "$DOH_HEALTH_STAMP" 2>/dev/null
		doh_rearm_after_cooldown "$1" && return 2
		return 0
	fi
	doh_clock_ok || return 0
	_dhn=$(date +%s)




	_dhl=$(cat "$DOH_HEALTH_STAMP" 2>/dev/null | tr -cd '0-9'); [ -n "$_dhl" ] || _dhl=0
	[ "$(age_since "$_dhl")" -ge "$DOH_HEALTH_EVERY" ] || return 0
	echo "$_dhn" > "$DOH_HEALTH_STAMP"




	if doh_probe 2 && doh_wire_ok; then rm -f "$DOH_HEALTH_MISS" 2>/dev/null; return 0; fi



	if [ -n "$1" ] && ! "$1"; then return 0; fi
	_dhm=$(cat "$DOH_HEALTH_MISS" 2>/dev/null | tr -cd '0-9'); [ -n "$_dhm" ] || _dhm=0
	_dhm=$((_dhm + 1)); echo "$_dhm" > "$DOH_HEALTH_MISS"
	[ "$_dhm" -ge "$DOH_HEALTH_MISS_MAX" ] || return 0



	doh_auto_active || return 0
	rm -f "$DOH_HEALTH_MISS" 2>/dev/null
	echo $((_dhn + DOH_COOLDOWN_SEC)) > "$DOH_AUTO_COOLDOWN"
	doh_auto_rollback
	doh_restore_plain_dns
	return 1
}



















doh_health_state() {
	_hsu=0; _hsua=-1; _hsri=-1; _hsc=-1
	if [ -f "$DOH_UNTUNNELED" ]; then
		_hsu=1
		_hsua=$(age_since "$(cat "$DOH_UNTUNNELED" 2>/dev/null | tr -cd '0-9')")
		[ "$_hsua" -lt 999999 ] 2>/dev/null || _hsua=-1

		if [ -f "$DOH_RETUNNEL_STAMP" ]; then
			_hsra=$(age_since "$(cat "$DOH_RETUNNEL_STAMP" 2>/dev/null | tr -cd '0-9')")
			if [ "$_hsra" -lt 999999 ] 2>/dev/null; then
				_hsri=$((DOH_RETUNNEL_BACKOFF - _hsra)); [ "$_hsri" -ge 0 ] || _hsri=0
			fi
		fi
	fi
	if [ -f "$DOH_AUTO_COOLDOWN" ]; then
		_hscu=$(cat "$DOH_AUTO_COOLDOWN" 2>/dev/null | tr -cd '0-9')
		if [ -n "$_hscu" ]; then


			if doh_clock_ok; then
				_hsc=$(( _hscu - $(date +%s) ))   # clock-raw: тот же вопрос, что у doh_auto_cooling, — «истёк ли срок»
				[ "$_hsc" -ge 0 ] || _hsc=-1
			else
				_hsc=-2
			fi
		fi
	fi
	_hsm=$(cat "$DOH_HEALTH_MISS" 2>/dev/null | tr -cd '0-9'); [ -n "$_hsm" ] || _hsm=0




	_hsf=0; _hsfa=-1; _hsfr=-1
	if doh_want && doh_upstream_set && [ "$(doh_proto)" = dot ] && [ "$(doh_proto_now)" = doh ]; then
		_hsf=1
		_hsfa=$(age_since "$(cat "$DOH_DOT_FALLBACK" 2>/dev/null | tr -cd '0-9')")
		[ "$_hsfa" -lt 999999 ] 2>/dev/null || _hsfa=-1

		_hsfl=$(cat "$DOH_DOT_TRY" 2>/dev/null | tr -cd '0-9')
		[ -n "$_hsfl" ] || _hsfl=$(cat "$DOH_DOT_FALLBACK" 2>/dev/null | tr -cd '0-9')
		_hsfl=$(age_since "$_hsfl")
		if [ "$_hsfl" -lt 999999 ] 2>/dev/null; then
			_hsfr=$((DOH_DOT_RETRY - _hsfl)); [ "$_hsfr" -ge 0 ] || _hsfr=0
		fi
	fi


	_hsb=-1
	if [ -f "$DOH_BAIL_STAMP" ] && doh_enabled && ! doh_upstream_set; then
		_hsba=$(age_since "$(cat "$DOH_BAIL_STAMP" 2>/dev/null | tr -cd '0-9')")
		if [ "$_hsba" -lt 999999 ] 2>/dev/null; then _hsb=$((DOH_BAIL_BACKOFF - _hsba)); [ "$_hsb" -ge 0 ] || _hsb=0; fi
	fi

	_hso=0; _hsoa=-1; _hsor=-1; _hsrn=''
	if [ "$(doh_proto)" = odoh ]; then
		_hsrn=$(doh_odoh_relay_now)
		if doh_want && doh_upstream_set && [ -f "$DOH_ODOH_FALLBACK" ]; then
			_hso=1
			_hsoa=$(age_since "$(cat "$DOH_ODOH_FALLBACK" 2>/dev/null | tr -cd '0-9')")
			[ "$_hsoa" -lt 999999 ] 2>/dev/null || _hsoa=-1
			_hsol=$(cat "$DOH_ODOH_TRY" 2>/dev/null | tr -cd '0-9'); [ -n "$_hsol" ] || _hsol=$(cat "$DOH_ODOH_FALLBACK" 2>/dev/null | tr -cd '0-9')
			_hsol=$(age_since "$_hsol")
			if [ "$_hsol" -lt 999999 ] 2>/dev/null; then _hsor=$(( $(doh_odoh_retry_wait) - _hsol )); [ "$_hsor" -ge 0 ] || _hsor=0; fi
		fi
	fi


	_hsq=0; _hsqa=-1; _hsqr=-1; _hsqn=''
	if doh_want && doh_upstream_set && [ "$(doh_lv_of)" = quic ] && [ "$(doh_proto_now)" != "$(doh_proto)" ]; then
		_hsq=1; _hsqn=$(doh_proto_now)
		_hsqa=$(age_since "$(cat "$DOH_QUIC_FALLBACK" 2>/dev/null | tr -cd '0-9')")
		[ "$_hsqa" -lt 999999 ] 2>/dev/null || _hsqa=-1
		_hsql=$(cat "$DOH_QUIC_TRY" 2>/dev/null | tr -cd '0-9')
		[ -n "$_hsql" ] || _hsql=$(cat "$DOH_QUIC_FALLBACK" 2>/dev/null | tr -cd '0-9')
		_hsql=$(age_since "$_hsql")
		if [ "$_hsql" -lt 999999 ] 2>/dev/null; then _hsqr=$((DOH_QUIC_RETRY - _hsql)); [ "$_hsqr" -ge 0 ] || _hsqr=0; fi
	fi
	printf 'untun=%s\nuntun_age=%s\nretun_in=%s\ncool=%s\nmiss=%s\nmiss_max=%s\ndotfb=%s\ndotfb_age=%s\ndotfb_retry=%s\nbail_in=%s\nodohfb=%s\nodohfb_age=%s\nodohfb_retry=%s\nodoh_relay=%s\nquicfb=%s\nquicfb_age=%s\nquicfb_retry=%s\nquicfb_to=%s\n' \
		"$_hsu" "$_hsua" "$_hsri" "$_hsc" "$_hsm" "$DOH_HEALTH_MISS_MAX" "$_hsf" "$_hsfa" "$_hsfr" "$_hsb" "$_hso" "$_hsoa" "$_hsor" "$_hsrn" \
		"$_hsq" "$_hsqa" "$_hsqr" "$_hsqn"
}








doh_apply_dns() {
	_doh_auto=0; DOH_APPLY_NOTE=
	if doh_enabled; then
		rm -f "$DOH_AUTO_STAMP" 2>/dev/null       # DNS держит тумблер, а не авто-режим
	elif [ "$1" = direct ] && doh_auto; then
		_doh_auto=1
		: > "$DOH_AUTO_STAMP"                     # ДО doh_start: гейт doh_want обязан пропустить
	else
		rm -f "$DOH_AUTO_STAMP" 2>/dev/null       # авто больше не держит DNS (ушли в туннель/запрещён)
		rm -f "$DOH_UNTUNNELED" "$DOH_RETUNNEL_STAMP" 2>/dev/null   # DoH выключен ⇒ и «уведён» не про что
		return 1
	fi

	rm -f "$DOH_BAIL_STAMP" 2>/dev/null



	if doh_dot_path_stale "$([ "$1" = tunnel ] && echo mark || echo bypass)"; then
		doh_dot_forget
		doh_running && { doh_resolver_mark del; doh_resolver_bypass del; doh_stop; }
	fi

	if doh_lv_path_stale quic "$([ "$1" = tunnel ] && echo mark || echo bypass)"; then
		doh_lv_forget quic
		doh_running && { doh_resolver_mark del; doh_resolver_bypass del; doh_stop; }
	fi











	if [ "$1" = direct ] && ! { doh_running && [ "$(doh_proto_now)" = "$(doh_proto)" ] && [ "$(doh_anchor_state)" = bypass ]; } \
	   && doh_quic_preset bypass; then
		doh_running && { doh_resolver_mark del; doh_resolver_bypass del; doh_stop; }
	fi






	_doh_started=0
	if ! doh_running; then
		doh_start
		sleep 1
		if ! doh_running; then
			doh_apply_fail
			return 1
		fi
		_doh_started=1
	fi


	if ! doh_wait_listen; then
		doh_apply_fail
		return 1
	fi



	rm -f "$DOH_UNTUNNELED" "$DOH_RETUNNEL_STAMP" 2>/dev/null
	_doh_was=$(doh_anchor_state)
	if [ "$1" = tunnel ]; then
		doh_resolver_bypass del      # если оставался RETURN прямого режима — снять
		doh_resolver_mark add
		_doh_now=mark
	else
		doh_resolver_mark del        # если оставалась форс-марка туннельного режима — снять
		doh_resolver_bypass add
		_doh_now=bypass
	fi














	_doh_fresh=0
	[ "$(age_since "$(cat "${CARRIER_UP_STAMP:-/tmp/.enodia-carrier-up.stamp}" 2>/dev/null | tr -cd '0-9')")" -lt 60 ] && _doh_fresh=1
	if [ "$_doh_started" = 0 ] && { [ "$_doh_was" != "$_doh_now" ] || [ "$_doh_fresh" = 1 ]; }; then


		doh_restart_wait 10 || { doh_apply_fail; return 1; }
	fi
	dns_upstream_put "$DOH_UPSTREAM"














	_doh_pn=2; { [ "$1" = tunnel ] || [ "$(doh_proto_now)" = odoh ]; } && _doh_pn=3
	if ! doh_probe "$_doh_pn"; then

















		if doh_quic_rescue; then
			_doh_qp=$(doh_proto_label "$(doh_proto)"); _doh_qn=$(doh_proto_label "$(doh_proto_now)")
			if [ "$(doh_proto_now)" = "$(doh_proto)" ]; then
				DOH_APPLY_NOTE="$_doh_qp этим путём снова отдаёт имена — вернулся на выбранный $_doh_qp"
			else
				DOH_APPLY_NOTE="$_doh_qp этим путём не отдаёт имён, а $_doh_qn того же резолвера отдаёт — шифрую по $_doh_qn; сторож проверит $_doh_qp и вернётся на него сам"
			fi
			doh_quic_preset_settle ok; return 0
		fi
		if doh_dot_rescue; then
			if [ "$(doh_proto_now)" = dot ]; then
				DOH_APPLY_NOTE="DoH этим путём не отдаёт имён, а выбранный DoT отдаёт — вернулся на DoT"
			else
				DOH_APPLY_NOTE="DoT этим путём не отдаёт имён, а DoH того же резолвера отдаёт — шифрую по DoH; сторож проверит DoT и вернётся на него сам"
			fi
			doh_quic_preset_settle ok; return 0
		fi

		if doh_odoh_rescue; then
			if [ "$(doh_proto_now)" = odoh ]; then
				DOH_APPLY_NOTE="ретранслятор ODoH не отдавал имён — иду через другой"
			else
				DOH_APPLY_NOTE="ни один ретранслятор ODoH не отдаёт имён — шифрую по DoH напрямую к цели; сторож проверит ретрансляторы и вернётся на ODoH сам"
			fi
			doh_quic_preset_settle ok; return 0
		fi
		_doh_pb=$(doh_proto_now)
		if [ "$1" = tunnel ] && doh_untunnel_apply && { doh_probe || doh_dot_rescue || doh_odoh_rescue || doh_quic_rescue; }; then
			DOH_APPLY_NOTE="резолвер уведён мимо несущей — та ещё не везёт (рукопожатие/сервер); сторож вернёт его в туннель, когда health пройдёт"




			_doh_pa=$(doh_proto_now)
			_doh_qp=$(doh_proto_label "$(doh_proto)"); _doh_qn=$(doh_proto_label "$_doh_pa")
			if [ "$_doh_pa" != "$_doh_pb" ] && [ "$(doh_lv_of)" = quic ]; then
				if [ "$_doh_pa" = "$(doh_proto)" ]; then
					DOH_APPLY_NOTE="$DOH_APPLY_NOTE; мимо несущей $_doh_qp отдаёт имена — вернулся на выбранный $_doh_qp"
				else
					DOH_APPLY_NOTE="$DOH_APPLY_NOTE; мимо несущей $_doh_qp не отдаёт имён, а $_doh_qn того же резолвера отдаёт — шифрую по $_doh_qn, сторож проверит $_doh_qp и вернётся на него сам"
				fi
			elif [ "$(doh_lv_of)" = quic ] && [ "$_doh_pa" != "$(doh_proto)" ]; then
				DOH_APPLY_NOTE="$DOH_APPLY_NOTE; шифрую по $_doh_qn, как и до увода, хотя выбран $_doh_qp — сторож проверит $_doh_qp на новом пути и вернётся на него сам"
			elif [ "$_doh_pa" != "$_doh_pb" ]; then
				if [ "$(doh_proto)" = odoh ]; then
					if [ "$_doh_pa" = odoh ]; then
						DOH_APPLY_NOTE="$DOH_APPLY_NOTE; мимо несущей ретранслятор отвечает — вернулся на выбранный ODoH"
					else
						DOH_APPLY_NOTE="$DOH_APPLY_NOTE; мимо несущей ретрансляторы ODoH не отдают имён — шифрую по DoH напрямую к цели, сторож проверит ретрансляторы и вернётся на ODoH сам"
					fi
				elif [ "$_doh_pa" = dot ]; then
					DOH_APPLY_NOTE="$DOH_APPLY_NOTE; мимо несущей DoH не отдал имён, а выбранный DoT отдаёт — вернулся на DoT"
				else
					DOH_APPLY_NOTE="$DOH_APPLY_NOTE; мимо несущей DoT не отдаёт имён, а DoH того же резолвера отдаёт — шифрую по DoH, сторож проверит DoT и вернётся на него сам"
				fi
			elif [ "$_doh_pa" = doh ] && [ "$(doh_proto)" = dot ]; then
				DOH_APPLY_NOTE="$DOH_APPLY_NOTE; шифрую по DoH, как и до увода, хотя выбран DoT — сторож проверит DoT на новом пути и вернётся на него сам"
			elif [ "$_doh_pa" = doh ] && [ "$(doh_proto)" = odoh ]; then
				DOH_APPLY_NOTE="$DOH_APPLY_NOTE; шифрую по DoH напрямую к цели, как и до увода — сторож проверит ретрансляторы на новом пути и вернётся на ODoH сам"
			fi
			doh_quic_preset_settle ok; return 0
		fi
		rm -f "$DOH_UNTUNNELED" 2>/dev/null
		doh_apply_fail
		return 1
	fi

	doh_quic_preset_settle ok
	return 0
}















case "$0" in
	*doh-lib.sh)
		case "${1:-}" in
			start) doh_start ;;







			restart) doh_running || exit 0
			         doh_restart_wait && doh_names_ok && exit 0
			         [ -f "$ENODIA_DIR/transport.sh" ] && sh "$ENODIA_DIR/transport.sh" dns >/dev/null 2>&1
			         doh_running && doh_names_ok 1 && exit 0
			         exit 1 ;;
			"")    : ;;
			*)     echo "usage: $0 start|restart" >&2; exit 2 ;;
		esac
		;;
esac
