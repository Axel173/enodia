#!/bin/sh







































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
TAB=$(printf '\t')

if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi
if [ -f "$ENODIA_DIR/lease-lib.sh" ]; then . "$ENODIA_DIR/lease-lib.sh"; fi
if [ -f "$ENODIA_DIR/dns-lib.sh" ]; then . "$ENODIA_DIR/dns-lib.sh"; fi
if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi
if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v dns_bulk_snippet >/dev/null 2>&1 || dns_bulk_snippet() { case "${1##*/}" in 06-adblock.conf|07-zapret-dom.conf|1[0-9]-geo*.conf) return 0 ;; esac; return 1; }


ld_ct() {
	if [ -n "${LANDNS_CT:-}" ]; then cat "$LANDNS_CT" 2>/dev/null; return 0; fi
	if command -v ct_list_all >/dev/null 2>&1; then ct_list_all; return 0; fi
	cat /proc/net/nf_conntrack 2>/dev/null || cat /proc/net/ip_conntrack 2>/dev/null
	return 0
}
command -v ip_is_self >/dev/null 2>&1 || ip_is_self() { [ -n "$1" ] || return 1; case "$(ip route get "${1%/32}" 2>/dev/null | sed -n 1p)" in "local "*) return 0 ;; esac; return 1; }   # not-wan: «is this the router itself», the rule of ip-lib.sh::ip_is_self
command -v ip_is_local >/dev/null 2>&1 || ip_is_local() { [ -n "$1" ] || return 1; case "$(ip route get "$1" 2>/dev/null | sed -n '1s/.* dev \([^ ]*\).*/\1/p')" in br-*|awgs0|lo) return 0 ;; esac; return 1; }   # not-wan: the client's bridge, the rule of lease-lib.sh::ip_is_local
command -v dnsmasq_conf_files >/dev/null 2>&1 || dnsmasq_conf_files() { for _dcf_f in /var/etc/dnsmasq.conf* /etc/dnsmasq.conf /tmp/dnsmasq.d/*; do [ -f "$_dcf_f" ] && echo "$_dcf_f"; done; }





ld_addr() {
	printf '%s\n' "$1" | tr -cd '0-9a-fA-F.:\n' | awk '/:/ && !/\./ {
		s = tolower($0); n = 0
		if (s ~ /::/) sub(/::/, ":z:", s)
		gsub(/:/, " ", s); $0 = s
		for (i = 1; i <= NF; i++) if ($i != "z") n++
		o = ""
		for (i = 1; i <= NF; i++) {
			if ($i == "z") { for (k = n; k < 8; k++) { if (o != "") o = o ":"; o = o "0" }; continue }
			g = $i; sub(/^0+/, "", g); if (g == "") g = "0"
			if (o != "") o = o ":"
			o = o g
		}
		print o; next } { print }'
}


_ld_self=" "; _ld_notself=" "; _ld_cli=" "; _ld_notcli=" "
ld_self() {
	case "$_ld_self" in *" $1 "*) return 0 ;; esac
	case "$_ld_notself" in *" $1 "*) return 1 ;; esac
	if ip_is_self "$1"; then _ld_self="$_ld_self$1 "; return 0; fi
	_ld_notself="$_ld_notself$1 "; return 1
}
ld_client() {
	case "$_ld_cli" in *" $1 "*) return 0 ;; esac
	case "$_ld_notcli" in *" $1 "*) return 1 ;; esac
	if ip_is_local "$1"; then _ld_cli="$_ld_cli$1 "; return 0; fi
	_ld_notcli="$_ld_notcli$1 "; return 1
}
















ld_records() {
	_ldfl=$(dnsmasq_conf_files | while IFS= read -r _ldf; do dns_bulk_snippet "$_ldf" || echo "$_ldf"; done)
	[ -n "$_ldfl" ] || return 0

	grep -H -E '^[[:space:]]*dhcp-(option|option-force|range)[[:space:]]*=' $_ldfl /dev/null 2>/dev/null | awk -v T="$TAB" 'BEGIN { FS = "," }
		{ f = $0; sub(/:.*/, "", f); s = $0; sub(/^[^:]*:/, "", s)
			gsub(/[\t\r]/, " ", s); sub(/ #.*/, "", s); gsub(/"/, "", s); $0 = s }
		/^[ \t]*dhcp-range[ \t]*=/ {
			sub(/^[ \t]*dhcp-range[ \t]*=/, "", s); $0 = s
			tag = "*"; st = ""; mk = ""
			for (i = 1; i <= NF; i++) { x = $i; gsub(/[ \t]/, "", x)
				if (x ~ /^set:/) { sub(/^set:/, "", x); tag = x; continue }
				if (i == 1 && x !~ /:/ && x !~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/) { tag = x; continue }
				if (x !~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/) continue
				if (st == "") st = x
				else if (x ~ /^255\./) mk = x
			}
			if (st == "") next
			if (mk == "") mk = "255.255.255.0"
			gsub(/[^A-Za-z0-9_*!-]/, "", tag); if (tag == "") tag = "*"
			print "R" T tag T st T mk; next
		}
		{
			sub(/^[ \t]*dhcp-option(-force)?[ \t]*=/, "", s); $0 = s
			tag = ""; opt = ""; st = 0
			for (i = 1; i <= NF; i++) { x = $i; gsub(/[][ \t]/, "", x); lx = tolower(x)
				if (x ~ /^(encap|vi-encap|rfc3925-encap|vendor):/) { opt = "skip"; break }
				if (lx ~ /^option6?:/ || lx ~ /^[0-9]+$/) { opt = lx; st = i + 1; break }
				if (x ~ /^(tag|set|net):/) sub(/^[a-z]+:/, "", x)
				if (tag == "") tag = x
			}
			if (opt != "6" && opt != "option:dns-server" && opt != "option6:dns-server" && opt != "option6:23") next
			a = ""
			for (i = st; i <= NF; i++) { x = $i; gsub(/[][ \t]/, "", x); if (x == "") continue; if (a != "") a = a " "; a = a x }
			if (a == "") next
			if (tag == "") tag = "*"
			print "O" T tag T a T f
		}'
}



ld_dhcp_src() {
	case "$1" in *[!A-Za-z0-9_]*|'') echo "file:$3"; return ;; esac
	for _lds in $(uci -q get "dhcp.$1.dns1" 2>/dev/null) $(uci -q get "dhcp.$1.dns2" 2>/dev/null); do
		case " $2 " in *" $(ld_addr "$_lds") "*) echo stock; return ;; esac
	done
	case " $(uci -q get "dhcp.$1.dhcp_option" 2>/dev/null) $(uci -q get "dhcp.$1.dhcp_option_force" 2>/dev/null) " in
		*" 6,"*|*"option:dns-server"*) echo uci; return ;;
	esac
	echo "file:$3"
}



ld_in_net() {
	case "$1.$2.$3" in *[!0-9.]*) return 1 ;; esac
	set -- $(echo "$1 $2 $3" | tr '.' ' ')
	[ "$#" -eq 12 ] || return 1
	[ $(( $1 & $9 )) -eq $(( $5 & $9 )) ] && [ $(( $2 & ${10} )) -eq $(( $6 & ${10} )) ] \
		&& [ $(( $3 & ${11} )) -eq $(( $7 & ${11} )) ] && [ $(( $4 & ${12} )) -eq $(( $8 & ${12} )) ]
}

ld_net_of() {   # $1 ip, $2 the R records
	printf '%s\n' "$2" | while IFS="$TAB" read -r _lnk _lnn _lns _lnm; do
		[ "$_lnk" = R ] || continue
		if ld_in_net "$1" "$_lns" "$_lnm"; then echo "$_lnn"; break; fi
	done
}


ld_given() {
	printf '%s\n' "$3" | while IFS="$TAB" read -r _lgn _lga _lgs _lgo; do
		case "$_lgn" in
			'*') ;;
			!*) [ -n "$2" ] && [ "${_lgn#!}" != "$2" ] || continue ;;
			*) [ -n "$2" ] && [ "$_lgn" = "$2" ] || continue ;;
		esac
		case " $_lga " in *" $1 "*) echo y; break ;; esac
	done | grep y >/dev/null
}

cmd_scan() {
	_ldrec=$(ld_records)


	_ldfound=$(printf '%s\n' "$_ldrec" | while IFS="$TAB" read -r _ldk _ldn _lda _ldf; do
		[ "$_ldk" = O ] || continue
		_ldo=0; _ldx=""
		for _lde in $_lda; do
			case "$_lde" in 0.0.0.0|::|'') _ldo=1; continue ;; esac
			if ld_self "$_lde"; then _ldo=1; continue; fi
			_ldx="$_ldx${_ldx:+ }$(ld_addr "$_lde")"
		done
		[ -n "$_ldx" ] || continue
		_ldn=$(printf '%s' "$_ldn" | tr -cd 'A-Za-z0-9_*!-')
		_ldp=$(printf '%s' "$_ldf" | tr -cd 'A-Za-z0-9_./-')
		printf '%s\t%s\t%s\t%s\n' "${_ldn:-*}" "$_ldx" "$(ld_dhcp_src "$_ldn" "$_ldx" "$_ldp")" "$_ldo"
	done | awk -F "$TAB" '!seen[$1 FS $2]++')
	[ -z "$_ldfound" ] || printf '%s\n' "$_ldfound" | sed 's/^/dhcp=/'



	_ldct=$(ld_ct | awk '{ seen = 1 } /dport=(53|853) / { s = ""; d = ""; p = ""; r = ""; n = 0
		for (i = 1; i <= NF; i++) {
			if ($i ~ /^src=/) { n++; if (n == 1) s = substr($i, 5); else if (n == 2) r = substr($i, 5) }
			else if ($i ~ /^dst=/ && d == "") d = substr($i, 5)
			else if ($i ~ /^dport=/ && p == "") p = substr($i, 7)
		}
		if (p == "53" || p == "853") print s, d, p, r }
		END { if (seen) print "#read" }')
	case "$_ldct" in *"#read"*) echo "ct=1" ;; *) echo "ct=0"; return 0 ;; esac
	printf '%s\n' "$_ldct" | grep -v '^#read$' | sort | uniq -c |
	while read -r _ldc _lds _ldd _ldp _ldr; do


		{ [ -z "$_ldr" ] || ld_self "$_ldr"; } && continue
		ld_self "$_lds" && continue          # the router's own query (to its upstream, a probe)
		ld_client "$_lds" || continue        # not a device of ours (a WAN host asking a LAN server)
		echo "$(ld_addr "$_lds") $(ld_addr "$_ldd") $_ldp $_ldc"
	done | awk '{ c[$1 "\t" $2 "\t" $3] += $4 } END { for (k in c) print k "\t" c[k] }' | sort |
	while IFS="$TAB" read -r _ldi _ldt _ldq _ldm; do
		_ldg=0
		ld_given "$_ldt" "$(ld_net_of "$_ldi" "$_ldrec")" "$_ldfound" && _ldg=1
		printf 'dev=%s\t%s\t%s\t%s\t%s\n' "$_ldi" "$_ldt" "$_ldq" "$_ldm" "$_ldg"
	done
}











ld_cap() {   # $1 seconds
	case "$1" in ''|0|*[!0-9]*) return 0 ;; esac
	command -v proc_tree_kill >/dev/null 2>&1 || return 0
	_ldme=$$
	( ( sleep "$1"; pid_runs "$_ldme" 'lan-dns\.sh json' && proc_tree_kill "$_ldme" ) & ) </dev/null >/dev/null 2>&1
	return 0
}



cmd_json() {
	cmd_scan | awk -v T="$TAB" 'BEGIN { FS = T; ct = ""; d = ""; v = "" }
		/^ct=/ { ct = substr($0, 4); next }
		/^dhcp=/ { n = substr($1, 6); if (n ~ /^!/) n = "*"; o = "false"; if ($4 == "1") o = "true"
			if (d != "") d = d ","
			d = d "{\"net\":\"" n "\",\"addr\":\"" $2 "\",\"src\":\"" $3 "\",\"own\":" o "}"; next }
		/^dev=/ { i = substr($1, 5); g = "false"; if ($5 == "1") g = "true"; p = $3 + 0; m = $4 + 0
			if (v != "") v = v ","
			v = v "{\"ip\":\"" i "\",\"to\":\"" $2 "\",\"port\":" p ",\"n\":" m ",\"dhcp\":" g "}"; next }
		END { if (ct == "") { print "null"; exit }
			c = "false"; if (ct == "1") c = "true"
			printf "{\"ct\":%s,\"dhcp\":[%s],\"devs\":[%s]}\n", c, d, v }'
}

case "$1" in
	scan) cmd_scan ;;
	json) ld_cap "$2"; cmd_json ;;
	*) echo "usage: lan-dns.sh scan|json [secs]" >&2; exit 2 ;;
esac
