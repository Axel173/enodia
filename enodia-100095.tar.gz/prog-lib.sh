#!/bin/sh


































PROG_DIR=/tmp/enodia-upd
PROG_FILE=$PROG_DIR/prog


PROG_LIB_DIR=${PROG_LIB_DIR:-$ENODIA_DIR}


prog_plan() { case "$1" in rollback) echo "chk snap swap apply" ;; *) echo "dl chk snap swap apply" ;; esac; }


_prog_deps() {
    command -v lbl_commit_out >/dev/null 2>&1 || { if [ -f "$PROG_LIB_DIR/label-lib.sh" ]; then . "$PROG_LIB_DIR/label-lib.sh"; fi; }
    command -v uptime_s >/dev/null 2>&1 || { if [ -f "$PROG_LIB_DIR/clock-lib.sh" ]; then . "$PROG_LIB_DIR/clock-lib.sh"; fi; }
    command -v uptime_s >/dev/null 2>&1 || uptime_s() { _cl_u=$(awk '{print int($1)}' /proc/uptime 2>/dev/null); case "$_cl_u" in ''|*[!0-9]*) _cl_u=999999999 ;; esac; echo "$_cl_u"; }
    command -v lbl_commit_out >/dev/null 2>&1
}



prog_on() { [ "${ENODIA_UPD_PROG:-}" = 1 ] && _prog_safe && [ -f "$PROG_FILE" ] && ! grep -q '^t1 ' "$PROG_FILE" 2>/dev/null && _prog_deps; }



_PRG_SAFE=0
_prog_safe() {
    [ "$_PRG_SAFE" = 1 ] && return 0
    [ -d "$PROG_DIR" ] && [ ! -L "$PROG_DIR" ] || return 1
    _prgo=$(ls -ldn "$PROG_DIR" 2>/dev/null | awk '{ print $1 " " $3 }')
    [ "$_prgo" = "drwx------ $(id -u 2>/dev/null)" ] || return 1
    _PRG_SAFE=1
}


_prog_txt() { printf '%s' "$*" | tr -d '\000-\037"\\'; }


_prog_put() { lbl_commit_out "$PROG_FILE" awk "$@" "$PROG_FILE" 2>/dev/null || true; }




prog_begin() {


    rm -rf "$PROG_DIR" 2>/dev/null
    _prog_deps || return 1
    mkdir -m 700 "$PROG_DIR" 2>/dev/null || return 1
    _PRG_SAFE=0; _prog_safe || return 1
    lbl_commit_out "$PROG_FILE" printf 'mode %s\nt0 %s\n' "$1" "$(uptime_s)" 2>/dev/null
}


prog_stage() {
    prog_on || return 0
    _prog_put -v k="$1" -v u="$(uptime_s)" '
        { L[++n] = $0; if ($1 == "st" && $3 == "now") cur = $2 }
        END {
            for (i = 1; i <= n; i++) {
                $0 = L[i]
                if (cur != k && $1 == "st" && $3 == "now") { $3 = "ok"; $5 = u }
                if (cur != k && $1 == "st" && $2 == k) continue
                print
            }
            if (cur != k) print "st " k " now " u " - 0 0 0 -"
        }'
}

prog_count() {
    prog_on || return 0
    _prog_put -v a="${1:-0}" -v b="${2:-0}" -v c="${3:-}" '$1 == "st" && $3 == "now" { $6 = a + 0; $7 = b + 0; if (c != "") $8 = c + 0 } { print }'
}

prog_flag() {
    prog_on || return 0
    _prog_put -v w="$1" '$1 == "st" && $3 == "now" { $9 = w } { print }'
}


prog_dl() {
    prog_on || return 0
    _prog_put -v t="${1:-0}" -v p="$2" -v u="$(uptime_s)" '$1 == "dl" { next } { print } END { print "dl " (t + 0) " " u " " p }'
}

prog_sub() {
    prog_on || return 0
    _prgk=$1; _prgs=$2; _prgn=${3:-0}; _prgm=${4:-0}; shift 2
    if [ $# -gt 0 ]; then shift; fi
    if [ $# -gt 0 ]; then shift; fi
    _prog_put -v k="$_prgk" -v l="sub $_prgk $_prgs $_prgn $_prgm $(_prog_txt "$*")" \
        '$1 == "sub" && $2 == k { if (!d) print l; d = 1; next } { print } END { if (!d) print l }'
}

prog_now() {
    prog_on || return 0
    _prgk=$1; shift
    _prog_put -v l="now $_prgk $(_prog_txt "$*")" '$1 == "now" || $1 == "nowd" { next } { print } END { print l }'
}


prog_nowd() {
    prog_on || return 0
    _prog_put -v l="nowd $(_prog_txt "$1")" '$1 == "nowd" { next } { print } END { print l }'
}


prog_ver() {
    prog_on || return 0
    _prog_put -v l="ver $(_prog_txt "${1:-?}") $(_prog_txt "${2:-0}") $(_prog_txt "${3:-?}") $(_prog_txt "${4:-0}")" '$1 == "ver" { next } { print } END { print l }'
}

prog_close() {
    prog_on || return 0
    _prog_put -v u="$(uptime_s)" '$1 == "t1" { next } { print } END { print "t1 " u }'
}







prog_json() {


    if [ ! -f "$PROG_FILE" ] || ! _prog_safe || ! _prog_deps; then printf 'null'; return 0; fi
    _prgp=$(awk '$1 == "dl" { print $4; exit }' "$PROG_FILE" 2>/dev/null)

    case "$_prgp" in /tmp/enodia-pkg.*/pkg.tar.gz) ;; *) _prgp="" ;; esac
    _prgg=-1
    if [ -n "$_prgp" ] && [ -f "$_prgp" ]; then _prgg=$(wc -c < "$_prgp" 2>/dev/null | tr -cd '0-9'); [ -n "$_prgg" ] || _prgg=-1; fi


    _prgj=$(awk -v o="$1" -v up="$(uptime_s)" -v got="$_prgg" -v pa="$(prog_plan apply)" -v pr="$(prog_plan rollback)" '
        /["\\]/ { next }
        $1 == "mode" { mode = ($2 == "rollback") ? "rollback" : "apply" }
        $1 == "nowd" { nd = $2 }
        $1 == "t0" { t0 = $2 + 0 }
        $1 == "t1" { t1 = $2 + 0; closed = 1 }
        $1 == "st" { S[$2] = 1; SS[$2] = $3; TS[$2] = $4 + 0; TE[$2] = $5; N[$2] = $6 + 0; M[$2] = $7 + 0; X[$2] = $8 + 0; F[$2] = ($9 == "-" ? "" : $9) }
        $1 == "dl" { dt = $2 + 0; dts = $3 + 0; hasdl = 1 }
        $1 == "sub" { if (!(($2) in SB)) SO[++ns] = $2; SB[$2] = $3; SN[$2] = $4 + 0; SM[$2] = $5 + 0
                      r = ""; for (i = 6; i <= NF; i++) { if (i > 6) r = r " "; r = r $i }; SR[$2] = r; if ($3 == "bad") subbad = 1 }
        $1 == "now" { nk = $2; na = ""; for (i = 3; i <= NF; i++) { if (i > 3) na = na " "; na = na $i }; hasnow = 1 }
        $1 == "ver" { vf = $2; vfc = $3 + 0; vt = $4; vtc = $5 + 0; hasver = 1 }
        END {
            # The plan as words of one line: awk here has no split() (BusyBox), so the keys are taken apart by hand.
            pl = (mode == "rollback") ? pr : pa; np = 0; w = ""
            for (i = 1; i <= length(pl); i++) { c = substr(pl, i, 1); if (c == " ") { if (w != "") P[++np] = w; w = "" } else w = w c }
            if (w != "") P[++np] = w
            last = 0; for (i = 1; i <= np; i++) if (P[i] in S) last = i
            printf "{\"mode\":\"%s\",\"up\":%d,\"t0\":%d,\"t1\":%s,\"plan\":[", mode, up, t0, (closed ? t1 : "null")
            for (i = 1; i <= np; i++) printf "%s\"%s\"", (i > 1 ? "," : ""), P[i]
            printf "],\"stages\":["
            for (i = 1; i <= np; i++) {
                k = P[i]
                if (k in S) {
                    st = SS[k]
                    if (st == "now" && o != "run") st = (o == "ok") ? "ok" : (o == "fail") ? "bad" : "cut"
                    if (k == "apply" && subbad && st == "ok") st = "bad"
                    te = (TE[k] == "-") ? ((SS[k] == "now" && closed) ? t1 : "null") : TE[k] + 0
                    printf "%s{\"k\":\"%s\",\"st\":\"%s\",\"ts\":%d,\"te\":%s,\"n\":%d,\"m\":%d,\"x\":%d,\"f\":\"%s\"}", (i > 1 ? "," : ""), k, st, TS[k], te, N[k], M[k], X[k], F[k]
                } else {
                    st = (i < last || o == "ok") ? "ok" : "wait"
                    printf "%s{\"k\":\"%s\",\"st\":\"%s\",\"ts\":null,\"te\":null,\"n\":0,\"m\":0,\"x\":0,\"f\":\"\"}", (i > 1 ? "," : ""), k, st
                }
            }
            printf "],\"dl\":"
            if (hasdl) printf "{\"total\":%d,\"ts\":%d,\"got\":%d}", dt, dts, got + 0; else printf "null"
            printf ",\"subs\":["
            # A step left running when the run ended takes the outcome of the run, as a stage does.
            for (i = 1; i <= ns; i++) {
                k = SO[i]; st = SB[k]
                if (st == "now" && o != "run") st = (o == "ok") ? "ok" : (o == "fail") ? "bad" : "cut"
                printf "%s{\"k\":\"%s\",\"st\":\"%s\",\"n\":%d,\"m\":%d,\"why\":\"%s\"}", (i > 1 ? "," : ""), k, st, SN[k], SM[k], SR[k]
            }
            printf "],\"now\":"
            if (hasnow) printf "{\"k\":\"%s\",\"a\":\"%s\",\"d\":\"%s\"}", nk, na, nd; else printf "null"
            printf ",\"ver\":"
            if (hasver) printf "{\"from\":\"%s\",\"fc\":%d,\"to\":\"%s\",\"tc\":%d}", vf, vfc, vt, vtc; else printf "null"
            printf "}"
        }' "$PROG_FILE" 2>/dev/null) || _prgj=""
    case "$_prgj" in '{'*'}') printf '%s' "$_prgj" ;; *) printf 'null' ;; esac
}
