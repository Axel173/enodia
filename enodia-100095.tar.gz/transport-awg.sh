#!/bin/sh
































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}




if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi

command -v ipt_top >/dev/null 2>&1 || ipt_top() { _itc=$1; shift; iptables -C "$_itc" "$@" 2>/dev/null || iptables -I "$_itc" 1 "$@"; }

command -v mss_clamp >/dev/null 2>&1 || { mss_clamp() { :; }; mss_unclamp() { :; }; }
command -v ct_flush >/dev/null 2>&1 || ct_flush()      { conntrack -F >/dev/null 2>&1 || true; }
command -v ct_flush_slot >/dev/null 2>&1 || ct_flush_slot() { ct_flush; }   # no scoped flush in an old ct-lib — the global one, as before
TABLE=1000
IFACE=awg0
FWMARK=0x1
TRANSPORT_FLAG="$ENODIA_STATE/.transport"
ACTIVE_CONF="$ENODIA_STATE/awg.conf"
SWITCH="$ENODIA_DIR/switch-vpn.sh"
AWG_SETUP="$ENODIA_DIR/awg_setup.sh"
NOTIFY_EVENT="$ENODIA_DIR/notify-event.sh"
APPLY_BYPASS="$ENODIA_DIR/apply-bypass.sh"
HS_MAX=180            # порог возраста handshake (сек) — как в watchdog.sh
PUB_DNS1=1.1.1.1
PUB_DNS2=8.8.8.8






if [ -f "$ENODIA_DIR/doh-lib.sh" ]; then . "$ENODIA_DIR/doh-lib.sh"; fi
command -v doh_apply_dns >/dev/null 2>&1 || doh_apply_dns() { return 1; }






if [ -f "$ENODIA_DIR/dns-lib.sh" ]; then . "$ENODIA_DIR/dns-lib.sh"; fi


command -v conf_dns >/dev/null 2>&1 || conf_dns() { grep -E '^DNS[[:space:]]*=' "$1" 2>/dev/null | head -1 | awk -F'= *' '{print $2}' | awk -F',' '{print $1}' | tr -d ' '; }



if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v age_since >/dev/null 2>&1 || age_since() {
    case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
    [ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}
command -v uptime_s >/dev/null 2>&1 || uptime_s() { _cl_u=$(awk '{print int($1)}' /proc/uptime 2>/dev/null); case "$_cl_u" in ''|*[!0-9]*) _cl_u=999999999 ;; esac; echo "$_cl_u"; }


if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v go_quiet >/dev/null 2>&1 || go_quiet() { "$@"; }   # the shim of a missing library: the launch as it was, with the banner
command -v carrier_barred >/dev/null 2>&1 || carrier_barred() { return 1; }
command -v carrier_run >/dev/null 2>&1 || carrier_run() { shift; "$@"; }


command -v pid_runs >/dev/null 2>&1 || pid_runs() { [ -n "$1" ] && [ -r "/proc/$1/cmdline" ] && tr '\000' ' ' 2>/dev/null < "/proc/$1/cmdline" | grep -qE "$2"; }
if [ -f "$ENODIA_DIR/label-lib.sh" ]; then . "$ENODIA_DIR/label-lib.sh"; fi


command -v daemon_step >/dev/null 2>&1 || { daemon_step_init() { DAEMON_STEP_Q=1; }; daemon_step() { sleep 1; }; }
command -v daemon_wait_gone >/dev/null 2>&1 || daemon_wait_gone() { _dwg=0; while [ -d "/proc/$1" ]; do [ "$_dwg" -ge "${2:-5}" ] && return 1; sleep 1; _dwg=$((_dwg+1)); done; return 0; }

command -v fw3_gen >/dev/null 2>&1 || fw3_gen() { cat /proc/sys/kernel/random/uuid 2>/dev/null || echo "$$-$RANDOM-$RANDOM"; }

command -v dns_upstream_put >/dev/null 2>&1 || dns_upstream_put() { mkdir -p /etc/dnsmasq.d; { echo no-resolv; for _dus in "$@"; do echo "server=$_dus"; done; } > /etc/dnsmasq.d/00-upstream.conf; /etc/init.d/dnsmasq restart >/dev/null 2>&1 || killall -HUP dnsmasq 2>/dev/null; }

log() { echo "[transport-awg] $*"; }
notify_event() { [ -f "$NOTIFY_EVENT" ] && sh "$NOTIFY_EVENT" "$1" "$2" "$3" "$4" >/dev/null 2>&1; }



wg_bin() {
    if [ -x "$ENODIA_BIN/awg" ]; then echo "$ENODIA_BIN/awg"
    elif command -v awg >/dev/null 2>&1; then echo awg
    else echo ""; fi
}





hs_age() {
    wg=$(wg_bin); [ -n "$wg" ] || { echo 999999; return; }
    hs=$("$wg" show "$IFACE" latest-handshakes 2>/dev/null | awk 'NR==1{print $2}')
    age_since "$hs"
}

carrier_up() { ip link show "$IFACE" 2>/dev/null | grep -q 'state UP\|UNKNOWN\|LOWER_UP'; }   # not-wan: своя несущая (awg0/awgN), а не аплинк; про аплинк отвечает ip-lib.sh




awg_endpoint_ip() {
    wg=$(wg_bin)
    if [ -n "$wg" ]; then
        ep=$("$wg" show "$IFACE" endpoints 2>/dev/null | awk 'NR==1{print $2}' | sed 's/:[0-9]*$//')
        echo "$ep" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' && { echo "$ep"; return 0; }
    fi
    ep=$(grep -E '^Endpoint' "$ACTIVE_CONF" 2>/dev/null | head -1 | awk -F'= *' '{print $2}' | sed 's/:[0-9]*$//; s/[[:space:]]//g')
    echo "$ep" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' && echo "$ep"
}



exclude_endpoint() {
    ep=$(awg_endpoint_ip)
    [ -n "$ep" ] || { log "endpoint awg не определён — пропуск анти-петли"; return 0; }
    [ -f "$APPLY_BYPASS" ] && sh "$APPLY_BYPASS" endpoint-set "$ep" >/dev/null 2>&1
    log "endpoint $ep исключён из маркировки (анти-петля)"
}






restore_vpn_dns() {


    if doh_apply_dns tunnel; then [ -n "${DOH_APPLY_NOTE:-}" ] && log "DoH: $DOH_APPLY_NOTE"; return 0; fi


    vpn_dns=$(conf_dns "$ACTIVE_CONF")
    [ -z "$vpn_dns" ] && vpn_dns=172.29.172.254
    ip route replace "$vpn_dns/32" dev "$IFACE" 2>/dev/null
    dns_upstream_put "$vpn_dns"
}


set_public_dns() {
    doh_apply_dns direct && return 0    # DoH ВКЛ (или авто-режим прямых) → резолв через локальный прокси; иначе → ниже как было
    vpn_dns=$(conf_dns "$ACTIVE_CONF")   # the SAME address restore_vpn_dns routed — else its route stays behind in direct mode
    [ -n "$vpn_dns" ] && ip route del "$vpn_dns/32" dev "$IFACE" 2>/dev/null
    dns_upstream_put "$PUB_DNS1" "$PUB_DNS2"
}








FW3_WIPED=0













carrier_matches_conf() { carrier_keys_match && carrier_endpoint_fresh; }
carrier_keys_match() {
    _cmw=$(wg_bin); [ -n "$_cmw" ] || return 0          # сверять нечем — прежнее поведение


    _cmk=$(sed -n 's/^[[:space:]]*PublicKey[[:space:]]*=[[:space:]]*//p' "$ACTIVE_CONF" 2>/dev/null | sed "s/#.*//" | tr -d ' \t\r')
    [ -n "$_cmk" ] || return 0                          # в конфиге нет ключа пира — не судим
    _cml=$("$_cmw" show "$IFACE" peers 2>/dev/null | tr -d ' \t\r')
    [ -n "$_cml" ] || return 0                          # демон ещё не сконфигурен — обычный путь
    for _cmx in $_cml; do printf '%s\n' "$_cmk" | grep -qxF -e "$_cmx" || return 1; done








    _cmp=$(sed -n 's/^[[:space:]]*PrivateKey[[:space:]]*=[[:space:]]*//p' "$ACTIVE_CONF" 2>/dev/null | head -1 | sed "s/#.*//" | tr -d ' \t\r')
    [ -n "$_cmp" ] || return 0
    _cmp=$(printf '%s\n' "$_cmp" | "$_cmw" pubkey 2>/dev/null | tr -d ' \t\r')
    [ -n "$_cmp" ] || return 0                          # ключ конфига не читается — сверить нечем
    _cmq=$("$_cmw" show "$IFACE" public-key 2>/dev/null | head -1 | tr -d ' \t\r')
    [ -n "$_cmq" ] || return 0
    [ "$_cmp" = "$_cmq" ]
}








carrier_endpoint_fresh() {
    [ -f "$ENODIA_STATE/awg0.conf" ] && return 0
    command -v is_ipv4 >/dev/null 2>&1 || return 0      # no dns-lib (a partial update) — not judged
    _cew=$(wg_bin); [ -n "$_cew" ] || return 0
    _cec=$(sed -n 's/^[[:space:]]*Endpoint[[:space:]]*=[[:space:]]*//p' "$ACTIVE_CONF" 2>/dev/null | sed "s/#.*//" | tr -d ' \t\r')
    [ -n "$_cec" ] || return 0
    for _cex in $_cec; do
        case "${_cex##*:}" in ''|*[!0-9]*) return 0 ;; esac   # no port — not judged
        is_ipv4 "${_cex%:*}" || return 0                    # a name or an IPv6 literal — not judged
    done
    _ced=$("$_cew" show "$IFACE" endpoints 2>/dev/null | awk '{print $2}' | tr -d '\r')
    for _cex in $_ced; do
        [ "$_cex" = "(none)" ] && continue
        printf '%s\n' "$_cec" | grep -qxF -e "$_cex" || return 1
    done
    return 0
}
ensure_carrier() {
    if ip link show "$IFACE" >/dev/null 2>&1; then
        carrier_matches_conf && return 0
        log "awg0 поднят с ДРУГИМ сервером или адресом (конфиг сменили, пока несущая была тёплым резервом) — пересоздаю"
        ip link del "$IFACE" 2>/dev/null
    fi
    for s in /etc/init.d/awg /etc/init.d/amneziawg /etc/init.d/amnezia; do
        [ -x "$s" ] && { "$s" start >/dev/null 2>&1; break; }
    done
    if ! ip link show "$IFACE" >/dev/null 2>&1 && [ -f "$AWG_SETUP" ]; then
        _ec_gen=$(fw3_gen)
        ( cd "$ENODIA_DIR" && sh ./awg_setup.sh >/tmp/enodia-transport-awg-setup.log 2>&1 )
        [ "$(fw3_gen)" = "$_ec_gen" ] || FW3_WIPED=1
    fi
    i=0; while [ $i -lt 15 ]; do
        ip link show "$IFACE" >/dev/null 2>&1 && return 0
        sleep 1; i=$((i+1))
    done
    return 1
}










replay_fw3() {
    [ "$FW3_WIPED" = 1 ] || return 0
    FW3_WIPED=0
    [ -f "$ENODIA_DIR/vpn-toggle.sh" ] || return 0
    log "awg_setup сделал firewall reload — переигрываю цепочки (vpn-toggle $1)"
    sh "$ENODIA_DIR/vpn-toggle.sh" "$1" >/dev/null 2>&1 || true
}




apply_awg_routing() {
    ip link set "$IFACE" up 2>/dev/null

    ipt_top FORWARD -o "$IFACE" -j ACCEPT
    ipt_top FORWARD -i "$IFACE" -j ACCEPT

    iptables -t nat -C POSTROUTING -o "$IFACE" -j MASQUERADE 2>/dev/null || iptables -t nat -A POSTROUTING -o "$IFACE" -j MASQUERADE
    mss_clamp "$IFACE"                          # the router's own TCP into the carrier — by ITS MTU (ipt-lib.sh)

    ip route replace default dev "$IFACE" table "$TABLE"
}




remove_awg_routing() {
    ip route del default dev "$IFACE" table "$TABLE" 2>/dev/null
    iptables -D FORWARD -o "$IFACE" -j ACCEPT 2>/dev/null
    iptables -D FORWARD -i "$IFACE" -j ACCEPT 2>/dev/null
    iptables -t nat -D POSTROUTING -o "$IFACE" -j MASQUERADE 2>/dev/null
    mss_unclamp "$IFACE"
}









slot_iface()   { echo "awg$1"; }               # id 2..7 -> awg2..awg7
slot_table()   { echo "100$1"; }               # id 2 -> 1002 ...
slot_srcconf() { echo "$ENODIA_STATE/configs/$1.conf"; }   # исходный конфиг страны/сервера
slot_ifconf()  { echo "$ENODIA_BIN/awg$1.conf"; }        # сгенерированный stripped conf для setconf






awg_daemon_pids() {   # $1 = iface (awg0 | awgN)
    for _p in /proc/[0-9]*; do
        [ -r "$_p/cmdline" ] || continue
        case "$(tr '\0' ' ' 2>/dev/null < "$_p/cmdline") " in
            *"amneziawg-go $1 "*) echo "${_p#/proc/}" ;;
        esac
    done
}



awg_kill_daemon() {   # $1 = iface
    _if="$1"
    _akd=$(awg_daemon_pids "$_if")
    for _pid in $_akd; do kill "$_pid" 2>/dev/null; done
    for _pid in $_akd; do
        daemon_wait_gone "$_pid" 3 && continue
        kill -9 "$_pid" 2>/dev/null
        daemon_wait_gone "$_pid" 5
    done
    rm -f "/var/run/amneziawg/$_if.sock" "/var/run/wireguard/$_if.sock" 2>/dev/null
}




awg_daemon_age() {   # $1 = iface
    _dap=$(awg_daemon_pids "$1" | head -n 1)
    [ -n "$_dap" ] || return 1

    _das=$(sed 's/^.*) //' "/proc/$_dap/stat" 2>/dev/null | awk 'NR == 1 && $20 ~ /^[0-9]+$/ { print int($20 / 100) }')
    case "$_das" in ''|*[!0-9]*) return 1 ;; esac
    _dau=$(uptime_s)
    [ "$_dau" -ge "$_das" ] 2>/dev/null || return 1
    echo $((_dau - _das))
}




AWG_MTU_DEFAULT=1376




slot_gen_conf() {   # $1 = src_conf, $2 = dst iface-conf
    _src="$1"; _dst="$2"
    _addr=$(grep -E '^[[:space:]]*Address[[:space:]]*=' "$_src" | head -1 | sed 's/^[^=]*=[[:space:]]*//' | cut -d',' -f1 | tr -d ' \t\r')
    _mtu=$(grep -E '^[[:space:]]*MTU[[:space:]]*=' "$_src" | head -1 | sed 's/^[^=]*=[[:space:]]*//' | tr -d ' \t\r')









    ( umask 077; rm -f "$_dst"; awk '{ t = tolower($0) } !(t ~ /^[[:space:]]*(address|dns|mtu|table|preup|postup|predown|postdown|saveconfig|listenport)[[:space:]]*=/)' "$_src" > "$_dst" )
    sed -i '/^[[:space:]]*I[1-5][[:space:]]*=[[:space:]]*$/d' "$_dst" 2>/dev/null   # пустые I1..I5 валят setconf
    _epsrc=$(grep -E '^[[:space:]]*Endpoint[[:space:]]*=' "$_src" | head -1 | sed 's/^[^=]*=[[:space:]]*//' | tr -d ' \t\r')
    _ephost=$(echo "$_epsrc" | sed 's/:[0-9]*$//')
    _epport=$(echo "$_epsrc" | sed -n 's/.*:\([0-9]*\)$/\1/p')
    case "$_ephost" in
        ''|\[*) : ;;                                   # нет Endpoint / IPv6-литерал — не подставляем


        *) if ! command -v is_ipv4 >/dev/null 2>&1; then



               log "слот: нет $ENODIA_DIR/dns-lib.sh — Endpoint '$_ephost' останется ИМЕНЕМ; awg setconf может отвергнуть конфиг слота целиком (обновите скрипты)" >&2
           elif ! is_ipv4 "$_ephost"; then
               _epip=$(resolve_ipv4 "$_ephost" 2>/dev/null)
               if [ -n "$_epip" ] && [ -n "$_epport" ]; then
                   sed -i "s|^[[:space:]]*Endpoint[[:space:]]*=.*|Endpoint = $_epip:$_epport|" "$_dst"
               else
                   log "слот: не зарезолвил Endpoint '$_ephost' (ни dnsmasq, ни DoH) — setconf может отвергнуть конфиг слота целиком" >&2
               fi
           fi ;;
    esac
    printf '%s\t%s\n' "$_addr" "$_mtu"
}












SLOT_KEEPALIVE=25
slot_keepalive() {   # $1 = iface
    [ -x "$ENODIA_BIN/awg" ] || return 0
    "$ENODIA_BIN/awg" show "$1" persistent-keepalive 2>/dev/null | awk -v cap="$SLOT_KEEPALIVE" '$2=="off" || $2+0>cap {print $1}' | while read -r _kp; do
        [ -n "$_kp" ] && "$ENODIA_BIN/awg" set "$1" peer "$_kp" persistent-keepalive "$SLOT_KEEPALIVE" 2>/dev/null
    done
    return 0
}











slot_carrier_up() {   # $1 = id ; $2 = cfg ; SLOT_FRESH=1 — the daemon was started by this call (a warm one is 0)
    _id="$1"; _cfg="$2"; _if=$(slot_iface "$_id"); SLOT_FRESH=0
    if ip link show "$_if" >/dev/null 2>&1; then ip link set "$_if" up 2>/dev/null; slot_keepalive "$_if"; slot_exclude_endpoint "$_id"; return 0; fi
    _am=$(slot_carrier_conf "$_id" "$_cfg") || return 1
    slot_exclude_endpoint "$_id"                # the anti-loop BEFORE the first packet (see the header)
    slot_carrier_start "$_id" "$_am" && { SLOT_FRESH=1; return 0; }
    [ -f "$APPLY_BYPASS" ] && sh "$APPLY_BYPASS" endpoint-slot-set "$_id" "" >/dev/null 2>&1
    return 1
}



slot_carrier_conf() {   # $1 = id ; $2 = cfg

    _src=$(slot_srcconf "$2")
    [ -f "$_src" ] || { log "слот №$1: нет конфига $_src" >&2; return 1; }
    [ -x "$ENODIA_BIN/amneziawg-go" ] && [ -x "$ENODIA_BIN/awg" ] || { log "слот №$1: нет бинарей amneziawg-go/awg" >&2; return 1; }
    _scc=$(slot_gen_conf "$_src" "$(slot_ifconf "$1")")
    [ -n "$(printf '%s' "$_scc" | cut -f1)" ] || { log "слот №$1: в $_src нет Address — awgN был бы без IPv4, не поднимаю" >&2; return 1; }
    printf '%s\n' "$_scc"
}

slot_carrier_start() {   # $1 = id ; $2 = "ADDRESS<TAB>MTU"
    awg_if_start "$(slot_iface "$1")" "$(slot_ifconf "$1")" "$2" "слот №$1"
}



awg_if_start() {   # $1 = iface ; $2 = ifconf ; $3 = "ADDRESS<TAB>MTU" ; $4 = кто
    _if="$1"; _dst="$2"; _wh="$4"
    _addr=$(printf '%s' "$3" | cut -f1); _mtu=$(printf '%s' "$3" | cut -f2)
    awg_kill_daemon "$_if"                      # добить возможный stale-демон/сокет ИМЕННО этого интерфейса




    go_quiet env $(sh "$ENODIA_DIR/net-tune.sh" memlimit-env 2>/dev/null | grep -E '^GOMEMLIMIT=[0-9]+MiB$') "$ENODIA_BIN/amneziawg-go" "$_if" || { log "$_wh: amneziawg-go $_if не стартовал"; return 1; }
    _i=0; while ! ip link show "$_if" >/dev/null 2>&1 && [ "$_i" -lt 10 ]; do sleep 1; _i=$((_i+1)); done
    ip link show "$_if" >/dev/null 2>&1 || { log "$_wh: $_if не появился"; awg_kill_daemon "$_if"; return 1; }


    "$ENODIA_BIN/awg" setconf "$_if" "$_dst" || { log "$_wh: awg setconf отверг конфиг $_if"; awg_kill_daemon "$_if"; ip link del "$_if" 2>/dev/null; return 1; }
    slot_keepalive "$_if"
    ip a add "$_addr" dev "$_if" 2>/dev/null
    ip link set dev "$_if" mtu "${_mtu:-$AWG_MTU_DEFAULT}" 2>/dev/null
    ip link set up "$_if"
    return 0
}



ifconf_ep_host() { grep -E '^[[:space:]]*Endpoint' "$1" 2>/dev/null | head -1 | awk -F'= *' '{print $2}' | sed 's/:[0-9]*$//; s/[[:space:]]//g'; }



slot_exclude_endpoint() {   # $1 = id
    _id="$1"
    _ep=$(ifconf_ep_host "$(slot_ifconf "$_id")")
    if echo "$_ep" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$'; then
        [ -f "$APPLY_BYPASS" ] && sh "$APPLY_BYPASS" endpoint-slot-set "$_id" "$_ep" >/dev/null 2>&1
        log "слот №$_id: endpoint $_ep исключён из маркировки (анти-петля)"
    else
        log "слот №$_id: endpoint не IPv4/не определён — пропуск анти-петли"
    fi
}



slot_apply_routing() {   # $1 = id
    _id="$1"; _if=$(slot_iface "$_id"); _tab=$(slot_table "$_id")
    ip link set "$_if" up 2>/dev/null
    ipt_top FORWARD -o "$_if" -j ACCEPT
    ipt_top FORWARD -i "$_if" -j ACCEPT
    iptables -t nat -C POSTROUTING -o "$_if" -j MASQUERADE 2>/dev/null || iptables -t nat -A POSTROUTING -o "$_if" -j MASQUERADE
    mss_clamp "$_if"
    ip route replace default dev "$_if" table "$_tab"
}
slot_remove_routing() {   # $1 = id
    _id="$1"; _if=$(slot_iface "$_id"); _tab=$(slot_table "$_id")
    ip route del default dev "$_if" table "$_tab" 2>/dev/null
    iptables -D FORWARD -o "$_if" -j ACCEPT 2>/dev/null
    iptables -D FORWARD -i "$_if" -j ACCEPT 2>/dev/null
    iptables -t nat -D POSTROUTING -o "$_if" -j MASQUERADE 2>/dev/null
    mss_unclamp "$_if"
}







SLOT_HS_WAIT=3
slot_wait_hs() {   # $1 = iface -> 0 — the handshake is there


    if [ "${ENODIA_UPD_PROG:-}" = 1 ] && [ -f "$ENODIA_DIR/prog-lib.sh" ]; then ( . "$ENODIA_DIR/prog-lib.sh"; prog_nowd hs ) 2>/dev/null; fi
    daemon_step_init; _swn=0
    while [ "$_swn" -lt $((SLOT_HS_WAIT * DAEMON_STEP_Q)) ]; do
        _swh=$("$ENODIA_BIN/awg" show "$1" latest-handshakes 2>/dev/null | awk 'NR==1{print $2+0}')
        [ "${_swh:-0}" -gt 0 ] && return 0
        daemon_step; _swn=$((_swn + 1))
    done
    return 1
}







slot_held() {   # $1 = cfg
    [ -f "$ENODIA_DIR/warp.sh" ] || return 1
    sh "$ENODIA_DIR/warp.sh" holds "$1" >/dev/null 2>&1
}

cmd_slot_up() {   # $1 = id, $2 = cfg
    _id="$1"; _cfg="$2"
    case "$_id" in [2-7]) ;; *) log "слот: id = 2..7"; return 1 ;; esac
    [ -n "$_cfg" ] && [ "$_cfg" != '-' ] || { log "слот №$_id: awg-выходу нужен конфиг (configs/<имя>.conf)"; return 1; }
    slot_held "$_cfg" && { log "слот №$_id: не поднимаю — на его конфиге идёт подбор порта WARP, выход вернёт сам подбор"; return 1; }







    if [ -f "$ENODIA_DIR/slots.sh" ] && _kb=$(sh "$ENODIA_DIR/slots.sh" key-holder "$_cfg" "$_id" live 2>/dev/null); then
        log "слот №$_id: не поднимаю — $_kb"
        ip link show "$(slot_iface "$_id")" >/dev/null 2>&1 && cmd_slot_down "$_id"
        return 1
    fi
    if ! slot_carrier_up "$_id" "$_cfg"; then
        log "слот №$_id: несущая awg не поднялась → выход живёт по fallback-политике (mark-core)"
        return 1
    fi
    slot_apply_routing "$_id"


    [ -f "$ENODIA_DIR/road.sh" ] && sh "$ENODIA_DIR/road.sh" mtu-fix >/dev/null 2>&1
    [ "$SLOT_FRESH" = 1 ] && slot_wait_hs "$(slot_iface "$_id")"
    ct_flush_slot "$_id"   # only this exit's flows (ct-lib.sh): a global flush tore the whole house on every flap
    log "слот №$_id: awg-несущая $(slot_iface "$_id") в table $(slot_table "$_id") (конфиг $_cfg)"
    return 0
}
cmd_slot_down() {   # $1 = id
    _id="$1"
    case "$_id" in [2-7]) ;; *) log "слот: id = 2..7"; return 1 ;; esac
    _if=$(slot_iface "$_id")
    slot_remove_routing "$_id"
    [ -f "$APPLY_BYPASS" ] && sh "$APPLY_BYPASS" endpoint-slot-set "$_id" "" >/dev/null 2>&1   # снять анти-петлю слота
    awg_kill_daemon "$_if"                      # гасим демон (владелец TUN) — TUN уходит следом
    ip link del "$_if" 2>/dev/null              # cleanup, если TUN пережил демон
    ct_flush_slot "$_id"
    log "слот №$_id: awg-несущая $_if снята"
    return 0
}















slot_reg_is() {   # $1 = id ; $2 = cfg
    [ -f "$ENODIA_DIR/slots.sh" ] || return 0
    _sri=$(sh "$ENODIA_DIR/slots.sh" show "$1" 2>/dev/null)
    [ "$(printf '%s' "$_sri" | cut -f6)" = on ] && [ "$(printf '%s' "$_sri" | cut -f3)" = awg ] && [ "$(printf '%s' "$_sri" | cut -f4)" = "$2" ]
}
SLOT_PROBE_WAIT=15   # с: живой сервер отвечает за доли секунды; не дошедшую инициацию WireGuard повторяет через 5 с
cmd_slot_probe() {   # $1 = id, $2 = cfg
    _id="$1"; _cfg="$2"
    case "$_id" in [2-7]) ;; *) log "слот: id = 2..7"; return 1 ;; esac
    [ -n "$_cfg" ] && [ "$_cfg" != '-' ] || { log "слот №$_id: awg-выходу нужен конфиг (configs/<имя>.conf)"; return 1; }
    _if=$(slot_iface "$_id")

    ip link show "$_if" >/dev/null 2>&1 && return 5

    slot_held "$_cfg" && { log "слот №$_id: пробу возврата не делаю — на его конфиге идёт подбор порта WARP"; return 5; }
    if [ -f "$ENODIA_DIR/slots.sh" ] && _kb=$(sh "$ENODIA_DIR/slots.sh" key-holder "$_cfg" "$_id" live 2>/dev/null); then
        log "слот №$_id: пробу возврата не делаю — $_kb"
        return 3
    fi
    _am=$(slot_carrier_conf "$_id" "$_cfg") || return 4
    slot_reg_is "$_id" "$_cfg" || return 6       # выключили/сменили, пока тик шёл к нам — ничего не поднимаем
    slot_exclude_endpoint "$_id"                # проба: анти-петля ДО первого пакета (см. шапку)
    _spr=4; _spp=""


    if ip link show "$_if" >/dev/null 2>&1; then log "слот №$_id: пока собирали конфиг, выход поднял кто-то другой — пробу не начинаю"; return 5; fi
    if slot_carrier_start "$_id" "$_am"; then
        _spr=1



        _spp=$(awg_daemon_pids "$_if")

        [ -n "$_spp" ] || { _spr=4; log "слот №$_id: amneziawg-go $_if умер сразу после старта — несущая не встала"; }
        _w=0
        while [ -n "$_spp" ] && [ "$_w" -lt "$SLOT_PROBE_WAIT" ]; do

            [ "$(awg_daemon_pids "$_if")" = "$_spp" ] || { _spr=5; break; }

            _hs=$("$ENODIA_BIN/awg" show "$_if" latest-handshakes 2>/dev/null | awk 'NR==1{print $2+0}')
            if [ "${_hs:-0}" -gt 0 ]; then

                if ! slot_reg_is "$_id" "$_cfg"; then _spr=6; break; fi
                slot_apply_routing "$_id"


                [ -f "$ENODIA_DIR/road.sh" ] && sh "$ENODIA_DIR/road.sh" mtu-fix >/dev/null 2>&1
                ct_flush_slot "$_id"
                log "слот №$_id: сервер ответил за ${_w}с — awg-несущая $_if снова в table $(slot_table "$_id") (конфиг $_cfg)"
                return 0
            fi
            sleep 1; _w=$((_w+1))
        done
        case "$_spr" in
            6) log "слот №$_id: выход выключили или сменили, пока шла проба, — поднятое снимаю, маршрут не ставлю" ;;
            5) ;;
            *) log "слот №$_id: сервер не ответил за ${SLOT_PROBE_WAIT}с — выход остаётся на запасном пути" ;;
        esac
    fi



    _spn=$(awg_daemon_pids "$_if")
    if [ -n "$_spp" ] && [ "$_spn" != "$_spp" ]; then
        if [ -n "$_spn" ]; then log "слот №$_id: пока шла проба, выход поднял кто-то другой (панель) — его не трогаю"
        else log "слот №$_id: демон пробы снят кем-то другим (панель) — уборка за ним"; fi
        return 5
    fi


    if [ -n "$_spp" ] && ip route show table "$(slot_table "$_id")" 2>/dev/null | grep -q "^default dev $_if"; then   # not-wan: несущая СЛОТА (table 100N)
        log "слот №$_id: пока шла проба, выход достроил кто-то другой (slot-up) — его не трогаю"
        return 5
    fi
    awg_kill_daemon "$_if"
    ip link del "$_if" 2>/dev/null
    [ -f "$APPLY_BYPASS" ] && sh "$APPLY_BYPASS" endpoint-slot-set "$_id" "" >/dev/null 2>&1   # проба не удалась: анти-петлю снять
    return "$_spr"
}

















TRY_IF=awgt0
TRY_PREF=51
TRY_LOCK=/tmp/enodia-awg-try.lock



TRY_DIR=/tmp/enodia-awg-try.d
TRY_CONF="$TRY_DIR/conf"
try_clean() {
    awg_kill_daemon "$TRY_IF"
    ip link del "$TRY_IF" 2>/dev/null
    [ -n "$_tep" ] && ip rule del to "$_tep" lookup "${_ttab:-main}" pref "$TRY_PREF" 2>/dev/null
    [ "${_tdir:-0}" = 1 ] && rm -rf "$TRY_DIR"
    lbl_lock_drop "$TRY_LOCK"
}




try_road_tab() {
    _trk=$(ip rule show 2>/dev/null | awk -v a="$1" '{ p = $1; sub(/:$/, "", p) } p ~ /^8[2-7]$/ { for (i = 2; i < NF; i++) if ($i == "to" && $(i + 1) == a) { for (j = i; j < NF; j++) if ($j == "lookup") { print $(j + 1); exit } } }')   # not-wan: road.sh's own rules
    case "$_trk" in
        100[2-7]) if [ -n "$(ip route show table "$_trk" 2>/dev/null | head -n 1)" ]; then _ttab=$_trk; else _ttab=main; fi ;;   # not-wan: the road exit's own table
    esac
}




try_rules_sweep() { _trs=0; while [ "$_trs" -lt 64 ] && ip rule del pref "$TRY_PREF" 2>/dev/null; do _trs=$((_trs + 1)); done; }

try_rule_put() {
    ip rule add to "$_tep" lookup "$_ttab" pref "$TRY_PREF" 2>/dev/null || { _tep=""; log >&2 "проба: правило к серверу не встало"; return 1; }
}
cmd_try() {   # $1 = путь конфига ; $2 = URL ; $3 = потолок запроса, с (по умолчанию 10)
    [ -f "$1" ] && [ -n "$2" ] || { log >&2 "проба: нужны конфиг и URL"; return 4; }
    [ -x "$ENODIA_BIN/amneziawg-go" ] && [ -x "$ENODIA_BIN/awg" ] || { log >&2 "проба: нет программ AmneziaWG"; return 4; }
    command -v lbl_lock_take >/dev/null 2>&1 || { log >&2 "проба: нет label-lib.sh — обновите скрипты"; return 4; }
    lbl_lock_take "$TRY_LOCK" 'transport-awg\.sh' || { log >&2 "проба: идёт другая проба"; return 5; }
    _tep=""; _tdir=0; _ttab=main; try_rules_sweep
    trap try_clean EXIT
    trap 'exit 1' INT TERM HUP PIPE

    rm -rf "$TRY_DIR" 2>/dev/null
    ( umask 077; mkdir "$TRY_DIR" ) 2>/dev/null || { log >&2 "проба: не создать свой каталог $TRY_DIR"; return 4; }
    _tdir=1
    _tam=$(slot_gen_conf "$1" "$TRY_CONF")   # the key's copy is closed by its maker (slot_gen_conf)
    [ -n "$(printf '%s' "$_tam" | cut -f1)" ] || { log >&2 "проба: в конфиге нет Address"; return 4; }
    _tep=$(ifconf_ep_host "$TRY_CONF")
    printf '%s' "$_tep" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || { _tep=""; log >&2 "проба: Endpoint не IPv4"; return 4; }
    _trv=""; _trc=""
    if [ -n "${TRY_ROAD:-}" ] && [ -f "$ENODIA_DIR/road.sh" ]; then
        _trv=$(sh "$ENODIA_DIR/road.sh" get awg "$TRY_ROAD" 2>/dev/null </dev/null | tr -cd '2-7' | cut -c1)
        _trc=$(sh "$ENODIA_DIR/road.sh" mtu-cap awg "$TRY_ROAD" 2>/dev/null </dev/null | tr -cd '0-9')
        if [ -n "$_trv" ] && [ -n "$_trc" ] && [ -n "$(ip route show table "$(slot_table "$_trv")" 2>/dev/null | head -n 1)" ]; then   # not-wan: the road exit's own table (100N), not the uplink
            _ttab=$(slot_table "$_trv")
        fi
    fi
    try_road_tab "$_tep"

    if [ "$_ttab" != main ] && [ -n "$_trc" ] && [ "$_ttab" = "$(slot_table "${_trv:-0}")" ]; then
        _tmu=$(printf '%s' "$_tam" | cut -f2); [ -n "$_tmu" ] || _tmu=$AWG_MTU_DEFAULT
        [ "$_tmu" -gt "$_trc" ] 2>/dev/null && _tam=$(printf '%s\t%s' "$(printf '%s' "$_tam" | cut -f1)" "$_trc")
    fi
    try_rule_put || return 4
    awg_if_start "$TRY_IF" "$TRY_CONF" "$_tam" "проба" >&2 || return 4
    _tca=$(curl_ca_opt "$2" --interface "$TRY_IF")   # the CA probe — by the probe's own path, not the default route

    curl -s $_tca --interface "$TRY_IF" --connect-timeout 6 --max-time "${3:-10}" "$2" 2>/dev/null || return 1



    if [ "${TRY_MS:-}" = 1 ]; then
        _tmh=$(printf '%s' "$2" | sed 's#^[a-z]*://##; s#[/:].*##')
        _tmc=$(curl -s -o /dev/null --interface "$TRY_IF" --connect-timeout 4 --max-time 6 -w '%{time_connect}' "http://$_tmh:443" 2>/dev/null)
        _tmm=$(awk -v t="$_tmc" 'BEGIN{ if (t + 0 > 0) printf "%.0f", t * 1000 }')
        [ -z "$_tmm" ] || printf '\ntry_ms=%s\n' "$_tmm"
    fi
    return 0
}














TRY_HS=${TRY_HS:-3}
try_stop() {   # $1 = the stop EREs, $2 = the answer → 0 when every ERE matches a line of it
    [ -n "$1" ] || return 1
    printf '%s\n' "$1" | { while IFS= read -r _tse; do [ -z "$_tse" ] || grep -Eq "$_tse" "$2" 2>/dev/null || exit 1; done; exit 0; }
}
cmd_try_each() {   # $1 = URL ; $2 = потолок запроса, с ; $3 = stop-ERE ; $4 = список кандидатов
    [ -n "$1" ] && [ -f "$4" ] || { log >&2 "проба: нужны URL и список"; return 4; }
    [ -x "$ENODIA_BIN/amneziawg-go" ] && [ -x "$ENODIA_BIN/awg" ] || { log >&2 "проба: нет программ AmneziaWG"; return 4; }
    command -v lbl_lock_take >/dev/null 2>&1 || { log >&2 "проба: нет label-lib.sh — обновите скрипты"; return 4; }



    daemon_step_init
    _tlw=$(uptime_s)
    while ! lbl_lock_take "$TRY_LOCK" 'transport-awg\.sh'; do
        [ $(( $(uptime_s) - _tlw )) -lt "${TRY_LOCK_WAIT:-40}" ] 2>/dev/null || { log >&2 "проба: идёт другая проба"; return 5; }
    done
    _tep=""; _tdir=0; _ttab=main; try_rules_sweep
    trap try_clean EXIT
    trap 'exit 1' INT TERM HUP PIPE
    rm -rf "$TRY_DIR" 2>/dev/null
    ( umask 077; mkdir "$TRY_DIR" ) 2>/dev/null || { log >&2 "проба: не создать свой каталог $TRY_DIR"; return 4; }
    _tdir=1
    _tt0=$(uptime_s); _tn=0; _tsig=""; _tca="-"
    while IFS= read -r _tcf <&3; do
        [ -n "$_tcf" ] || continue
        _tn=$((_tn+1))
        if [ "${TRY_BUDGET:-0}" -gt 0 ] 2>/dev/null && [ $(( $(uptime_s) - _tt0 )) -ge "$TRY_BUDGET" ]; then echo '!budget'; break; fi
        echo "#$_tn"
        rm -f "$_tcf.out"
        _tam=$(slot_gen_conf "$_tcf" "$TRY_CONF")
        _tnep=$(ifconf_ep_host "$TRY_CONF")
        if [ -z "$(printf '%s' "$_tam" | cut -f1)" ] || ! printf '%s' "$_tnep" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$'; then
            printf '=%s\t-\t-\n' "$_tn"; continue      # no Address, or a server that is not IPv4: NOT ASKED (not «no handshake»)
        fi
        if [ "$_tnep" != "$_tep" ]; then
            [ -z "$_tep" ] || ip rule del to "$_tep" lookup "$_ttab" pref "$TRY_PREF" 2>/dev/null
            _tep=$_tnep; _ttab=main; try_road_tab "$_tep"
            try_rule_put || return 4
        fi
        _tns="$_tam|$(grep -E '^[[:space:]]*I1[[:space:]]*=' "$TRY_CONF" | head -n 1)"
        if [ "$_tns" != "$_tsig" ] || ! ip link show "$TRY_IF" >/dev/null 2>&1; then
            awg_if_start "$TRY_IF" "$TRY_CONF" "$_tam" "проба" </dev/null >&2 || return 4
            _tsig=$_tns
        fi

        "$ENODIA_BIN/awg" setconf "$TRY_IF" "$TRY_CONF" 2>/dev/null || { printf '=%s\t-\t-\n' "$_tn"; continue; }   # text refused: not asked
        slot_keepalive "$TRY_IF"


        _ths=0; _thn=1; [ "$_tn" = 1 ] && _thn=${TRY_HS_FIRST:-1}
        while :; do
            _thw=0
            while [ "$_thw" -lt $(( TRY_HS * ${DAEMON_STEP_Q:-1} )) ]; do
                _thl=$("$ENODIA_BIN/awg" show "$TRY_IF" latest-handshakes 2>/dev/null | awk '{ print $2; exit }')
                if [ -n "$_thl" ] && [ "$_thl" != 0 ]; then _ths=1; break; fi
                daemon_step; _thw=$((_thw+1))
            done
            [ "$_ths" = 0 ] || break
            _thn=$((_thn - 1)); [ "$_thn" -gt 0 ] 2>/dev/null || break
            "$ENODIA_BIN/awg" setconf "$TRY_IF" "$TRY_CONF" 2>/dev/null || break
            slot_keepalive "$TRY_IF"
        done
        [ "$_ths" = 1 ] || { printf '=%s\t0\t-\n' "$_tn"; continue; }
        [ "$_tca" != "-" ] || _tca=$(curl_ca_opt "$1" --interface "$TRY_IF")   # once: the CA probe by the probe's own path

        curl -s $_tca --interface "$TRY_IF" --connect-timeout 4 --max-time "${2:-10}" "$1" </dev/null > "$_tcf.out" 2>/dev/null; _trc=$?


        if [ "$_trc" = 60 ] && [ -z "$_tca" ]; then
            _tca=$(curl_ca_opt "$1" --interface "$TRY_IF")

            [ -z "$_tca" ] || { curl -s $_tca --interface "$TRY_IF" --connect-timeout 4 --max-time "${2:-10}" "$1" </dev/null > "$_tcf.out" 2>/dev/null; _trc=$?; }
        fi
        printf '=%s\t1\t%s\n' "$_tn" "$_trc"
        [ "$_trc" = 0 ] && try_stop "$3" "$_tcf.out" && break
    done 3< "$4"
    return 0
}


cmd_up() {




    if command -v clock_boot_sync >/dev/null 2>&1 && clock_boot_sync; then log "$CLOCK_MSG"; fi
    if ! ensure_carrier; then
        log "awg0 не поднялся — несущую не активирую"
        replay_fw3 rules
        return 1
    fi
    exclude_endpoint        # анти-петля: endpoint мимо маркировки ДО постановки default->awg0
    apply_awg_routing
    restore_vpn_dns
    echo awg > "$TRANSPORT_FLAG"
    replay_fw3 repair       # только ПОСЛЕ записи флага: repair поднимает несущую по .transport

    rm -f /tmp/enodia-watchdog.xstate /tmp/enodia-failover-episode 2>/dev/null
    ct_flush
    log "транспорт = AmneziaWG (default table $TABLE -> $IFACE). mark-core сохранён."
    cmd_status
}

cmd_down() {
    remove_awg_routing
    set_public_dns


    rm -f /tmp/enodia-watchdog.xstate /tmp/enodia-failover-episode 2>/dev/null
    ct_flush
    log "AmneziaWG-несущая снята ($IFACE — тёплый резерв, трафик напрямую)."
}












cmd_cold() {
    awg_kill_daemon "$IFACE"



    if ip link show "$IFACE" >/dev/null 2>&1; then ip link del "$IFACE" 2>/dev/null; fi
    log "AmneziaWG-несущая погашена холодно ($IFACE снят вместе с демоном)."
}







cmd_rewarm() {
    case "$(cat "$TRANSPORT_FLAG" 2>/dev/null | tr -d ' \r\n')" in
        ""|awg) log "rewarm: AmneziaWG сейчас несёт трафик — это основной канал, а не резерв"; return 1 ;;
    esac
    cmd_cold
    if ensure_carrier; then
        replay_fw3 repair





        [ -f "$ENODIA_DIR/road.sh" ] && [ -s "$ENODIA_STATE/.cfg-via" ] && sh "$ENODIA_DIR/road.sh" wire >/dev/null 2>&1
        log "тёплый резерв AmneziaWG поднят заново ($IFACE)"; return 0
    fi
    replay_fw3 repair
    log "rewarm: $IFACE не поднялся — резерв пропал до следующей загрузки"
    return 1
}

cmd_health() {
    t=awg; [ -f "$TRANSPORT_FLAG" ] && t=$(cat "$TRANSPORT_FLAG" 2>/dev/null | tr -d ' \r\n')
    [ "$t" = awg ] || return 0          # активен не awg — судить не нам
    carrier_up || { log "health: $IFACE не поднят"; return 1; }
    age=$(hs_age)
    if [ "$age" -ge "$HS_MAX" ]; then
        log "health: handshake устарел (${age}с >= ${HS_MAX}с)"
        return 1
    fi
    return 0
}





cmd_failover() {
    [ -f "$SWITCH" ] || { log "нет $SWITCH"; return 1; }
    sh "$SWITCH" failover
}

cmd_status() {








    t=; [ -f "$TRANSPORT_FLAG" ] && t=$(cat "$TRANSPORT_FLAG" 2>/dev/null | tr -d ' \r\n')
    echo "--- transport-awg status ---"
    echo "активный транспорт (.transport): ${t:-(флаг пуст — транспорт не выбран)}"
    echo "--- default в table $TABLE ---"; ip route show table "$TABLE" 2>/dev/null | grep default || echo "(нет default — прямой режим)"   # raw-print: сырой вывод человеку в `status`, вердикта тут нет
    echo "--- $IFACE ---"; ip link show "$IFACE" >/dev/null 2>&1 && echo "поднят (handshake $(hs_age)с назад)" || echo "нет"
    echo "--- FORWARD $IFACE ---"; iptables -C FORWARD -o "$IFACE" -j ACCEPT 2>/dev/null && echo "ACCEPT есть" || echo "нет"
}



carrier_undo() { cmd_down; cmd_cold; }







cmd_conf_gen() {
    [ $# -gt 0 ] || return 0
    awk '
        FNR == 1 { n++; nm = FILENAME; sub(/^.*\//, "", nm); sub(/\.conf$/, "", nm); N[n] = nm; G[n] = 0 }
        { sub(/\r$/, "") }
        !/=/ { next }
        {
            k = $0; sub(/[ \t]*=.*$/, "", k); sub(/^[ \t]+/, "", k)
            v = $0; sub(/^[^=]*=[ \t]*/, "", v); sub(/[ \t]+$/, "", v)
            if (v == "") next
            r = 0
            if (k == "RandomTrailers" || k == "DisableCookies") r = 31
            else if (k == "HeaderProtectionKey" || k == "ContentPaddingAddition" || k == "RekeyAfterTime" || k == "RejectAfterTime" || k == "KeepaliveTimeout" || k == "MaxHandshakeAttempts") r = 30
            else if (k == "S3" || k == "S4") r = 20
            else if (k ~ /^H[1-4]$/ && v ~ /^[0-9]+[ \t]*-[ \t]*[0-9]+$/) r = 20
            else if (k ~ /^(I[1-5]|J[1-3]|Itime)$/) r = 15
            else if (k ~ /^(Jc|Jmin|Jmax|S1|S2|H[1-4])$/) r = 10
            if (r > G[n]) G[n] = r
        }
        END {
            for (i = 1; i <= n; i++) {
                g = "wg"
                if (G[i] == 31) g = "3.1"; else if (G[i] == 30) g = "3.0"; else if (G[i] == 20) g = "2.0"; else if (G[i] == 15) g = "1.5"; else if (G[i] == 10) g = "1.0"
                printf "%s\t%s\n", N[i], g
            }
        }' "$@" 2>/dev/null
}

case "$1" in


    up)       carrier_run carrier_undo cmd_up ;;
    down)     cmd_down ;;
    cold)     cmd_cold ;;                 # «выключили VPN» — гасим демон, тёплый резерв не нужен


    rewarm)   carrier_run cmd_cold cmd_rewarm ;;
    status)   cmd_status ;;
    health)   cmd_health ;;
    failover) carrier_run carrier_undo cmd_failover ;;


    dns)      if carrier_barred; then set_public_dns; else restore_vpn_dns; fi ;;
    slot-up)   carrier_run cmd_slot_down cmd_slot_up "$2" "$3" ;;   # доп-выход (Ф2): поднять awgN в table 100N
    slot-down) cmd_slot_down "$2" ;;      # доп-выход: снять awgN (-> fallback-политика mark-core)
    slot-probe) carrier_run cmd_slot_down cmd_slot_probe "$2" "$3" ;;   # снятый выход: проба сервера без перепроводки, жив — вернуть




    slot-iface) slot_iface "$2" ;;
    slot-age)   awg_daemon_age "$(slot_iface "$2")"; exit $? ;;   # how old the exit's daemon is, s (nothing — no daemon)
    conf-gen)   shift; cmd_conf_gen "$@" ;;   # поколение протокола конфигов (разбор у cmd_conf_gen)

    try)        cmd_try "$2" "$3" "$4"; exit $? ;;
    try-each)   cmd_try_each "$2" "$3" "$4" "$5"; exit $? ;;
    *) echo "usage: $0 up|down|cold|rewarm|status|health|failover|dns|slot-up <id> <cfg>|slot-down <id>|slot-probe <id> <cfg>|slot-iface <id>|slot-age <id>|conf-gen <файл>…|try <конфиг> <URL> [с]|try-each <URL> <с> <stop-ERE> <список>"; exit 2 ;;
esac
