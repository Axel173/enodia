#!/bin/sh



























































dom_ok() {

    case "$1" in ''|.*|*.|*..*|*[!A-Za-z0-9._-]*) return 1 ;; esac
    [ "${#1}" -le 253 ] || return 1
    _do_rest="$1"
    while : ; do
        case "$_do_rest" in
            *.*) _do_lab=${_do_rest%%.*}; _do_rest=${_do_rest#*.} ;;
            *)   _do_lab=$_do_rest;       _do_rest='' ;;
        esac
        [ "${#_do_lab}" -le 63 ] || return 1     # длина ≥1 гарантирована отсевом пустых меток выше
        [ -n "$_do_rest" ] || return 0
    done
}





















if ! command -v uptime_s >/dev/null 2>&1 && [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v uptime_s >/dev/null 2>&1 || uptime_s() { _cl_u=$(awk '{print int($1)}' /proc/uptime 2>/dev/null); case "$_cl_u" in ''|*[!0-9]*) _cl_u=999999999 ;; esac; echo "$_cl_u"; }
_dns_time_left() {
    _dt_max=$1
    if [ -n "${DNS_SEED_DEADLINE:-}" ]; then
        _dt_now=$(uptime_s)
        [ "$_dt_now" -ne 999999999 ] || return 1
        _dt_left=$((DNS_SEED_DEADLINE - _dt_now))
        [ "$_dt_left" -gt 0 ] || return 1
        [ "$_dt_left" -ge "$_dt_max" ] || _dt_max=$_dt_left
    fi
    printf '%s\n' "$_dt_max"
}
_dns_seed_curl() {
    _dsc_max=$1; shift
    if [ -n "${DNS_SEED_DEADLINE:-}" ]; then
        _dsc_max=$(_dns_time_left "$_dsc_max") || return 28
        set -- "$@" --max-time "$_dsc_max"
    fi
    curl "$@"
}
resolve_ipv4() {
    _h="$1"









    _rip_wait=$(_dns_time_left "${RESOLVE_NS_TIMEOUT:-2}") || return 1
    _ip=$(timeout -t "$_rip_wait" nslookup "$_h" 2>/dev/null | awk '/^Name:/{f=1;next} f&&/Address/{x=$NF; if(x ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/){print x; exit}}')
    [ -n "$_ip" ] && { echo "$_ip"; return 0; }

    _ip=$(doh_ips "$_h" "" | head -1)
    [ -n "$_ip" ] && { echo "$_ip"; return 0; }
    return 1
}
















ns_ips() {
    if [ -n "${2:-}" ]; then timeout -t "$2" nslookup "$1" 2>/dev/null
    else nslookup "$1" 2>/dev/null; fi | awk '/^Name:/{f=1}
        f{for(i=1;i<=NF;i++) if ($i ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/) print $i}'
}























doh_ips() {
    _dq_h="$1"; _dq_a="$2"
    _dq_w=$(_dnslib_wan)
    if [ -n "$_dq_w" ]; then
        _dq_r=$(_dnslib_doh_all "$_dq_h" "$_dq_a --interface $_dq_w"); _dq_c=$?
        if [ -n "$_dq_r" ]; then echo "$_dq_r"; return 0; fi
        if [ "$_dq_c" = 2 ]; then return 1; fi
    fi
    _dq_r=$(_dnslib_doh_all "$_dq_h" "$_dq_a")
    if [ -n "$_dq_r" ]; then echo "$_dq_r"; return 0; fi
    return 1
}








command -v wan_iface >/dev/null 2>&1 || wan_iface() { ip route show default 2>/dev/null | awk '/^default/{d=""; for(i=1;i<=NF;i++) if($i=="dev") d=$(i+1); if(d!="" && d !~ /^(awg|xtun)/){print d; exit}}'; }
_dnslib_wan() { wan_iface; }




















CURL_CA_CAP="${CURL_CA_CAP:-/tmp/.enodia-curl-cafile}"
CURL_CA_CANDIDATES="${CURL_CA_CANDIDATES:-/etc/ssl/certs/ca-certificates.crt /etc/ssl/cert.pem /usr/share/ca-certificates/ca-certificates.crt}"
curl_ca_opt() {   # $1 = URL пробы; $2… = доп-аргументы curl (напр. --resolve); без URL — только известный ответ
    if [ -f "$CURL_CA_CAP" ]; then
        [ -s "$CURL_CA_CAP" ] && printf -- '--cacert %s' "$(cat "$CURL_CA_CAP" 2>/dev/null)"
        return 0
    fi
    [ -n "$1" ] || return 0
    _ccu="$1"; shift
    _cc60=0






    for _cca in $CURL_CA_CANDIDATES; do
        [ -s "$_cca" ] || continue
        _ccc=$(_dns_seed_curl 10 -s -o /dev/null -w '%{http_code}' --cacert "$_cca" --connect-timeout 5 --max-time 10 "$@" "$_ccu" 2>/dev/null)
        _ccr=$?
        case "$_ccc" in



            ''|000) if [ "$_ccr" = 60 ]; then _cc60=1; else break; fi ;;
            *) printf '%s' "$_cca" > "$CURL_CA_CAP" 2>/dev/null
               printf -- '--cacert %s' "$_cca"; return 0 ;;
        esac
    done
    [ "$_cc60" = 1 ] && : > "$CURL_CA_CAP" 2>/dev/null   # это ОТВЕТ «бандлы не помогают» — помним до ребута
    return 0
}











_dnslib_doh_all() {
    _dda_ans=0
    for _dq in 'https://1.1.1.1/dns-query' 'https://8.8.8.8/resolve'; do




        _dda_b=$(_dns_seed_curl 8 -s --connect-timeout 3 --max-time 8 $2 "$_dq?name=$1&type=A" -H 'accept: application/dns-json' 2>/dev/null || true)











        case "$_dda_b" in
            *'"Status"'*) ;;
            *) _dda_ca=$(curl_ca_opt "$_dq?name=$1&type=A")
               if [ -n "$_dda_ca" ]; then
                   _dda_b=$(_dns_seed_curl 8 -s $_dda_ca --connect-timeout 3 --max-time 8 $2 "$_dq?name=$1&type=A" -H 'accept: application/dns-json' 2>/dev/null || true)
               fi
               case "$_dda_b" in
                   *'"Status"'*) ;;
                   *) _dda_b=$(_dns_seed_curl 8 -sk --connect-timeout 3 --max-time 8 $2 "$_dq?name=$1&type=A" -H 'accept: application/dns-json' 2>/dev/null || true) ;;
               esac ;;
        esac
        case "$_dda_b" in *'"Status"'*) _dda_ans=1 ;; esac
        _di=$(printf '%s' "$_dda_b" | grep -o '"data":"[0-9.]*"' | cut -d'"' -f4)
        case "$_di" in *.*.*.*) echo "$_di"; return 0 ;; esac
    done
    if [ "$_dda_ans" = 1 ]; then return 2; fi
    return 1
}


is_ipv4() { echo "$1" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$'; }


seed_pin_names() {   # own legacy seed and the current IPv4 rows of its publication
    _spn_ips=" $(printf '%s' "$2" | tr '\n' ' ') "
    awk -F/ -v ips="$_spn_ips" '$1=="address=" && index(ips," " $3 " ") {print $2}' "$1" 2>/dev/null
    awk -v ips="$_spn_ips" -v tag="${1##*/}" '$3=="#" && $4=="awg-seed" && $5==tag && index(ips," " $1 " ") {print $2}' "$SEED_HOSTS" 2>/dev/null
}
seed_ipv4_rows() {   # host [seed file] [shared]
    if is_ipv4 "$1"; then [ "${3:-}" = pins ] || printf '%s\n' "$1"; return 0; fi
    if [ -n "${2:-}" ]; then
        awk -F/ -v h="$1" '$1=="address=" && ($2 "")==(h "") && $3 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ {print $3}' "$2" 2>/dev/null
    fi


    if [ -n "${3:-}" ]; then
        awk -v h="$1" '
            BEGIN { h=tolower(h); sub(/\.$/, "", h) }
            $1 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ && $3=="#" && $4=="awg-seed" &&
            $5 ~ /^02-altserver(-s[2-7])?\.conf$/ {
                name=tolower($2); sub(/\.$/, "", name); if (name==h) print $1
            }' "$SEED_HOSTS" 2>/dev/null
    fi
}

hy2_conf_host() {
    _hch=$(grep -E '^[[:space:]]*server:' "$1" 2>/dev/null | head -1 | sed 's/^[[:space:]]*server:[[:space:]]*//; s/[[:space:]]*$//; s/^["'\'']//; s/["'\'']$//')
    printf '%s\n' "${_hch%:*}"
}












conf_dns() {
    grep -iE '^[[:space:]]*DNS[[:space:]]*=' "$1" 2>/dev/null | sed 's/^[^=]*=//' | tr -d ' \t\r' | tr ',' '\n' \
        | grep -E '^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])$' | head -n 1
}






















if [ -f "$ENODIA_DIR/label-lib.sh" ]; then . "$ENODIA_DIR/label-lib.sh"; fi   # lbl_commit_out: a file replaced whole or not at all
command -v lbl_commit_out_as >/dev/null 2>&1 || { lbl_commit_out_as() { _lct=$1; _lcf=$2; shift 2; "$@" > "$_lct" && mv -f "$_lct" "$_lcf" && return 0; rm -f "$_lct"; return 1; }; lbl_commit_out() { _lcf=$1; shift; lbl_commit_out_as "$_lcf.$$.new" "$_lcf" "$@"; }; lbl_grep() { grep "$@" || [ "$?" -le 1 ]; }; lbl_without() { if [ -f "$1" ]; then lbl_grep -v -- "$2" "$1" || return 1; fi; [ -z "${3:-}" ] || printf '%s\n' "$3"; }; }   # write-blind: the shim of a missing library is the old line
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
SEED_CACHE="${SEED_CACHE:-$ENODIA_STATE/.dns-seed-cache}"
if [ ! -f "$SEED_CACHE" ] && [ -f "${ENODIA_DIR:-/data/usr/app/enodia}/.dns-seed-cache" ] && [ -d "$ENODIA_STATE" ]; then   # migrate: см. mv ниже
    mv "${ENODIA_DIR:-/data/usr/app/enodia}/.dns-seed-cache" "$SEED_CACHE" 2>/dev/null || true   # migrate: код → состояние, один раз
fi
SEED_TRIES=${SEED_TRIES:-6}                  # ожиданий сети, когда прошлого адреса НЕТ (прежнее поведение)
SEED_TRIES_CACHED=${SEED_TRIES_CACHED:-2}    # ...и когда ЕСТЬ: дальше поднимаемся на нём



seed_cache_get() {
    [ -f "$SEED_CACHE" ] || return 1
    awk -v h="$1" '$1==h{print $2; exit}' "$SEED_CACHE" 2>/dev/null
}


_seed_cache_text() {   # the cache's new text: the other hosts' lines, then this host's
    if [ -f "$SEED_CACHE" ]; then awk -v h="$1" '$1!=h' "$SEED_CACHE" || return 1; fi
    printf '%s\t%s\t%s\n' "$1" "$2" "$(date +%s)"   # clock-raw: отметка для дампа, возраст по ней не считаем
}
seed_cache_put() {
    _scp_h="$1"; _scp_i="$2"
    [ -n "$_scp_h" ] && [ -n "$_scp_i" ] || return 0
    lbl_commit_out "$SEED_CACHE" _seed_cache_text "$_scp_h" "$_scp_i" 2>/dev/null
    return 0
}





















_seed_live() { case "$1" in /etc/dnsmasq.d/*) echo "/tmp/dnsmasq.d/${1##*/}" ;; esac; }















SEED_HOSTS="${SEED_HOSTS:-/etc/hosts}"
_seed_tag() { echo "# awg-seed ${1##*/}"; }




seed_hosts_put() {
    _shp_h="$1"; _shp_i="$2"
    { [ -n "$_shp_h" ] && [ -n "$(printf '%s' "$_shp_i" | tr -d ' ')" ]; } || return 0
    _shp_t=$(_seed_tag "$3")
    _shp_w=$(for _shp_a in $_shp_i; do printf '%s\t%s\t%s\n' "$_shp_a" "$_shp_h" "$_shp_t"; done)
    [ -f "$SEED_HOSTS" ] || : > "$SEED_HOSTS" 2>/dev/null

    [ "$(grep -F "$_shp_t" "$SEED_HOSTS" 2>/dev/null)" = "$_shp_w" ] && return 0

    lbl_commit_out_as "$SEED_HOSTS.enodiatmp" "$SEED_HOSTS" _seed_hosts_text "$_shp_t" "$_shp_w" 2>/dev/null
    return 0
}
_seed_hosts_text() {   # /etc/hosts без строк с меткой $1, затем свои строки $2 (lbl_grep: «ничего не осталось» — не отказ)
    lbl_grep -vF "$1" "$SEED_HOSTS" || return 1
    printf '%s\n' "$2"
}


seed_hosts_clear() {
    _shc_t=$(_seed_tag "$1")
    grep -qF "$_shc_t" "$SEED_HOSTS" 2>/dev/null || return 1




    lbl_commit_out_as "$SEED_HOSTS.enodiatmp" "$SEED_HOSTS" lbl_grep -vF "$_shc_t" "$SEED_HOSTS" 2>/dev/null
    return 0
}






DNS_RELOAD_MARK=${DNS_RELOAD_MARK:-/tmp/enodia-dns-reload}
seed_host_clear() {
    _sc_f="$1"; [ -n "$_sc_f" ] || return 1
    _sc_l=$(_seed_live "$_sc_f"); _sc_hit=1
    [ -f "$_sc_f" ] && _sc_hit=0
    [ -n "$_sc_l" ] && [ -f "$_sc_l" ] && _sc_hit=0
    rm -f "$_sc_f" 2>/dev/null
    [ -n "$_sc_l" ] && rm -f "$_sc_l" 2>/dev/null
    if seed_hosts_clear "$_sc_f"; then _sc_hit=0; fi    # третья копия (форма `if` — она безразлична к позиции под set -e)
    if [ "$_sc_hit" = 0 ]; then : > "$DNS_RELOAD_MARK" 2>/dev/null; fi
    return $_sc_hit
}

seed_dns_reload() {   # optional command prefix, e.g. timeout -t 5
    if "$@" /etc/init.d/dnsmasq restart >/dev/null 2>&1; then
        rm -f "$DNS_RELOAD_MARK" 2>/dev/null
    else
        killall -HUP dnsmasq 2>/dev/null
    fi
    return 0
}
seed_dns_reload_pending() {
    [ ! -e "$DNS_RELOAD_MARK" ] || seed_dns_reload
}
seed_host_retire() {   # seed file; "defer" leaves dnsmasq reload to the next DNS owner
    if seed_host_clear "$1" && [ "${2:-}" != defer ]; then
        seed_dns_reload
    fi
    return 0
}

seed_host_dns() {   # $1 = host ; $2 = seed-файл ; $3 = pre-resolved IPv4 (optional)
    _sh_host="$1"; _sh_file="$2"
    [ -n "$_sh_host" ] && [ -n "$_sh_file" ] || return 1
    if is_ipv4 "$_sh_host"; then
        seed_host_clear "$_sh_file"; return 0          # server уже IP — сеять нечего, чистим прошлый сид (обе копии)
    fi



    _sh_ip=${3:-}
    [ -n "$_sh_ip" ] || seed_resolve_host "$_sh_host" || return 1


    seed_hosts_put "$_sh_host" "$_sh_ip" "$_sh_file"










    _sh_want="address=/$_sh_host/$_sh_ip"
    _sh_live=$(_seed_live "$_sh_file")
    if [ "$(cat "$_sh_file" 2>/dev/null)" = "$_sh_want" ] \
       && { [ -z "$_sh_live" ] || [ "$(cat "$_sh_live" 2>/dev/null)" = "$_sh_want" ]; } \
       && timeout -t "${RESOLVE_NS_TIMEOUT:-2}" nslookup "$_sh_host" 2>/dev/null | awk '/^Name:/{f=1;next} f&&/Address/{print $NF}' | grep -qx "$_sh_ip"; then
        _dnslib_log "локальный DNS: $_sh_host → $_sh_ip (сид уже стоит — dnsmasq не трогаю)"
        return 0
    fi
    mkdir -p /etc/dnsmasq.d
    printf '%s\n' "$_sh_want" > "$_sh_file"
    if [ -n "$_sh_live" ]; then mkdir -p /tmp/dnsmasq.d 2>/dev/null; printf '%s\n' "$_sh_want" > "$_sh_live"; fi
    seed_dns_reload
    _sh_k=0                                            # дождаться, что dnsmasq реально отдаёт сид (до старта демона)
    while [ "$_sh_k" -lt 6 ]; do
        timeout -t "${RESOLVE_NS_TIMEOUT:-2}" nslookup "$_sh_host" 127.0.0.1 2>/dev/null | awk '/^Name:/{f=1;next} f&&/Address/{print $NF}' | grep -qx "$_sh_ip" && break
        _sh_k=$((_sh_k+1)); sleep 1
    done
    _dnslib_log "локальный DNS: $_sh_host → $_sh_ip (демон резолвит имя сам; конфиг по имени не трогаем)"
    return 0
}












dns_bulk_snippet() { case "${1##*/}" in 06-adblock.conf|07-zapret-dom.conf|1[0-9]-geo*.conf) return 0 ;; esac; return 1; }

_dcf_keep() {   # $1 file, $2 the conf-dir argument after the directory
	_dck_in=0; _dck_hit=0; _dck_r="$2,"
	while [ -n "$_dck_r" ]; do
		_dck_e=${_dck_r%%,*}; _dck_r=${_dck_r#*,}
		case "$_dck_e" in
			'') ;;
			\**) _dck_in=1; case "$1" in *"${_dck_e#\*}") _dck_hit=1 ;; esac ;;
			*) case "$1" in *"$_dck_e") return 1 ;; esac ;;
		esac
	done
	[ "$_dck_in" = 0 ] || [ "$_dck_hit" = 1 ]
}
dnsmasq_conf_files() {
	_dcf_m=''
	for _dcf_p in $(pidof dnsmasq 2>/dev/null); do
		_dcf_m="$_dcf_m $(tr '\0' '\n' 2>/dev/null < "/proc/$_dcf_p/cmdline" | awk 'c { print; c = 0; next } $0 == "-C" || $0 == "--conf-file" { c = 1; next } /^--conf-file=/ { sub(/^--conf-file=/, ""); print; next } /^-C./ { print substr($0, 3) }')"
	done
	for _dcf_f in /var/etc/dnsmasq.conf*; do _dcf_m="$_dcf_m $_dcf_f"; done
	_dcf_m="$_dcf_m /etc/dnsmasq.conf"

	_dcf_m="$_dcf_m $(cat $_dcf_m 2>/dev/null | sed -n 's/^[[:space:]]*conf-file=//p')"
	_dcf_ds=$(cat $_dcf_m 2>/dev/null | sed -n 's/^[[:space:]]*conf-dir=//p')
	[ -n "$_dcf_ds" ] || _dcf_ds=$(printf '%s\n' /etc/dnsmasq.d /tmp/dnsmasq.d)
	{
		for _dcf_f in $_dcf_m; do echo "$_dcf_f"; done
		printf '%s\n' "$_dcf_ds" | while IFS= read -r _dcf_d; do
			_dcf_r=''
			case "$_dcf_d" in *,*) _dcf_r=${_dcf_d#*,}; _dcf_d=${_dcf_d%%,*} ;; esac
			for _dcf_f in "$_dcf_d"/*; do
				case "$_dcf_f" in *~) continue ;; esac
				_dcf_keep "$_dcf_f" "$_dcf_r" && echo "$_dcf_f"
			done
		done
	} | while IFS= read -r _dcf_f; do [ -f "$_dcf_f" ] && echo "$_dcf_f"; done | awk '!seen[$0]++'
}




_dnslib_log() { if command -v log >/dev/null 2>&1; then log "$@"; else echo "[dns-lib] $*"; fi; }


seed_resolve_host() {
    _sh_host=$1
    _sh_ip=""; _sh_n=0; _sh_from_cache=0
    _sh_cached=$(seed_cache_get "$_sh_host")
    while [ "$_sh_n" -lt "$SEED_TRIES" ]; do
        _sh_ip=$(resolve_ipv4 "$_sh_host"); [ -n "$_sh_ip" ] && break
        _sh_n=$((_sh_n+1))
        if [ -n "$_sh_cached" ] && [ "$_sh_n" -ge "$SEED_TRIES_CACHED" ]; then
            _sh_ip="$_sh_cached"; _sh_from_cache=1
            _dnslib_log "резолв '$_sh_host' не удался ($_sh_n) → поднимаюсь на ПРОШЛОМ рабочем адресе $_sh_ip (кэш)"
            break
        fi
        _dnslib_log "резолв server-host '$_sh_host' попытка $_sh_n не удалась — повтор через 2с…"; sleep 2
    done
    [ -n "$_sh_ip" ] || { _dnslib_log "НЕ зарезолвил server-host '$_sh_host' за $SEED_TRIES попыток → несущая не встанет (честно)"; return 1; }
    is_ipv4 "$_sh_ip" || { _dnslib_log "резолв вернул не-IP '$_sh_ip' — не сею"; return 1; }


    if [ "$_sh_from_cache" = 0 ] && [ "$_sh_ip" != "$_sh_cached" ]; then seed_cache_put "$_sh_host" "$_sh_ip"; fi
}





seed_hosts_dns() (
    _shs_hosts=$1; _shs_file=$2; _shs_uncached=''; _shs_cached=''



    DNS_SEED_DEADLINE=${DNS_SEED_DEADLINE:-$(($(uptime_s) + 12))}
    _shs_rows=${3:-}
    if [ -z "$_shs_rows" ]; then _shs_rows=$(
        for _shs_host in $_shs_hosts; do
            if is_ipv4 "$_shs_host"; then printf '%s\n' literal; continue; fi
            case "$_shs_host" in *:*) printf '%s\n' literal; continue ;; esac
            dom_ok "$_shs_host" || continue
            _shs_ip=$(seed_cache_get "$_shs_host")
            if is_ipv4 "$_shs_ip"; then
                printf '%s %s\n' "$_shs_host" "$_shs_ip"
                _shs_cached="$_shs_cached $_shs_host"
            else
                _shs_uncached="$_shs_uncached $_shs_host"
            fi
        done
        for _shs_host in $_shs_uncached $_shs_cached; do
            _dns_time_left 1 >/dev/null || break
            _shs_ip=$(resolve_ipv4 "$_shs_host")
            is_ipv4 "$_shs_ip" || continue
            seed_cache_put "$_shs_host" "$_shs_ip"
            printf '%s %s\n' "$_shs_host" "$_shs_ip"
        done
    ); fi
    [ -n "$_shs_rows" ] || return 1
    [ -n "$_shs_file" ] || { printf '%s\n' "$_shs_rows"; return 0; }
    _shs_tag=$(_seed_tag "$_shs_file")
    _shs_rows=$(printf '%s\n' "$_shs_rows" | awk 'NF==2 {ip[$1]=$2} END {for(h in ip) print h,ip[h]}' | sort)
    _shs_conf=$(printf '%s\n' "$_shs_rows" | awk 'NF==2 {printf "address=/%s/%s\n",$1,$2}')
    _shs_lines=$(printf '%s\n' "$_shs_rows" | awk -v tag="$_shs_tag" 'NF==2 {printf "%s\t%s\t%s\n",$2,$1,tag}')
    [ -n "$_shs_conf" ] || { seed_host_clear "$_shs_file"; return 0; }
    _shs_live=$(_seed_live "$_shs_file")
    mkdir -p "${_shs_file%/*}" || return 1
    if [ -n "$_shs_live" ]; then mkdir -p "${_shs_live%/*}" || return 1; fi
    [ -f "$SEED_HOSTS" ] || : > "$SEED_HOSTS" || return 1
    _shs_changed=0
    [ "$(grep -F "$_shs_tag" "$SEED_HOSTS" 2>/dev/null)" = "$_shs_lines" ] || {
        lbl_commit_out_as "$SEED_HOSTS.enodiatmp" "$SEED_HOSTS" _seed_hosts_text "$_shs_tag" "$_shs_lines" || return 1
        _shs_changed=1
    }
    if [ "$(cat "$_shs_file" 2>/dev/null)" != "$_shs_conf" ]; then
        lbl_commit_out "$_shs_file" printf '%s\n' "$_shs_conf" || return 1
        _shs_changed=1
    fi
    if [ -n "$_shs_live" ] && [ "$(cat "$_shs_live" 2>/dev/null)" != "$_shs_conf" ]; then
        lbl_commit_out "$_shs_live" printf '%s\n' "$_shs_conf" || return 1
        _shs_changed=1
    fi


    if [ "$_shs_changed" = 0 ]; then
        for _shs_row in $_shs_conf; do
            _shs_wait=$(_dns_time_left "${RESOLVE_NS_TIMEOUT:-2}") || break
            _shs_check_host=${_shs_row#address=/}; _shs_check_host=${_shs_check_host%/*}
            _shs_check_ip=${_shs_row##*/}
            if ! ns_ips "$_shs_check_host" "$_shs_wait" | grep -qxF "$_shs_check_ip"; then _shs_changed=1; break; fi
        done
    fi
    if [ "$_shs_changed" = 1 ]; then
        seed_dns_reload timeout -t 5
    fi
    return 0
)
