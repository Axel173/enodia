#!/bin/sh






















LBL_TAB=$(printf '\t')
LBL_CFG_KEY_RE='^(awg|xray|hy2)/[A-Za-z0-9_.-]+$'
lbl_cfg_key() {
    case "$1" in *"$LBL_NL"*) return 1 ;; esac
    printf '%s' "$1" | grep -qE "$LBL_CFG_KEY_RE"
}
lbl_endpoint_key() { sed -n 's/^key=//p' "$@" 2>/dev/null; }
lbl_endpoint_hosts() { sed -n 's/^host=//p' "$@" 2>/dev/null; }
lbl_endpoint_ips() { sed '/^key=/d; /^host=/d' "$@" 2>/dev/null; }
LBL_NL='
'

XT_ROAD_LOCK=/tmp/enodia-xray-test.road
TRY_LOCK=/tmp/enodia-awg-try.lock
TRY_LOCK_HOLDERS='transport-awg\.sh|road\.sh'
lbl_lock_live() {   # A missing PID can be a holder still publishing it.
    _lp=$(cat "$1/pid" 2>/dev/null | tr -cd '0-9')
    [ -n "$_lp" ] || { sleep 1; _lp=$(cat "$1/pid" 2>/dev/null | tr -cd '0-9'); }
    pid_runs "$_lp" "$2"
}
lbl_rule_sweep() {
    _lrs_n=$(ip rule show 2>/dev/null | grep -c "^$1:")
    while [ "$_lrs_n" -gt 0 ] && ip rule del pref "$@" 2>/dev/null; do _lrs_n=$((_lrs_n - 1)); done
}




lbl_lock_take() {
    _lbli=0
    while ! mkdir "$1" 2>/dev/null; do
        _lbli=$((_lbli+1)); [ "$_lbli" -gt 5 ] && return 1
        _lblp=$(cat "$1/pid" 2>/dev/null | tr -d ' \r\n')
        if [ -n "$_lblp" ]; then
            pid_runs "$_lblp" "$2" || { rm -rf "$1" 2>/dev/null; continue; }
        elif [ "$_lbli" -ge 3 ]; then
            rm -rf "$1" 2>/dev/null; continue
        fi
        sleep 1
    done
    echo $$ > "$1/pid" 2>/dev/null
    return 0
}
lbl_lock_drop() { rm -rf "$1" 2>/dev/null; }



lbl_san() { printf '%s' "$1" | tr '\t\r\n' '   ' | tr -d '\000-\037"\\' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//; s/[[:space:]][[:space:]]*/ /g'; }




lbl_list() {
    [ -f "$1" ] || return 0
    tr -d '\000-\010\013-\037"\\' < "$1" 2>/dev/null | awk -F"$LBL_TAB" -v kre="$2" -v low="${3:-}" '
    {
        m = $1; if (low != "") m = tolower(m); gsub(/ /, "", m)
        if (m !~ kre) next
        if (m in seen) next
        n = $2; for (i = 3; i <= NF; i++) n = n " " $i
        gsub(/  +/, " ", n); sub(/^ /, "", n); sub(/ $/, "", n)
        if (n == "") next
        seen[m] = 1; print m "\t" n
    }'
}



lbl_write() {
    _lblw=$(lbl_list "$1" "$4" "$5" | awk -F"$LBL_TAB" -v m="$2" '$1!=m')
    [ -n "$3" ] && _lblw="${_lblw:+$_lblw$LBL_NL}$2$LBL_TAB$3"
    lbl_commit "$1" "$_lblw"
}


lbl_merge() {
    _lblw=$( { lbl_list "$2" "$3" "$4"; lbl_list "$1" "$3" "$4"; } | awk -F"$LBL_TAB" '!($1 in s) { s[$1] = 1; print }')
    lbl_commit "$1" "$_lblw"
}





lbl_import() {   # store, archive file (may be absent), brought keys, key regex
    _lbia=""
    if [ -f "$2" ]; then
        while IFS= read -r _lbir || [ -n "$_lbir" ]; do
            [ -n "$_lbir" ] || continue
            case "$LBL_NL$3$LBL_NL" in *"$LBL_NL${_lbir%%"$LBL_TAB"*}$LBL_NL"*) _lbia="${_lbia:+$_lbia$LBL_NL}$_lbir" ;; esac
        done <<EOF
$(lbl_list "$2" "$4")
EOF
    fi
    _lbik=""
    while IFS= read -r _lbir || [ -n "$_lbir" ]; do
        [ -n "$_lbir" ] || continue
        case "$LBL_NL$3$LBL_NL" in *"$LBL_NL${_lbir%%"$LBL_TAB"*}$LBL_NL"*) continue ;; esac
        _lbik="${_lbik:+$_lbik$LBL_NL}$_lbir"
    done <<EOF
$(lbl_list "$1" "$4")
EOF
    lbl_commit "$1" "$(printf '%s\n%s\n' "$_lbia" "$_lbik" | awk -F"$LBL_TAB" 'NF >= 2 && !($1 in s) { s[$1] = 1; print }')"
}



lbl_commit() {
    if [ -z "$2" ]; then rm -f "$1"; return $?; fi
    _lblt="$1.$$"
    if printf '%s\n' "$2" > "$_lblt" 2>/dev/null && [ "$(cat "$_lblt" 2>/dev/null)" = "$2" ]; then
        mv "$_lblt" "$1" && return 0
    fi
    rm -f "$_lblt"; return 1
}
















lbl_commit_out() { _lcf=$1; shift; lbl_commit_out_as "$_lcf.$$.new" "$_lcf" "$@"; }


lbl_commit_out_as() {
    _lct=$1; _lcf=$2; shift 2
    _lcr=$( { { "$@" 3>&-; echo "p$?" >&3; } | { { cat > "$_lct"; } 2>/dev/null; _lcs=$?; [ "$_lcs" = 0 ] || cat > /dev/null; echo "s$_lcs" >&3; }; } 3>&1 )
    case "$_lcr" in
        "p0${LBL_NL}s0"|"s0${LBL_NL}p0") mv -f "$_lct" "$_lcf" 2>/dev/null && return 0 ;;
    esac
    rm -f "$_lct" 2>/dev/null; return 1
}



lbl_grep() { grep "$@" || [ "$?" -le 1 ]; }



lbl_without() { if [ -f "$1" ]; then lbl_grep -v -- "$2" "$1" || return 1; fi; [ -z "${3:-}" ] || printf '%s\n' "$3"; }
