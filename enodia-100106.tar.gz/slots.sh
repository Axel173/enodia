#!/bin/sh


















































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
ENODIA_BIN=${ENODIA_BIN:-/data/usr/app/enodia-bin}




if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi
command -v ct_flush >/dev/null 2>&1 || ct_flush()      { conntrack -F >/dev/null 2>&1 || true; }
command -v ct_flush_slot >/dev/null 2>&1 || ct_flush_slot()   { ct_flush; }   # no scoped flush in an old ct-lib — the global one, as before
SLOTS_FILE="$ENODIA_STATE/.slots"
MIN_ID=2
MAX_ID=7
TAB=$(printf '\t')





if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
command -v bin_path >/dev/null 2>&1 || bin_path() { printf '%s' "$ENODIA_BIN/$1"; }



if [ -f "$ENODIA_DIR/slot-tun-lib.sh" ]; then . "$ENODIA_DIR/slot-tun-lib.sh"; fi

if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v slot_socks_port >/dev/null 2>&1 || slot_socks_port() { echo $((10830 + $1)); }
if [ -f "$ENODIA_DIR/label-lib.sh" ]; then . "$ENODIA_DIR/label-lib.sh"; fi   # lbl_commit_out: a file replaced whole or not at all
command -v lbl_commit_out_as >/dev/null 2>&1 || { lbl_commit_out_as() { _lct=$1; _lcf=$2; shift 2; "$@" > "$_lct" && mv -f "$_lct" "$_lcf" && return 0; rm -f "$_lct"; return 1; }; lbl_commit_out() { _lcf=$1; shift; lbl_commit_out_as "$_lcf.$$.new" "$_lcf" "$@"; }; lbl_grep() { grep "$@" || [ "$?" -le 1 ]; }; lbl_without() { if [ -f "$1" ]; then lbl_grep -v -- "$2" "$1" || return 1; fi; [ -z "${3:-}" ] || printf '%s\n' "$3"; }; }   # write-blind: the shim of a missing library is the old line

b64e() { printf '%s' "$1" | base64 | tr -d '\n'; }
b64d() { printf '%s' "$1" | base64 -d 2>/dev/null; }

valid_id() { case "$1" in [0-9]) [ "$1" -ge "$MIN_ID" ] && [ "$1" -le "$MAX_ID" ] ;; *) return 1 ;; esac; }







valid_transport() {
    _known=""
    [ -f "$ENODIA_DIR/transport.sh" ] && _known=$(sh "$ENODIA_DIR/transport.sh" names 2>/dev/null)
    case "$_known" in ''|*usage*) _known="awg xray hy2 byedpi zapret" ;; esac
    for _kt in $_known; do [ "$1" = "$_kt" ] && return 0; done
    return 1
}

slot_line() { grep "^$1$TAB" "$SLOTS_FILE" 2>/dev/null | head -n1; }

slot_rule() { ip rule show 2>/dev/null | grep "fwmark 0x$1 " | head -n1; }







SLOTS_LOCK=/tmp/.enodia-slots.lock
slots_lock_take() {   # $1 = сколько секунд ждать (деф. 10)
    _lw="${1:-10}"; _li=0
    while ! mkdir "$SLOTS_LOCK" 2>/dev/null; do
        _lp=$(cat "$SLOTS_LOCK/pid" 2>/dev/null | tr -d ' \r\n')
        if [ -z "$_lp" ] || ! kill -0 "$_lp" 2>/dev/null; then
            rm -rf "$SLOTS_LOCK" 2>/dev/null; continue        # держатель умер — лок протух
        fi
        _li=$((_li+1)); [ "$_li" -ge "$_lw" ] && return 1
        sleep 1
    done
    echo $$ > "$SLOTS_LOCK/pid" 2>/dev/null
    return 0
}
slots_lock_drop() { rm -rf "$SLOTS_LOCK" 2>/dev/null; }





SLOTS_NOWRITE="[slots] реестр выходов не записался (нет места на разделе настроек?) — изменение не сохранено"
_slots_write() {   # $1 = id ; [$2..$6 = name_b64 transport config fallback en]
    _wln=""; [ "$#" -le 1 ] || _wln="$1$TAB$2$TAB$3$TAB$4$TAB$5$TAB$6"
    lbl_commit_out "$SLOTS_FILE" lbl_without "$SLOTS_FILE" "^$1$TAB" "$_wln" || return 1
    [ -s "$SLOTS_FILE" ] || rm -f "$SLOTS_FILE"
}


cmd_restore_registry() {   # staged registry, previous contents
    [ -f "$1" ] && [ "$#" = 2 ] || return 1
    slots_lock_take || return 1
    _srr_now=""; _srr_rc=1
    if { [ ! -e "$SLOTS_FILE" ] || _srr_now=$(cat "$SLOTS_FILE"); } && [ "$_srr_now" = "$2" ]; then
        lbl_commit_out "$SLOTS_FILE" cat "$1" && _srr_rc=0
    fi
    slots_lock_drop
    return "$_srr_rc"
}






cmd_carriers() { [ -s "$SLOTS_FILE" ] || return 0; cut -f3 "$SLOTS_FILE" 2>/dev/null | grep -v '^$' | sort -u; }




cmd_holders() {
    [ -s "$SLOTS_FILE" ] || return 0
    awk -F"$TAB" -v t="$1" -v n="$2" -v o="${3:-}" \
        '($3 "") == (t "") && ($4 "") == (n "") && (o != "on" || $6 == "on") { printf "%s%s", (c++ ? "," : ""), $1 }' "$SLOTS_FILE" 2>/dev/null | tr -cd '0-9,'
}

cmd_list() {
    [ -s "$SLOTS_FILE" ] || return 0
    while IFS="$TAB" read -r id nb t cfg fb en; do
        [ -n "$id" ] || continue
        printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$id" "$(b64d "$nb")" "$t" "$cfg" "$fb" "$en"
    done < "$SLOTS_FILE"
}




cmd_configs() {
    [ -s "$SLOTS_FILE" ] || return 0
    awk -F"$TAB" -v t="$1" '($3 "") == (t "") && $4 != "" && $4 != "-" { print $4 }' "$SLOTS_FILE" 2>/dev/null
}

cmd_list_enabled() {
    [ -s "$SLOTS_FILE" ] || return 0
    while IFS="$TAB" read -r id nb t cfg fb en; do
        [ "$en" = on ] || continue
        printf '%s\t%s\t%s\t%s\n' "$id" "$t" "$cfg" "$fb"
    done < "$SLOTS_FILE"
}













slot_pool_sets() {   # <id> -> имена ipset, наполняемые dnsmasq для этого выхода
    case "$1" in
        0) _ss="grp_vpn geo_vpn enodia_list"
           [ "$(cat "$ENODIA_STATE/.transport" 2>/dev/null)" = zapret ] && _ss="$_ss zapret_set zapret_dom geo_zapret"
           echo "$_ss" ;;
        *) echo "grp_vpn_s$1 geo_vpn_s$1" ;;
    esac
}
collect_domains() {   # <id> -> дописать домены привязок выхода в $_raw
    _c="$1"

    _gtsv="$ENODIA_STATE/groups/groups.tsv"
    if [ -f "$_gtsv" ]; then
        while IFS="$TAB" read -r _gid _gen _gdir _gslot _gname _gsrc; do
            [ "$_gen" = 1 ] && [ "$_gdir" = vpn ] && [ "${_gslot:-0}" = "$_c" ] || continue
            [ -f "$ENODIA_STATE/groups/$_gid.list" ] && cat "$ENODIA_STATE/groups/$_gid.list" >> "$_raw"
        done < "$_gtsv"
    fi


    _geor="$ENODIA_STATE/geo/actions.tsv"
    if [ -f "$_geor" ]; then
        while IFS="$TAB" read -r _gk _ga _gc _gt _gs; do
            [ "$_ga" = vpn ] && [ "${_gs:-0}" = "$_c" ] || continue
            [ -f "/tmp/enodia-geo/cache/$_gk" ] && cat "/tmp/enodia-geo/cache/$_gk" >> "$_raw"
        done < "$_geor"
    fi




    for _s in $(slot_pool_sets "$_c"); do
        awk -F/ -v s="$_s" '/^ipset=/ && NF==3 && ("," $3 ",") ~ ("," s ",") {print $2}' \
            /tmp/dnsmasq.d/*.conf 2>/dev/null >> "$_raw"
    done
}
cmd_domains() {
    _id="$1"; [ -n "$_id" ] || _id=0
    case "$_id" in
        zapret|0) ;;
        *) valid_id "$_id" || { echo "[slots] domains: битый id '$_id'" >&2; return 1; } ;;
    esac
    _cap="$2"; case "$_cap" in ''|*[!0-9]*) _cap=24 ;; esac
    _raw="/tmp/.enodia-slot-doms.$$"; : > "$_raw"
    if [ "$_id" = zapret ]; then



        [ "$(cat "$ENODIA_STATE/.transport" 2>/dev/null)" = zapret ] && collect_domains 0
        if [ -s "$SLOTS_FILE" ]; then
            while IFS="$TAB" read -r _zi _zn _zt _zc _zf _ze; do
                [ "$_ze" = on ] && [ "$_zt" = zapret ] && collect_domains "$_zi"
            done < "$SLOTS_FILE"
        fi
    else
        collect_domains "$_id"
    fi


    _d2='^[A-Za-z0-9-]+\.[A-Za-z][A-Za-z]+$'
    _dn='^[A-Za-z0-9.-]+\.[A-Za-z][A-Za-z]+$'
    { grep -E "$_d2" "$_raw" 2>/dev/null | sort -u
      grep -E "$_dn" "$_raw" 2>/dev/null | grep -Ev "$_d2" | sort -u
    } > "$_raw.s"






    _acc=""; _n=0
    while read -r _d; do
        [ -n "$_d" ] || continue
        _skip=""
        for _p in $_acc; do case "$_d" in *".$_p") _skip=1; break ;; esac; done
        [ -n "$_skip" ] && continue
        _acc="$_acc $_d"; echo "$_d"
        _n=$((_n+1)); [ "$_n" -ge "$_cap" ] && break
    done < "$_raw.s"
    rm -f "$_raw" "$_raw.s" 2>/dev/null
    return 0
}











slot_route_sets() {   # <id|0|zapret> -> сеты, попадание в которые = «едет через эту цель»
    case "$1" in
        0)  _rs="enodia_list grp_vpn geo_vpn iplist_set"
            [ "$(cat "$ENODIA_STATE/.transport" 2>/dev/null)" = zapret ] && _rs="$_rs zapret_set zapret_cidr zapret_dom geo_zapret"
            echo "$_rs" ;;
        zapret)
            _rs=""
            [ "$(cat "$ENODIA_STATE/.transport" 2>/dev/null)" = zapret ] && _rs="zapret_set zapret_cidr zapret_dom geo_zapret"
            if [ -s "$SLOTS_FILE" ]; then
                while IFS="$TAB" read -r _zi _zn _zt _zc _zf _ze; do
                    [ "$_ze" = on ] && [ "$_zt" = zapret ] && _rs="$_rs grp_vpn_s$_zi geo_vpn_s$_zi"
                done < "$SLOTS_FILE"
            fi
            echo "$_rs" ;;
        *)  echo "grp_vpn_s$1 geo_vpn_s$1" ;;
    esac
}
cmd_route() {   # <id|0|zapret> <домен>
    _rid="$1"; [ -n "$_rid" ] || _rid=0
    case "$_rid" in
        zapret|0) ;;
        *) valid_id "$_rid" || { printf 'badhost\t-\t-\n'; return 1; } ;;
    esac
    _rh="$2"
    printf '%s' "$_rh" | grep -qE '^[A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?$' || { printf 'badhost\t-\t-\n'; return 1; }





    if ! command -v ns_ips >/dev/null 2>&1 && [ -f "$ENODIA_DIR/dns-lib.sh" ]; then . "$ENODIA_DIR/dns-lib.sh"; fi
    if command -v ns_ips >/dev/null 2>&1; then _rips=$(ns_ips "$_rh")
    else _rips=$(nslookup "$_rh" 2>/dev/null | awk '/^Name:/{f=1} f&&/^Address/{for(i=1;i<=NF;i++) if($i ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/) print $i}'); fi
    [ -n "$_rips" ] || { printf 'noresolve\t-\t-\n'; return 0; }
    _rsets=$(slot_route_sets "$_rid")
    for _ri in $_rips; do
        for _rss in $_rsets; do
            ipset test "$_rss" "$_ri" >/dev/null 2>&1 && { printf 'hit\t%s\t%s\n' "$_ri" "$_rss"; return 0; }
        done
    done
    printf 'miss\t%s\t-\n' "$(echo "$_rips" | head -n1)"
    return 0
}


















slot_state() {   # <id> <transport> <fallback>
    _sid="$1"; _stp="$2"
    if [ "$_stp" = zapret ]; then
        _sets=0
        ipset list -n 2>/dev/null | grep -qx "grp_vpn_s$_sid" && _sets=1
        ipset list -n 2>/dev/null | grep -qx "geo_vpn_s$_sid" && _sets=1
        [ "$_sets" = 1 ] || { echo idle; return 0; }
        _srul=0
        iptables -t mangle -S POSTROUTING 2>/dev/null | grep -q -- "--match-set grp_vpn_s$_sid dst" && _srul=1
        iptables -t mangle -S POSTROUTING 2>/dev/null | grep -q -- "--match-set geo_vpn_s$_sid dst" && _srul=1
        _spid=$(cat /tmp/enodia-zapret-nfqws.pid 2>/dev/null | tr -d ' \r\n')
        if [ "$_srul" = 1 ] && [ -n "$_spid" ] && kill -0 "$_spid" 2>/dev/null; then echo up; else echo down; fi
        return 0
    fi
    _srl=$(slot_rule "$_sid")
    [ -n "$_srl" ] || { echo down; return 0; }
    if ip route show table "100$_sid" 2>/dev/null | grep -q '^default'; then   # not-wan: несущая СЛОТА (table 100N), а не основная и не WAN




        case "$_stp" in
            byedpi|xray|hy2)
                netstat -ltn 2>/dev/null | grep -q "127.0.0.1:$(slot_socks_port "$_sid")" || { echo dead; return 0; } ;;
        esac
        echo up; return 0
    fi



    case "$_srl" in *"lookup 1000"*) echo fallback ;; *) echo direct ;; esac
}



cmd_state() {
    [ -s "$SLOTS_FILE" ] || return 0
    while IFS="$TAB" read -r id nb t cfg fb en; do
        [ -n "$id" ] || continue
        if [ "$en" = on ]; then _st=$(slot_state "$id" "$t" "$fb"); else _st=off; fi
        printf '%s%s%s\n' "$id" "$TAB" "$_st"
    done < "$SLOTS_FILE"
}






slot_bindings() {   # $1 = id
    _bc=0; _be=0; _bk=''
    if [ -f "$_gtsv" ]; then
        while IFS="$TAB" read -r _gid _gen _gdir _gslot _gname _gsrc; do
            [ "$_gslot" = "$1" ] && _bc=$((_bc+1))
        done < "$_gtsv"
    fi
    if [ -f "$_geor" ]; then
        while IFS="$TAB" read -r _bkey _ga _gcnt _gt _gs; do
            [ "$_ga" = vpn ] && [ "$_gs" = "$1" ] || continue
            _be=$((_be+1)); _bk="$_bk${_bk:+,}\"$_bkey\""
        done < "$_geor"
    fi
}

cmd_list_json() {
    _gtsv="$ENODIA_STATE/groups/groups.tsv"
    _geor="$ENODIA_STATE/geo/actions.tsv"
    _n=0; _first=1; _krlx=0; _krix=0   # держатели ключей — один раз на ответ, а не на выход (живой ключ = вызовы awg)



    _rdl=''; if [ -f "$ENODIA_DIR/road.sh" ] && [ -s "$ENODIA_STATE/.cfg-via" ]; then _rdl=$(sh "$ENODIA_DIR/road.sh" list 2>/dev/null); fi
    _wpl=''; if [ -f "$ENODIA_DIR/warp.sh" ]; then _wpl=$(sh "$ENODIA_DIR/warp.sh" list 2>/dev/null | cut -f1); fi
    printf '{"slots":['
    if [ -s "$SLOTS_FILE" ]; then
        while IFS="$TAB" read -r id nb t cfg fb en; do
            [ -n "$id" ] || continue
            _n=$((_n+1))
            [ "$_first" = 1 ] || printf ','
            _first=0
            slot_bindings "$id"


            if [ "$en" = on ]; then _st=$(slot_state "$id" "$t" "$fb"); else _st=off; fi





            _kcl=''
            if [ "$t" = awg ] && [ -f "$AWG_CONFIGS/$cfg.conf" ]; then
                if [ "$en" = on ]; then [ "$_krlx" = 1 ] || { _krl=$(key_rows live); _krlx=1; }; _kr=$_krl
                else [ "$_krix" = 1 ] || { _kri=$(key_rows intent); _krix=1; }; _kr=$_kri; fi
                _kcl=$(awg_ids "$AWG_CONFIGS/$cfg.conf" | key_match "$_kr" "s$id" | head -n1 | cut -f2)
            fi

            _rdr=''; _rlegacy=''
            if [ -n "$_rdl" ]; then
                _rdr=$(printf '%s\n' "$_rdl" | awk -F"$TAB" -v i="$id" '$2 == i { printf "%s\"%s\"", (c++ ? "," : ""), $1 }')
                _rlegacy=$(printf '%s\n' "$_rdl" | awk -F"$TAB" -v i="$id" '$2 == i && $1 ~ /^awg\// { printf "%s\"%s\"", (c++ ? "," : ""), substr($1,5) }')
            fi
            _wp=false; if [ "$t" = awg ] && [ -n "$_wpl" ] && printf '%s\n' "$_wpl" | grep -qxF -- "$cfg"; then _wp=true; fi
            printf '{"id":%s,"name_b64":"%s","transport":"%s","config":"%s","fallback":"%s","enabled":%s,"state":"%s","groups":%s,"geo":%s,"geo_keys":[%s],"key_clash":"%s","riders":[%s],"road_riders":[%s],"warp":%s}' \
                "$id" "$nb" "$t" "$cfg" "$fb" "$([ "$en" = on ] && echo true || echo false)" "$_st" "$_bc" "$_be" "$_bk" "$_kcl" "$_rlegacy" "$_rdr" "$_wp"
        done < "$SLOTS_FILE"
    fi






    _ready=''



    if [ -f "$ENODIA_DIR/transport.sh" ]; then
        _rl=$(sh "$ENODIA_DIR/transport.sh" slot-list 2>/dev/null) || _rl=$(sh "$ENODIA_DIR/transport.sh" list 2>/dev/null)
        for _rt in $_rl; do
            _ready="$_ready${_ready:+,}\"$_rt\""
        done
    fi




    printf '],"count":%s,"max":%s,"full":%s,"ready":[%s],"byedpi":%s}\n' \
        "$_n" "$((MAX_ID-MIN_ID+1))" "$([ "$_n" -ge $((MAX_ID-MIN_ID+1)) ] && echo true || echo false)" "$_ready" \
        "$([ -x "$(bin_path byedpi)" ] && echo true || echo false)"
}







valid_config() {
    case "$1" in
        -) return 0 ;;
        '') return 1 ;;
        *) [ "$(printf '%s' "$1" | wc -l)" -eq 0 ] && printf '%s' "$1" | grep -qE '^[A-Za-z0-9._-]+$' ;;
    esac
}































AWG_CONFIGS="$ENODIA_STATE/configs"











AWG_CLAMP_BEGIN='BEGIN { B = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"; for (i = 0; i < 64; i++) b64[substr(B, i + 1, 1)] = i }'
AWG_CLAMP='if (length(v) == 44 && (substr(v, 1, 1) in b64) && (substr(v, 2, 1) in b64) && (substr(v, 42, 1) in b64)) { c0 = b64[substr(v, 1, 1)]; c1 = b64[substr(v, 2, 1)]; c41 = b64[substr(v, 42, 1)]; c0 = c0 - c0 % 2; c1 = c1 % 16; c41 = int(c41 / 16) * 16 + 4 + c41 % 4; v = substr(B, c0 + 1, 1) substr(B, c1 + 1, 1) substr(v, 3, 39) substr(B, c41 + 1, 1) substr(v, 43) }'
AWG_ID_AWK="$AWG_CLAMP_BEGIN"'
FNR == 1 && NR > 1 && pk != "" { if (np == 0) print "C\t" nm "\t" pk; for (k = 1; k <= np; k++) print "C\t" nm "\t" pk ":" pe[k] }
FNR == 1 { nm = FILENAME; sub(/.*\//, "", nm); sub(/\.conf$/, "", nm); pk = ""; np = 0 }
{ l = $0; sub(/\r$/, "", l); t = tolower(l) }
t ~ /^[ \t]*privatekey[ \t]*=/ && pk == "" { v = l; sub(/^[^=]*=/, "", v); sub(/#.*/, "", v); gsub(/[ \t]/, "", v); '"$AWG_CLAMP"'; pk = v }
t ~ /^[ \t]*publickey[ \t]*=/ { v = l; sub(/^[^=]*=/, "", v); sub(/#.*/, "", v); gsub(/[ \t]/, "", v); if (v != "") pe[++np] = v }
END { if (pk != "") { if (np == 0) print "C\t" nm "\t" pk; for (k = 1; k <= np; k++) print "C\t" nm "\t" pk ":" pe[k] } }'
awg_ids() { awk "$AWG_ID_AWK" "$@" 2>/dev/null; }             # файлы .conf -> «C⇥имя⇥идентичность» (строка на пир)
awg_key_file() { [ -f "$1" ] || return 0; awg_ids "$1" | cut -f3; }
awg_key_live() {   # $1 = iface -> «ключ:пир» живого демона строкой на пир (пусто, если его нет или нечем спросить)
    ip link show "$1" >/dev/null 2>&1 || return 0
    _kb=$(bin_path awg); [ -x "$_kb" ] || return 0


    _kl=$("$_kb" show "$1" private-key 2>/dev/null | head -n1 | tr -d ' \t\r' | awk "$AWG_CLAMP_BEGIN"' { v = $0; '"$AWG_CLAMP"'; print v }')
    [ -n "$_kl" ] || return 0
    _kp=$("$_kb" show "$1" peers 2>/dev/null | tr -d ' \t\r')
    if [ -z "$_kp" ]; then printf '%s\n' "$_kl"; return 0; fi
    printf '%s\n' "$_kp" | while IFS= read -r _kq; do [ -n "$_kq" ] && printf '%s:%s\n' "$_kl" "$_kq"; done
    return 0
}
key_row() {   # $1 = кто, $2 = имя, $3 = идентичности строками -> R-строки
    printf '%s\n' "$3" | while IFS= read -r _kr1; do [ -n "$_kr1" ] && printf 'R\t%s\t%s\t%s\n' "$1" "$2" "$_kr1"; done
    return 0
}


key_rows() {
    _rmode="$1"
    _rm=$(awg_key_file "$ENODIA_STATE/awg.conf"); _ra=$(cat "$ENODIA_STATE/.active" 2>/dev/null | tr -d ' \r\n')
    if [ "$_rmode" = intent ] || [ "$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')" = awg ]; then
        key_row main "$_ra" "$_rm"
    fi


    _rl=$(awg_key_live awg0)
    if [ -n "$_rl" ]; then
        if [ "$(printf '%s\n' "$_rl" | head -n1 | cut -d: -f1)" = "$(printf '%s\n' "$_rm" | head -n1 | cut -d: -f1)" ]; then
            key_row main "$_ra" "$_rl"
        else key_row main '' "$_rl"; fi
    fi
    if [ "$_rmode" = intent ] && [ "$(cat "$ENODIA_STATE/.failover-mode" 2>/dev/null | tr -d ' \t\r\n')" = home ]; then
        _rh=$(cat "$ENODIA_STATE/.failover-home" 2>/dev/null | tr -d ' \r\n')
        if [ -n "$_rh" ] && [ "$_rh" != "$_ra" ] && valid_config "$_rh"; then
            key_row main "$_rh" "$(awg_key_file "$AWG_CONFIGS/$_rh.conf")"
        fi
    fi
    [ -s "$SLOTS_FILE" ] || return 0

    while IFS="$TAB" read -r _ri _rn _rt _rc _rf _re || [ -n "$_ri" ]; do
        [ "$_rt" = awg ] || continue
        if [ "$_rmode" = intent ]; then _rk=$(awg_key_file "$AWG_CONFIGS/$_rc.conf")
        else [ "$_re" = on ] || continue; _rk=$(awg_key_live "awg$_ri"); fi
        key_row "s$_ri" "$_rc" "$_rk"
    done < "$SLOTS_FILE"
}



KEY_MATCH_AWK='
$1 == "R" { n++; rw[n] = $2; rn[n] = $3; rp[n] = $4; next }
$1 == "C" {
    ck = $3; sub(/:.*/, "", ck); ce = ""; if ($3 ~ /:/) { ce = $3; sub(/^[^:]*:/, "", ce) }
    for (i = 1; i <= n; i++) {
        if (rw[i] == self) continue
        rk = rp[i]; sub(/:.*/, "", rk)
        if (rk == "" || rk != ck) continue
        re = ""; if (rp[i] ~ /:/) { re = rp[i]; sub(/^[^:]*:/, "", re) }
        if (ce != "" && re != "" && ce != re) continue
        print $2 "\t" rw[i] "\t" rn[i]
    }
}'
key_match() {   # $1 = R-строки (key_rows), $2 = self; stdin — C-строки
    { printf '%s\n' "$1"; cat; } | awk -F"$TAB" -v self="$2" "$KEY_MATCH_AWK"
}


key_busy_msg() {
    _mh=$(printf '%s' "$2" | cut -f1); _mhn=$(printf '%s' "$2" | cut -f2)


    case "$_mh" in
        main) _mwho="сервер AmneziaWG основного канала" ;;
        *)    _mwho="конфиг выхода №${_mh#s}" ;;
    esac
    if [ "$_mhn" = "$1" ]; then
        _mwhat="конфиг «$1» уже занят: это $_mwho"
    elif [ -n "$_mhn" ]; then
        _mwhat="у конфига «$1» тот же ключ, что у «$_mhn», а это $_mwho"
    else
        _mwhat="у конфига «$1» тот же ключ, что у $(printf '%s' "$_mwho" | sed 's/^сервер /сервера /; s/^конфиг /конфига /')"
    fi
    echo "$_mwhat. Один ключ AmneziaWG не держит два подключения: сервер оставит одно, и второе будет постоянно отваливаться. Заведите отдельный конфиг (с другим ключом)."
}
key_self() { case "$1" in main|none) printf '%s' "$1" ;; *) printf 's%s' "$1" ;; esac; }


cmd_key_holder() {
    _kc="$1"; _ks=$(key_self "$2"); _kmode=intent; [ "$3" = live ] && _kmode=live
    valid_config "$_kc" && [ "$_kc" != '-' ] || return 2
    [ -f "$AWG_CONFIGS/$_kc.conf" ] || return 2
    _kid=$(awg_ids "$AWG_CONFIGS/$_kc.conf"); [ -n "$_kid" ] || return 2
    _kh=$(printf '%s\n' "$_kid" | key_match "$(key_rows "$_kmode")" "$_ks" | head -n1 | cut -f2-)
    [ -n "$_kh" ] || return 1
    key_busy_msg "$_kc" "$_kh"
    return 0
}




cmd_key_map() {
    [ -d "$AWG_CONFIGS" ] || return 0


    set --; for _kf in "$AWG_CONFIGS"/*.conf; do [ -f "$_kf" ] && [ -r "$_kf" ] && set -- "$@" "$_kf"; done
    [ $# -gt 0 ] || return 0
    awg_ids "$@" | key_match "$(key_rows intent)" none | awk -F"$TAB" '
        { kk = $1 "\t" $2; if (kk in s) next; s[kk] = 1
          if ($1 in h) h[$1] = h[$1] "," $2; else { k++; o[k] = $1; h[$1] = $2 } }
        END { for (i = 1; i <= k; i++) print o[i] "\t" h[o[i]] }'
}


slot_key_guard() {
    [ "$1" = awg ] || return 0
    _kg=$(cmd_key_holder "$2" "$3") || return 0
    echo "[slots] $_kg"
    return 1
}




slot_ram_guard() {   # $1 = transport
    case "$1" in xray|hy2) ;; *) return 0 ;; esac
    command -v daemon_ram_room >/dev/null 2>&1 || return 0
    daemon_ram_room "$DAEMON_GO_NEED_KB" && return 0
    if [ "$1" = xray ]; then _srg=Xray; else _srg=Hysteria2; fi
    echo "[slots] мало свободной памяти для ещё одного $_srg ($DAEMON_RAM_WHY) — выход не поднимаю: он уронил бы основной туннель"
    return 1
}




slot_road_guard() {   # $1 = id, $2 = what the person tried (words)
    [ -f "$ENODIA_DIR/road.sh" ] || return 0
    _srr=$(_sr_sep=''; sh "$ENODIA_DIR/road.sh" riders "$1" 2>/dev/null | while IFS= read -r _sr_key; do
        _sr_file=${_sr_key#*/}
        _sr_name=$(sh "$ENODIA_DIR/cfg-names.sh" display "${_sr_key%%/*}" "$_sr_file" 2>/dev/null) || _sr_name=''
        printf '%s%s' "$_sr_sep" "${_sr_name:-$_sr_file}"
        _sr_sep=', '
    done)
    [ -n "$_srr" ] || return 0
    printf '%s\n' "[slots] выход №$1 служит дорогой к серверу ($_srr) — сначала переключите их дорогу на «напрямую», потом $2"
    return 1
}



slot_free_id() {
    _sfi=$MIN_ID
    while [ "$_sfi" -le "$MAX_ID" ]; do
        [ -z "$(slot_line "$_sfi")" ] && { echo "$_sfi"; return 0; }
        _sfi=$((_sfi+1))
    done
    return 1
}
SLOTS_FULL="[slots] мест нет: заняты все $((MAX_ID-MIN_ID+1)) доп-выходов"

cmd_add() {
    name="$1"; t="$2"; cfg="${3:--}"; fb="${4:-main}"
    [ -n "$name" ] || { echo "[slots] имя обязательно"; return 1; }
    valid_transport "$t" || { echo "[slots] неизвестный транспорт '$t' (awg|xray|hy2|byedpi|zapret)"; return 1; }
    valid_config "$cfg" || { echo "[slots] недопустимое имя конфига (буквы, цифры, . _ - или '-')"; return 1; }
    case "$fb" in main|direct) ;; *) echo "[slots] fallback = main|direct"; return 1 ;; esac




    slots_lock_take || { echo "[slots] реестр занят другой операцией — повторите"; return 1; }
    slot_key_guard "$t" "$cfg" new || { slots_lock_drop; return 1; }
    slot_ram_guard "$t" || { slots_lock_drop; return 1; }
    id=$(slot_free_id) || { slots_lock_drop; echo "$SLOTS_FULL"; return 1; }
    _slots_write "$id" "$(b64e "$name")" "$t" "$cfg" "$fb" on || { slots_lock_drop; echo "$SLOTS_NOWRITE"; return 1; }
    slots_lock_drop


    slot_activate "$id"

    if [ "$cfg" = '-' ]; then _cfgh=""; else _cfgh=" · $cfg"; fi
    echo "[slots] выход №$id «$name» ($t$_cfgh) создан, fallback=$fb"
}





cmd_rename_config() {
    t="$1"; old="$2"; new="$3"
    valid_transport "$t" || { echo "[slots] неизвестный транспорт '$t'"; return 1; }
    { [ "$old" != '-' ] && valid_config "$old" && [ "$new" != '-' ] && valid_config "$new"; } \
        || { echo "[slots] недопустимое имя конфига"; return 1; }
    [ -f "$SLOTS_FILE" ] || { echo 0; return 0; }
    slots_lock_take || { echo "[slots] реестр занят другой операцией — повторите"; return 1; }





    _rdup=$(awk -F"$TAB" -v t="$t" -v n="$new" '$3==t && ($4 "") == (n "") { print $1; exit }' "$SLOTS_FILE" 2>/dev/null)
    if [ -n "$_rdup" ]; then slots_lock_drop; echo "[slots] имя «$new» уже указано у выхода №$_rdup — выберите другое"; return 1; fi

    _rn=$(_slots_renamed "$t" "$old" "$new" count) \
        || { slots_lock_drop; echo "[slots] реестр выходов не читается — переименование не выполнено"; return 1; }
    case "$_rn" in ''|*[!0-9]*) _rn=0 ;; esac


    if [ "$_rn" -gt 0 ] && ! lbl_commit_out "$SLOTS_FILE" _slots_renamed "$t" "$old" "$new"; then
        slots_lock_drop; echo "$SLOTS_NOWRITE"; return 1
    fi
    slots_lock_drop
    echo "$_rn"
}


_slots_renamed() {
    _rnn=0
    while IFS="$TAB" read -r _i _nb _t _c _f _e || [ -n "$_i" ]; do
        [ -n "$_i" ] || continue
        if [ "$_t" = "$1" ] && [ "$_c" = "$2" ]; then _c="$3"; _rnn=$((_rnn+1)); fi
        [ "${4:-}" = count ] || printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$_i" "$_nb" "$_t" "$_c" "$_f" "$_e"
    done < "$SLOTS_FILE" || return 1
    [ "${4:-}" != count ] || echo "$_rnn"
}



cmd_set() {
    id="$1"; field="$2"; val="$3"
    valid_id "$id" || { echo "[slots] id = $MIN_ID..$MAX_ID"; return 1; }
    line=$(slot_line "$id"); [ -n "$line" ] || { echo "[slots] нет слота №$id"; return 1; }
    old_nb=$(echo "$line" | cut -f2); old_t=$(echo "$line" | cut -f3)
    old_cfg=$(echo "$line" | cut -f4); old_fb=$(echo "$line" | cut -f5); old_en=$(echo "$line" | cut -f6)
    case "$field" in
        name)      old_nb=$(b64e "$val") ;;
        transport) valid_transport "$val" || { echo "[slots] неизвестный транспорт '$val'"; return 1; }
                   old_t="$val" ;;
        config)    valid_config "$val" || { echo "[slots] недопустимое имя конфига (буквы, цифры, . _ - или '-')"; return 1; }
                   old_cfg="$val" ;;
        fallback)  case "$val" in main|direct) ;; *) echo "[slots] fallback = main|direct"; return 1 ;; esac
                   old_fb="$val" ;;
        *) echo "[slots] поле = name|transport|config|fallback"; return 1 ;;
    esac

    case "$field" in transport|config) slot_key_guard "$old_t" "$old_cfg" "$id" || return 1 ;; esac

    [ "$field" = transport ] && [ "$old_t" != awg ] && { slot_road_guard "$id" "меняйте транспорт" || return 1; }


    if [ "$field" = transport ] && [ "$old_en" = on ]; then
        case "$(echo "$line" | cut -f3)" in xray|hy2) ;; *) slot_ram_guard "$old_t" || return 1 ;; esac
    fi
    if [ "$field" = config ] && [ -f "$ENODIA_DIR/road.sh" ] && [ -n "$(sh "$ENODIA_DIR/road.sh" get "$old_t" "$old_cfg" 2>/dev/null)" ]; then
        slot_road_guard "$id" "ставьте ему конфиг, который сам едет по дороге" || return 1
    fi
    if [ "$field" = config ] && [ "$old_t" = awg ]; then
        slot_road_clash "$id" "$old_cfg" || return 1
    fi





    reup=0
    case "$field" in transport|config) [ "$old_en" = on ] && reup=1 ;; esac
    if [ "$reup" = 1 ]; then slot_deactivate "$id" || return 1; fi


    _swhy=""
    if ! slots_lock_take; then _swhy="[slots] реестр занят другой операцией — повторите"
    elif ! _slots_write "$id" "$old_nb" "$old_t" "$old_cfg" "$old_fb" "$old_en"; then slots_lock_drop; _swhy=$SLOTS_NOWRITE
    else slots_lock_drop; fi
    if [ -n "$_swhy" ]; then
        echo "$_swhy"
        [ "$reup" = 1 ] && [ -f "$ENODIA_DIR/transport.sh" ] && sh "$ENODIA_DIR/transport.sh" slot-up "$id" >/dev/null 2>&1
        return 1
    fi


    if [ "$reup" = 1 ] && [ -f "$ENODIA_STATE/.vpn-off" ]; then
        echo "[slots] слот №$id: $field обновлён; VPN выключен вручную — выход поднимется при включении"
        return 0
    fi
    if [ "$reup" = 1 ]; then
        if [ -f "$ENODIA_DIR/transport.sh" ] && sh "$ENODIA_DIR/transport.sh" slot-up "$id" >/dev/null 2>&1; then
            echo "[slots] слот №$id: $field обновлён, несущая перезапущена"
        else
            echo "[slots] слот №$id: $field обновлён, но несущая не поднялась — выход идёт по запасному пути"
        fi
        return 0
    fi


    if [ "$field" = fallback ] && [ "$old_en" = on ] && [ -f "$ENODIA_DIR/mark-core.sh" ]; then
        _sfr=$(slot_rule "$id")
        sh "$ENODIA_DIR/mark-core.sh" >/dev/null 2>&1




        [ "$(slot_rule "$id")" = "$_sfr" ] || ct_flush_slot "$id"
    fi
    echo "[slots] слот №$id: $field обновлён"
}


write_en() {
    slots_lock_take || { echo "[slots] реестр занят другой операцией — повторите"; return 1; }
    line=$(slot_line "$1")
    [ -n "$line" ] || { slots_lock_drop; return 1; }
    _slots_write "$1" "$(printf '%s' "$line" | cut -f2)" "$(printf '%s' "$line" | cut -f3)" \
                 "$(printf '%s' "$line" | cut -f4)" "$(printf '%s' "$line" | cut -f5)" "$2" \
        || { slots_lock_drop; echo "$SLOTS_NOWRITE"; return 1; }
    slots_lock_drop
}












rebind_owners() {
    id="$1"




    if [ -f "$ENODIA_DIR/groups.sh" ] && [ -s "$ENODIA_STATE/groups/groups.tsv" ] &&
       awk -F"$TAB" -v s="$id" '$4==s{f=1} END{exit !f}' "$ENODIA_STATE/groups/groups.tsv" 2>/dev/null; then
        sh "$ENODIA_DIR/groups.sh" apply >/dev/null 2>&1 || true
    fi



    if [ -f "$ENODIA_DIR/apply-bypass.sh" ] && [ -s "$ENODIA_STATE/.fullvpn-ips" ] &&
       awk -F"$TAB" -v s="s$id" '$2==s{f=1} END{exit !f}' "$ENODIA_STATE/.fullvpn-ips" 2>/dev/null; then
        sh "$ENODIA_DIR/apply-bypass.sh" force-rebind >/dev/null 2>&1 || true
    fi
    if [ -f "$ENODIA_DIR/geo.sh" ] && [ -s "$ENODIA_STATE/geo/actions.tsv" ] &&
       awk -F"$TAB" -v s="$id" '$5==s{f=1} END{exit !f}' "$ENODIA_STATE/geo/actions.tsv" 2>/dev/null; then
        if [ -x /sbin/start-stop-daemon ]; then
            rm -f /tmp/enodia-geo.pid 2>/dev/null
            start-stop-daemon -S -b -m -p /tmp/enodia-geo.pid -x /bin/sh -- "$ENODIA_DIR/geo.sh" apply >/dev/null 2>&1
        else
            ( sh "$ENODIA_DIR/geo.sh" apply >/dev/null 2>&1 & )
        fi
    fi
}











slot_deactivate() {
    [ -f "$ENODIA_DIR/transport.sh" ] || return 0


    sh "$ENODIA_DIR/transport.sh" slot-down "$1" >/dev/null 2>&1 && return 0
    [ "$?" = 2 ] && return 0
    echo "[slots] выход №$1 не снят — настройки сохранены, повторите операцию"
    return 1
}
slot_road_clash() {
    [ -f "$ENODIA_DIR/road.sh" ] || return 0
    _scl=$(sh "$ENODIA_DIR/road.sh" clash "$1" "$2" 2>/dev/null)
    [ -z "$_scl" ] || { echo "[slots] выход №$1 служит дорогой, а новый конфиг идёт к серверу $_scl, который уже едет по дороге — выберите конфиг к другому серверу"; return 1; }
}
slot_activate() {
    id="$1"
    if [ -f "$ENODIA_DIR/transport.sh" ]; then sh "$ENODIA_DIR/transport.sh" slot-up "$id" >/dev/null 2>&1
    else [ -f "$ENODIA_DIR/mark-core.sh" ] && sh "$ENODIA_DIR/mark-core.sh" >/dev/null 2>&1; fi
    rebind_owners "$id"   # привязанные пулы обязаны переехать в сет ЭТОГО выхода
}

cmd_toggle() {
    id="$1"; en="$2"
    valid_id "$id" || { echo "[slots] id = $MIN_ID..$MAX_ID"; return 1; }
    [ -n "$(slot_line "$id")" ] || { echo "[slots] нет слота №$id"; return 1; }
    TRANSPORT_SH="$ENODIA_DIR/transport.sh"
    if [ "$en" = on ]; then


        _tl=$(slot_line "$id")
        slot_key_guard "$(printf '%s' "$_tl" | cut -f3)" "$(printf '%s' "$_tl" | cut -f4)" "$id" || return 1
        if [ "$(printf '%s' "$_tl" | cut -f3)" = awg ]; then slot_road_clash "$id" "$(printf '%s' "$_tl" | cut -f4)" || return 1; fi

        if [ "$(printf '%s' "$_tl" | cut -f6)" != on ]; then slot_ram_guard "$(printf '%s' "$_tl" | cut -f3)" || return 1; fi



        write_en "$id" on || return 1
        slot_activate "$id"
        echo "[slots] слот №$id включён"
    else
        slot_road_guard "$id" "выключайте выход" || return 1



        if [ "$(slot_line "$id" | cut -f6)" = on ]; then slot_deactivate "$id" || return 1; fi
        if ! write_en "$id" off; then   # still `on` in the registry, and its carrier is down already — bring it back
            [ -f "$TRANSPORT_SH" ] && sh "$TRANSPORT_SH" slot-up "$id" >/dev/null 2>&1
            return 1
        fi
        cmd_unwire "$id"
        rebind_owners "$id"   # иначе пул выхода останется в осиротевшем сете = НАПРЯМУЮ мимо VPN
        echo "[slots] слот №$id выключен"
    fi
}





cmd_unwire() {
    id="$1"
    valid_id "$id" || { echo "[slots] id = $MIN_ID..$MAX_ID"; return 1; }
    for sset in "grp_vpn_s$id" "geo_vpn_s$id"; do
        for chain in PREROUTING OUTPUT; do
            while iptables -t mangle -D "$chain" -m set --match-set "$sset" dst -j ACCEPT 2>/dev/null; do :; done
            while iptables -t mangle -D "$chain" -m set --match-set "$sset" dst -j MARK --set-mark "0x$id" 2>/dev/null; do :; done
        done
    done
    ip rule del fwmark "0x$id" table "100$id" 2>/dev/null || true


    ip rule del fwmark "0x$id" table 1000 2>/dev/null || true
    ct_flush_slot "$id"   # only this exit's flows (ct-lib.sh): the house keeps its connections
}

cmd_del() {
    id="$1"
    valid_id "$id" || { echo "[slots] id = $MIN_ID..$MAX_ID"; return 1; }
    line=$(slot_line "$id"); [ -n "$line" ] || { echo "[slots] нет слота №$id"; return 1; }
    slot_road_guard "$id" "удаляйте выход" || return 1


    if [ "$(printf '%s' "$line" | cut -f6)" = on ] && [ -f "$ENODIA_DIR/transport.sh" ]; then
        slot_deactivate "$id" || return 1
    fi
    cmd_unwire "$id"



    _dwhy=""
    if ! slots_lock_take; then _dwhy="[slots] реестр занят другой операцией — повторите"
    elif ! _slots_write "$id"; then slots_lock_drop; _dwhy=$SLOTS_NOWRITE
    else slots_lock_drop; fi
    if [ -n "$_dwhy" ]; then
        echo "$_dwhy"
        [ "$(printf '%s' "$line" | cut -f6)" = on ] && slot_activate "$id" >/dev/null 2>&1
        return 1
    fi


    rebind_owners "$id"
    echo "[slots] слот №$id удалён (правила сняты)"
}

case "$1" in
    list)         cmd_list ;;
    list-enabled) cmd_list_enabled ;;
    list-json)    cmd_list_json ;;
    state)        cmd_state ;;
    carriers)     cmd_carriers ;;
    configs)      cmd_configs "$2" ;;
    show)         slot_line "$2" ;;
    restore-registry) shift; cmd_restore_registry "$@" ;;
    domains)      cmd_domains "$2" "$3" ;;
    route)        cmd_route "$2" "$3" ;;
    add)          cmd_add "$2" "$3" "$4" "$5" ;;
    free)         slot_free_id || { echo "$SLOTS_FULL"; exit 1; } ;;
    set)          cmd_set "$2" "$3" "$4" ;;
    enable)       cmd_toggle "$2" on ;;
    disable)      cmd_toggle "$2" off ;;
    del)          cmd_del "$2" ;;
    unwire)       cmd_unwire "$2" ;;
    rename-config) cmd_rename_config "$2" "$3" "$4" ;;
    key-holder)   cmd_key_holder "$2" "$3" "$4" ;;
    key-map)      cmd_key_map ;;
    holders)      cmd_holders "$2" "$3" "$4" ;;
    *) echo "usage: $0 list|list-enabled|list-json|state|carriers|configs <транспорт>|show <id>|domains <id|0> [кап]|route <id|0> <домен>|add <имя> <транспорт> [конфиг] [fallback]|set <id> <поле> <знач>|enable <id>|disable <id>|del <id>|unwire <id>|rename-config <транспорт> <старое> <новое>|key-holder <конфиг> <main|2..7> [live]|key-map|holders <транспорт> <конфиг> [on]"; exit 2 ;;
esac
