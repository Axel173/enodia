#!/bin/sh








































: "${ENODIA_DIR:=/data/usr/app/enodia}"
: "${ENODIA_STATE:=/data/usr/app/enodia-state}"
: "${ENODIA_BIN:=/data/usr/app/enodia-bin}"

STORE_MARK="$ENODIA_STATE/.bin-store"        # путь к каталогу-хранилищу; пишет usb-offload.sh
STORE_SENTINEL=.enodia-bin-store        # им опознаём СВОЙ каталог на чужом накопителе






STORE_SUB=enodia-store                  # подкаталог на накопителе (остальное там — файлы юзера)
STORE_MNT=/mnt/enodia-usb               # СВОЯ точка монтирования (если сток не смонтировал сам)




STORE_SUB_OLD=be7000-store
STORE_SENTINEL_OLD=.be7000-bin-store
STORE_MNT_OLD=/mnt/be7000-usb








DATA_RESERVE_B=2621440                  # 2.5 МБ





























harden_tree() {     # $1 = корень, $2 = режим каталогов, $3 = режим файлов («-» = не трогать)
    [ -d "$1" ] || return 0



    find "$1" -type d -exec chmod "$2" {} ';' 2>/dev/null || :
    [ "$3" = "-" ] || find "$1" -type f -exec chmod "$3" {} ';' 2>/dev/null || :
    return 0
}




harden_perms() {    # $1 = каталог кода, $2 = каталог состояния, $3 = каталог бинарей
    harden_tree "$1" 755 -      # код: каталоги 755, файлы уже верны (0755 скрипты, 0644 данные)
    harden_tree "$2" 700 600    # состояние: секреты, читать их некому, кроме root






    harden_tree "$3" 755 755



    find "$3" -type f -name 'awg[0-9]*.conf' -exec chmod 600 {} ';' 2>/dev/null || :
    return 0
}

























fs_anchor()  { _fan="${1:-$ENODIA_DIR}"; while [ -n "$_fan" ] && [ ! -e "$_fan" ]; do _fan="${_fan%/*}"; done; printf '%s' "${_fan:-/}"; }




fs_line()    { df -k "$(fs_anchor "$1")" 2>/dev/null | tail -1 | awk '{for(i=NF;i>1;i--) if($i ~ /%$/) break; if(i>=4 && $(i-3) ~ /^[0-9]+$/ && $(i-1) ~ /^[0-9]+$/ && $(i-3)+0>0){m=""; for(j=i+1;j<=NF;j++){ if(j>i+1) m=m " "; m=m $j }; print $(i-3), $(i-1), m}}'; }
fs_free_b()  { _fsb=$(fs_line "$1" | awk '{printf "%.0f", $2*1024}'); case "$_fsb" in ''|*[!0-9]*) _fsb=0 ;; esac; printf '%s' "$_fsb"; }
fs_total_b() { _fst=$(fs_line "$1" | awk '{printf "%.0f", $1*1024}'); case "$_fst" in ''|*[!0-9]*) _fst=0 ;; esac; printf '%s' "$_fst"; }
fs_mount()   { _fsm=$(fs_line "$1"); printf '%s' "${_fsm#* * }"; }
fs_same_volume() {
    _fsv=$(fs_mount "$1")
    [ -n "$_fsv" ] && [ "$_fsv" = "$(fs_mount "$2")" ]
}



data_flash_tight() {
    _dft=$(fs_total_b "$ENODIA_BOOT")
    [ "$_dft" -gt 0 ] || return 1
    fs_same_volume "$1" "$ENODIA_BOOT" || return 1
    [ "$_dft" -le $((DATA_RESERVE_B * 16)) ] || [ "$(fs_free_b "$ENODIA_BOOT")" -lt "$DATA_RESERVE_B" ]
}













store_is_ours() {
    [ -n "$1" ] && [ -d "$1/bin" ] || return 1
    [ -f "$1/$STORE_SENTINEL" ] && return 0
    [ -n "$STORE_SENTINEL_OLD" ] && [ -f "$1/$STORE_SENTINEL_OLD" ]
}










STORE_DIR=
BIN_DIR="$ENODIA_BIN"
if [ -f "$STORE_MARK" ]; then
    _sr=
    read -r _sr < "$STORE_MARK" 2>/dev/null || :
    if store_is_ours "$_sr"; then
        STORE_DIR="$_sr"
        BIN_DIR="$_sr/bin"
    fi
    unset _sr
fi




store_ready() { [ -n "$STORE_DIR" ]; }


store_root() { printf '%s' "$STORE_DIR"; }








store_state() {
    if store_ready; then printf 'ok'
    elif [ -f "$STORE_MARK" ]; then printf 'lost'
    else printf 'none'; fi
}








bin_path() {
    if [ "$BIN_DIR" != "$ENODIA_BIN" ] && [ -x "$BIN_DIR/$1" ]; then
        printf '%s' "$BIN_DIR/$1"
    else
        printf '%s' "$ENODIA_BIN/$1"
    fi
}



bin_where() {
    if [ "$BIN_DIR" != "$ENODIA_BIN" ] && [ -x "$BIN_DIR/$1" ]; then
        printf 'store'
    elif [ -x "$ENODIA_BIN/$1" ]; then
        printf 'router'
    fi
}










bin_on_store() { path_on_store "$(bin_path "$1")"; }



path_on_store() {
    _bos_b=$(fs_mount "$1")
    _bos_r=$(fs_mount "${ENODIA_BOOT:-/data/usr/app/enodia-boot}")
    [ -n "$_bos_b" ] && [ -n "$_bos_r" ] && [ "$_bos_b" != "$_bos_r" ]
}















STORE_MOVABLE="xray hysteria hev byedpi nfqws"

store_movable() { case " $STORE_MOVABLE " in *" $1 "*) return 0 ;; esac; return 1; }




















KEEP_MARK="$ENODIA_STATE/.bin-keep"     # по имени в строке; пишет usb-offload.sh place
BIN_KEEP=
if [ -f "$KEEP_MARK" ]; then
    while read -r _bk || [ -n "$_bk" ]; do
        case "$_bk" in ''|'#'*) continue ;; esac
        BIN_KEEP="$BIN_KEEP $_bk"
    done < "$KEEP_MARK"
    unset _bk
fi


bin_pinned() { case " $BIN_KEEP " in *" $1 "*) return 0 ;; esac; return 1; }







bin_deps() { case "$1" in xray|hysteria|byedpi) printf 'hev' ;; esac; }




bin_dest() {
    if store_ready && store_movable "$1" && ! bin_pinned "$1"; then
        printf '%s' "$BIN_DIR/$1"
    else
        printf '%s' "$ENODIA_BIN/$1"
    fi
}





bin_prune() {
    _bd=$(bin_dest "$1")
    if [ "$_bd" = "$ENODIA_BIN/$1" ]; then
        if [ "$BIN_DIR" != "$ENODIA_BIN" ]; then rm -f "$BIN_DIR/$1" 2>/dev/null; fi
    else
        rm -f "$ENODIA_BIN/$1" 2>/dev/null
    fi
    unset _bd
    return 0                    # best-effort: под set -e чистка не имеет права ронять вызывающего
}



store_purge_dir() {   # $1 = owned bin directory, $2 = keep callback, then names
    [ -d "$1" ] || return 0
    [ ! -L "$1" ] || { echo "soft-float: linked bin directory skipped: $1" >&2; return 1; }
    _spd_dir=$1; _spd_keep=$2; shift 2
    for _spd_name do
        _spd_path="$_spd_dir/$_spd_name"
        if [ ! -L "$_spd_path" ]; then
            [ -f "$_spd_path" ] || continue
            if "$_spd_keep" "$_spd_name" "$_spd_path"; then continue
            elif [ "$?" != 1 ]; then
                echo "soft-float: cannot read digest: $_spd_path" >&2; return 1
            fi
        fi
        rm -f "$_spd_path" || return 1
        echo "soft-float: removed incompatible binary: $_spd_path"
        _sp_changed=1
    done
}

store_purge_bins() {   # optional USB root about to be admitted; otherwise sweep the current layout
    _sp_root=$1; shift
    _sp_changed=0; _sp_rc=0
    if [ -z "$_sp_root" ]; then

        if [ "${ENODIA_DIR##*/}" = enodia ] && [ "$ENODIA_BIN" = "${ENODIA_DIR%/*}/bin" ]; then
            _sp_root=${ENODIA_BIN%/*}
        else
            store_purge_dir "$ENODIA_BIN" "$@" || _sp_rc=1
            _sp_root=$STORE_DIR
        fi
    fi
    if [ -n "$_sp_root" ]; then
        if [ ! -L "$_sp_root" ] && store_is_ours "$_sp_root"; then
            store_purge_dir "$_sp_root/bin" "$@" || _sp_rc=1
        else
            echo "soft-float: purge skipped (storage ownership unconfirmed): $_sp_root" >&2
            _sp_rc=1
        fi
    fi
    [ "$_sp_changed" = 0 ] || sync 2>/dev/null
    return "$_sp_rc"
}





bin_install() {
    _bd=$(bin_dest "$2")
    mkdir -p "${_bd%/*}" 2>/dev/null
    mv -f "$1" "$_bd" 2>/dev/null || { unset _bd; return 1; }
    chmod +x "$_bd" 2>/dev/null
    unset _bd
    bin_prune "$2"
    return 0
}
