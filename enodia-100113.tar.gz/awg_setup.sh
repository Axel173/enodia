#!/bin/sh





: "${ENODIA_DIR:=/data/usr/app/enodia}"
: "${ENODIA_STATE:=/data/usr/app/enodia-state}"
: "${ENODIA_BIN:=/data/usr/app/enodia-bin}"
config_file="$ENODIA_STATE/amnezia_for_awg.conf"
interface_config="$ENODIA_STATE/awg0.conf"













guest_dns() {
    _gdo=$(iptables -t nat -S PREROUTING 2>/dev/null | grep -E -- '^-A PREROUTING -s 192\.168\.33\.0/24 .*--dport 53 -j DNAT --to-destination ' \
        | grep -vE -- '--to-destination 192\.168\.33\.1:53$')
    [ "$1" = migrate ] && [ -z "$_gdo" ] && return 0
    printf '%s\n' "$_gdo" | sed -n 's/^-A /-D /p' | while read -r _gd; do iptables -t nat $_gd 2>/dev/null; done
    iptables -t nat -C PREROUTING -p udp -s 192.168.33.0/24 --dport 53 -j DNAT --to-destination 192.168.33.1:53 2>/dev/null || iptables -t nat -A PREROUTING -p udp -s 192.168.33.0/24 --dport 53 -j DNAT --to-destination 192.168.33.1:53
    iptables -t nat -C PREROUTING -p tcp -s 192.168.33.0/24 --dport 53 -j DNAT --to-destination 192.168.33.1:53 2>/dev/null || iptables -t nat -A PREROUTING -p tcp -s 192.168.33.0/24 --dport 53 -j DNAT --to-destination 192.168.33.1:53
    [ "$1" = migrate ] && echo "Гостевая сеть: DNS гостей — к dnsmasq роутера (прежнее правило к резолверу туннеля снято)"
    return 0
}
case "${1:-}" in
    guest-dns)

        if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi
        guest_dns "${2:-on}"; exit 0 ;;
esac




if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v go_quiet >/dev/null 2>&1 || go_quiet() { "$@"; }   # the shim of a missing library: the launch as it was, with the banner
command -v carrier_barred >/dev/null 2>&1 || carrier_barred() { return 1; }
if [ -f "$ENODIA_DIR/label-lib.sh" ]; then . "$ENODIA_DIR/label-lib.sh"; fi   # lbl_commit_out: a file replaced whole or not at all
command -v lbl_commit_out_as >/dev/null 2>&1 || { lbl_commit_out_as() { _lct=$1; _lcf=$2; shift 2; "$@" > "$_lct" && mv -f "$_lct" "$_lcf" && return 0; rm -f "$_lct"; return 1; }; lbl_commit_out() { _lcf=$1; shift; lbl_commit_out_as "$_lcf.$$.new" "$_lcf" "$@"; }; lbl_grep() { grep "$@" || [ "$?" -le 1 ]; }; lbl_without() { if [ -f "$1" ]; then lbl_grep -v -- "$2" "$1" || return 1; fi; [ -z "${3:-}" ] || printf '%s\n' "$3"; }; }   # write-blind: the shim of a missing library is the old line

if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
command -v carrier_up_mark >/dev/null 2>&1 || carrier_up_mark() { return 0; }
if carrier_barred; then
    echo "VPN выключен вручную — awg0 не поднимаю (включить: тумблер в панели)"
    exit 1
fi
if [ ! -f "$config_file" ]; then
    echo "File $config_file not found"
    exit 1
fi






address=$(grep -E '^[[:space:]]*Address[[:space:]]*=' "$config_file" | head -1 | sed 's/^[^=]*=[[:space:]]*//' | cut -d',' -f1 | tr -d ' \t\r')



mtu=$(grep -E '^[[:space:]]*MTU[[:space:]]*=' "$config_file" | head -1 | sed 's/^[^=]*=[[:space:]]*//' | tr -d ' \t\r')















AWG_MTU_DEFAULT=1376
echo "AmneziaWG client address: $address"

if [ -f "$interface_config" ]; then
    echo "$interface_config already exists"



    if grep -qiE '^[[:space:]]*listenport[[:space:]]*=' "$interface_config" 2>/dev/null; then
        lbl_commit_out "$interface_config" awk '{ t = tolower($0) } !(t ~ /^[[:space:]]*listenport[[:space:]]*=/)' "$interface_config" 2>/dev/null
    fi
else








    awk '{ t = tolower($0) } !(t ~ /^[[:space:]]*(address|dns|mtu|table|preup|postup|predown|postdown|saveconfig|listenport)[[:space:]]*=/)' "$config_file" > "$interface_config"






    sed -i '/^[[:space:]]*I[1-5][[:space:]]*=[[:space:]]*$/d' "$interface_config" 2>/dev/null
    echo "$interface_config created"
fi

















if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi


if [ -f "$ENODIA_DIR/dns-lib.sh" ]; then . "$ENODIA_DIR/dns-lib.sh"; else
    echo "нет $ENODIA_DIR/dns-lib.sh — обновите установку (панель → «Обновление» или переустановка с компьютера)" >&2; exit 1
fi
ep_src=$(grep -E '^[[:space:]]*Endpoint[[:space:]]*=' "$config_file" | head -1 | sed 's/^[^=]*=[[:space:]]*//' | tr -d ' \t\r')
ep_host=$(echo "$ep_src" | sed 's/:[0-9]*$//')
ep_port=$(echo "$ep_src" | sed -n 's/.*:\([0-9]*\)$/\1/p')
case "$ep_host" in
    ''|\[*) : ;;                                   # нет Endpoint / IPv6-литерал — не наш случай
    *)
        if ! is_ipv4 "$ep_host"; then
            ep_ip=$(resolve_ipv4 "$ep_host")
            if [ -n "$ep_ip" ] && [ -n "$ep_port" ]; then
                sed -i "s|^[[:space:]]*Endpoint[[:space:]]*=.*|Endpoint = $ep_ip:$ep_port|" "$interface_config"
                echo "Endpoint $ep_host -> $ep_ip (подставлен IP: awg setconf не резолвит через мёртвый dnsmasq)"
            else


                echo "ВНИМАНИЕ: не зарезолвил Endpoint '$ep_host' (ни dnsmasq, ни DoH) — awg setconf может отвергнуть конфиг целиком" >&2
            fi
        fi ;;
esac















if [ ! -f "$ENODIA_BIN/awg" ] || [ ! -f "$ENODIA_BIN/amneziawg-go" ]; then
    echo "ERROR: бинари AmneziaWG (awg/amneziawg-go) не найдены." >&2
    echo "       Поставьте AmneziaWG в панели :8088 -> «Компоненты». Качать старую" >&2
    echo "       AWG 1.x с github НЕ будем — она ломает конфиг AWG 2.0." >&2
    exit 1
fi
echo "AmneziaWG binaries exist, setting up awg0 interface"




















awg0_daemon_pids() {
    for p in /proc/[0-9]*; do
        [ -r "$p/cmdline" ] || continue
        case "$(tr '\0' ' ' 2>/dev/null < "$p/cmdline") " in
            *"amneziawg-go awg0 "*) echo "${p#/proc/}" ;;
        esac
    done
}
if [ -n "$(awg0_daemon_pids)" ]; then
    for p in $(awg0_daemon_pids); do kill "$p" 2>/dev/null; done
    i=0
    while [ -n "$(awg0_daemon_pids)" ] && [ "$i" -lt 10 ]; do
        if [ "$i" = 3 ]; then
            for p in $(awg0_daemon_pids); do kill -9 "$p" 2>/dev/null; done
        fi
        sleep 1; i=$((i + 1))
    done
fi
rm -f /var/run/amneziawg/awg0.sock /var/run/wireguard/awg0.sock 2>/dev/null











go_quiet env $(sh "$ENODIA_DIR/net-tune.sh" memlimit-env 2>/dev/null | grep -E '^GOMEMLIMIT=[0-9]+MiB$') "$ENODIA_BIN/amneziawg-go" awg0
"$ENODIA_BIN/awg" setconf awg0 "$interface_config"
if [ -n "$address" ]; then
    ip a add "$address" dev awg0
else
    echo "ERROR: поле Address не найдено в $config_file — awg0 останется БЕЗ IPv4 (туннель не понесёт трафик)." >&2
fi

ip link set dev awg0 mtu "${mtu:-$AWG_MTU_DEFAULT}"



if [ -f "$ENODIA_DIR/net-tune.sh" ]; then
    sh "$ENODIA_DIR/net-tune.sh" mtu >/dev/null 2>&1
fi
ip l set up awg0

if carrier_barred; then
    echo "VPN выключили вручную, пока поднимался awg0, — снимаю его"
    for p in $(awg0_daemon_pids); do kill "$p" 2>/dev/null; done
    ip link del awg0 2>/dev/null
    exit 1
fi




carrier_up_mark










command -v fw3_gen_new >/dev/null 2>&1 || fw3_gen_new() { :; }   # нет ipt-lib — у вызывателей шим «reload был всегда»
awg_zone_ready() {
    [ "$(uci -q get firewall.awg)" = zone ] || return 1
    for _z in name=awg network=awg0 input=ACCEPT output=ACCEPT forward=ACCEPT; do
        [ "$(uci -q get "firewall.awg.${_z%%=*}")" = "${_z#*=}" ] || return 1
    done
    uci show firewall 2>/dev/null | grep -qE "src='awg'|dest='awg'" || return 1
    iptables -S zone_awg_forward >/dev/null 2>&1
}
if awg_zone_ready; then
    echo "Зона awg в фаерволе уже стоит — firewall reload не нужен, правила остаются на месте"
    ip route flush cache









    _awg_wired=1
    iptables -t mangle -C PREROUTING -j VPN_EXCLUDE 2>/dev/null || _awg_wired=0
    if [ "$_awg_wired" = 1 ] && [ "$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')" = awg ]; then
        iptables -C FORWARD -o awg0 -j ACCEPT 2>/dev/null || _awg_wired=0
    fi
    if [ "$_awg_wired" = 0 ]; then
        echo "Нашей проводки в ядре нет (чужой firewall reload?) — отмечаю: вызыватель переиграет правила"
        fw3_gen_new
    fi
else

    uci set firewall.awg=zone
    uci set firewall.awg.name='awg'
    uci set firewall.awg.network='awg0'
    uci set firewall.awg.input='ACCEPT'
    uci set firewall.awg.output='ACCEPT'
    uci set firewall.awg.forward='ACCEPT'
    if ! uci show firewall | grep -qE "src='awg'|dest='awg'"; then
        uci add firewall forwarding
        uci set firewall.@forwarding[-1].src='guest'
        uci set firewall.@forwarding[-1].dest='awg'
        uci add firewall forwarding
        uci set firewall.@forwarding[-1].src='awg'
        uci set firewall.@forwarding[-1].dest='guest'
    fi
    uci commit firewall








    echo "Restarting firewall..."
    echo "--- НИЖЕ ВЫВОД СТОКОВОГО firewall reload (fw3/miwifi). Его ошибки — НЕ наши ---"
    ip route flush cache
    /etc/init.d/firewall reload
    fw3_gen_new
    echo "--- конец вывода стокового firewall reload ---"
fi



















ip route replace 192.168.33.0/24 dev br-guest table main













while ip rule del from 192.168.33.0/24 to 192.168.33.1 dport 53 table main pref 100 2>/dev/null; do :; done



ip rule add from 192.168.33.0/24 to 192.168.33.1 dport 53 table main pref 100



while ip rule del from 192.168.33.0/24 table 200 pref 200 2>/dev/null; do :; done


iptables -C FORWARD -i br-guest -d 192.168.33.1 -p tcp --dport 53 -j ACCEPT 2>/dev/null || iptables -A FORWARD -i br-guest -d 192.168.33.1 -p tcp --dport 53 -j ACCEPT
iptables -C FORWARD -i br-guest -d 192.168.33.1 -p udp --dport 53 -j ACCEPT 2>/dev/null || iptables -A FORWARD -i br-guest -d 192.168.33.1 -p udp --dport 53 -j ACCEPT
iptables -C FORWARD -i br-guest -s 192.168.33.1 -p tcp --sport 53 -j ACCEPT 2>/dev/null || iptables -A FORWARD -i br-guest -s 192.168.33.1 -p tcp --sport 53 -j ACCEPT
iptables -C FORWARD -i br-guest -s 192.168.33.1 -p udp --sport 53 -j ACCEPT 2>/dev/null || iptables -A FORWARD -i br-guest -s 192.168.33.1 -p udp --sport 53 -j ACCEPT


iptables -C FORWARD -i br-guest -o awg0 -j ACCEPT 2>/dev/null || iptables -A FORWARD -i br-guest -o awg0 -j ACCEPT
iptables -C FORWARD -i awg0 -o br-guest -j ACCEPT 2>/dev/null || iptables -A FORWARD -i awg0 -o br-guest -j ACCEPT


guest_dns on


iptables -t nat -C POSTROUTING -s 192.168.33.0/24 -o awg0 -j MASQUERADE 2>/dev/null || iptables -t nat -A POSTROUTING -s 192.168.33.0/24 -o awg0 -j MASQUERADE


echo 1 > /proc/sys/net/ipv4/ip_forward
