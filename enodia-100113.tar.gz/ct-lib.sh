#!/bin/sh































CT_ECM_DEFUNCT=/sys/kernel/debug/ecm/ecm_db/defunct_all   # ручка ускорителя (debugfs, root, 0644)
CT_PROC=/proc/net/nf_conntrack                            # таблица соединений — читается и без утилиты

_ct_have_tool() { command -v conntrack >/dev/null 2>&1; }



_ct_ecm_defunct() {
	[ -w "$CT_ECM_DEFUNCT" ] || return 1
	echo 1 > "$CT_ECM_DEFUNCT" 2>/dev/null || return 1
}


ct_flush() {
	[ "${CT_SLOT_EDIT:-}" != defer ] || return 0
	if _ct_have_tool; then conntrack -F >/dev/null 2>&1 || true; return 0; fi
	_ct_ecm_defunct || true
	return 0
}





















CT_MARK_MASK=0xff


if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi
CT_SAVE_CHAIN=POSTROUTING
CT_SAVE_SPEC="-m conntrack --ctdir ORIGINAL -m comment --comment enodia-ctmark -j CONNMARK --save-mark --nfmask $CT_MARK_MASK --ctmask $CT_MARK_MASK"





ct_mark_save() {
	case "$1" in
		on)    case "$(iptables -t mangle -S "$CT_SAVE_CHAIN" 2>/dev/null | sed -n 2p)" in *"--comment enodia-ctmark "*) return 0 ;; esac
		       while iptables -t mangle -D "$CT_SAVE_CHAIN" $CT_SAVE_SPEC 2>/dev/null; do :; done
		       iptables -t mangle -I "$CT_SAVE_CHAIN" 1 $CT_SAVE_SPEC 2>/dev/null ;;
		off)   while iptables -t mangle -D "$CT_SAVE_CHAIN" $CT_SAVE_SPEC 2>/dev/null; do :; done; return 0 ;;
		check) iptables -t mangle -C "$CT_SAVE_CHAIN" $CT_SAVE_SPEC 2>/dev/null ;;
		*)     return 1 ;;
	esac
}


ct_flush_mark() {
	[ -n "$1" ] || return 0
	if _ct_have_tool; then conntrack -D --mark "$1/$CT_MARK_MASK" >/dev/null 2>&1 || true; return 0; fi
	_ct_ecm_defunct || true
	return 0
}


slot_rule_rows() {
	awk -v id="$1" '$2=="from" && $3=="all" && $4=="fwmark" && $5=="0x" id &&
		($6=="lookup" || $6=="table") && $7 ~ /^100[02-7]$/ &&
		($1=="9" id ":" || $1 ~ /^11[0-5]:$/) {print $1+0, $7}'
}

slot_route_default() { ip route show table "$1" 2>/dev/null | grep -q '^default[[:space:]]'; }   # not-wan: owned table
slot_owned_default() {   # id, transport
	case "$2" in awg) set -- "$1" "awg$1" ;; xray|hy2|byedpi) set -- "$1" "xtun$1" ;; *) return 1 ;; esac
	ip route show table "100$1" 2>/dev/null | grep -qE "^default .*dev $2( |$)"   # not-wan: owned table
}


slot_rule_path() (
	while read -r _ct_pref _ct_table; do
		[ -n "$_ct_table" ] || continue
		if [ "$_ct_table" = "$1" ] || slot_route_default "$_ct_table"; then echo "$_ct_table"; exit 0; fi
	done
)




ct_flush_route() (
	if ! _ct_have_tool || ! ct_mark_save check; then
		if [ "$3" = strict ]; then ct_flush_mark "$1"; else ct_flush; fi
		return 0
	fi
	ct_flush_mark "$1"
	[ -n "$2" ] || return 0
	_ct_rules=$(ip rule show 2>/dev/null) || return 0
	printf '%s\n' "$_ct_rules" | awk -v t="$2" '{
		l = ""; m = ""; d = ""
		for (i = 1; i < NF; i++) {
			if ($i == "lookup" || $i == "table") l = $(i + 1)
			if ($i == "fwmark") m = $(i + 1)
			if ($i == "to") d = $(i + 1)
		}
		if (l != t) next
		if (m != "") print "m " m; else if (d != "") print "d " d
	}' | sort -u | while read -r _ctk _ctv; do
		case "$_ctk" in
			m) _ct_mark=${_ctv%%/*}
			   [ "$_ct_mark" != "$1" ] || continue
			   case "$_ct_mark" in 0x[2-7])
			       _ct_path=$(printf '%s\n' "$_ct_rules" | slot_rule_rows "${_ct_mark#0x}" | slot_rule_path "$2")
			       [ -z "$_ct_path" ] || [ "$_ct_path" = "$2" ] || continue ;;
			   esac
			   ct_flush_mark "$_ct_mark" ;;
			d) ct_flush_dst "${_ctv%/32}" ;;
		esac
	done
	return 0
)


ct_flush_slot() {
	case "$1" in [2-7]) ;; *) return 1 ;; esac
	case "${CT_SLOT_EDIT:-}" in
		defer) return 0 ;;
		[2-7]) [ "$1" = "$CT_SLOT_EDIT" ] || return 0 ;;
	esac
	if [ "$2" = origin ]; then ct_flush_mark "0x$1"; else ct_flush_route "0x$1" "100$1" strict; fi
}



ct_flush_src() {
	[ "${CT_SLOT_EDIT:-}" != defer ] || return 0
	[ -n "$1" ] || return 0
	if _ct_have_tool; then conntrack -D --src "$1" >/dev/null 2>&1 || true; return 0; fi
	_ct_ecm_defunct || true
	return 0
}





ct_flush_src_n() {
	[ -n "$1" ] || return 0
	if _ct_have_tool; then conntrack -D --src "$1" 2>/dev/null | wc -l; return 0; fi
	_ct_ecm_defunct || true
	return 0
}



ct_flush_dst() {
	[ "${CT_SLOT_EDIT:-}" != defer ] || return 0
	[ -n "$1" ] || return 0
	if _ct_have_tool; then
		if [ -n "$2" ]; then conntrack -D -p tcp -d "$1" --dport "$2" >/dev/null 2>&1 || true
		else                 conntrack -D -d "$1" >/dev/null 2>&1 || true; fi
		return 0
	fi
	_ct_ecm_defunct || true
	return 0
}



ct_flush_dport() {
	[ -n "$1" ] || return 0
	if _ct_have_tool; then conntrack -D -p tcp --dport "$1" >/dev/null 2>&1 || true; return 0; fi
	_ct_ecm_defunct || true
	return 0
}









ct_list_src() {
	[ -n "$1" ] || return 0
	if _ct_have_tool; then conntrack -L -s "$1" 2>/dev/null; return 0; fi
	[ -r "$CT_PROC" ] || return 0
	awk -v ip="$1" '{ for(i=1;i<=NF;i++) if (substr($i,1,4)=="src=") { if (substr($i,5)==ip) print; break } }' \
		"$CT_PROC" 2>/dev/null
	return 0
}





ct_list_all() {
	if _ct_have_tool; then conntrack -L 2>/dev/null; return 0; fi
	[ -r "$CT_PROC" ] || return 0
	cat "$CT_PROC" 2>/dev/null
	return 0
}




ct_tool() {
	if _ct_have_tool; then echo conntrack
	elif [ -w "$CT_ECM_DEFUNCT" ]; then echo ecm
	else echo none; fi
}
