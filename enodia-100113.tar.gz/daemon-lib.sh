#!/bin/sh































DAEMON_WAIT_STORE=${DAEMON_WAIT_STORE:-60}



DAEMON_PID_GRACE=${DAEMON_PID_GRACE:-3}

DAEMON_WAIT_WHY=''


daemon_wait_secs() {   # $1 = имя бинаря ; $2 = срок для флеша ; -> секунды
    _dws=${2:-8}
    if daemon_on_store "$1" && [ "$_dws" -lt "$DAEMON_WAIT_STORE" ]; then _dws=$DAEMON_WAIT_STORE; fi
    printf '%s' "$_dws"
}



daemon_on_store() {   # $1 = имя бинаря
    command -v bin_on_store >/dev/null 2>&1 || return 1
    bin_on_store "$1"
}







daemon_where_ru() {   # $1 = имя бинаря
    if daemon_on_store "$1"; then printf 'на накопителе'; return 0; fi
    command -v bin_where >/dev/null 2>&1 || { printf 'носитель неизвестен'; return 0; }
    case "$(bin_where "$1" 2>/dev/null)" in
        '') printf 'не найден' ;;
        *)  printf 'на флеше роутера' ;;
    esac
}








pid_runs() { [ -n "$1" ] && [ -r "/proc/$1/cmdline" ] && tr '\000' ' ' 2>/dev/null < "/proc/$1/cmdline" | grep -qE "$2"; }


server_candidates() {
    _dsc_kind=$1; shift
    if [ ! -s "$ENODIA_STATE/.server-favs" ] || [ ! -f "$ENODIA_DIR/server-favs.sh" ]; then printf '%s\n' "$@"; return; fi
    {
        sh "$ENODIA_DIR/server-favs.sh" list
        printf '%s\n' --
        printf '%s\n' "$@"
    } | awk -v kind="$_dsc_kind/" '
        $0 == "--" { paths=1; next }
        !paths { if (index($0,kind)==1) fav[++f]=$0; next }
        {
            path[++n]=$0; key=$0; sub(/^.*\//,"",key); sub(/\.[^.]+$/,"",key)
            pos[kind key]=n
        }
        END {
            for (i=1; i<=f; i++) if (fav[i] in pos) { j=pos[fav[i]]; print path[j]; used[j]=1 }
            for (i=1; i<=n; i++) if (!(i in used)) print path[i]
        }'
}


SETTLE_LOCK=${SETTLE_LOCK:-/tmp/enodia-vpnoff-settle.lock}
settle_lock_take() {
    _stw=0
    while ! ( set -C; echo $$ > "$SETTLE_LOCK" ) 2>/dev/null; do
        _sth=$(cat "$SETTLE_LOCK" 2>/dev/null | tr -cd '0-9')
        if { [ -n "$_sth" ] && ! pid_runs "$_sth" '(vpn-toggle|mark-core)\.sh'; } ||
           { [ -z "$_sth" ] && [ "$_stw" -ge 2 ]; }; then
            rm -f "$SETTLE_LOCK" 2>/dev/null || return 1
        else
            [ "$_stw" -lt "${1:-60}" ] || return 1
            sleep 1; _stw=$((_stw + 1))
        fi
    done
}
settle_lock_drop() { [ "$(cat "$SETTLE_LOCK" 2>/dev/null)" = "$$" ] && rm -f "$SETTLE_LOCK" 2>/dev/null; return 0; }









lists_work_alive() {
    _lwa=$(cat /proc/[0-9]*/cmdline 2>/dev/null | tr '\000' '\n')
    printf '%s\n' "$_lwa" | grep -qxF -e "$ENODIA_DIR/lists-update.sh" -e "$ENODIA_DIR/geo.sh" -e "$ENODIA_DIR/iplist-update.sh"
}







switch_holder_mark() { ENODIA_SWITCH_HOLDER=$$; export ENODIA_SWITCH_HOLDER; }



switch_work_alive() {   # $1 — пид держателя из лока
    case "$1" in ''|*[!0-9]*) return 1 ;; esac
    for _swf in $(grep -l "ENODIA_SWITCH_HOLDER=$1" /proc/[0-9]*/environ 2>/dev/null); do
        tr '\000' '\n' 2>/dev/null < "$_swf" | grep -qxF "ENODIA_SWITCH_HOLDER=$1" || continue
        tr '\000' '\n' 2>/dev/null < "${_swf%/environ}/cmdline" | awk -v d="$ENODIA_DIR/" \
            'substr($0, 1, length(d)) == d && substr($0, length($0) - 2) == ".sh" { f = 1 } END { exit f ? 0 : 1 }' && return 0
    done
    return 1
}








switch_lock_reap() {   # $1 — содержимое лока, по которому вызывающий признал его мёртвым; $2 — его mtime (`date -r`), опц.
    _srl=${SWITCH_LOCK:-/tmp/enodia-switching.lock}
    if ! mkdir "$_srl.reap" 2>/dev/null; then


        _srm=$(date -r "$_srl.reap" +%s 2>/dev/null)
        case "$_srm" in ''|*[!0-9]*) return 1 ;; esac
        [ $(( $(date +%s) - _srm )) -gt 10 ] || return 1   # clock-raw: брошенный мьютекс живёт микросекунды — скачок часов лишь снимет его раньше
        rmdir "$_srl.reap" 2>/dev/null; mkdir "$_srl.reap" 2>/dev/null || return 1
    fi
    if [ "$(cat "$_srl" 2>/dev/null | tr -d ' \r\n')" = "$1" ] && { [ -z "$2" ] || [ "$(date -r "$_srl" +%s 2>/dev/null)" = "$2" ]; }; then
        rm -f "$_srl" 2>/dev/null
    fi
    rmdir "$_srl.reap" 2>/dev/null
    return 0
}






DL_WD_LOCK=${ENODIA_WD_LOCK:-/tmp/enodia-watchdog.lock}
DL_WD_PID=${ENODIA_WD_PID:-/tmp/enodia-watchdog.pid}
DL_HEAL_LOCK=${ENODIA_HEAL_LOCK:-/tmp/enodia-heal.lock}
wd_tick_alive() {
    [ -e "$DL_WD_LOCK" ] || return 1
    _wta=$(cat "$DL_WD_PID" 2>/dev/null | tr -cd '0-9')
    pid_runs "$_wta" 'watchdog\.sh'
}




DL_REPLAY_PID=${ENODIA_REPLAY_PID:-/tmp/enodia-heal-replay.pid}
heal_alive() {
    _hla=$(cat "$DL_HEAL_LOCK" 2>/dev/null | tr -d '\r'); _hla=${_hla%% *}
    case "$_hla" in ''|*[!0-9]*) _hla= ;; esac
    [ -n "$_hla" ] && pid_runs "$_hla" 'heal\.sh' && return 0
    _hlr=$(cat "$DL_REPLAY_PID" 2>/dev/null | tr -cd '0-9')
    pid_runs "$_hlr" 'heal\.sh'
}


carrier_busy() { wd_tick_alive || heal_alive; }







switch_hold() {   # $1 — путь лока, $2 — потолок ожидания, с, [$3 — пауза перед переспросом тика, с; деф. 1]
    _shw=0; DL_HOLD_MINE=0
    while :; do
        _shp=$(cat "$1" 2>/dev/null | tr -d ' \r\n')
        case "$_shp" in ''|*[!0-9]*) ;; *) [ -d "/proc/$_shp" ] || switch_work_alive "$_shp" || SWITCH_LOCK=$1 switch_lock_reap "$_shp" ;; esac
        if ! carrier_busy && ( set -C; echo $$ > "$1" ) 2>/dev/null; then
            DL_HOLD_MINE=1
            sleep "${3:-1}"
            while carrier_busy && [ "$_shw" -lt "$2" ]; do sleep 1; _shw=$((_shw + 1)); done
            carrier_busy || { switch_holder_mark; return 0; }
            rm -f "$1" 2>/dev/null; DL_HOLD_MINE=0
        fi
        [ "$_shw" -ge "$2" ] && return 1
        sleep 1; _shw=$((_shw + 1))
    done
}




DL_MODE_PID=${ENODIA_MODE_PID:-/tmp/enodia-store-mode.pid}
store_mode_alive() {
    _sma=$(cat "$DL_MODE_PID" 2>/dev/null | tr -cd '0-9')
    pid_runs "$_sma" 'usb-offload\.sh.* mode'
}



DL_PKG_LOCK=${ENODIA_PKG_INST_LOCK:-/tmp/enodia-pkg-install.lock}
pkg_install_alive() {
    _pia=$(cat "$DL_PKG_LOCK/pid" 2>/dev/null | tr -cd '0-9')
    pid_runs "$_pia" 'pkg-install\.sh'
}



DL_UNINST_PID=${ENODIA_UNINST_PID:-/tmp/enodia-uninstall.pid}
uninstall_alive() {
    _ual=$(cat "$DL_UNINST_PID" 2>/dev/null | tr -cd '0-9')
    pid_runs "$_ual" 'uninstall\.sh (deactivate|purge)'
}










carrier_barred() { [ -f "$ENODIA_STATE/.vpn-off" ] || [ -f "$ENODIA_STATE/.vpn-deactivated" ]; }

slot_rows() {   # enabled|admitted|off [id] [transport] [registry]
    [ "$1" = enabled ] || [ ! -f "$ENODIA_STATE/.vpn-deactivated" ] || return 0
    _slr_mode=$1
    if [ "$1" = admitted ] && [ -f "$ENODIA_STATE/.vpn-off" ]; then _slr_mode=off; fi
    _slr_file=${4:-$ENODIA_STATE/.slots}
    [ -s "$_slr_file" ] || return 0
    awk -F '\t' -v OFS='\t' -v mode="$_slr_mode" -v id="${2:-}" -v kind="${3:-}" '
        $1~/^[2-7]$/ && $6=="on" && (id=="" || $1==id) && (kind=="" || $3==kind) &&
        (mode!="off" || (NF==7 && $7=="keep_when_off=1")) {print $1,$3,$4,$5}
    ' "$_slr_file"
}
slot_admitted() { [ -n "$(slot_rows admitted "$@")" ]; }
slot_kept() { [ -n "$(slot_rows off "$@")" ]; }
carrier_run_barred() {
    if [ -n "$2" ]; then ! slot_admitted "$1" "$2"; else carrier_barred; fi
}
_crlog() { if command -v log >/dev/null 2>&1; then log "$1"; else echo "$1"; fi; }

carrier_run() {
    _crslot='' _crkind=''
    if [ "$1" = -s ]; then _crkind=$2; shift 2; _crslot=$3; fi
    _cru=$1; _crf=$2; shift 2
    if carrier_run_barred "$_crslot" "$_crkind"; then _crlog "VPN выключен вручную — несущую не поднимаю"; return 1; fi
    "$_crf" "$@"; _crr=$?
    carrier_run_barred "$_crslot" "$_crkind" || return "$_crr"
    _crlog "VPN выключили вручную, пока поднималась несущая, — отпускаю её"
    "$_cru" "$@" >/dev/null 2>&1
    return 1
}




exe_deleted() { ls -l /proc/[0-9]*/exe 2>/dev/null | sed -n 's#^.* /proc/\([0-9][0-9]*\)/exe -> \(.*\) (deleted)$#\1 \2#p'; }





proc_tree() {
	_pt_all="$1"; _pt_q="$1"
	while [ -n "$_pt_q" ]; do
		_pt_n=""
		for _pt_p in $_pt_q; do
			for _pt_f in $(grep -l "^PPid:[[:space:]]*$_pt_p\$" /proc/[0-9]*/status 2>/dev/null); do
				_pt_c=${_pt_f#/proc/}; _pt_n="$_pt_n ${_pt_c%/status}"
			done
		done
		_pt_all="$_pt_all$_pt_n"; _pt_q=$_pt_n
	done
	echo "$_pt_all"
}










proc_tree_kill() {
	_ptk=''; _ptk_i=0; _ptk_all=''
	while :; do
		_ptk_n=$(proc_tree "$1")
		kill -STOP $_ptk_n 2>/dev/null
		_ptk_all="$_ptk_all $_ptk_n"
		[ "$_ptk_n" = "$_ptk" ] && break
		_ptk=$_ptk_n; _ptk_i=$((_ptk_i+1))
		[ "$_ptk_i" -lt 8 ] || break
	done
	kill -TERM $_ptk_all 2>/dev/null; kill -CONT $_ptk_all 2>/dev/null
	case "${2:-}" in ''|0|*[!0-9]*) ;; *) sleep "$2"; kill -KILL $_ptk_all 2>/dev/null ;; esac
	return 0
}





daemon_wait_gone() {   # $1 pid ; $2 потолок, с (по умолчанию 5) -> 0 процесса нет, 1 ещё жив
    case "$1" in ''|*[!0-9]*) return 0 ;; esac
    _dwg=0; _dwgm=$(( ${2:-5} * 10 ))
    while [ -d "/proc/$1" ]; do
        [ "$_dwg" -ge "$_dwgm" ] && return 1
        if command -v usleep >/dev/null 2>&1; then usleep 100000; else sleep 1; _dwg=$((_dwg+9)); fi
        _dwg=$((_dwg+1))
    done
    return 0
}
daemon_port_listens()  { netstat -ltn 2>/dev/null | grep -q "$1:$2 "; }
daemon_uport_listens() { netstat -lnu 2>/dev/null | grep -q "$1:$2 "; }   # UDP: резолвер DoH/DoT
daemon_dev_exists()    { ip link show "$1" >/dev/null 2>&1; }




daemon_step_init() { DAEMON_STEP_Q=1; if command -v usleep >/dev/null 2>&1; then DAEMON_STEP_Q=5; fi; }
daemon_step() { if [ "${DAEMON_STEP_Q:-1}" = 5 ]; then usleep 200000; else sleep 1; fi; }




_daemon_wait() {   # $1 пидфайл ; $2 бинарь ; $3 срок-на-флеше ; $4 «чего ждём» словами ; далее — КОМАНДА-проба
    _dwpid="$1"; _dwbin="$2"; _dwwhat="$4"
    _dwmax=$(daemon_wait_secs "$_dwbin" "$3")
    shift 4



    _dwi=0; _dwt=0; daemon_step_init; _dwq=$DAEMON_STEP_Q
    while :; do
        if "$@"; then DAEMON_WAIT_WHY=''; return 0; fi






        _dwp=$(cat "$_dwpid" 2>/dev/null | tr -d ' \r\n')
        if [ -z "$_dwp" ]; then
            if [ "$_dwi" -ge "$DAEMON_PID_GRACE" ]; then
                DAEMON_WAIT_WHY="процесс НЕ ЗАПУСТИЛСЯ (пидфайл $_dwpid пуст через $_dwi с), $_dwwhat не появился"
                return 1
            fi
        elif [ ! -d "/proc/$_dwp" ]; then
            DAEMON_WAIT_WHY="процесс УМЕР через $_dwi с — $_dwwhat не появился"
            return 1
        fi
        [ "$_dwi" -ge "$_dwmax" ] && break
        daemon_step
        _dwt=$((_dwt+1)); _dwi=$((_dwt/_dwq))
    done
    DAEMON_WAIT_WHY="процесс ЖИВ, но за $_dwmax с $_dwwhat не появился (бинарь $_dwbin $(daemon_where_ru "$_dwbin"))"
    return 1
}


daemon_wait_port() {   # $1 пидфайл ; $2 бинарь ; $3 срок-на-флеше ; $4 адрес ; $5 порт
    _daemon_wait "$1" "$2" "$3" "порт $4:$5" daemon_port_listens "$4" "$5"
}



daemon_wait_uport() {  # $1 пидфайл ; $2 бинарь ; $3 срок-на-флеше ; $4 адрес ; $5 порт
    _daemon_wait "$1" "$2" "$3" "порт $4:$5/udp" daemon_uport_listens "$4" "$5"
}


daemon_wait_dev() {    # $1 пидфайл ; $2 бинарь ; $3 срок-на-флеше ; $4 имя интерфейса
    _daemon_wait "$1" "$2" "$3" "устройство $4" daemon_dev_exists "$4"
}










go_quiet() {


    [ -z "${LOG_LEVEL:-}" ] || { "$@"; return $?; }
    _gqf=$(mktemp /tmp/enodia-awg-start.XXXXXX 2>/dev/null) || { "$@"; return $?; }
    "$@" 2>"$_gqf"; _gqr=$?

    grep -v -e '^┌' -e '^│' -e '^└' -e '^| https://github\.com/amnezia-vpn/' "$_gqf" >&2
    rm -f "$_gqf"
    return "$_gqr"
}







DAEMON_LOG_PREV=${DAEMON_LOG_PREV:-60}   # lines kept from the previous run
daemon_log_fresh() {   # $1 = log path
    if [ -s "$1" ]; then tail -n "$DAEMON_LOG_PREV" "$1" > "$1.prev" 2>/dev/null || rm -f "$1.prev" 2>/dev/null; fi
    : > "$1" 2>/dev/null || true
}






DAEMON_GO_NEED_KB=${DAEMON_GO_NEED_KB:-40960}         # a Go tunnel daemon at its start: 39 MB measured (a test xray, BE6500 armv7)
DAEMON_RAM_RESERVE_KB=${DAEMON_RAM_RESERVE_KB:-49152}  # what the system keeps after it
DAEMON_RAM_WHY=''
daemon_ram_room() {   # $1 = KB the new daemon takes → 0 room; 1 none (DAEMON_RAM_WHY — the numbers, in words)
    DAEMON_RAM_WHY=''
    _drm=$(awk '/^MemAvailable:/{a=$2}/^MemFree:/{f=$2}END{printf "%.0f", (a==""?f:a)}' "${MEMINFO:-/proc/meminfo}" 2>/dev/null)
    case "$_drm" in ''|*[!0-9]*) return 0 ;; esac
    [ "$_drm" -ge $(( $1 + DAEMON_RAM_RESERVE_KB )) ] && return 0
    DAEMON_RAM_WHY="доступно $(( _drm / 1024 )) МБ, нужно $(( ($1 + DAEMON_RAM_RESERVE_KB) / 1024 ))"
    return 1
}





XRAY_EGRESS_TIMEOUT=8   # one egress attempt, shared by readiness and health
daemon_xray_ready() {
    command -v xp_pool >/dev/null 2>&1 || return 0
    xp_pool "$2" || return 0
    command -v uptime_s >/dev/null 2>&1 || {
        if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi
    }
    command -v uptime_s >/dev/null 2>&1 || uptime_s() { _cl_u=$(awk '{print int($1)}' /proc/uptime 2>/dev/null); case "$_cl_u" in ''|*[!0-9]*) _cl_u=999999999 ;; esac; echo "$_cl_u"; }
    _dxr_pid=$(cat "$1" 2>/dev/null | tr -cd '0-9')
    [ -n "$_dxr_pid" ] && [ -r "/proc/$_dxr_pid/stat" ] || return 1
    _dxr_start=$(awk '{print $22}' "/proc/$_dxr_pid/stat")
    _dxr_mark="$1.pool-ready"
    _dxr_mp=''; _dxr_ms=''; _dxr_end=''
    if [ -r "$_dxr_mark" ]; then read -r _dxr_mp _dxr_ms _dxr_end < "$_dxr_mark" || true; fi
    if [ "$_dxr_mp" != "$_dxr_pid" ] || [ "$_dxr_ms" != "$_dxr_start" ]; then
        _dxr_end=$(( $(uptime_s)+30 ))
        if [ -f "$ENODIA_DIR/label-lib.sh" ]; then . "$ENODIA_DIR/label-lib.sh"; fi
        command -v lbl_commit_out >/dev/null 2>&1 || return 1
        lbl_commit_out "$_dxr_mark" printf '%s %s %s\n' "$_dxr_pid" "$_dxr_start" "$_dxr_end" || return 1
    fi
    [ "$_dxr_end" != ready ] || return 0
    case "$_dxr_end" in ''|*[!0-9]*) return 1 ;; esac
    daemon_step_init
    while :; do
        pid_runs "$_dxr_pid" 'xray' || { DAEMON_WAIT_WHY='xray exited during pool warm-up'; return 1; }
        _dxr_timeout=$((_dxr_end - $(uptime_s)))
        [ "$_dxr_timeout" -gt 0 ] || break
        [ "$_dxr_timeout" -le "$XRAY_EGRESS_TIMEOUT" ] || _dxr_timeout=$XRAY_EGRESS_TIMEOUT
        _dxr_ip=$(IP_PROBE_END="$_dxr_end" probe_ext_ip "--socks5-hostname 127.0.0.1:$3" "$_dxr_timeout")
        if [ -n "$_dxr_ip" ]; then
            lbl_commit_out "$_dxr_mark" printf '%s %s ready\n' "$_dxr_pid" "$_dxr_start" || return 1
            DAEMON_WAIT_WHY=''; return 0
        fi
        [ "$(uptime_s)" -lt "$_dxr_end" ] || break
        daemon_step
    done
    DAEMON_WAIT_WHY='pool has no usable egress after bounded observatory warm-up'
    return 1
}

proc_start_id() {
	case "$1" in ''|*[!0-9]*|0|1) return 1 ;; esac
	awk '{ sub(/^.*\) /, ""); if ($1 != "Z" && NF >= 20) print $20 }' "/proc/$1/stat" 2>/dev/null
}

proc_ref_alive() { [ -n "$2" ] && [ "$(proc_start_id "$1")" = "$2" ]; }
proc_ref_tree_kill() (
	proc_ref_alive "$1" "$2" || exit 0
	_prtk_root=$1; _prtk_ref=$2; _prtk_seen=''; _prtk_round=0
	while proc_ref_alive "$_prtk_root" "$_prtk_ref" && [ "$_prtk_round" -lt 8 ]; do
		_prtk_new=0
		for _prtk_p in $(proc_tree "$_prtk_root"); do
			case " $_prtk_seen " in *" $_prtk_p:"*) continue ;; esac
			_prtk_s=$(proc_start_id "$_prtk_p"); [ -n "$_prtk_s" ] || continue
			proc_ref_alive "$_prtk_p" "$_prtk_s" && kill -STOP "$_prtk_p" 2>/dev/null
			_prtk_seen="$_prtk_seen $_prtk_p:$_prtk_s"; _prtk_new=1
		done
		[ "$_prtk_new" = 1 ] || break
		_prtk_round=$((_prtk_round + 1))
	done
	for _prtk_r in $_prtk_seen; do
		_prtk_p=${_prtk_r%:*}; _prtk_s=${_prtk_r#*:}
		if proc_ref_alive "$_prtk_p" "$_prtk_s"; then kill -TERM "$_prtk_p" 2>/dev/null; kill -CONT "$_prtk_p" 2>/dev/null; fi
	done
	sleep 1
	for _prtk_r in $_prtk_seen; do
		_prtk_p=${_prtk_r%:*}; _prtk_s=${_prtk_r#*:}
		proc_ref_alive "$_prtk_p" "$_prtk_s" && kill -KILL "$_prtk_p" 2>/dev/null
	done
	exit 0
)

awg_peers_match() {   # awg binary, interface, config; 2 if live peers cannot be read
    local _ap_expected _ap_live
    [ -n "$1" ] || return 0
    _ap_expected=$(sed -n 's/^[[:space:]]*PublicKey[[:space:]]*=[[:space:]]*//p' "$3" 2>/dev/null | sed 's/#.*//' | tr -d ' \t\r' | sort -u)
    [ -n "$_ap_expected" ] || return 0
    _ap_live=$("$1" show "$2" peers 2>/dev/null) || return 2
    _ap_live=$(printf '%s\n' "$_ap_live" | tr -d ' \t\r' | sort -u)
    [ -n "$_ap_live" ] || return 2
    [ "$_ap_live" = "$_ap_expected" ]
}

carrier_endpoint() {   # slot ID or empty for main, IPv4 rows, [typed key], [held IPv4 rows], [dial names]
    [ -f "$APPLY_BYPASS" ] || return 0
    if [ -n "$1" ]; then
        sh "$APPLY_BYPASS" endpoint-slot-set "$@" >/dev/null
    else
        shift
        sh "$APPLY_BYPASS" endpoint-set "$@" >/dev/null
    fi
}
