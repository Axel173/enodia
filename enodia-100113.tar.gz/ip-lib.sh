#!/bin/sh













IP_PROBE_TRACE="https://1.1.1.1/cdn-cgi/trace"      # DNS-free дефолт; Cloudflare ∈ iplist_set














IP_PROBE_TRACE2="https://1.0.0.1/cdn-cgi/trace"
IP_PROBE_URL="${IP_PROBE_URL:-$IP_PROBE_TRACE}"      # можно переопределить окружением/аргументом





_ip_from_body() {
    _e=$(printf '%s\n' "$1" | sed -n 's/^ip=\([0-9.]*\).*/\1/p' | head -1)
    [ -n "$_e" ] || _e=$(printf '%s' "$1" | tr -d ' \t\r\n')
    printf '%s' "$_e" | grep -qE '^([0-9]{1,3}\.){3}[0-9]{1,3}$' && printf '%s' "$_e"
}













probe_ext_ip() {
    _pa="$1"; _pt="${2:-7}"; _url="${3:-$IP_PROBE_URL}"; _pn="${4:-1}"
    [ -n "$_url" ] || _url="$IP_PROBE_TRACE"
    _body=$(curl -s -k $_pa --max-time "$_pt" "$_url" 2>/dev/null)   # $_pa НАМЕРЕННО без кавычек — сплит на аргументы
    _ip=$(_ip_from_body "$_body")
    [ -n "$_ip" ] && { printf '%s' "$_ip"; return 0; }
    if [ "$_url" != "$IP_PROBE_TRACE" ]; then                         # primary был кастомным — добиваем trace'ом
        if [ -n "${IP_PROBE_END:-}" ]; then
            if ! command -v uptime_s >/dev/null 2>&1 && [ -n "${ENODIA_DIR:-}" ] && [ -f "$ENODIA_DIR/clock-lib.sh" ]; then
                . "$ENODIA_DIR/clock-lib.sh"
            fi
            command -v uptime_s >/dev/null 2>&1 || uptime_s() { _cl_u=$(awk '{print int($1)}' /proc/uptime 2>/dev/null); case "$_cl_u" in ''|*[!0-9]*) _cl_u=999999999 ;; esac; echo "$_cl_u"; }
            _ip_left=$((IP_PROBE_END - $(uptime_s)))
            [ "$_ip_left" -gt 0 ] || return 0
            [ "$_pt" -le "$_ip_left" ] || _pt=$_ip_left
        fi
        _body=$(curl -s -k $_pa --max-time "$_pt" "$IP_PROBE_TRACE" 2>/dev/null)
        _ip=$(_ip_from_body "$_body")
        [ -n "$_ip" ] && { printf '%s' "$_ip"; return 0; }
    fi


    if [ "$_pn" -gt 1 ] 2>/dev/null; then
        case "$_pa" in
            *--interface*|*--socks5*)
                _body=$(curl -s -k $_pa --max-time "$_pt" "$IP_PROBE_TRACE2" 2>/dev/null)
                _ip_from_body "$_body" ;;
        esac
    fi








    return 0
}





is_private_ip() {
    case "$1" in
        10.*|127.*|169.254.*|192.168.*) return 0 ;;
        172.1[6-9].*|172.2[0-9].*|172.3[0-1].*) return 0 ;;
        100.6[4-9].*|100.[7-9][0-9].*|100.1[0-1][0-9].*|100.12[0-7].*) return 0 ;;
    esac
    return 1
}








ip_is_self() {
    [ -n "$1" ] || return 1
    case "$(ip route get "${1%/32}" 2>/dev/null | sed -n 1p)" in
        "local "*) return 0 ;;
    esac
    return 1
}


















wan_iface() {
    ip route show default 2>/dev/null | awk '/^default/{d=""; for(i=1;i<=NF;i++) if($i=="dev") d=$(i+1); if(d!="" && d !~ /^(awg|xtun)/){print d; exit}}'
}


ipv6_endpoint_unreachable() (
    case "$1" in \[*\]) set -- "${1#\[}"; set -- "${1%\]}" ;; esac
    case "$1" in *[!0-9a-fA-F:.]*) exit 1 ;; *:*) ;; *) exit 1 ;; esac
    awk -v s="$1" 'BEGIN {
        if (s ~ /:::/) exit 1
        if (s ~ /\./) {
            n=split(s,a,":"); v=a[n]; k=split(v,b,".")
            if(k!=4) exit 1
            for(i=1;i<=4;i++) if(b[i] !~ /^[0-9]+$/ || b[i]+0>255) exit 1
            s=substr(s,1,length(s)-length(v)) "0:0"
        }
        t=s; c=gsub(/::/,"X",t); if(c>1 || t ~ /::/) exit 1
        if(c==0 && (s ~ /^:/ || s ~ /:$/)) exit 1
        n=split(s,a,":"); groups=0
        for(i=1;i<=n;i++) if(a[i]!="") {
            if(length(a[i])>4 || a[i] !~ /^[0-9a-fA-F]+$/) exit 1
            groups++
        }
        if (c ? groups>=8 : groups!=8) exit 1
        # An IPv4-mapped destination has five zero words, then ffff.
        pad=8-groups; pos=0
        for(i=1;i<=n;i++) {
            if(a[i]=="") { pos+=pad; pad=0; continue }
            if(++pos==6) exit tolower(a[i])=="ffff"
            if(a[i] !~ /^0+$/) exit 0
        }
    }' || exit 1
    _v6r=$(LC_ALL=C ip -6 route get "$1" 2>&1)
    case "${_v6r#ip: }" in
        prohibit|prohibit\ *|unreachable|unreachable\ *|blackhole|blackhole\ *|\
        'RTNETLINK answers: Network is unreachable'|'RTNETLINK answers: No route to host'|\
        'RTNETLINK answers: Permission denied'|'RTNETLINK answers: Communication administratively prohibited') exit 0 ;;
    esac
    exit 1
)





wan_gateway() {
    ip route show default 2>/dev/null | awk '/^default/{for(i=1;i<=NF;i++) if($i=="via"){print $(i+1); exit}}'
}






carrier_iface() {
    ip route show table 1000 2>/dev/null | awk '/^default/{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}'
}













carrier_mtu() {
    _cmi=$(carrier_iface)
    if [ -n "$_cmi" ]; then cat "/sys/class/net/$_cmi/mtu" 2>/dev/null || true; fi
    return 0
}









wan_up() {
    _wu=$(wan_iface)
    [ -n "$_wu" ] || return 1
    if [ -r "/sys/class/net/$_wu/carrier" ]; then
        [ "$(cat "/sys/class/net/$_wu/carrier" 2>/dev/null)" = "1" ] || return 1
    fi
    return 0
}










wan_probe_ok() {
    _wpi=$(wan_iface)
    [ -n "$_wpi" ] || return 1
    [ -n "$(probe_ext_ip "--interface $_wpi" 4)" ] && return 0
    curl -s -k -o /dev/null --interface "$_wpi" --max-time 4 https://8.8.8.8/ 2>/dev/null
}







WAN_RECHECK=${WAN_RECHECK:-10}
wan_recheck() {
    sleep "$WAN_RECHECK"
    wan_probe_ok
}
