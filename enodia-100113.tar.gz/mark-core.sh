#!/bin/sh





















FWMARK=0x1
TABLE=1000





UNWIRE=0
[ "${1:-}" = unwire ] && UNWIRE=1

ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}









ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}





if [ -f "$ENODIA_DIR/ipt-lib.sh" ]; then . "$ENODIA_DIR/ipt-lib.sh"; fi


if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi
if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
if [ -f "$ENODIA_DIR/label-lib.sh" ]; then . "$ENODIA_DIR/label-lib.sh"; fi
if [ -f "$ENODIA_DIR/set-lib.sh" ]; then . "$ENODIA_DIR/set-lib.sh"; fi   # set_slot_needed: which exit sets the builders require
command -v set_slot_needed >/dev/null 2>&1 || set_slot_needed() { :; }   # no library = the 10b7e50 behaviour (nothing required)
command -v ipt_top >/dev/null 2>&1 || ipt_top() { _itc=$1; shift; iptables -C "$_itc" "$@" 2>/dev/null || iptables -I "$_itc" 1 "$@"; }
SLOTS_SH="$ENODIA_DIR/slots.sh"



case "${1:-}" in
    slot-repair|slot-replay)
        if command -v settle_lock_take >/dev/null 2>&1 &&
           { [ -z "$ENODIA_SETTLE_OWNER" ] || [ "$(cat "$SETTLE_LOCK" 2>/dev/null)" != "$ENODIA_SETTLE_OWNER" ]; }; then
            _settle_wait=60
            [ -z "$ENODIA_SLOTS_OWNER" ] || _settle_wait=0
            settle_lock_take "$_settle_wait" || exit 1
            trap 'settle_lock_drop' EXIT
            trap 'exit 1' HUP INT TERM PIPE
        fi ;;
esac
MAIN_ADMITTED=1
[ ! -f "$ENODIA_STATE/.vpn-off" ] || MAIN_ADMITTED=0
SLOT_RULE_LOCK=/tmp/enodia-slot-rules.lock


slot_routes() (
    command -v slot_rule_rows >/dev/null && command -v lbl_lock_take >/dev/null || exit 0
    _sr_before=$(ip rule show 2>/dev/null) || exit 1
    if [ ! -s "$ENODIA_STATE/.slots" ] && ! printf '%s\n' "$_sr_before" | grep -qE '^(9[2-7]|11[0-5]):'; then exit 0; fi
    lbl_lock_take "$SLOT_RULE_LOCK" 'mark-core\.sh' || exit 1
    trap 'lbl_lock_drop "$SLOT_RULE_LOCK"' EXIT
    trap 'exit 1' HUP INT TERM PIPE
    _sr_before=$(ip rule show 2>/dev/null) || exit 1
    _sr_plan=''
    if [ -z "$1" ] && [ -s "$ENODIA_STATE/.slots" ]; then
        _sr_plan=$(sh "$SLOTS_SH" slot-plan "$2") || exit 1
    fi
    _sr_rc=0
    for _sr_id in ${1:-2 3 4 5 6 7}; do
        _sr_old=$(printf '%s\n' "$_sr_before" | slot_rule_rows "$_sr_id")
        _sr_new=$(printf '%s\n' "$_sr_plan" | awk -v id="$_sr_id" '$1==id {print $2,$3}')
        [ "$_sr_old" != "$_sr_new" ] || continue
        _sr_ok=1
        while read -r _sr_pref _sr_table; do
            [ -n "$_sr_table" ] || continue
            printf '%s\n' "$_sr_old" | grep -qxF "$_sr_pref $_sr_table" && continue
            ip rule add fwmark "0x$_sr_id" table "$_sr_table" pref "$_sr_pref" || _sr_ok=0
        done <<EOF
$_sr_new
EOF
        _sr_kept=''
        if [ "$_sr_ok" = 1 ]; then
            while read -r _sr_pref _sr_table; do
                [ -n "$_sr_table" ] || continue
                _sr_row="$_sr_pref $_sr_table"
                if printf '%s\n' "$_sr_new" | grep -qxF "$_sr_row" && ! printf '%s\n' "$_sr_kept" | grep -qxF "$_sr_row"; then
                    _sr_kept="$_sr_kept
$_sr_row"
                    continue
                fi
                ip rule del fwmark "0x$_sr_id" table "$_sr_table" pref "$_sr_pref" || _sr_ok=0
            done <<EOF
$_sr_old
EOF
        fi
        if [ "$_sr_ok" != 1 ]; then
            _sr_rc=1
            _sr_new=$(ip rule show 2>/dev/null | slot_rule_rows "$_sr_id")
        fi
        [ "$(printf '%s\n' "$_sr_old" | slot_rule_path)" = "$(printf '%s\n' "$_sr_new" | slot_rule_path)" ] ||
            ct_flush_slot "$_sr_id" origin
    done
    exit "$_sr_rc"
)

slot_firewall_repair() {
    sh "$SLOTS_SH" list-admitted | while IFS="$(printf '\t')" read -r _rp_id _rp_type _rp_cfg _rp_fb; do
        case "$_rp_type" in awg) _rp_if=awg$_rp_id ;; xray|hy2|byedpi) _rp_if=xtun$_rp_id ;; *) continue ;; esac
        slot_owned_default "$_rp_id" "$_rp_type" || continue
        if [ "$_rp_type" != awg ]; then
            ipt_top FORWARD -o "$_rp_if" -j ACCEPT
            ipt_top FORWARD -i "$_rp_if" -j ACCEPT
        fi
        case "$_rp_type" in awg|byedpi) sh "$ENODIA_DIR/transport.sh" slot-firewall "$_rp_id" ;; esac
    done
}


slot_off_clean() {
    _oc_rules=$(ip rule show 2>/dev/null) || return 1
    _oc_plan=''
    if [ -s "$ENODIA_STATE/.slots" ]; then _oc_plan=$(sh "$SLOTS_SH" slot-plan) || return 1; fi
    ! printf '%s\n' "$_oc_rules" | grep -qE 'fwmark 0x1(/[^ ]+)? .*lookup 1000( |$)' || return 1
    for _oc_id in 2 3 4 5 6 7; do
        _oc_have=$(printf '%s\n' "$_oc_rules" | slot_rule_rows "$_oc_id")
        while read -r _oc_pref _oc_table; do
            [ -n "$_oc_pref" ] || continue
            printf '%s\n' "$_oc_plan" | grep -qxF "$_oc_id $_oc_pref $_oc_table" || return 1
        done <<EOF
$_oc_have
EOF
    done
}

SLOT_OUTPUT=ENODIA_SLOT_OUT
slot_output_unwire() {
    iptables -t mangle -S "$SLOT_OUTPUT" >/dev/null 2>&1
    case "$?" in 1) return 0 ;; 0) ;; *) return 1 ;; esac
    ipt_delete_all mangle OUTPUT -j "$SLOT_OUTPUT" &&
        iptables -t mangle -F "$SLOT_OUTPUT" && iptables -t mangle -X "$SLOT_OUTPUT"
}

slot_output_guards() (
    _sog_op=$1
    for _sog_proto in udp tcp; do
        iptables -t mangle "$_sog_op" "$SLOT_OUTPUT" -p "$_sog_proto" --dport 53 -j RETURN || exit 1
    done
    [ -f "$ENODIA_DIR/doh-lib.sh" ] || exit 0
    . "$ENODIA_DIR/doh-lib.sh"
    _sog_proto=$(doh_wire_l4); _sog_port=$(doh_wire_port)
    for _sog_ip in $(dns_now anchors | tr ' ' '\n' | grep -E '^([0-9]{1,3}\.){3}[0-9]{1,3}$' | sort -u); do
        iptables -t mangle "$_sog_op" "$SLOT_OUTPUT" -d "$_sog_ip" -p "$_sog_proto" --dport "$_sog_port" -j RETURN || exit 1
    done
)

slot_wiring() {
    [ -f "$SLOTS_SH" ] || return 0
    _sw_rows=$(sh "$SLOTS_SH" list-admitted 2>/dev/null | cut -f1 | tr '\n' ' ')
    case "$1:$UNWIRE" in
        check:0)
            iptables -t mangle -C OUTPUT -j "$SLOT_OUTPUT" 2>/dev/null &&
                slot_output_guards -C 2>/dev/null || return 1 ;;
        *)
            slot_output_unwire || return 1
            if [ "$UNWIRE" = 0 ] && [ -n "$_sw_rows" ]; then
                iptables -t mangle -N "$SLOT_OUTPUT" && slot_output_guards -A &&
                    iptables -t mangle -A OUTPUT -j "$SLOT_OUTPUT" || return 1
            fi ;;
    esac
    sh "$SLOTS_SH" list-enabled 2>/dev/null | while IFS="$(printf '\t')" read -r sid stransport _scfg _sfb; do
        case "$sid" in [2-7]) ;; *) continue ;; esac
        [ -z "$2" ] || [ "$sid" = "$2" ] || continue
        _sw_admitted=0
        case " $_sw_rows" in *" $sid "*) _sw_admitted=1 ;; esac
        for sset in "grp_vpn_s$sid" "geo_vpn_s$sid"; do
            ipset list -n 2>/dev/null | grep -qx "$sset" || continue
            if [ "$1" = check ]; then
                [ "$_sw_admitted" = 1 ] && [ "$stransport" != zapret ] || continue
                for chain in PREROUTING "$SLOT_OUTPUT"; do
                    iptables -t mangle -C "$chain" -m set --match-set "$sset" dst -j MARK --set-mark "0x$sid" 2>/dev/null &&
                    iptables -t mangle -C "$chain" -m set --match-set "$sset" dst -j ACCEPT 2>/dev/null || exit 1
                done
                continue
            fi

            for chain in PREROUTING OUTPUT; do
                while iptables -t mangle -D "$chain" -m set --match-set "$sset" dst -j ACCEPT 2>/dev/null; do :; done
                while iptables -t mangle -D "$chain" -m set --match-set "$sset" dst -j MARK --set-mark "0x$sid" 2>/dev/null; do :; done
            done
            [ "$UNWIRE:$_sw_admitted" = 0:1 ] || continue
            [ "$stransport" != zapret ] || continue
            mpos=$(iptables -t mangle -nL PREROUTING --line-numbers 2>/dev/null | awk '/miwifi|ipt_compiler|NFQUEUE/{print $1; exit}')
            if [ -n "$mpos" ]; then
                iptables -t mangle -I PREROUTING "$mpos" -m set --match-set "$sset" dst -j ACCEPT &&
                iptables -t mangle -I PREROUTING "$mpos" -m set --match-set "$sset" dst -j MARK --set-mark "0x$sid" || exit 1
            else
                iptables -t mangle -A PREROUTING -m set --match-set "$sset" dst -j MARK --set-mark "0x$sid" &&
                iptables -t mangle -A PREROUTING -m set --match-set "$sset" dst -j ACCEPT || exit 1
            fi
            iptables -t mangle -A "$SLOT_OUTPUT" -m set --match-set "$sset" dst -j MARK --set-mark "0x$sid" &&
            iptables -t mangle -A "$SLOT_OUTPUT" -m set --match-set "$sset" dst -j ACCEPT || exit 1
        done
    done
}


slot_classifiers_wired() {
    ipt_reply_guard check &&
        slot_wiring check "$1" &&
        sh "$ENODIA_DIR/apply-bypass.sh" slot-check "$1"
}

case "${1:-}" in
    slot-rules) slot_routes ''; exit $? ;;
    slot-off-clean) slot_off_clean; exit $? ;;
    slot-wired)
        case "$2" in [2-7]) ;; *) exit 1 ;; esac
        slot_admitted "$2" "$3" && slot_owned_default "$2" "$3" || exit 1




        _swn=$(set_slot_needed "$2")
        [ -n "$_swn" ] || { slot_classifiers_wired "$2"; exit $?; }
        _swl=$(ipset list -n 2>/dev/null)
        for _sws in $_swn; do printf '%s\n' "$_swl" | grep -qx "$_sws" || exit 1; done
        iptables -t mangle -S 2>/dev/null | grep -qE -- "-j MARK --set-(x)?mark 0x$2(/[^ ]+)?( |$)" &&
            slot_classifiers_wired "$2"
        exit $? ;;
    slot-downgrade) slot_routes '' legacy; exit $? ;;
    slot-unrule) case "$2" in [2-7]) slot_routes "$2"; exit $? ;; *) exit 2 ;; esac ;;
    slot-unrules) slot_routes '2 3 4 5 6 7'; exit $? ;;
esac

if [ "$UNWIRE" = 0 ]; then
    [ ! -f "$ENODIA_STATE/.vpn-deactivated" ] || exit 0
    if { [ "$MAIN_ADMITTED" = 0 ] || [ "$1" = slot-repair ]; } &&
       [ -z "$(sh "$SLOTS_SH" list-admitted 2>/dev/null)" ]; then
        slot_routes '' && slot_output_unwire || exit 1
        [ "$1" != slot-replay ] || { sh "$ENODIA_DIR/apply-bypass.sh" apply; exit $?; }
        exit 0
    fi
    if [ "$1" = slot-repair ] &&
       iptables -t mangle -C OUTPUT -j VPN_EXCLUDE 2>/dev/null &&
       iptables -t mangle -C VPN_EXCLUDE -j VPN_ENDPOINT 2>/dev/null &&
       slot_classifiers_wired ''; then
        slot_routes '' && slot_firewall_repair && ct_mark_save on
        exit $?
    fi
fi

[ "$UNWIRE" = 1 ] || slot_routes '' || exit 1


if command -v ipt_reply_guard >/dev/null 2>&1; then
    ipt_reply_guard "$UNWIRE" || echo "[mark-core] ВНИМАНИЕ: reply-guard не поставлен"
fi

















for p in 465 587 25; do
    while iptables -t mangle -D OUTPUT -p tcp --dport "$p" -j ACCEPT 2>/dev/null; do :; done
    [ "$UNWIRE" = 0 ] && iptables -t mangle -I OUTPUT 1 -p tcp --dport "$p" -j ACCEPT 2>/dev/null
done
[ "$UNWIRE" = 0 ] && echo "[mark-core] notify-guard: router SMTP (465/587/25) мимо туннеля (письма-уведомления всегда напрямую)"













_ptls_port=$(cat "$ENODIA_STATE/.panel-tls" 2>/dev/null | tr -cd '0-9' | sed 's/^0*//')
if [ -n "$_ptls_port" ]; then
    while iptables -t mangle -D OUTPUT -p tcp --sport "$_ptls_port" -j ACCEPT 2>/dev/null; do :; done
    if [ "$UNWIRE" = 0 ]; then
        iptables -t mangle -I OUTPUT 1 -p tcp --sport "$_ptls_port" -j ACCEPT 2>/dev/null
        echo "[mark-core] panel-guard: ответы панели с :$_ptls_port мимо туннеля"
    fi
fi









_vsrv_port=$(cat "$ENODIA_STATE/server/port" 2>/dev/null | tr -cd '0-9')
if [ -n "$_vsrv_port" ]; then
    while iptables -t mangle -D OUTPUT -p udp --sport "$_vsrv_port" -j ACCEPT 2>/dev/null; do :; done
    if [ "$UNWIRE" = 0 ]; then
        iptables -t mangle -I OUTPUT 1 -p udp --sport "$_vsrv_port" -j ACCEPT 2>/dev/null
        echo "[mark-core] vpnsrv-guard: ответы VPN-сервера с :$_vsrv_port мимо туннеля"
    fi
fi


slot_wiring full || exit 1



































for set in enodia_list iplist_set grp_vpn enodia_ip_vpn geo_vpn; do
    if ipset list -n 2>/dev/null | grep -qx "$set"; then

        while iptables -t mangle -D PREROUTING -m set --match-set "$set" dst -j ACCEPT 2>/dev/null; do :; done
        while iptables -t mangle -D PREROUTING -m set --match-set "$set" dst -j MARK --set-mark $FWMARK 2>/dev/null; do :; done


        while iptables -t mangle -D OUTPUT -m set --match-set "$set" dst -j MARK --set-mark $FWMARK 2>/dev/null; do :; done
        [ "$UNWIRE:$MAIN_ADMITTED" = 0:1 ] || continue

        mpos=$(iptables -t mangle -nL PREROUTING --line-numbers 2>/dev/null | awk '/miwifi|ipt_compiler|NFQUEUE/{print $1; exit}')
        if [ -n "$mpos" ]; then


            iptables -t mangle -I PREROUTING "$mpos" -m set --match-set "$set" dst -j ACCEPT
            iptables -t mangle -I PREROUTING "$mpos" -m set --match-set "$set" dst -j MARK --set-mark $FWMARK
        else
            iptables -t mangle -A PREROUTING -m set --match-set "$set" dst -j MARK --set-mark $FWMARK
        fi
        iptables -t mangle -A OUTPUT -m set --match-set "$set" dst -j MARK --set-mark $FWMARK
    fi
done

if command -v ct_mark_save >/dev/null 2>&1; then
    if [ "$UNWIRE" = 1 ]; then ct_mark_save off; else ct_mark_save on; fi
fi
if [ "$UNWIRE" = 1 ]; then slot_routes '2 3 4 5 6 7'; fi


case "$1" in slot-repair|slot-replay) ;; *) ip rule del fwmark $FWMARK table $TABLE 2>/dev/null ;; esac
if [ "$UNWIRE" = 1 ]; then


    echo "[mark-core] маркировка СНЯТА (правила ядра и ip rule убраны; сеты и default в table $TABLE — не наша забота)"
    exit 0
fi
case "$1:$MAIN_ADMITTED" in slot-*:*) ;; *:1) ip rule add fwmark $FWMARK table $TABLE pref 99 || exit 1 ;; esac


if [ "${1#slot-}" = "${1:-}" ] && [ "$MAIN_ADMITTED" = 1 ] && [ -f "$ENODIA_STATE/.vpn-off" ]; then
    ip rule del fwmark $FWMARK table $TABLE 2>/dev/null
    [ -z "$(sh "$SLOTS_SH" list-admitted 2>/dev/null)" ] || exec sh "$ENODIA_DIR/mark-core.sh" slot-replay
    exec sh "$ENODIA_DIR/mark-core.sh" unwire
fi
case "$1" in
    slot-repair|slot-replay)
        sh "$ENODIA_DIR/apply-bypass.sh" apply || exit 1
        [ ! -f "$ENODIA_DIR/road.sh" ] || sh "$ENODIA_DIR/road.sh" wire || exit 1
        [ "$1" != slot-repair ] || slot_firewall_repair || exit 1 ;;
esac

echo "[mark-core] маркировка применена (table $TABLE, fwmark $FWMARK; default ставит транспорт)"
