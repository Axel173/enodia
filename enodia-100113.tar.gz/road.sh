#!/bin/sh















































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
STORE="$ENODIA_STATE/.cfg-via"
LOCK=/tmp/enodia-road.lock          # store writes
WLOCK=/tmp/enodia-road-wire.lock    # kernel rebuild: carriers, the panel and heal call it concurrently; `ip rule add` doesn't dedupe
OVERHEAD=80                         # WireGuard over IPv6 outer: 40 IP + 8 UDP + 32 WG (1500 − 80 = WireGuard's own 1420)
TAB=$(printf '\t')
if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v pid_runs >/dev/null 2>&1 || pid_runs() { [ -n "$1" ] && [ -r "/proc/$1/cmdline" ] && tr '\000' ' ' 2>/dev/null < "/proc/$1/cmdline" | grep -qE "$2"; }
if [ -f "$ENODIA_DIR/label-lib.sh" ]; then . "$ENODIA_DIR/label-lib.sh"; else
    echo "[road] нет $ENODIA_DIR/label-lib.sh — обновите установку" >&2; exit 1
fi
if [ -f "$ENODIA_DIR/ct-lib.sh" ]; then . "$ENODIA_DIR/ct-lib.sh"; fi
command -v ct_flush_dst >/dev/null 2>&1 || ct_flush_dst() { [ -n "$1" ] && conntrack -D -d "$1" >/dev/null 2>&1; return 0; }

KEY_RE=$LBL_CFG_KEY_RE
is_ip4() { printf '%s' "$1" | grep -Eq '^([0-9]{1,3}\.){3}[0-9]{1,3}$'; }
cmd_list() { lbl_list "$STORE" "$KEY_RE" | awk -F"$TAB" '$2 ~ /^[2-7]$/'; }
via_of() { cmd_list | awk -F"$TAB" -v k="$1" '$1==k { print $2; exit }'; }   # $1 = kind/file
cmd_riders() { cmd_list | awk -F"$TAB" -v i="$1" '$2==i { print $1 }'; }

cfg_path() {
    _rcp=$(lbl_cfg_path "$1" "$2") || return 1
    printf '%s/%s\n' "$ENODIA_STATE" "$_rcp"
}
alt_members() (   # kind, config path, hosts|ips, seed file, [shared]
    [ -r "$2" ] && [ -f "$ENODIA_DIR/dns-lib.sh" ] || exit 0
    . "$ENODIA_DIR/dns-lib.sh"
    case "$1" in
        xray) [ -f "$ENODIA_DIR/xray-profile-lib.sh" ] && . "$ENODIA_DIR/xray-profile-lib.sh" && xp_members "$2" "$3" "$4" "${5:-}" ;;
        hy2) _ram_host=$(hy2_conf_host "$2")
             if [ "$3" = hosts ]; then printf '%s\n' "$_ram_host"; else seed_ipv4_rows "$_ram_host" "$4" "${5:-}" | sort -u; fi ;;
    esac
)
live_pin_ips() (   # publication, seed file
    [ -f "$ENODIA_DIR/dns-lib.sh" ] || exit 0
    . "$ENODIA_DIR/dns-lib.sh"
    _rlp_hosts=$(printf '%s\n' "$1" | lbl_endpoint_hosts)
    [ -n "$_rlp_hosts" ] || _rlp_hosts=$(seed_pin_names "$2" "$(printf '%s\n' "$1" | sed '/^key=/,$d')")
    for _rlp_host in $_rlp_hosts; do seed_ipv4_rows "$_rlp_host" "$2" pins; done
)
key_ips() {   # addresses known before an edit, including any live publication
    case "$1" in
        awg/*)
            _rki_file=${1#*/}
            endpoint_ip_of "$(cfg_path awg "$_rki_file")"
            [ "$(active_cfg)" != "$_rki_file" ] || main_ip "$_rki_file"
            for _rki_id in $(exits_on "$_rki_file"); do exit_ip "$_rki_id" "$_rki_file"; done ;;
        *) alt_members "${1%%/*}" "$(cfg_path "${1%%/*}" "${1#*/}")" ips "" shared ;;
    esac
    for _rki_store in "$ENODIA_STATE/.endpoint-bypass" "$ENODIA_STATE"/.endpoint-bypass-s[2-7]; do
        [ "$(lbl_endpoint_key "$_rki_store")" = "$1" ] || continue
        sed '/^key=/,$d' "$_rki_store"
        case "$1" in xray/*|hy2/*)
            _rki_suffix=${_rki_store##*/.endpoint-bypass}
            live_pin_ips "$(cat "$_rki_store")" "/etc/dnsmasq.d/02-altserver$_rki_suffix.conf" ;;
        esac
    done
}
hy2_mtu_ok() { [ "$(cat "/sys/class/net/awg$1/mtu" 2>/dev/null)" -ge 1228 ] 2>/dev/null; }

hy2_warp_notice() {   # exit id, [timeout]
    local _hwn_cfg
    [ -f "$ENODIA_DIR/warp.sh" ] || return 1
    _hwn_cfg=$(slots_enabled | awk -F"$TAB" -v id="$1" '$1==id && $2=="awg" {print $3; exit}')
    [ -n "$_hwn_cfg" ] || return 1
    sh "$ENODIA_DIR/warp.sh" list | awk -F"$TAB" -v c="$_hwn_cfg" '($1 "")==(c "") {ok=1; exit} END {exit !ok}' || return 1
    [ ! -f "$ENODIA_DIR/nf-i18n.sh" ] || . "$ENODIA_DIR/nf-i18n.sh"
    case "$(command -v nf_lang >/dev/null 2>&1 && nf_lang):$2" in
        en:timeout) echo '[road] Hysteria2 handshake timed out through WARP. Choose another road or connect directly.' ;;
        *:timeout)  echo '[road] Тайм-аут рукопожатия Hysteria2 через WARP. Выберите другую дорогу или прямое подключение.' ;;
        en:*)       echo '[road] WARP can drop large Hysteria2 handshake packets. Verify egress after switching.' ;;
        *)          echo '[road] WARP может терять крупные пакеты рукопожатия Hysteria2. После подключения проверьте выход в интернет через сервер.' ;;
    esac
}


slots_enabled() { [ -f "$ENODIA_DIR/slots.sh" ] && sh "$ENODIA_DIR/slots.sh" list-enabled 2>/dev/null; }
slots_routing() { [ -f "$ENODIA_DIR/slots.sh" ] && sh "$ENODIA_DIR/slots.sh" list-admitted 2>/dev/null; }




exits_on() { "${2:-slots_enabled}" | awk -F"$TAB" -v c="$1" '$2=="awg" && ($3 "") == (c "") { print $1 }'; }



overlap() {   # road endpoint IPv4, optional new rider key
    [ -n "$1" ] || return 0
    for _rok in ${2:-$(cmd_list | cut -f1)}; do
        key_ips "$_rok" | grep -qxF "$1" && { echo "${_rok#awg/}"; break; }
    done
    return 0
}
cmd_clash() {
    [ -n "$(cmd_riders "$1")" ] || return 0
    overlap "$(endpoint_ip_of "$(cfg_path awg "$2")")"
}
cmd_serves() {   # $1 = file
    for _rvm in $(exits_on "$1"); do
        [ -n "$(cmd_riders "$_rvm")" ] && { echo "$_rvm"; return 0; }
    done
    return 0
}
active_transport() { [ -f "$ENODIA_DIR/transport.sh" ] && sh "$ENODIA_DIR/transport.sh" active 2>/dev/null | head -n1 | tr -d ' \t\r'; }
active_cfg() { head -n1 "$ENODIA_STATE/.active" 2>/dev/null | tr -d '\r\n'; }
store_ip() { _rsi=$(head -n1 "$1" 2>/dev/null | tr -d ' \r\n'); is_ip4 "$_rsi" && printf '%s\n' "$_rsi"; }
endpoint_ip_of() {   # $1 = a WireGuard config: its Endpoint when it is an IPv4 literal
    _rei=$(grep -E '^[[:space:]]*Endpoint[[:space:]]*=' "$1" 2>/dev/null | head -n1 | sed 's/^[^=]*=//; s/:[0-9]*[[:space:]]*$//' | tr -d ' \t\r')
    is_ip4 "$_rei" && printf '%s\n' "$_rei"
}




main_ip() {   # $1 = file of `.active`
    endpoint_ip_of "$ENODIA_STATE/configs/$1.conf" && return 0
    endpoint_ip_of "$ENODIA_STATE/awg0.conf" && return 0
    [ "$(active_transport)" = awg ] && store_ip "$ENODIA_STATE/.endpoint-bypass"
}


exit_ip() {   # $1 = id, $2 = its config
    store_ip "$ENODIA_STATE/.endpoint-bypass-s$1" && return 0
    endpoint_ip_of "$ENODIA_STATE/configs/$2.conf"
}

road_exits() {
    { cmd_list; printf '%s\n' "$1"; } | awk -F "$TAB" '
        NF==2 { via[$1]=1; next }
        $2=="awg" { print $0 "\t" (!via["awg/" $3]) }'
}
road_peer_stale() {   # exit, configured file; a cold exit can still be selected
    command -v awg_peers_match >/dev/null 2>&1 || return 1
    ip link show "awg$1" >/dev/null 2>&1 || return 1
    _rps_awg=${ENODIA_BIN:-/data/usr/app/enodia-bin}/awg
    [ -x "$_rps_awg" ] || _rps_awg=$(command -v awg)
    ! awg_peers_match "$_rps_awg" "awg$1" "$(cfg_path awg "$2")"
}



road_ok() {   # $1 = id, $2 = slots_enabled output, $3 = the rider's address (empty — not checked)
    _rol=$(road_exits "$2" | awk -F"$TAB" -v i="$1" '$1==i && $5 { print $3; exit }')
    [ -n "$_rol" ] || return 1
    road_peer_stale "$1" "$_rol" && return 2
    [ -z "$3" ] || [ "$(exit_ip "$1" "$_rol")" != "$3" ]
}
cmd_eligible() {
    if [ -n "$3" ] && ! slot_admitted "$3"; then return 0; fi
    _rei_id=$(via_of "$1/$2")
    [ -n "$_rei_id" ] || return 0
    road_ok "$_rei_id" "$(slots_routing)" ""; _rei_status=$?
    [ "$_rei_status" != 1 ] || return 0
    printf '%s\n' "$_rei_id"
    return "$_rei_status"
}


carrier_rows() {   # carrier, fallback key, slot, published record, current selection flag
    _rcr_key=$(printf '%s\n' "$4" | lbl_endpoint_key)
    _rcr_live=1
    if [ -z "$_rcr_key" ]; then
        _rcr_key=$2
        case "$2:$4" in awg/*:[0-9]*) ;; *) _rcr_live=0 ;; esac
    fi
    lbl_cfg_key "$_rcr_key" || return 0
    case "$_rcr_key" in
        awg/*)
            if [ "$_rcr_live" = 1 ]; then _rcr_ips=$(printf '%s\n' "$4" | grep -E '^[0-9]')
            else _rcr_ips=$(endpoint_ip_of "$(cfg_path awg "${_rcr_key#*/}")"); fi ;;
        *) _rcr_ips=$({
            _rcr_seed="/etc/dnsmasq.d/02-altserver${3:+-s$3}.conf"
            if [ "$_rcr_live" = 1 ]; then
                printf '%s\n' "$4" | sed '/^key=/,$d'
                live_pin_ips "$4" "$_rcr_seed"
            else
                alt_members "${_rcr_key%%/*}" "$(cfg_path "${_rcr_key%%/*}" "${_rcr_key#*/}")" ips "$_rcr_seed" shared
            fi
        } | sort -u) ;;
    esac
    for _rcr_ip in ${_rcr_ips:--}; do
        printf '%s\t%s\t%s\t%s\t%s\n' "$1" "$_rcr_key" "$_rcr_live" "$_rcr_ip" "$5"
    done
}
rider_rows() {   # carrier, selected key, slot, published record
    _rrr_live=$(printf '%s\n' "$4" | lbl_endpoint_key)
    if [ -z "$2" ]; then
        carrier_rows "$1" '' "$3" "$4" 2   # a legacy publication can own rules without a selected rider
    elif [ -n "$_rrr_live" ] && [ "$_rrr_live" != "$2" ]; then
        carrier_rows "$1" '' "$3" "$4" 0
        carrier_rows "$1" "$2" "$3" '' 1
    else
        carrier_rows "$1" "$2" "$3" "$4" 1
    fi
}
road_main_rows() {
    _rr_record=$(cat "$ENODIA_STATE/.endpoint-bypass" 2>/dev/null)
    _rr_cfg=$(active_cfg)
    _rr_kind=$(head -n1 "$ENODIA_STATE/.transport" 2>/dev/null)
    [ -n "$_rr_kind" ] || _rr_kind=$(active_transport)
    _rr_selected=''
    case "$_rr_kind" in
        awg|'') _rr_selected=${_rr_cfg:+awg/$_rr_cfg} ;;
        xray|hy2)
            _rr_name=$(head -n1 "$ENODIA_STATE/.$_rr_kind-active" 2>/dev/null | tr -d '\r')
            _rr_selected=${_rr_name:+$_rr_kind/$_rr_name} ;;
    esac
    _rr_main=$(printf '%s\n' "$_rr_record" | lbl_endpoint_key)
    if [ -z "$_rr_main" ] && [ -n "$_rr_cfg" ] && [ "$_rr_selected" = "awg/$_rr_cfg" ]; then
        printf 'main\t%s\t1\t%s\t1\n' "$_rr_selected" "$(main_ip "$_rr_cfg")"
    else
        rider_rows main "$_rr_selected" '' "$_rr_record"
    fi
    if [ -n "$_rr_cfg" ] && [ "$_rr_main" != "awg/$_rr_cfg" ]; then
        [ "$_rr_selected" = "awg/$_rr_cfg" ] || printf 'warm\tawg/%s\t1\t%s\t0\n' "$_rr_cfg" "$(main_ip "$_rr_cfg")"
    fi
}
road_rows() {
    [ ! -f "$ENODIA_STATE/.vpn-deactivated" ] || return 0
    _rr_via=$(cmd_list)
    printf '%s\n' "$_rr_via" | sed "s/^/via$TAB/"
    if [ ! -f "$ENODIA_STATE/.vpn-off" ]; then road_main_rows; fi
    _rr_slots=$(slots_routing)
    road_exits "$_rr_slots" | while IFS="$TAB" read -r _rr_id _rr_kind _rr_file _rr_fb _rr_ok; do
        _rr_addr=$(exit_ip "$_rr_id" "$_rr_file")
        _rr_mtu=0; hy2_mtu_ok "$_rr_id" && _rr_mtu=1
        _rr_stale=0
        if printf '%s\n' "$_rr_via" | grep -q "${TAB}$_rr_id\$" && road_peer_stale "$_rr_id" "$_rr_file"; then _rr_stale=1; fi
        printf 'exit\t%s\t%s\t%s\t%s\t%s\n' "$_rr_id" "$_rr_ok" "$_rr_addr" "$_rr_mtu" "$_rr_stale"
    done
    printf '%s\n' "$_rr_slots" | while IFS="$TAB" read -r _rr_id _rr_kind _rr_file _rr_fb; do
        rider_rows "s$_rr_id" "$_rr_kind/$_rr_file" "$_rr_id" "$(cat "$ENODIA_STATE/.endpoint-bypass-s$_rr_id" 2>/dev/null)"
    done
}
road_resolver_anchors() (
    [ -f "$ENODIA_DIR/doh-lib.sh" ] || exit 0
    . "$ENODIA_DIR/doh-lib.sh"
    dns_now anchors
)

road_view() {
    [ -s "$STORE" ] || return 0

    road_rows | awk -F "$TAB" -v mode="$1" -v dns="$(road_resolver_anchors)" '
        BEGIN { nips=split(dns, ips, /[[:space:]]+/); for (j=1; j<=nips; j++) guard[ips[j]]=1 }
        $1=="via" { via[$2]=$3; serving[$3]=1; next }
        $1=="exit" { exits[$2]=$3; mtu[$2]=$5; stale[$2]=$6; if (serving[$2] && $4!="") guard[$4]=1; next }
        { tag[++n]=$1; key[n]=$2; live[n]=$3; ip[n]=$4; selected[n]=$5
          if ($3) { published[$1]=1; if ($2~/^hy2\//) quic[$4]=1 } }
        END {
            for (i=1; i<=n; i++) {
                a=ip[i]; r=via[key[i]]
                if (r && exits[r] && tag[i]!="s" r && !(a in guard))
                    candidate[i]=r
                if (live[i] && a!="" && a!="-" && candidate[i] && !stale[r] && !winner[a] && (!quic[a] || mtu[r])) {
                    winner[a]=r
                    if (mode=="want") print a "\t" r "\t" (tag[i]=="warm" ? "main" : tag[i])
                }
            }
            if (mode=="want") exit
            for (i=1; i<=n; i++) {
                t=tag[i]; if (t=="warm") continue
                if (mode=="watchdog" ? selected[i]!=1 : published[t] && !live[i]) continue
                r=winner[ip[i]]
                if (!r) r=candidate[i]
                if (!(t in dep)) { dep[t]=r; rider[t]=key[i] }
                else if (dep[t]!=r) dep[t]=""
            }
            for (i=1; i<=n; i++) {
                t=tag[i]; if (!dep[t]) continue
                printf "%s\t%s",t,dep[t]
                if (mode=="watchdog") printf "\t%s\t%d",rider[t],stale[dep[t]]
                printf "\n"; delete dep[t]
            }
        }'
}

have_rules() {
    _hrules=$(ip rule show 2>/dev/null) || return 1
    printf '%s\n' "$_hrules" | awk '$1 ~ /^8[2-7]:$/ { p = $1; sub(/:$/, "", p); t = ""; l = ""
    for (i = 2; i < NF; i++) { if ($i == "to") t = $(i+1); if ($i == "lookup" || $i == "table") l = $(i+1) }
    sub(/\/32$/, "", t); if (t != "") print p "\t" t "\t" l }'; }

road_table_up() {
    ip route show table "100$1" 2>/dev/null | grep -E "^default dev awg$1([[:space:]]|$)" | grep -vq ' linkdown'   # not-wan: road table
}


usable_paths() {
    _rpr=$1
    [ -n "$_rpr" ] || return 0
    _rpu=" "
    for _rpi in $(printf '%s\n' "$_rpr" | awk '$3 == 1000 + ($1-80) && !seen[$1]++ { print $1-80 }'); do
        if road_table_up "$_rpi"; then
            _rpu="$_rpu$_rpi "
        fi
    done
    printf '%s\n' "$_rpr" | awk -F "$TAB" -v usable="$_rpu" '
        { id=$1-80 }
        $3==1000+id && index(usable," " id " ") && !seen[$2]++ { print $2 "\t" id }'
}

cmd_paths() { usable_paths "$(have_rules)"; }
road_live_ips() { road_rows | awk -F "$TAB" '$1=="exit" || ($1!="via" && $3) {print $4}' | sort -u; }



cmd_probe_paths() {   # <kind/file> <bound|temporary> <address>...
    _rpp_key=$1; _rpp_mode=$2; shift 2
    _rpp_rules=$(have_rules) || return 1
    _rpp_live=$(usable_paths "$_rpp_rules")
    _rpp_id=$(via_of "$_rpp_key")
    _rpp_ready=
    for _rpp_ip do
        is_ip4 "$_rpp_ip" || return 1
        _rpp_hit=$(printf '%s\n' "$_rpp_live" | awk -F "$TAB" -v a="$_rpp_ip" '$1==a {print $2; exit}')
        if [ -n "$_rpp_hit" ]; then
            printf '%s\t%s\tinstalled\n' "$_rpp_ip" "$_rpp_hit"
            continue
        fi
        printf '%s\n' "$_rpp_rules" | awk -F "$TAB" -v a="$_rpp_ip" '$2==a{found=1; exit} END{exit !found}' && return 1
        if [ -z "$_rpp_ready" ]; then
            [ -n "$_rpp_id" ] && [ ! -f "$ENODIA_STATE/.vpn-off" ] && road_table_up "$_rpp_id" &&
                road_ok "$_rpp_id" "$(slots_enabled)" "" || return 1
            _rpp_edge=$(exit_ip "$_rpp_id" "$_rol")
            if [ "$_rpp_mode" = temporary ]; then
                _rpp_protected=$(road_live_ips)
            fi
            _rpp_ready=1
        fi
        [ "$_rpp_ip" != "$_rpp_edge" ] || return 1
        if [ "$_rpp_mode" = temporary ] && printf '%s\n' "$_rpp_protected" | grep -qxF "$_rpp_ip"; then return 2; fi
        printf '%s\t%s\tsaved\n' "$_rpp_ip" "$_rpp_id"
    done
}


cmd_probe_wire() (
    lbl_lock_take "$WLOCK" 'road\.sh' || exit 3
    trap 'lbl_lock_drop "$WLOCK"' EXIT
    trap 'exit 3' HUP INT TERM PIPE
    _rpw_key=$1; shift
    _rpw_paths=$(cmd_probe_paths "$_rpw_key" temporary "$@") || exit "$?"
    _rpw_dns=$(road_resolver_anchors)
    _rpw_n=0
    while IFS="$TAB" read -r _rpw_ip _rpw_id _rpw_src; do
        [ "$_rpw_src" = saved ] || continue
        printf '%s\n' "$_rpw_dns" | tr ' ' '\n' | grep -qxF "$_rpw_ip" && continue
        ip rule add to "$_rpw_ip/32" iif lo lookup "100$_rpw_id" pref 88 2>/dev/null || exit 5
        _rpw_n=$((_rpw_n + 1))
    done <<EOF
$_rpw_paths
EOF
    printf '%s\n' "$_rpw_n"
)

road_probe_reap() {
    _rpr_rules=$(ip rule show 2>/dev/null) || return 0
    if printf '%s\n' "$_rpr_rules" | grep -q '^88:'; then
        if [ -d "$XT_ROAD_LOCK" ] && lbl_lock_live "$XT_ROAD_LOCK" xray-test; then
            for _rpr_ip in $(road_live_ips); do lbl_rule_sweep 88 iif lo to "$_rpr_ip/32"; done
        else
            lbl_rule_sweep 88 iif lo
        fi
    fi
    if printf '%s\n' "$_rpr_rules" | grep -q '^51:' &&
       { [ ! -d "$TRY_LOCK" ] || ! lbl_lock_live "$TRY_LOCK" "$TRY_LOCK_HOLDERS"; } &&
       lbl_lock_take "$TRY_LOCK" "$TRY_LOCK_HOLDERS"; then
        lbl_rule_sweep 51
        lbl_lock_drop "$TRY_LOCK"
    fi
}

cmd_main_path() {   # kind, active config (legacy AWG fallback)
    _rmp_paths=$(cmd_paths)
    [ -n "$_rmp_paths" ] || return 0
    _rmp_record=$(cat "$ENODIA_STATE/.endpoint-bypass" 2>/dev/null)
    if [ -n "$(printf '%s\n' "$_rmp_record" | lbl_endpoint_key)" ]; then
        _rmp_ips=$(carrier_rows main "" "" "$_rmp_record" 1 | cut -f4)
    elif [ "$1" = awg ]; then _rmp_ips=$(main_ip "$2")
    else _rmp_ips=$(printf '%s\n' "$_rmp_record" | grep -E '^[0-9]'); fi

    printf '%s\nmain\n%s\n' "$_rmp_paths" "$_rmp_ips" | awk -F "$TAB" '
        $0=="main" { main=1; next }
        !main { path[$1]=$2; next }
        NF { if (!path[$1] || (id && id!=path[$1])) { mixed=1; exit }; id=path[$1] }
        END { if (id && !mixed) print id }'
}

cmd_wire() {
    _rwchg=""; _rwfail=0
    _rwerr="[road] не удалось применить правила дороги — повторите выбор"

    if [ ! -s "$STORE" ] && [ ! -d "$WLOCK" ]; then
        _rwh=$(ip rule show 2>/dev/null) || { echo "$_rwerr"; return 1; }
        printf '%s\n' "$_rwh" | grep -qE '^(51|8[2-8]):' || return 0
    fi
    if [ "${1:-}" != held ]; then
        lbl_lock_take "$WLOCK" 'road\.sh' || { echo "[road] правила дорог сейчас пересобирает другая операция — повторите"; return 1; }
    fi
    road_probe_reap
    _rwh=$(have_rules) || { lbl_lock_drop "$WLOCK"; echo "$_rwerr"; return 1; }
    _rww=$(road_view want | cut -f1,2)

    _rwseen=""
    while IFS="$TAB" read -r _rwp _rwt _rwl; do
        [ -n "$_rwp" ] || continue
        _rwid=${_rwp#8}
        _rwk="$_rwt$TAB$_rwid"
        if [ "$_rwl" = "100$_rwid" ] && printf '%s\n' "$_rww" | grep -qxF "$_rwk" && ! printf '%s\n' "$_rwseen" | grep -qxF "$_rwk"; then
            _rwseen="$_rwseen$LBL_NL$_rwk"; continue
        fi
        if ip rule del pref "$_rwp" to "$_rwt" lookup "$_rwl" 2>/dev/null; then _rwchg="$_rwchg $_rwt"
        else _rwfail=1; fi
    done <<EOF
$_rwh
EOF

    while [ "$_rwfail" = 0 ] && IFS="$TAB" read -r _rwt _rwid; do
        [ -n "$_rwt" ] || continue
        printf '%s\n' "$_rwseen" | grep -qxF "$_rwt$TAB$_rwid" && continue
        if ip rule add to "$_rwt/32" lookup "100$_rwid" pref "8$_rwid" 2>/dev/null; then _rwchg="$_rwchg $_rwt"
        else _rwfail=1; fi
    done <<EOF
$_rww
EOF
    lbl_lock_drop "$WLOCK"

    for _rwt in $(printf '%s\n' $_rwchg | sort -u); do ct_flush_dst "$_rwt"; done
    [ "$_rwfail" = 0 ] || { echo "$_rwerr"; return 1; }
    cmd_mtu_fix
    return 0
}
cmd_unwire() {
    have_rules | while IFS="$TAB" read -r _rup _rut _rul; do
        ip rule del pref "$_rup" to "$_rut" lookup "$_rul" 2>/dev/null && ct_flush_dst "$_rut"
    done
    return 0
}

cmd_off_clean() {
    _roc_have=$(have_rules) || return 1
    _roc_want=$(road_view want | awk -F "$TAB" -v OFS="$TAB" '{print "8" $2,$1,"100" $2}')
    [ "$(printf '%s\n' "$_roc_have" | sort)" = "$(printf '%s\n' "$_roc_want" | sort)" ]
}



cmd_mtu_cap() {   # $1 = kind, $2 = file
    [ "$1" = awg ] && lbl_cfg_key "$1/$2" || return 0
    _rmv=$(via_of "$1/$2"); [ -n "$_rmv" ] || return 0


    _rma=$(endpoint_ip_of "$ENODIA_STATE/configs/$2.conf"); [ -z "$_rma" ] && [ "$2" = "$(active_cfg)" ] && _rma=$(main_ip "$2")
    _rm_slots=$(slots_routing)
    if [ -f "$ENODIA_STATE/.vpn-off" ]; then
        printf '%s\n' "$_rm_slots" | awk -F "$TAB" -v cfg="$2" '$2=="awg" && $3==cfg {found=1} END {exit !found}' || return 0
    fi
    road_ok "$_rmv" "$_rm_slots" "$_rma" || return 0
    _rmu=$(cat "/sys/class/net/awg$_rmv/mtu" 2>/dev/null | tr -cd '0-9'); [ -n "$_rmu" ] || return 0
    _rms=$(grep -E '^[[:space:]]*S4[[:space:]]*=' "$ENODIA_STATE/configs/$2.conf" 2>/dev/null | head -n1 | sed 's/^[^=]*=//' | tr -cd '0-9')
    _rmc=$((_rmu - OVERHEAD - ${_rms:-0}))
    [ "$_rmc" -ge 576 ] 2>/dev/null || _rmc=576
    printf '%s\n' "$_rmc"
}
lower_mtu() {   # $1 = iface, $2 = kind/file — lower to the ceiling, never raise
    [ -r "/sys/class/net/$1/mtu" ] || return 0
    _rlc=$(cmd_mtu_cap "${2%%/*}" "${2#*/}"); [ -n "$_rlc" ] || return 0
    _rlm=$(cat "/sys/class/net/$1/mtu" 2>/dev/null | tr -cd '0-9')
    [ -n "$_rlm" ] && [ "$_rlm" -gt "$_rlc" ] 2>/dev/null && ip link set dev "$1" mtu "$_rlc" 2>/dev/null
    return 0
}
cmd_mtu_fix() {
    [ -s "$STORE" ] || return 0
    if [ ! -f "$ENODIA_STATE/.vpn-off" ]; then
        _rfc=$(active_cfg)
        [ -n "$_rfc" ] && lower_mtu awg0 "awg/$_rfc"   # carrying or the warm reserve — both ride the road
    fi
    slots_routing | while IFS="$TAB" read -r _rfid _rft _rfcfg _rffb; do
        [ "$_rft" = awg ] && lower_mtu "awg$_rfid" "awg/$_rfcfg"
    done
    return 0
}


cmd_carrier() {   # $1 = main | 2..7
    case "$1" in
        main) road_view carriers | awk -F"$TAB" '$1=="main" { print $2; exit }' ;;
        [2-7]) road_view carriers | awk -F"$TAB" -v c="s$1" '$1==c { print $2; exit }' ;;
    esac
    return 0
}

road_expect() {   # kind/file, expected digest
    _rex_file=$(cfg_path "${1%%/*}" "${1#*/}") && lbl_cfg_matches "$_rex_file" "$2" ||
        { echo '[road] Конфиг изменился. Обновите список серверов.'; return 1; }
}
put() (   # kind/file, road id (empty = drop), expected exit config, optional rider digest
    lbl_lock_take "$LOCK" 'road\.sh' || { echo "[road] дороги сейчас правит другая операция — повторите"; return 1; }
    _rpr_lease=0
    trap '[ "$_rpr_lease" != 1 ] || sh "$ENODIA_DIR/subs-import.sh" row-unlock "$$" >/dev/null 2>&1; lbl_lock_drop "$LOCK"' EXIT
    trap 'exit 1' HUP INT TERM PIPE
    if [ -n "${4:-}" ]; then
        sh "$ENODIA_DIR/subs-import.sh" row-lock "$$" >/dev/null 2>&1 ||
            { echo 'Идёт обновление подписок — повторите действие.'; return 1; }
        _rpr_lease=1
        road_expect "$1" "$4" || return 1
        [ "$(via_of "$1")" != "$2" ] || return 0
    fi
    if [ -n "$2" ] && [ "$(sh "$ENODIA_DIR/slots.sh" show "$2" 2>/dev/null | cut -f3,4,6)" != "awg$TAB$3${TAB}on" ]; then
        echo "[road] выход №$2 изменился — выберите дорогу заново"; return 1
    fi
    lbl_write "$STORE" "$1" "$2" "$KEY_RE" || { echo "[road] не удалось записать дорогу (место на разделе?)"; return 1; }
)



runners() {   # $1 = file
    if [ ! -f "$ENODIA_STATE/.vpn-off" ] && [ "$(active_cfg)" = "$1" ]; then
        if [ "$(active_transport)" = awg ]; then echo main
        elif [ -e /sys/class/net/awg0 ]; then echo warm; fi
    fi
    exits_on "$1" slots_routing
}

cmd_set() {   # $1 = kind, $2 = file, $3 = id | "", $4 = observed digest (optional for CLI)
    lbl_cfg_key "$1/$2" || { echo "[road] дорога доступна для конфигов AmneziaWG, Xray и Hysteria2"; return 1; }
    [ -z "${4:-}" ] || road_expect "$1/$2" "$4" || return 1
    _rso=$(via_of "$1/$2")
    if [ -n "$3" ] && [ "$_rso" != "$3" ]; then

        _rsfile=$(cfg_path "$1" "$2")
        [ -f "$_rsfile" ] || { echo "[road] нет конфига «$2»"; return 1; }
        case "$3" in [2-7]) ;; *) echo "[road] номер выхода — от 2 до 7"; return 1 ;; esac
        _rsl=$([ -f "$ENODIA_DIR/slots.sh" ] && sh "$ENODIA_DIR/slots.sh" show "$3" 2>/dev/null)
        [ -n "$_rsl" ] || { echo "[road] выхода №$3 нет"; return 1; }
        [ "$(printf '%s' "$_rsl" | cut -f6)" = on ] || { echo "[road] выход №$3 выключен — включите его, тогда он станет дорогой"; return 1; }
        [ "$(printf '%s' "$_rsl" | cut -f3)" = awg ] || { echo "[road] дорогой служит только выход AmneziaWG"; return 1; }
        _rsc=$(printf '%s' "$_rsl" | cut -f4)
        [ "awg/$_rsc" != "$1/$2" ] || { echo "[road] выход №$3 работает на этом же конфиге — по самому себе ехать нельзя"; return 1; }
        road_ok "$3" "$(printf '%s\n' "$_rsl" | cut -f1,3-5)" ""
        case "$?" in
            1) echo "[road] выход №$3 сам едет по дороге — выберите выход, который идёт напрямую"; return 1 ;;
            2) echo "[road] выход №$3 ещё работает с прежним сервером — переподнимите выход"; return 1 ;;
        esac

        _rsm=$([ "$1" != awg ] || cmd_serves "$2")
        [ -z "$_rsm" ] || { echo "[road] этот конфиг сам служит дорогой (выход №$_rsm) — дорога бывает только в один шаг"; return 1; }
        _rsh=$(if [ "$1" = awg ]; then grep -E '^[[:space:]]*Endpoint[[:space:]]*=' "$_rsfile" | sed 's/[[:space:]]*#.*//; s/:[0-9]*[[:space:]]*$//'; else alt_members "$1" "$_rsfile" hosts ""; fi)
        case "$_rsh" in *:*) echo "[road] дорога к серверу доступна только по IPv4 — в конфиге адрес IPv6"; return 1 ;; esac
        [ "$1" != hy2 ] || hy2_mtu_ok "$3" || { echo "[road] Hysteria2 нужен больший MTU пути"; return 1; }
        _rse=$(exit_ip "$3" "$_rsc")
        _rs_conflict=$(overlap "$_rse")
        if [ -n "$_rs_conflict" ] && [ -z "$(cmd_riders "$3")" ]; then
            echo "[road] выход №$3 уже нужен серверу $_rs_conflict по другой дороге — выберите выход к другому серверу"; return 1
        fi
        while IFS="$TAB" read -r _rsi _rst _rsk _rsf; do
            [ "$_rst" = awg ] && { [ "$_rsi" = "$3" ] || [ -n "$(cmd_riders "$_rsi")" ]; } || continue
            _rsx=$(exit_ip "$_rsi" "$_rsk"); [ -n "$_rsx" ] || continue
            [ -n "$(overlap "$_rsx" "$1/$2")" ] || continue
            echo "[road] выход №$_rsi идёт к тому же серверу ($_rsx) — его пакеты к серверу пошли бы сами в себя; выберите выход к другому серверу"; return 1
        done <<EOF
$(slots_enabled)
EOF
    fi
    { [ "$_rso" = "$3" ] && [ -z "${4:-}" ]; } || put "$1/$2" "$3" "${_rsc:-}" "${4:-}" || return 1
    cmd_wire || return 1
    if [ "$1" = hy2 ] && [ -n "$3" ]; then hy2_warp_notice "$3" "" || :; fi
    if [ "$_rso" = "$3" ] && [ -z "$_rwchg" ]; then
        if [ -n "$3" ]; then echo "[road] дорога уже через выход №$3"
        else echo "[road] дороги и так нет — сервер идёт напрямую"; fi
        return 0
    fi
    if [ "$1" = awg ]; then










        for _rsr in $(runners "$2"); do
            case "$_rsr" in
                main) [ -n "$3" ] || sh "$ENODIA_DIR/transport.sh" restart >/dev/null 2>&1 ;;
                warm) [ -n "$3" ] || sh "$ENODIA_DIR/transport.sh" rewarm awg >/dev/null 2>&1 ;;
                *)  if [ ! -e "/sys/class/net/awg$_rsr" ]; then
                        sh "$ENODIA_DIR/transport.sh" slot-probe "$_rsr" >/dev/null 2>&1
                    elif [ -z "$3" ]; then
                        sh "$ENODIA_DIR/transport.sh" slot-down "$_rsr" >/dev/null 2>&1
                        sh "$ENODIA_DIR/transport.sh" slot-up "$_rsr" >/dev/null 2>&1
                    fi ;;
            esac
        done
    elif [ ! -f "$ENODIA_STATE/.vpn-off" ]; then
        _rs_live=$(lbl_endpoint_key "$ENODIA_STATE/.endpoint-bypass")
        if [ "$_rs_live" = "$1/$2" ] || { [ -z "$_rs_live" ] && [ "$(active_transport)" = "$1" ] && [ "$(head -n1 "$ENODIA_STATE/.$1-active" 2>/dev/null)" = "$2" ]; }; then
            sh "$ENODIA_DIR/transport.sh" restart >/dev/null 2>&1
        fi
        for _rsr in $(slots_enabled | awk -F"$TAB" -v k="$1/$2" '$2 "/" $3 == k {print $1}'); do
            sh "$ENODIA_DIR/transport.sh" slot-down "$_rsr" >/dev/null 2>&1
            sh "$ENODIA_DIR/transport.sh" slot-up "$_rsr" >/dev/null 2>&1
        done
    fi
    if [ -n "$3" ]; then echo "[road] дорога к серверу — через выход №$3"; else echo "[road] дорога снята — сервер идёт напрямую"; fi
    return 0
}

cmd_mv() {   # $1 = kind, $2 = old, $3 = new
    lbl_cfg_key "$1/$2" && lbl_cfg_key "$1/$3" || return 0
    lbl_lock_take "$LOCK" 'road\.sh' || { echo "[road] дороги сейчас правит другая операция — повторите"; return 1; }
    _rmvv=$(via_of "$1/$2")
    _rmvr=0
    if [ -n "$_rmvv" ]; then
        lbl_commit_out "$STORE" awk -F "$TAB" -v old="$1/$2" -v new="$1/$3" -v id="$_rmvv" '$1!=old && $1!=new; END {print new "\t" id}' "$STORE"
        _rmvr=$?
    fi
    lbl_lock_drop "$LOCK"
    [ "$_rmvr" = 0 ] || { echo "[road] не удалось перенести дорогу"; return 1; }
    [ -z "$_rmvv" ] || cmd_wire >/dev/null
    return 0
}

restore_slot() { ENODIA_STATE="$1" sh "$ENODIA_DIR/slots.sh" show "$2" 2>/dev/null | cut -f3,4; }
cmd_restore_scan() {   # compare against the local config before CGI copies the archive
    _rrs_root=$ENODIA_STATE
    [ ! -f "$1/.slots" ] || _rrs_root=$1
    for _rrs_id in 2 3 4 5 6 7; do
        _rrs_old=$(restore_slot "$ENODIA_STATE" "$_rrs_id")
        _rrs_new=$(restore_slot "$_rrs_root" "$_rrs_id")
        case "$_rrs_old:$_rrs_new" in awg"$TAB"*|*:awg"$TAB"*) ;; *) continue ;; esac
        if [ "${_rrs_old%%"$TAB"*}" = awg ] && [ "${_rrs_new%%"$TAB"*}" = awg ]; then
            _rrs_cfg=${_rrs_new#*"$TAB"}
            _rrs_prev=${_rrs_old#*"$TAB"}
            lbl_cfg_key "awg/$_rrs_cfg" && lbl_cfg_key "awg/$_rrs_prev" || continue
            _rrs_src="$1/configs/$_rrs_cfg.conf"
            [ -f "$_rrs_src" ] || _rrs_src=$(cfg_path awg "$_rrs_cfg")
            _rrs_dst=$(cfg_path awg "$_rrs_prev")
            if [ "$_rrs_src" = "$_rrs_dst" ] || cmp -s "$_rrs_src" "$_rrs_dst"; then continue; fi
        fi
        printf '%s\n' "$_rrs_id"
    done
}


cmd_import() (
    _rik=$(lbl_cfg_keys "$1")
    lbl_lock_take "$LOCK" 'road\.sh' || exit 1
    _ri_stage="$STORE.$$.new"
    trap 'rm -f "$_ri_stage"; lbl_lock_drop "$LOCK"' EXIT
    trap 'exit 1' HUP INT TERM PIPE
    _ri_before=""
    [ ! -e "$ENODIA_STATE/.slots" ] || _ri_before=$(cat "$ENODIA_STATE/.slots") || exit 1
    _ri_ids=$(cmd_restore_scan "$1" | tr '\n' ' ')
    _ri_local=$(cmd_list)
    _ri_archive=$(lbl_list "$1/.cfg-via" "$KEY_RE")
    _ri_rows=$(printf 'archive\n%s\nlocal\n%s\n' "$_ri_archive" "$_ri_local" |
        awk -F "$TAB" -v OFS="$TAB" -v ids=" $_ri_ids " -v brought="\n$_rik\n" '
        NF==1 { src=$1; next }
        $2 ~ /^[2-7]$/ {
            if (index(ids, " " $2 " ")) { if (!drop[$1,$2]++) print "drop", $1, $2 }
            else if ((src=="local" || index(brought, "\n" $1 "\n")) && !seen[$1]++) print "keep", $1, $2
        }')
    _ri_next=$(printf '%s\n' "$_ri_rows" | awk -F "$TAB" '$1=="keep"' | cut -f2-)
    [ "$_ri_next" = "$_ri_local" ] || lbl_commit "$_ri_stage" "$_ri_next" || exit 1
    if [ -f "$1/.slots" ] || [ -n "$_ri_before" ]; then
        sh "$ENODIA_DIR/slots.sh" restore-registry "$1/.slots" "$_ri_before" "$1/.vpn-off" "$1" "${2:-}" || exit 1
    elif [ -n "${2:-}" ] && [ -f "$ENODIA_DIR/subs-import.sh" ]; then
        sh "$ENODIA_DIR/subs-import.sh" restore-lock "$2" || exit 1
    fi
    if [ "$_ri_next" != "$_ri_local" ]; then
        if [ -n "$_ri_next" ]; then mv -f "$_ri_stage" "$STORE" || exit 1; else rm -f "$STORE" || exit 1; fi
    fi
    trap - EXIT HUP INT TERM PIPE
    lbl_lock_drop "$LOCK"
    cmd_wire >/dev/null || true
    printf '%s\n' "$_ri_rows" | awk -F "$TAB" '$1=="drop"' | cut -f2-
)
cmd_merge() {
    [ -f "$1" ] || { echo "[road] нет файла $1"; return 1; }
    lbl_lock_take "$LOCK" 'road\.sh' || { echo "[road] дороги сейчас правит другая операция — повторите"; return 1; }
    lbl_merge "$STORE" "$1" "$KEY_RE"; _rgr=$?
    lbl_lock_drop "$LOCK"
    [ "$_rgr" = 0 ] || { echo "[road] не удалось записать дороги (место на разделе?)"; return 1; }
    cmd_wire >/dev/null || true
    return 0
}



cmd_remove_saved() (   # delete-config|prune-sub, kind, file, [expected digest]
    lbl_cfg_key "$2/$3" || exit 1
    lbl_lock_take "$LOCK" 'road\.sh' || { echo '[road] дороги сейчас правит другая операция — повторите'; exit 1; }
    _rda_stage="$STORE.$$.delete.new"
    road_remove_cleanup() {
        rm -f "$_rda_stage"
        [ "$(cat "$WLOCK/pid" 2>/dev/null)" != "$$" ] || lbl_lock_drop "$WLOCK"
        lbl_lock_drop "$LOCK"
    }
    trap 'road_remove_cleanup' EXIT
    trap 'exit 1' HUP INT TERM PIPE
    lbl_stage_drop "$STORE" "$2/$3" "$_rda_stage" || { echo 'Не удалось подготовить удаление дороги к серверу.'; exit 1; }
    _rda_wire=''
    [ ! -f "$_rda_stage" ] || _rda_wire=$$
    ENODIA_DELETE_WIRE_LOCK=$WLOCK sh "$ENODIA_DIR/slots.sh" "$@" "$_rda_wire" || exit $?


    if [ -f "$_rda_stage" ]; then
        lbl_publish_drop "$STORE" "$_rda_stage" && cmd_wire held >/dev/null ||
            echo 'Конфиг удалён. Не удалось обновить дорогу к серверу.'
    fi
    exit 0
)

case "$1" in
    get)     lbl_cfg_key "$2/$3" && via_of "$2/$3"; exit 0 ;;
    eligible) lbl_cfg_key "$2/$3" && cmd_eligible "$2" "$3" "$4"; exit $? ;;
    off-clean) cmd_off_clean ;;
    set)     cmd_set "$2" "$3" "$4" "${5:-}" ;;
    del)     lbl_cfg_key "$2/$3" || exit 0; [ -z "$(via_of "$2/$3")" ] || put "$2/$3" "" || exit 1; cmd_wire >/dev/null ;;
    delete-config|prune-sub) cmd_remove_saved "$@" ;;
    mv)      cmd_mv "$2" "$3" "$4" ;;
    riders)  case "$2" in [2-7]) cmd_riders "$2" ;; esac; exit 0 ;;
    serves)  [ "$2" = awg ] && lbl_cfg_key "$2/$3" && cmd_serves "$3"; exit 0 ;;
    clash)   case "$2" in [2-7]) lbl_cfg_key "awg/$3" && cmd_clash "$2" "$3" ;; esac; exit 0 ;;
    list)    cmd_list; exit 0 ;;
    json)    cmd_list | awk -F"$TAB" '{ printf "%s\"%s\":\"%s\"", (c++ ? "," : ""), $1, $2 }'; exit 0 ;;
    wire)    cmd_wire ;;
    unwire)  cmd_unwire ;;
    want)    road_view want; exit 0 ;;
    installed) have_rules; exit 0 ;;
    paths)   cmd_paths ;;
    probe-paths) lbl_cfg_key "$2" && [ "$#" -ge 4 ] && { shift; cmd_probe_paths "$@"; } ;;
    probe-wire) lbl_cfg_key "$2" && [ "$#" -ge 3 ] && { shift; cmd_probe_wire "$@"; } ;;
    main-path) cmd_main_path "$2" "$3" ;;
    mtu-cap) cmd_mtu_cap "$2" "$3"; exit 0 ;;
    hy2-mtu-ok) case "$2" in [2-7]) hy2_mtu_ok "$2" ;; *) exit 1 ;; esac ;;
    hy2-warp-timeout) case "$2" in [2-7]) hy2_warp_notice "$2" timeout ;; *) exit 1 ;; esac ;;
    mtu-fix) cmd_mtu_fix ;;
    carrier) cmd_carrier "$2"; exit 0 ;;
    carriers) case "$2" in watchdog) road_view watchdog ;; *) road_view carriers ;; esac; exit 0 ;;
    import)  cmd_import "$2" "${3:-}" ;;
    merge)   cmd_merge "$2" ;;
    *) echo "usage: $0 get <вид> <файл> | set <вид> <файл> <id|\"\"> | del <вид> <файл> | mv <вид> <старый> <новый> | riders <id> | list | json | wire | unwire | want | mtu-cap <вид> <файл> | mtu-fix | carrier <main|id> | import <корень архива> | merge <файл>"; exit 2 ;;
esac
