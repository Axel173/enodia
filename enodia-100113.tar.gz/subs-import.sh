#!/bin/sh









































ENODIA_DIR=${ENODIA_DIR:-/data/usr/app/enodia}
ENODIA_STATE=${ENODIA_STATE:-/data/usr/app/enodia-state}
CFGDIR="$ENODIA_STATE/xray-configs"
NAMES="$ENODIA_STATE/.sub-names"
ACTIVE_F="$ENODIA_STATE/.xray-active"
HY2DIR="$ENODIA_STATE/hy2-configs"
HY2_ACTIVE_F="$ENODIA_STATE/.hy2-active"
AWGDIR="$ENODIA_STATE/configs"
AWG_ACTIVE_F="$ENODIA_STATE/.active"


AWG_TRIED=/tmp/enodia-subs-awg-tried

WD_STATE=/tmp/enodia-watchdog.state
LOG=/tmp/enodia-subs-update.log
LOCK=/tmp/enodia-subs-update.lock
TMPD=/tmp/enodia-subs-update.$$
TAB=$(printf '\t')

MINFREE_KB=${MINFREE_KB:-2048}

if [ -f "$ENODIA_DIR/label-lib.sh" ]; then . "$ENODIA_DIR/label-lib.sh"; fi   # lbl_commit_out: a file replaced whole or not at all
command -v lbl_commit_out_as >/dev/null 2>&1 || { lbl_commit_out_as() { _lct=$1; _lcf=$2; shift 2; "$@" > "$_lct" && mv -f "$_lct" "$_lcf" && return 0; rm -f "$_lct"; return 1; }; lbl_commit_out() { _lcf=$1; shift; lbl_commit_out_as "$_lcf.$$.new" "$_lcf" "$@"; }; lbl_grep() { grep "$@" || [ "$?" -le 1 ]; }; lbl_without() { if [ -f "$1" ]; then lbl_grep -v -- "$2" "$1" || return 1; fi; [ -z "${3:-}" ] || printf '%s\n' "$3"; }; }   # write-blind: the shim of a missing library is the old line

if [ -f "$ENODIA_DIR/clock-lib.sh" ]; then . "$ENODIA_DIR/clock-lib.sh"; fi

if [ -f "$ENODIA_DIR/daemon-lib.sh" ]; then . "$ENODIA_DIR/daemon-lib.sh"; fi
command -v switch_hold >/dev/null 2>&1 || switch_hold() { ( set -C; echo $$ > "$1" ) 2>/dev/null; }
command -v pid_runs >/dev/null 2>&1 || pid_runs() { [ -n "$1" ] && [ -r "/proc/$1/cmdline" ] && tr '\000' ' ' 2>/dev/null < "/proc/$1/cmdline" | grep -qE "$2"; }
SWITCH_LOCK=/tmp/enodia-switching.lock



CHG="изменился в подписке"; CHG_D=" (адрес/креды)"
case "${SUBS_PUT_WHY:-}" in premium) CHG="получил новый ключ Amnezia"; CHG_D="" ;; esac

CARRIER_HOLD_MAX=${CARRIER_HOLD_MAX:-120}
command -v age_since >/dev/null 2>&1 || age_since() {
	case "$1" in ''|*[!0-9]*) echo 999999; return ;; esac
	[ "$1" -gt 0 ] && echo $(( $(date +%s) - $1 )) || echo 999999
}



if [ -f "$ENODIA_DIR/subs-lib.sh" ]; then
	. "$ENODIA_DIR/subs-lib.sh"
else
	sub_host_public() { return 1; }
	sub_fetch() { return 1; }


	sub_info_put() { return 0; }
	sub_tags() { [ -f "$ENODIA_STATE/.subs" ] && cut -d"$TAB" -f1 "$ENODIA_STATE/.subs" 2>/dev/null; }
	sub_url_of() { [ -f "$ENODIA_STATE/.subs" ] && grep "^$1$TAB" "$ENODIA_STATE/.subs" 2>/dev/null | head -1 | cut -d"$TAB" -f2; }
	sub_label_of() { [ -f "$ENODIA_STATE/.subs" ] && grep "^$1$TAB" "$ENODIA_STATE/.subs" 2>/dev/null | head -1 | cut -d"$TAB" -f3-; }
	sub_owner_tag() { printf '%s' ""; }
fi



command -v sub_info_put >/dev/null 2>&1 || sub_info_put() { return 0; }

command -v sub_fetch_tag >/dev/null 2>&1 || sub_fetch_tag() { sub_fetch "$2" "$3"; }


command -v sub_sum_cut >/dev/null 2>&1 || sub_sum_cut() { tr -d '\t\r\n' | cut -c1-"$1"; }



command -v sub_names_keep_other >/dev/null 2>&1 || sub_names_keep_other() { [ -f "$ENODIA_STATE/.sub-names" ] && grep -v "^sub-$1-" "$ENODIA_STATE/.sub-names"; return 0; }

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG" 2>/dev/null; }
say() { echo "$*"; log "$*"; }



JF=""
[ -x /usr/bin/jsonfilter ] && JF=/usr/bin/jsonfilter
[ -n "$JF" ] || JF=$(command -v jsonfilter 2>/dev/null)
jf() { [ -n "$JF" ] || return 1; "$JF" -i "$1" -e "$2" 2>/dev/null; }
if [ -f "$ENODIA_DIR/xray-profile-lib.sh" ]; then . "$ENODIA_DIR/xray-profile-lib.sh"; fi
if [ -f "$ENODIA_DIR/store-lib.sh" ]; then . "$ENODIA_DIR/store-lib.sh"; fi
profile_xray_bin() {
    if command -v bin_path >/dev/null 2>&1; then bin_path xray
    else printf '%s/xray\n' "${ENODIA_BIN:-/data/usr/app/enodia-bin}"; fi
}
command -v xp_pool >/dev/null 2>&1 || xp_pool() { return 1; }




ud() { printf '%b' "$(printf '%s' "$1" | sed 's/\\/\\\\/g; s/%\(..\)/\\x\1/g')" 2>/dev/null; }







SAN_CR=$(printf '\r')
SAN_TAB=$(printf '\t')
san() {
	printf '%s' "$1" \
		| sed "s/\\\\/\\\\\\\\/g; s/\"/\\\\\"/g; s/$SAN_CR/\\\\r/g; s/$SAN_TAB/\\\\t/g" \
		| awk 'NR>1{printf "\\n"} {printf "%s", $0}'
}





san_txt() { printf '%s' "$1" | tr -d '\r\n\t'; }
is_port() { case "$1" in ''|*[!0-9]*) return 1 ;; esac; [ "$1" -ge 1 ] && [ "$1" -le 65535 ]; }
is_host() { printf '%s' "$1" | grep -qE '^[A-Za-z0-9._:-]{1,253}$'; }





p_reset() {
	P_PROTO=; P_UUID=; P_HOST=; P_PORT=; P_REMARK=; P_TYPE=; P_SEC=; P_SNI=; P_FP=
	P_PBK=; P_SID=; P_SPX=; P_PATH=; P_HHDR=; P_SVC=; P_ALPN=; P_MODE=; P_FLOW=
	P_ENC=; P_AID=; P_SCY=; P_PASS=; P_METHOD=
	P_INSECURE=; P_OBFS=; P_OBFSPASS=
	P_CONF=
	P_PROFILE=
}




b64_dec() {
	tr -d ' \t\r\n=' | tr '_-' '/+' > "$TMPD/b64.in" 2>/dev/null || return 1
	case $(( $(wc -c < "$TMPD/b64.in") % 4 )) in
		2) printf '==' >> "$TMPD/b64.in" ;;
		3) printf '=' >> "$TMPD/b64.in" ;;
	esac
	base64 -d < "$TMPD/b64.in" 2>/dev/null
}



hp_split() {
	HP_HOST=; HP_PORT=
	_s=$(printf '%s' "$1" | sed 's|/*$||')
	case "$_s" in
		\[*)
			HP_HOST=${_s#\[}; HP_HOST=${HP_HOST%%\]*}
			HP_PORT=${_s##*\]:}
			[ "$HP_PORT" = "$_s" ] && return 1 ;;
		*)
			case "$_s" in *:*) : ;; *) return 1 ;; esac
			HP_PORT=${_s##*:}; HP_HOST=${_s%:*} ;;
	esac
	is_host "$HP_HOST" && is_port "$HP_PORT"
}



apply_query() {
	_oifs=$IFS; IFS='&'
	for _kv in $1; do
		[ -n "$_kv" ] || continue
		case "$_kv" in *=*) : ;; *) continue ;; esac
		_k=${_kv%%=*}; _v=$(san "$(ud "${_kv#*=}")")
		case "$_k" in
			type)        P_TYPE=$_v ;;
			security)    P_SEC=$_v ;;
			encryption)  P_ENC=$_v ;;
			flow)        P_FLOW=$_v ;;
			sni|serverName) P_SNI=$_v ;;
			fp)          P_FP=$_v ;;
			pbk)         P_PBK=$_v ;;
			sid)         P_SID=$_v ;;
			spx)         P_SPX=$_v ;;
			path)        P_PATH=$_v ;;
			host)        P_HHDR=$_v ;;
			serviceName) P_SVC=$_v ;;
			alpn)        P_ALPN=$_v ;;
			mode)        P_MODE=$_v ;;
		esac
	done
	IFS=$_oifs
}




jflat() {
	_j="$1"; _k="$2"
	_r=$(printf '%s' "$_j" | sed -n "s/.*\"$_k\"[[:space:]]*:[[:space:]]*\"\([^\"]*\)\".*/\1/p" | head -1)
	[ -n "$_r" ] || _r=$(printf '%s' "$_j" | sed -n "s/.*\"$_k\"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p" | head -1)
	printf '%s' "$_r"
}


parse_link() {
	p_reset
	_l=$(printf '%s' "$1" | tr -d '\r')
	case "$_l" in
		vless://*)  P_PROTO=vless;  _rest=${_l#vless://} ;;
		trojan://*) P_PROTO=trojan; _rest=${_l#trojan://} ;;
		vmess://*)  parse_vmess "${_l#vmess://}"; return $? ;;
		ss://*)     parse_ss "${_l#ss://}"; return $? ;;
		*) return 1 ;;
	esac
	case "$_rest" in *#*) P_REMARK=$(san_txt "$(ud "${_rest#*#}")"); _rest=${_rest%%#*} ;; esac
	_q=""
	case "$_rest" in *\?*) _q=${_rest#*\?}; _rest=${_rest%%\?*} ;; esac
	case "$_rest" in *@*) : ;; *) return 1 ;; esac
	_ui=${_rest%%@*}; _hp=${_rest#*@}
	hp_split "$_hp" || return 1
	P_HOST=$HP_HOST; P_PORT=$HP_PORT
	apply_query "$_q"
	if [ "$P_PROTO" = trojan ]; then
		P_PASS=$(san "$(ud "$_ui")"); [ -n "$P_PASS" ] || return 1
		[ -n "$P_SEC" ] || P_SEC=tls
		[ -n "$P_TYPE" ] || P_TYPE=tcp
		[ -n "$P_SNI" ] || P_SNI=$P_HOST
	else
		P_UUID=$(san "$(ud "$_ui")"); [ -n "$P_UUID" ] || return 1
	fi
	return 0
}



parse_vmess() {
	p_reset; P_PROTO=vmess
	_j=$(printf '%s' "$1" | b64_dec)
	[ -n "$_j" ] || return 1
	P_HOST=$(san "$(jflat "$_j" add)"); P_PORT=$(jflat "$_j" port | tr -cd '0-9')
	P_UUID=$(san "$(jflat "$_j" id)")
	is_host "$P_HOST" && is_port "$P_PORT" && [ -n "$P_UUID" ] || return 1
	P_REMARK=$(san_txt "$(jflat "$_j" ps)")
	P_AID=$(jflat "$_j" aid | tr -cd '0-9'); [ -n "$P_AID" ] || P_AID=0
	P_SCY=$(san "$(jflat "$_j" scy)"); [ -n "$P_SCY" ] || P_SCY=auto
	P_TYPE=$(san "$(jflat "$_j" net)"); [ -n "$P_TYPE" ] || P_TYPE=tcp
	_tls=$(san "$(jflat "$_j" tls)")
	case "$_tls" in reality) P_SEC=reality ;; ?*) P_SEC=tls ;; *) P_SEC=none ;; esac
	P_SNI=$(san "$(jflat "$_j" sni)"); P_FP=$(san "$(jflat "$_j" fp)"); P_ALPN=$(san "$(jflat "$_j" alpn)")
	_hh=$(san "$(jflat "$_j" host)"); _pt=$(san "$(jflat "$_j" path)")
	if [ "$P_TYPE" = grpc ]; then P_SVC=$_pt; else P_PATH=$_pt; P_HHDR=$_hh; fi
	[ "$P_SEC" != none ] && [ -z "$P_SNI" ] && P_SNI=$_hh
	return 0
}



parse_ss() {
	p_reset; P_PROTO=shadowsocks; P_TYPE=tcp; P_SEC=none
	_s="$1"
	case "$_s" in *#*) P_REMARK=$(san_txt "$(ud "${_s#*#}")"); _s=${_s%%#*} ;; esac
	case "$_s" in *\?*) _s=${_s%%\?*} ;; esac
	if [ "${_s#*@}" != "$_s" ]; then
		_ui=${_s%@*}; _hp=${_s##*@}
		case "$_ui" in *:*) _ui=$(ud "$_ui") ;; *) _ui=$(printf '%s' "$_ui" | b64_dec) ;; esac
	else
		_d=$(printf '%s' "$_s" | b64_dec)
		[ -n "$_d" ] || return 1
		_ui=${_d%@*}; _hp=${_d##*@}
	fi
	case "$_ui" in *:*) : ;; *) return 1 ;; esac
	P_METHOD=$(san "${_ui%%:*}"); P_PASS=$(san "${_ui#*:}")
	hp_split "$_hp" || return 1
	P_HOST=$HP_HOST; P_PORT=$HP_PORT
	[ -n "$P_METHOD" ] || return 1
	return 0
}










parse_hy2() {
	p_reset; P_PROTO=hy2; P_SEC=tls; P_TYPE=udp; P_INSECURE=false
	_s=$(printf '%s' "$1" | tr -d '\r')
	case "$_s" in *#*) P_REMARK=$(san_txt "$(ud "${_s#*#}")"); _s=${_s%%#*} ;; esac
	_q=""
	case "$_s" in *\?*) _q=${_s#*\?}; _s=${_s%%\?*} ;; esac
	case "$_s" in *@*) : ;; *) return 1 ;; esac
	_ui=${_s%@*}; _hp=${_s##*@}
	hp_split "$_hp" || return 1
	P_HOST=$HP_HOST; P_PORT=$HP_PORT
	P_PASS=$(san "$(ud "$_ui")")
	[ -n "$P_PASS" ] || return 1
	_oifs=$IFS; IFS='&'
	for _kv in $_q; do
		[ -n "$_kv" ] || continue
		case "$_kv" in *=*) : ;; *) continue ;; esac
		_k=${_kv%%=*}; _v=$(san "$(ud "${_kv#*=}")")
		case "$_k" in
			sni)                     P_SNI=$_v ;;
			insecure)                case "$_v" in 1|true) P_INSECURE=true ;; esac ;;
			obfs)                    P_OBFS=$_v ;;
			obfs-password|obfsParam) P_OBFSPASS=$_v ;;
		esac
	done
	IFS=$_oifs
	[ -n "$P_SNI" ] || P_SNI=$P_HOST
	return 0
}





hq() { printf '"%s"' "$1"; }



emit_hy2() {
	_hostp=$P_HOST
	case "$P_HOST" in *:*) _hostp="[$P_HOST]" ;; esac
	printf 'server: %s:%s\n' "$_hostp" "$P_PORT"
	printf 'auth: %s\n' "$(hq "$P_PASS")"
	printf 'tls:\n'
	printf '  sni: %s\n' "$(hq "$P_SNI")"
	printf '  insecure: %s\n' "${P_INSECURE:-false}"
	if [ "$P_OBFS" = salamander ] && [ -n "$P_OBFSPASS" ]; then
		printf 'obfs:\n  type: salamander\n  salamander:\n    password: %s\n' "$(hq "$P_OBFSPASS")"
	fi
	printf 'socks5:\n  listen: 127.0.0.1:10808\n'
}












VPN_MAX=262144   # bytes of an inflated container we agree to hold in RAM: a zlib bomb in a subscription stops here
VPN_CONT=8       # containers of one `vpn://` we look through





ZL_ABC=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/
zlib_at() {
	_zb=$(tail -c +"$(( $2 + 1 ))" "$1" 2>/dev/null | head -c 2 | base64 2>/dev/null | tr -d '\r\n')
	case "$_zb" in ??=*) return 1 ;; ???=) : ;; *) return 1 ;; esac     # `??==` is ONE byte: the file is shorter than a header
	_zr=${_zb#?}; _zq=${_zr#?}
	_z0=${ZL_ABC%%"${_zb%???}"*}; _z1=${ZL_ABC%%"${_zr%??}"*}; _z2=${ZL_ABC%%"${_zq%?}"*}
	_zv=$(( (${#_z0} << 10) | (${#_z1} << 4) | (${#_z2} >> 2) ))
	[ $(( _zv % 31 )) -eq 0 ] && [ $(( (_zv >> 8) & 15 )) -eq 8 ]
}


zlib_inflate() {
	{ printf '\037\213\010\000\000\000\000\000\000\003'; tail -c +"$(( $2 + 3 ))" "$1"; } 2>/dev/null \
		| gunzip -c 2>/dev/null | head -c "$((VPN_MAX+1))" > "$3" 2>/dev/null
	if [ "$(wc -c < "$3")" -gt "$VPN_MAX" ]; then N_PARTIAL=1; return 1; fi
	[ -s "$3" ]
}



vpn_val() { rm -f "$3" 2>/dev/null; lbl_commit_out "$3" jf "$1" "$2" 2>/dev/null && [ -s "$3" ]; }



vpn_conf_in() {
	_vf="$1"; VPN_INNER=
	case "$(head -c 64 "$_vf" 2>/dev/null | tr -d ' \t\r\n' | cut -c1)" in
		'{') vpn_val "$_vf" '@.config' "$_vd.inner" && { _vf="$_vd.inner"; VPN_INNER=1; } ;;
	esac
	grep -qF '[Interface]' "$_vf" 2>/dev/null && grep -qF '[Peer]' "$_vf" 2>/dev/null || return 1
	cp "$_vf" "$_vd.conf" 2>/dev/null
}



vpn_meta() {
	_vm=$(jf "$_vj" "@.$1" | head -1)
	if [ -z "$_vm" ] && [ "$_vfound" != root ]; then _vm=$(jf "$_vj" "@.containers[$_vfound].*.$1" | head -1); fi
	if [ -z "$_vm" ] && [ -n "$VPN_INNER" ]; then _vm=$(jf "$_vd.val" "@.$1" | head -1); fi
	printf '%s' "$_vm"
}
is_dns_ip() { case "$1" in ''|*[!0-9A-Fa-f:.]*) return 1 ;; esac; return 0; }



vpn_from() {
	_vj="$1"; _vfound=; VPN_INNER=; _vmtu=; _vdns1=; _vdns2=
	rm -f "$_vd.conf" "$_vd.inner" "$_vd.val" 2>/dev/null
	if jf "$_vj" '@' >/dev/null 2>&1; then
		for _vp in '@.config' '@.last_config'; do
			if vpn_val "$_vj" "$_vp" "$_vd.val" && vpn_conf_in "$_vd.val"; then _vfound=root; break; fi
		done
		_vi=0
		while [ -z "$_vfound" ] && [ "$_vi" -lt "$VPN_CONT" ]; do
			for _vp in "@.containers[$_vi].*.last_config" "@.containers[$_vi].*.config" "@.containers[$_vi].last_config" "@.containers[$_vi].config"; do
				if vpn_val "$_vj" "$_vp" "$_vd.val" && vpn_conf_in "$_vd.val"; then _vfound=$_vi; break; fi
			done
			_vi=$((_vi + 1))
		done
		if [ -z "$_vfound" ] && [ "$_vi" -eq "$VPN_CONT" ] && vpn_val "$_vj" "@.containers[$_vi]" "$_vd.val"; then N_PARTIAL=1; fi
		[ -n "$_vfound" ] || return 1
		VPN_NAME=$(vpn_meta description)
		_vdns1=$(vpn_meta dns1); _vdns2=$(vpn_meta dns2); _vmtu=$(vpn_meta mtu)
	else

		grep -q "^[ $TAB]*\[Interface\][ $TAB$SAN_CR]*\$" "$_vj" 2>/dev/null \
			&& grep -q "^[ $TAB]*\[Peer\][ $TAB$SAN_CR]*\$" "$_vj" 2>/dev/null || return 1
		cp "$_vj" "$_vd.conf" 2>/dev/null || return 1
	fi

	sed "s/$SAN_CR\$//" "$_vd.conf" 2>/dev/null | tr '\r' '\n' > "$_vd.fin" 2>/dev/null || return 1



	if grep -qE '\$[{]?(PRIMARY|SECONDARY)_DNS' "$_vd.fin" 2>/dev/null; then
		is_dns_ip "$_vdns1" || _vdns1=1.1.1.1
		is_dns_ip "$_vdns2" || _vdns2=1.0.0.1
		lbl_commit_out "$_vd.fin" sed "s/\\\$[{]\\{0,1\\}PRIMARY_DNS[}]\\{0,1\\}/$_vdns1/g; s/\\\$[{]\\{0,1\\}SECONDARY_DNS[}]\\{0,1\\}/$_vdns2/g" "$_vd.fin" 2>/dev/null || return 1
	fi



	if ! grep -qi "^[ $TAB]*DNS[ $TAB]*=" "$_vd.fin" 2>/dev/null; then
		iface_add "$_vd.fin" "DNS = 1.1.1.1, 1.0.0.1" || return 1
	fi


	_vmtu=$(printf '%s' "$_vmtu" | sed 's/\..*//' | tr -cd '0-9' | sed 's/^0*//')
	if [ -n "$_vmtu" ] && [ "${#_vmtu}" -le 4 ] && [ "$_vmtu" -ge 1280 ] && [ "$_vmtu" -le 1500 ] \
	   && ! grep -qi "^[ $TAB]*MTU[ $TAB]*=" "$_vd.fin" 2>/dev/null; then
		iface_add "$_vd.fin" "MTU = $_vmtu" || return 1
	fi
	[ -s "$_vd.fin" ]
}




iface_add() {
	lbl_commit_out "$1" awk -v l="$2" '
		{ L[NR] = $0 }
		END {
			pos = 0
			for (i = 1; i <= NR; i++) {
				if (L[i] ~ /^[ \t]*\[[Ii][Nn][Tt][Ee][Rr][Ff][Aa][Cc][Ee]\]/) pos = i
				else if (pos > 0 && L[i] ~ /^[ \t]*[Aa][Dd][Dd][Rr][Ee][Ss][Ss][ \t]*=/) { pos = i; break }
				else if (pos > 0 && L[i] ~ /^[ \t]*\[/) break
			}
			for (i = 1; i <= NR; i++) { print L[i]; if (i == pos) print l }
		}' "$1" 2>/dev/null
}




vpn_decode() {
	vpn_raw "$1" || return 1
	if [ -s "$_vd.un" ]; then vpn_from "$_vd.un" && return 0; fi
	vpn_from "$_vd.bin"
}


vpn_raw() {
	VPN_NAME=; _vd="$TMPD/vpn"
	rm -f "$_vd".* 2>/dev/null
	printf '%s' "$1" | lbl_commit_out "$_vd.bin" b64_dec 2>/dev/null
	[ -s "$_vd.bin" ] || return 1
	_voff=
	if zlib_at "$_vd.bin" 4; then _voff=4; elif zlib_at "$_vd.bin" 0; then _voff=0; fi
	[ -z "$_voff" ] || zlib_inflate "$_vd.bin" "$_voff" "$_vd.un" || rm -f "$_vd.un" 2>/dev/null
	return 0
}

vpn_body() { head -n 1 "$1" 2>/dev/null | tr -d " \r\t" | sed 's#^vpn://##'; }




awg_take() {
	grep -q "^[ $TAB]*\[Interface\][ $TAB]*\$" "$1" 2>/dev/null && grep -q "^[ $TAB]*\[Peer\][ $TAB]*\$" "$1" 2>/dev/null || return 1
	grep -qE "^[ $TAB]*PrivateKey[ $TAB]*=[ $TAB]*[A-Za-z0-9+/]{43}=[ $TAB]*\$" "$1" || return 1
	grep -qE "^[ $TAB]*PublicKey[ $TAB]*=[ $TAB]*[A-Za-z0-9+/]{43}=[ $TAB]*\$" "$1" || return 1
	_ae=$(sed -n "s/^[ $TAB]*Endpoint[ $TAB]*=[ $TAB]*//p" "$1" | head -1 | tr -d " $TAB")
	hp_split "$_ae" || return 1
	P_HOST=$HP_HOST; P_PORT=$HP_PORT
	lbl_commit_out "$TMPD/awg.conf" awk '{ L[NR] = $0 } END { n = NR; while (n > 0 && L[n] ~ /^[ \t]*$/) n--; for (i = 1; i <= n; i++) print L[i] }' "$1" 2>/dev/null || return 1
	[ -s "$TMPD/awg.conf" ] || return 1
	P_CONF="$TMPD/awg.conf"
}




awg_comment() {
	sed -n "s/^[ $TAB]*#[ $TAB]*\([^ $TAB].*\)\$/\1/p" "$1" 2>/dev/null | sed "s/[ $TAB]*\$//" | grep -v '=' \
		| while IFS= read -r _ac; do
			[ "$(printf '%s' "$_ac" | tr -d '\200-\277' | wc -c)" -le 40 ] || continue
			printf '%s' "$_ac"
			break
		done
}


parse_vpn() {
	p_reset; P_PROTO=awg
	vpn_decode "$1" || return 1
	awg_take "$_vd.fin" || return 1
	P_REMARK=$(san_txt "$VPN_NAME" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')
	[ -n "$P_REMARK" ] || P_REMARK=$(san_txt "$(awg_comment "$P_CONF")")
	return 0
}



wg_key() {
	_wkk=$(printf '%s' "$1" | tr ' ' '+' | tr -d '\r\n\t')
	case "$_wkk" in *=) : ;; *) [ "${#_wkk}" -eq 43 ] && _wkk="$_wkk=" ;; esac
	printf '%s' "$_wkk" | grep -qE '^[A-Za-z0-9+/]{43}=$' || return 1
	printf '%s' "$_wkk"
}



wg_list() {
	ud "$(printf '%s' "$1" | tr '+' ' ')" | tr ', \t' '\n\n\n' | while IFS= read -r _wl || [ -n "$_wl" ]; do
		[ -n "$_wl" ] || continue
		case "$_wl" in *[!$2]*) continue ;; esac
		printf '%s\n' "$_wl"
	done | awk 'NR > 1 { printf ", " } { printf "%s", $0 }'
}




parse_wg() {
	p_reset; P_PROTO=awg
	_s=$(printf '%s' "$1" | tr -d '\r')
	_wrem=
	case "$_s" in *#*) _wrem=$(san_txt "$(ud "${_s#*#}")"); _s=${_s%%#*} ;; esac
	_q=""
	case "$_s" in *\?*) _q=${_s#*\?}; _s=${_s%%\?*} ;; esac
	case "$_s" in *@*) : ;; *) return 1 ;; esac
	_ui=${_s%@*}; _hp=${_s##*@}
	hp_split "$_hp" || return 1
	_wep="$HP_HOST:$HP_PORT"
	case "$HP_HOST" in *:*) _wep="[$HP_HOST]:$HP_PORT" ;; esac
	_wk=$(wg_key "$(ud "$_ui")") || return 1
	_wpub=; _wpsk=; _waddr=; _wdns=; _wmtu=; _wka=; _wbad=
	_oifs=$IFS; IFS='&'
	for _kv in $_q; do
		[ -n "$_kv" ] || continue
		case "$_kv" in *=*) : ;; *) continue ;; esac
		_k=${_kv%%=*}; _v=${_kv#*=}
		case "$_k" in
			publickey)    _wpub=$(wg_key "$(ud "$_v")") || _wbad=1 ;;
			presharedkey) _wpsk=$(wg_key "$(ud "$_v")") || _wbad=1 ;;
			address)      _waddr=$(wg_list "$_v" '0-9A-Fa-f:./') ;;
			dns)          _wdns=$(wg_list "$_v" '0-9A-Za-z:.-') ;;
			mtu)          _wmtu=$(ud "$_v" | tr -cd '0-9' | sed 's/^0*//') ;;
			keepalive)    _wka=$(ud "$_v" | tr -cd '0-9' | sed 's/^0*//') ;;
		esac
	done
	IFS=$_oifs


	[ -z "$_wbad" ] && [ -n "$_wpub" ] && [ -n "$_waddr" ] || return 1
	lbl_commit_out "$TMPD/wg.conf" wg_emit 2>/dev/null || return 1
	awg_take "$TMPD/wg.conf" || return 1
	P_REMARK=$_wrem
	return 0
}

wg_emit() {
	printf '[Interface]\nPrivateKey = %s\nAddress = %s\n' "$_wk" "$_waddr"




	printf 'DNS = %s\n' "${_wdns:-1.1.1.1, 1.0.0.1}"
	if [ -n "$_wmtu" ] && [ "${#_wmtu}" -le 4 ] && [ "$_wmtu" -ge 1280 ] && [ "$_wmtu" -le 1500 ]; then printf 'MTU = %s\n' "$_wmtu"; fi
	printf '\n'
	[ -z "$_wrem" ] || printf '# %s\n' "$_wrem"
	printf '[Peer]\nPublicKey = %s\n' "$_wpub"
	[ -z "$_wpsk" ] || printf 'PresharedKey = %s\n' "$_wpsk"
	printf 'AllowedIPs = 0.0.0.0/0, ::/0\nEndpoint = %s\n' "$_wep"
	if [ -n "$_wka" ] && [ "${#_wka}" -le 5 ] && [ "$_wka" -le 65535 ]; then printf 'PersistentKeepalive = %s\n' "$_wka"; fi
	return 0
}




parse_any() {
	_pl=$(printf '%s' "$1" | tr -d '\r')
	case "$_pl" in
		hy2://*)       parse_hy2 "${_pl#hy2://}" ;;
		hysteria2://*) parse_hy2 "${_pl#hysteria2://}" ;;
		vpn://*)       parse_vpn "${_pl#vpn://}" ;;
		wireguard://*) parse_wg "${_pl#wireguard://}" ;;
		*)             parse_link "$_pl" ;;
	esac
}









emit_cfg() {
	printf '{\n  "log": {\n    "access": "none",\n    "error": "/tmp/xray.log",\n    "loglevel": "warning"\n  },\n'
	printf '  "inbounds": [\n    {\n      "tag": "socks-in",\n      "listen": "127.0.0.1",\n      "port": 10808,\n      "protocol": "socks",\n      "settings": { "udp": true }\n    }\n  ],\n'
	printf '  "outbounds": [\n    {\n      "tag": "proxy",\n      "protocol": "%s",\n' "$P_PROTO"

	printf '      "settings": {\n'
	case "$P_PROTO" in
		vmess)
			printf '        "vnext": [\n          {\n            "address": "%s",\n            "port": %s,\n            "users": [\n              { "id": "%s", "alterId": %s, "security": "%s" }\n            ]\n          }\n        ]\n' \
				"$P_HOST" "$P_PORT" "$P_UUID" "${P_AID:-0}" "${P_SCY:-auto}" ;;
		trojan)
			printf '        "servers": [\n          {\n            "address": "%s",\n            "port": %s,\n            "password": "%s"%s\n          }\n        ]\n' \
				"$P_HOST" "$P_PORT" "$P_PASS" "$([ -n "$P_FLOW" ] && printf ',\n            "flow": "%s"' "$P_FLOW")" ;;
		shadowsocks)
			printf '        "servers": [\n          {\n            "address": "%s",\n            "port": %s,\n            "method": "%s",\n            "password": "%s"\n          }\n        ]\n' \
				"$P_HOST" "$P_PORT" "${P_METHOD:-aes-128-gcm}" "$P_PASS" ;;
		*)
			printf '        "vnext": [\n          {\n            "address": "%s",\n            "port": %s,\n            "users": [\n              { "id": "%s", "encryption": "%s"%s }\n            ]\n          }\n        ]\n' \
				"$P_HOST" "$P_PORT" "$P_UUID" "${P_ENC:-none}" "$([ -n "$P_FLOW" ] && printf ', "flow": "%s"' "$P_FLOW")" ;;
	esac
	printf '      },\n'

	_net=${P_TYPE:-tcp}; _sec=${P_SEC:-none}
	case "$_net" in splithttp) _net=xhttp ;; http) _net=h2 ;; esac
	case "$_sec" in xtls) _sec=tls ;; esac
	printf '      "streamSettings": {\n        "network": "%s",\n        "security": "%s"' "$_net" "$_sec"
	if [ "$_sec" = reality ]; then
		printf ',\n        "realitySettings": {\n          "serverName": "%s",\n          "fingerprint": "%s",\n          "publicKey": "%s",\n          "shortId": "%s",\n          "spiderX": "%s"\n        }' \
			"$P_SNI" "${P_FP:-chrome}" "$P_PBK" "$P_SID" "$P_SPX"
	elif [ "$_sec" = tls ]; then
		printf ',\n        "tlsSettings": {\n          "serverName": "%s",\n          "fingerprint": "%s"' "$P_SNI" "${P_FP:-chrome}"
		if [ -n "$P_ALPN" ]; then
			printf ',\n          "alpn": ['
			_first=1; _oifs=$IFS; IFS=','
			for _a in $P_ALPN; do [ -n "$_a" ] || continue; [ $_first -eq 1 ] || printf ', '; printf '"%s"' "$_a"; _first=0; done
			IFS=$_oifs; printf ']'
		fi
		printf '\n        }'
	fi
	case "$_net" in
		ws)
			printf ',\n        "wsSettings": {\n          "path": "%s"' "${P_PATH:-/}"
			[ -n "$P_HHDR" ] && printf ',\n          "headers": { "Host": "%s" }' "$P_HHDR"
			printf '\n        }' ;;
		grpc)
			printf ',\n        "grpcSettings": {\n          "serviceName": "%s"\n        }' "$P_SVC" ;;
		xhttp)
			printf ',\n        "xhttpSettings": {\n          "path": "%s",\n          "mode": "%s"' "${P_PATH:-/}" "${P_MODE:-auto}"
			[ -n "$P_HHDR" ] && printf ',\n          "host": "%s"' "$P_HHDR"
			printf '\n        }' ;;
		httpupgrade)
			printf ',\n        "httpupgradeSettings": {\n          "path": "%s"' "${P_PATH:-/}"
			[ -n "$P_HHDR" ] && printf ',\n          "host": "%s"' "$P_HHDR"
			printf '\n        }' ;;
		h2)
			printf ',\n        "httpSettings": {\n          "path": "%s"' "${P_PATH:-/}"
			if [ -n "$P_HHDR" ]; then
				printf ',\n          "host": ['
				_first=1; _oifs=$IFS; IFS=','
				for _a in $P_HHDR; do [ -n "$_a" ] || continue; [ $_first -eq 1 ] || printf ', '; printf '"%s"' "$_a"; _first=0; done
				IFS=$_oifs; printf ']'
			fi
			printf '\n        }' ;;
	esac
	printf '\n      }\n    }\n  ]\n}\n'
}






FAM_DIR=; FAM_EXT=; FAM_ACT=; FAM_LIVE=; FAM_TSH=; FAM_TNAME=


FAMS="xray hy2 awg"
fam_set() {
	case "$1" in
		hy2)
			FAM_DIR="$HY2DIR"; FAM_EXT=yaml; FAM_ACT="$HY2_ACTIVE_F"
			FAM_LIVE="$ENODIA_STATE/hysteria.yaml"; FAM_TSH=transport-hy2.sh; FAM_TNAME=hy2 ;;
		awg)



			FAM_DIR="$AWGDIR";  FAM_EXT=conf; FAM_ACT="$AWG_ACTIVE_F"
			FAM_LIVE="$ENODIA_STATE/awg.conf";      FAM_TSH=switch-vpn.sh; FAM_TNAME=awg ;;
		*)
			FAM_DIR="$CFGDIR";  FAM_EXT=json; FAM_ACT="$ACTIVE_F"
			FAM_LIVE="$ENODIA_STATE/xray.json";     FAM_TSH=xray-transport.sh; FAM_TNAME=xray ;;
	esac
}

name_elsewhere() {
	[ "$FAM_EXT" = json ] || [ ! -f "$CFGDIR/$1.json" ] || return 0
	[ "$FAM_EXT" = yaml ] || [ ! -f "$HY2DIR/$1.yaml" ] || return 0
	[ "$FAM_EXT" = conf ] || [ ! -f "$AWGDIR/$1.conf" ] || return 0
	return 1
}




conf_val() { sed -n "s/^[ $TAB]*$2[ $TAB]*=[ $TAB]*//p" "$1" 2>/dev/null | head -1 | tr -d " $TAB\r"; }
cfg_addr() {
	case "$1" in
		*.yaml) sed -n 's/^server: *\(.*\):[0-9]\{1,5\}$/\1/p' "$1" 2>/dev/null | head -1 | tr -d '[]' ;;
		*.conf) conf_val "$1" Endpoint | sed 's/:[0-9]*$//' | tr -d '[]' ;;
		*)      xp_field "$1" address ;;
	esac
}
cfg_port() {
	case "$1" in
		*.yaml) sed -n 's/^server: .*:\([0-9]\{1,5\}\)$/\1/p' "$1" 2>/dev/null | head -1 ;;
		*.conf) conf_val "$1" Endpoint | sed -n 's/^.*:\([0-9]\{1,5\}\)$/\1/p' ;;
		*)      xp_field "$1" port ;;
	esac
}
cfg_cred() {
	case "$1" in
		*.yaml) sed -n 's/^auth: "\(.*\)"$/\1/p' "$1" 2>/dev/null | head -1 ;;
		*.conf) conf_val "$1" PrivateKey ;;
		*)      _cc=$(xp_field "$1" account.id); [ -n "$_cc" ] || _cc=$(xp_field "$1" account.password); san "$_cc" ;;
	esac
}



cfg_sig() {
	[ -f "$1" ] || return 1
	case "$1" in
		*.yaml)


			grep -E '^(server:|auth:|  sni:|  insecure:|  type:|    password:)' "$1" 2>/dev/null \
				| tr -d ' \t' | sort | tr '\n' ';' ;;
		*.conf)




			tr -d " $TAB\r" < "$1" 2>/dev/null | grep -vE '^(#|$)' | grep -vE '^[A-Za-z0-9]+=$' | tr '\n' ';' ;;
		*)
			_csg=$(xp_runtime "$1" 10808) || return 1
			printf '%s\n' "$_csg" | md5sum | cut -d' ' -f1 ;;
	esac
}



cfg_identity() {
	case "$1" in
		*.yaml|*.conf)
			_ci_host=$(cfg_addr "$1" | tr 'A-Z' 'a-z')
			_ci_port=$(cfg_port "$1")
			[ -n "$_ci_host" ] && [ -n "$_ci_port" ] || return 1
			_ci_text=$(printf '%s\n%s\n%s\n%s' "${1##*.}" "$_ci_host" "$_ci_port" "$(cfg_cred "$1")")
			if [ "${1##*.}" = conf ]; then _ci_text="$_ci_text$LBL_NL$(conf_val "$1" PublicKey)"; fi ;;
		*) _ci_text=$(xp_subscription_ids "$1"); [ -n "$_ci_text" ] || return 1 ;;
	esac
	printf '%s' "$_ci_text" | sha256sum | cut -d' ' -f1
}
identity_index() (
	for _ii_family in $FAMS; do
		fam_set "$_ii_family"
		for _ii_cfg in "$FAM_DIR"/sub-"$1"-*."$FAM_EXT"; do
			[ -f "$_ii_cfg" ] || continue
			_ii_name=${_ii_cfg##*/}; _ii_name=${_ii_name%.*}
			[ "$(sub_owner_tag "$_ii_name")" = "$1" ] || continue
			_ii_key=$(cfg_identity "$_ii_cfg") || continue
			printf '%s\t%s\t%s\n' "$_ii_key" "$FAM_TNAME" "$_ii_name"
		done
	done
)
stage_identities() {
	: > "$TMPD/old-names"
	[ ! -f "$NAMES" ] || cat "$NAMES" > "$TMPD/old-names"
	identity_index "$1" > "$TMPD/identities"
}
name_taken() {
	[ -e "$FAM_DIR/$1.$FAM_EXT" ] || name_elsewhere "$1" || grep -qxF "$1" "$TMPD/used"
}
name_for() {   # tag, remark, ordinal, full identity digest
	printf '%s\n' "$2" > "$TMPD/remark"
	_nm=$(awk -F "$TAB" -v id="$4" -v kind="$FAM_TNAME" '
		FILENAME==ARGV[1] {remark=$0; next}
		FILENAME==ARGV[2] {used[$1]=1; next}
		FILENAME==ARGV[3] {label[$1]=$2; next}
		$1==id && $2==kind && !used[$3] {
			if ((label[$3] "") == (remark "")) {pick=$3; exit}
			if (!first) first=$3
		}
		END {print (pick ? pick : first)}
	' "$TMPD/remark" "$TMPD/used" "$TMPD/old-names" "$TMPD/identities")
	if [ -z "$_nm" ]; then
		_rem=$(printf '%s' "$2" | sed 's/[^A-Za-z0-9._-]/-/g; s/^-*//; s/-*$//')
		_hp=$(printf '%s-%s' "$P_HOST" "$P_PORT" | sed 's/[^A-Za-z0-9]/-/g; s/^-*//; s/-*$//')
		if [ -n "$P_PROFILE" ]; then _hp="pool-$(printf '%.12s' "$4")"; fi
		case "$_rem" in
			'')        _rem="$_hp" ;;
			*[!0-9-]*) : ;;
			*)         _rem="$_hp-$_rem" ;;
		esac
		_nm=$(printf 'sub-%s-%s' "$1" "${_rem:-$3}" | cut -c1-48)
		if name_taken "$_nm"; then
			_base=$(printf '%s' "$_nm" | cut -c1-39)
			_h=$(printf '%.8s' "$4")
			_nm="$_base-$_h"
			_k=2
			while name_taken "$_nm"; do _nm="$_base-$_h-$_k"; _k=$((_k+1)); done
		fi
	fi
	echo "$_nm" >> "$TMPD/used"
	printf '%s' "$_nm"
}



put_server() {
	_t="$1"; _i="$2"
	[ -n "$P_PROFILE" ] || { is_host "$P_HOST" && is_port "$P_PORT"; } || { N_BAD=$((N_BAD+1)); return 1; }


	fam_set "$P_PROTO"
	mkdir -p "$FAM_DIR" 2>/dev/null
	_raw=$(printf '%s' "$P_REMARK" | tr -d '\r\n\t' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')
	[ -n "$_raw" ] || _raw="#$_i"




	case "$P_PROTO" in
		hy2) emit_hy2 > "$TMPD/cfg.new.$FAM_EXT" 2>/dev/null ;;
		awg) cat "$P_CONF" > "$TMPD/cfg.new.$FAM_EXT" 2>/dev/null ;;   # the link IS the config: awg_take has checked and trimmed it
		*)   if [ -n "$P_PROFILE" ]; then cat "$P_PROFILE"; else emit_cfg; fi > "$TMPD/cfg.new.$FAM_EXT" 2>/dev/null ;;
	esac
	[ -s "$TMPD/cfg.new.$FAM_EXT" ] || { N_BAD=$((N_BAD+1)); return 1; }
	_new_id=$(cfg_identity "$TMPD/cfg.new.$FAM_EXT") || { N_BAD=$((N_BAD+1)); return 1; }
	_nm=$(name_for "$_t" "$_raw" "$_i" "$_new_id")
	_dst="$FAM_DIR/$_nm.$FAM_EXT"
	if [ ! -f "$_dst" ]; then
		cfg_put "$TMPD/cfg.new.$FAM_EXT" "$_dst" || return 1
		N_NEW=$((N_NEW+1))
	elif [ "$(cfg_sig "$TMPD/cfg.new.$FAM_EXT")" != "$(cfg_sig "$_dst")" ]; then
		cfg_put "$TMPD/cfg.new.$FAM_EXT" "$_dst" || return 1
		N_CHG=$((N_CHG+1))
		printf '%s\t%s\n' "$FAM_TNAME" "$_nm" >> "$TMPD/changed"
	else
		rm -f "$TMPD/cfg.new.$FAM_EXT" 2>/dev/null
		N_SAME=$((N_SAME+1))
	fi
	keep_server
}

keep_server() {
	if ! { printf '%s\t%s\n' "$_nm" "$_raw" >> "$TMPD/names" && printf '%s\n' "$_nm" >> "$TMPD/keep"; }; then
		N_SPACE_STOP="не удалось сохранить имена серверов"
		return 1
	fi

	N_NAME_BYTES=$((N_NAME_BYTES+${#_nm}+4*${#_raw}+2))
}

sub_space() {
	_sfree=$(df -Pk "$ENODIA_STATE" 2>/dev/null | awk 'NR==2 && $4 ~ /^[0-9]+$/ { print $4 }')
	[ -n "$_sfree" ] && [ "$_sfree" -ge "$((MINFREE_KB+$1))" ]
}
sub_space_reason() {
	if [ -n "$_sfree" ]; then printf 'мало места на разделе настроек'; else printf 'не удалось проверить свободное место'; fi
}




cfg_put() {
	_cpbytes=$(wc -c < "$1")
	if ! sub_space "$((4+(_cpbytes+N_NAME_BYTES+${#_nm}+4*${#_raw}+2+1023)/1024))"; then
		N_SPACE_STOP=$(sub_space_reason)
		rm -f "$1" 2>/dev/null
		return 1
	fi
	( umask 077; lbl_commit_out "$2" cat "$1" ) 2>/dev/null; _cpr=$?
	if [ "$_cpr" = 0 ] && [ "$FAM_EXT" = json ] && command -v xp_meta_stage >/dev/null 2>&1; then
		cfg_meta_stage "$1" >> "$TMPD/xray-meta" 2>/dev/null || N_META_BAD=1
	fi
	rm -f "$1" 2>/dev/null
	[ "$_cpr" = 0 ] && return 0
	say "  конфиг «$(basename "$2")» не записался (место на разделе?) — прежний оставлен"
	N_BAD=$((N_BAD+1))
	N_SPACE_STOP="не удалось записать конфиг"
	return 1
}
cfg_meta_stage() {

	if [ -n "$P_PROFILE" ] || [ "$P_HOST" = null ]; then xp_meta_stage "$1"; return; fi
	_cms_flow=; _cms_sni=; _cms_fp=
	case "$P_PROTO" in vless|trojan) _cms_flow=$P_FLOW ;; esac
	case "$_sec" in tls|reality) _cms_sni=$P_SNI; _cms_fp=${P_FP:-chrome} ;; esac
	case "$_net$_sec$_cms_flow$_cms_sni$_cms_fp" in
		*[!A-Za-z0-9._:-]*) xp_meta_stage "$1" ;;
		*) xp_meta_stage "$1" "$P_PROTO" "$P_HOST" "$_cms_flow" "$_net" "$_sec" "$_cms_sni" "$_cms_fp" ;;
	esac
}


relay_read_progress() {
	[ -n "${SUB_RELAY_PROGRESS:-}" ] || return 0
	case "$N_READ" in 1|*0) ;;
		*) return 0 ;;
	esac
	printf '%s\n' "$N_READ" > "$SUB_RELAY_PROGRESS.new" && mv -f "$SUB_RELAY_PROGRESS.new" "$SUB_RELAY_PROGRESS"
}

parse_links() {
	_f="$1"; _t="$2"; _i=0



	while IFS= read -r _line || { [ "$SUB_FETCH_PARTIAL" = 0 ] && [ -n "$_line" ]; }; do
		case "$_line" in *://*) : ;; *) continue ;; esac
		_line=$(printf '%s' "$_line" | tr -d '\r' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')
		if parse_any "$_line"; then
			_i=$((_i+1)); N_READ=$_i; relay_read_progress; put_server "$_t" "$_i"
			[ -z "$N_SPACE_STOP" ] || break
		else
			N_SKIP=$((N_SKIP+1))
		fi
	done < "$_f"
	[ "$_i" -gt 0 ]
}



parse_json() {
	_pj_file=$1; _pj_tag=$2; _pji=0; _n=0; _pj_geo=0
	[ -n "$JF" ] || { say '  подписка JSON требует jsonfilter'; return 1; }
	_pj_xray=$(profile_xray_bin)
	xp_profile_rows "$_pj_file" > "$TMPD/profiles" || return 1
	while IFS= read -r _pj_json; do
		_pji=$((_pji+1)); N_READ=$_pji; relay_read_progress
		printf '%s\n' "$_pj_json" > "$TMPD/el.json" || return 1
		if xp_prepare "$TMPD/el.json" "$TMPD/profile.json" "$_pj_xray"; then
			[ "$XP_GEO_REMOVED" != 1 ] || _pj_geo=1
			p_reset
			P_PROFILE="$TMPD/profile.json"
			P_PROTO=xray
			P_REMARK=$(jf "$TMPD/el.json" '@.remarks')
			[ -n "$P_REMARK" ] || P_REMARK=$(xp_field "$P_PROFILE" tag)
			_n=$((_n+1))
			put_server "$_pj_tag" "$_n"
			[ -z "$N_SPACE_STOP" ] || break
		else
			say "  профиль $_pji пропущен: $XP_REASON"
			N_BAD=$((N_BAD+1))
		fi
	done < "$TMPD/profiles"
	if [ "$_pj_geo" = 1 ]; then
		RUN_GEO=1
		say "  $(xp_geo_notice)"
	fi
	[ "$_n" -gt 0 ]
}





prune_stale() {
	_t="$1"


	for _psf in $FAMS; do
		fam_set "$_psf"
		_act=$(cat "$FAM_ACT" 2>/dev/null | tr -d ' \r\n"\\')


		_phome=""; [ "$_psf" != awg ] || _phome=$(cat "$ENODIA_STATE/.failover-home" 2>/dev/null | tr -d ' \r\n"\\')
		for _f in "$FAM_DIR"/sub-"$_t"-*."$FAM_EXT"; do
			[ -e "$_f" ] || continue
			_b=$(basename "$_f" ".$FAM_EXT")
			[ "$(sub_owner_tag "$_b")" = "$_t" ] || continue
			grep -qxF "$_b" "$TMPD/keep" 2>/dev/null && continue
			if [ -n "$_phome" ] && [ "$_b" = "$_phome" ] && [ "$_b" != "$_act" ]; then HOME_GONE="${HOME_GONE:+$HOME_GONE }$_b"; continue; fi
			if [ "$_b" = "$_act" ]; then




				ACT_GONE="${ACT_GONE:+$ACT_GONE }$_b"
				continue
			fi




			_hx=$(held_by "$FAM_TNAME" "$_b")
			if [ -n "$_hx" ]; then
				HELD_GONE="${HELD_GONE:+$HELD_GONE }$_b:$_hx"
				continue
			fi
			cfg_gone "$_f" "$_b"
			case "$?" in
				0) N_DEL=$((N_DEL+1)) ;;
				2)
					BUSY_GONE="$BUSY_GONE $_b"
					say "  сервер «$(disp_of "$_b")» оставлен: занят выходом/дорогой или выбран для подключения" ;;
				*) DEL_FAILED="$DEL_FAILED $_b" ;;
			esac
			[ "$SUBS_LOCK_MINE" = 1 ] || return 1
		done
	done
}



held_by() {
	[ -f "$ENODIA_DIR/slots.sh" ] || return 0
	sh "$ENODIA_DIR/slots.sh" holders "$1" "$2" ${3:+"$3"} 2>/dev/null </dev/null | grep -E '^[2-7](,[2-7])*$' | head -1
}


prune_through_owner() (
	if [ -z "${ENODIA_SWITCH_HOLDER:-}" ] ||
	    [ "$(cat "$SWITCH_LOCK" 2>/dev/null)" != "$ENODIA_SWITCH_HOLDER" ]; then
		switch_hold "$SWITCH_LOCK" 0 0 || { echo 'идёт смена транспорта или сервера — повторите удаление'; exit 1; }
		trap 'rm -f "$SWITCH_LOCK"' EXIT
		trap 'exit 1' HUP INT TERM PIPE
	fi
	if [ -f "$ENODIA_DIR/road.sh" ]; then
		sh "$ENODIA_DIR/road.sh" prune-sub "$@"
	elif [ ! -s "$ENODIA_STATE/.cfg-via" ]; then
		sh "$ENODIA_DIR/slots.sh" prune-sub "$@"
	else
		return 1
	fi
)
cfg_gone() {
	_cg_digest=$(lbl_cfg_digest "$1") || return 1
	drop_lock
	_cg_out=$(prune_through_owner "$FAM_TNAME" "$2" "$_cg_digest" 2>&1 </dev/null); _cg_rc=$?
	take_lock || return 1
	if [ -n "$_cg_out" ] && [ "$_cg_rc" != 2 ]; then say "  $_cg_out" >&2; fi
	return "$_cg_rc"
}


disp_of() {
	_dp=$(awk -F"$TAB" -v n="$1" '($1 "") == (n "") { print $2; exit }' "$TMPD/names" 2>/dev/null)
	[ -n "$_dp" ] || _dp=$(awk -F"$TAB" -v n="$1" '($1 "") == (n "") { print $2; exit }' "$NAMES" 2>/dev/null)
	printf '%s' "${_dp:-$1}"
}





names_text() {
	if [ -n "$N_SPACE_STOP$N_PARTIAL" ]; then

		if [ -f "$2" ]; then
			awk -F "$TAB" 'FILENAME==ARGV[1] { new[$1]=1; next } !($1 in new)' "$3" "$2" || return 1
		fi
		cat "$3"
		return $?
	fi
	sub_names_keep_other "$1" "$2"




	if [ -n "$ACT_GONE$HELD_GONE$HOME_GONE$BUSY_GONE$DEL_FAILED" ] && [ -f "$2" ]; then
		for _ag in $ACT_GONE $HELD_GONE $HOME_GONE $BUSY_GONE $DEL_FAILED; do grep "^${_ag%%:*}$TAB" "$2" 2>/dev/null | head -1; done
	fi
	if [ -s "$3" ]; then cat "$3"; fi
	return 0
}


write_names() {
	_t="$1"
	names_text "$_t" "$NAMES" "$TMPD/names" > "$TMPD/names.next" || return 1
	cmp -s "$TMPD/names.next" "$NAMES" && return 0
	if ! sub_space "$((4+($(wc -c < "$TMPD/names.next")+1023)/1024))"; then
		N_SPACE_STOP=$(sub_space_reason)
		return 1
	fi
	( umask 077; lbl_commit_out "$NAMES" cat "$TMPD/names.next" )
}





refresh_active() {   # $1 = the subscription's tag
	_rat=$1

	for _raf in $FAMS; do
		fam_set "$_raf"
		_act=$(cat "$FAM_ACT" 2>/dev/null | tr -d ' \r\n"\\')
		[ -n "$_act" ] || continue

		if [ "$_raf" = awg ]; then refresh_awg "$_rat" "$_act"; continue; fi
		grep -qxF "$FAM_TNAME$TAB$_act" "$TMPD/changed" 2>/dev/null || continue
		cp "$FAM_DIR/$_act.$FAM_EXT" "$FAM_LIVE" 2>/dev/null && chmod 600 "$FAM_LIVE" 2>/dev/null
		if [ "$(cat "$ENODIA_STATE/.transport" 2>/dev/null)" = "$FAM_TNAME" ]; then



			if [ -e /tmp/enodia-switching.lock ]; then
				say "  активный сервер «$_act» изменился, но идёт смена транспорта — несущую не трогаю"
				continue
			fi


			if [ -f "$ENODIA_STATE/.vpn-off" ]; then
				say "  активный сервер «$_act» $CHG — VPN выключен вручную, применится при включении"
				continue
			fi
			[ -f "$ENODIA_DIR/$FAM_TSH" ] || { say "  активный сервер «$_act» изменился, но $FAM_TSH не найден"; continue; }



			if ! switch_hold "$SWITCH_LOCK" "$CARRIER_HOLD_MAX"; then
				say "  активный сервер «$_act» $CHG, но роутер сейчас сам ведёт туннель — применится при следующем подъёме"
				continue
			fi
			say "  активный сервер «$_act» $CHG — перезапускаю несущую"
			sh "$ENODIA_DIR/$FAM_TSH" down >/dev/null 2>&1
			sh "$ENODIA_DIR/$FAM_TSH" up   >/dev/null 2>&1
			rm -f "$SWITCH_LOCK" 2>/dev/null
			ev "subs-active-changed" 3600 "Подписка обновила активный сервер" \
				"Сервер «$_act» $CHG$CHG_D. Конфиг обновлён, несущая перезапущена."
		else
			say "  активный конфиг «$_act» обновлён (применится при переключении на $FAM_TNAME)"
		fi
	done
}








refresh_awg() {
	_rwa=$2
	[ "$(sub_owner_tag "$_rwa")" = "$1" ] || return 0
	_rwf="$AWGDIR/$_rwa.conf"

	[ -f "$_rwf" ] && [ -s "$FAM_LIVE" ] || return 0
	_rws=$(cfg_sig "$_rwf"); [ -n "$_rws" ] || return 0
	[ "$_rws" != "$(cfg_sig "$FAM_LIVE")" ] || return 0
	_rwd=$(disp_of "$_rwa")
	_rwm=$(printf '%s' "$_rws" | md5sum 2>/dev/null | cut -c1-32 | tr -cd 'a-f0-9')


	if [ -n "$_rwm" ] && [ "$(cat "$AWG_TRIED" 2>/dev/null)" = "$_rwa$TAB$_rwm" ]; then
		if awg_direct; then
			say "  активный сервер «$_rwd»: новый конфиг из подписки уже пробовали — не применился; роутер в прямом режиме, мимо VPN"
			AWG_LAGS=2
		else
			say "  активный сервер «$_rwd»: новый конфиг из подписки уже пробовали — не применился, работает прежний"
			AWG_LAGS=1
		fi
		return 0
	fi
	[ -f "$ENODIA_DIR/switch-vpn.sh" ] || { say "  активный сервер «$_rwd» изменился, но switch-vpn.sh не найден"; return 0; }






	if ! switch_hold "$SWITCH_LOCK" "$CARRIER_HOLD_MAX"; then
		_rwn="применю при следующем обновлении"; [ "${SUBS_PUT_WHY:-}" = premium ] && _rwn="подниму, когда она закончится"
		if awg_direct; then
			say "  активный сервер «$_rwd» $CHG, но идёт смена транспорта или сервера, а роутер в прямом режиме — $_rwn"
			AWG_LAGS=2
		else
			say "  активный сервер «$_rwd» $CHG, но идёт смена транспорта или сервера — $_rwn"
			AWG_LAGS=1
		fi
		AWG_DEFER=1
		return 0
	fi

	_rwt=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
	_rwc=0
	[ "$_rwt" = awg ] && [ ! -f "$ENODIA_STATE/.vpn-off" ] && _rwc=1
	[ "$_rwc" = 1 ] && say "  активный сервер «$_rwd» $CHG — поднимаю новый конфиг"

	sh "$ENODIA_DIR/switch-vpn.sh" refresh "$_rwa" > "$TMPD/refresh.out" 2>&1 </dev/null; _rwr=$?




	_rwr2=""
	case "$_rwt" in ''|awg) ;; *)
		if [ "$(cfg_sig "$FAM_LIVE")" = "$_rws" ] && [ -e /sys/class/net/awg0 ] && [ ! -f "$ENODIA_STATE/.vpn-off" ] && [ -f "$ENODIA_DIR/transport.sh" ]; then
			sh "$ENODIA_DIR/transport.sh" rewarm awg >/dev/null 2>&1 </dev/null && _rwr2="; тёплый резерв AmneziaWG поднят на нём"
		fi ;;
	esac
	rm -f "$SWITCH_LOCK" 2>/dev/null


	if [ "$(cfg_sig "$FAM_LIVE")" = "$_rws" ]; then
		rm -f "$AWG_TRIED" 2>/dev/null
		if [ "$_rwc" = 1 ] && [ "$_rwr" = 0 ]; then
			say "  новый конфиг сервера «$_rwd» поднят"
			ev "subs-active-changed" 3600 "Подписка обновила активный сервер" \
				"Сервер «$_rwd» $CHG. Роутер поднял его новый конфиг."
		elif [ "$_rwt" = awg ]; then
			say "  активный конфиг «$_rwd» обновлён (поднимется при включении VPN)"
		else
			say "  активный конфиг «$_rwd» обновлён (применится при переключении на awg$_rwr2)"
		fi
		return 0
	fi

	if [ "$_rwr" = 3 ]; then
		say "  активный сервер сменился, пока шло обновление, — конфиг «$_rwd» лежит новым, рабочую копию не трогаю"
		return 0
	fi

	_rww=$(grep 'FAIL' "$TMPD/refresh.out" 2>/dev/null | head -1 | tr -d '\033' | sed 's/\[[0-9;]*m//g; s/^[[:space:]]*\[FAIL\][[:space:]]*//' | tr -d '\r\n\t')
	AWG_LAGS=1
	[ -z "$_rwm" ] || lbl_commit_out "$AWG_TRIED" printf '%s\t%s\n' "$_rwa" "$_rwm" 2>/dev/null



	if [ "$_rwc" = 1 ] && awg_direct; then
		say "  новый конфиг сервера «$_rwd» не поднялся, прежний тоже — роутер в прямом режиме, мимо VPN${_rww:+ ($_rww)}"
		_rwx="с новым конфигом туннель не поднялся, прежний тоже не отвечает — роутер в прямом режиме, мимо VPN"
		AWG_LAGS=2
	elif [ "$_rwc" = 1 ]; then
		say "  новый конфиг сервера «$_rwd» не поднялся — работает прежний${_rww:+ ($_rww)}"
		_rwx="с новым конфигом туннель не поднялся — роутер вернул прежний"
	else
		say "  новый конфиг сервера «$_rwd» не разложен — рабочая копия прежняя${_rww:+ ($_rww)}"
		_rwx="разложить его новый конфиг не удалось — рабочая копия осталась прежней"
	fi
	ev "subs-active-refused" 21600 "Новый конфиг активного сервера не применён" \
		"Сервер «$_rwd» $CHG, но $_rwx.${_rww:+ Причина: $_rww.} Роутер попробует снова после перезагрузки или когда конфиг в подписке изменится ещё раз; сразу — выберите этот сервер в панели заново."
	return 0
}




awg_direct() { [ "$(head -n 1 "$WD_STATE" 2>/dev/null | tr -d ' \r\n')" = FAILOPEN ]; }





reup_exits() {
	[ -s "$TMPD/changed" ] && [ -f "$ENODIA_DIR/slots.sh" ] || return 0
	while IFS="$TAB" read -r _rxt _rxn || [ -n "$_rxt" ]; do
		[ -n "$_rxn" ] || continue
		_rxh=$(held_by "$_rxt" "$_rxn" on)
		[ -n "$_rxh" ] || continue
		_oifs=$IFS; IFS=','
		for _rxi in $_rxh; do
			IFS=$_oifs
			_rxo=$(sh "$ENODIA_DIR/slots.sh" refresh-config "$_rxi" "$_rxt" "$_rxn" 2>&1 </dev/null); _rxr=$?
			_rxl=$(printf '%s\n' "$_rxo" | tail -n 1 | sed 's/^\[slots\] //' | tr -d '\r\n\t')
			say "  выход №$_rxi: сервер «$(disp_of "$_rxn")» $CHG — ${_rxl:-перезапущен}"
			if [ "$_rxr" != 0 ] || printf '%s' "$_rxo" | grep -q 'не поднялась'; then
				ev_log "subs-exit-reup" 3600 "Выход №$_rxi не поднялся после обновления подписки" \
					"Сервер «$(disp_of "$_rxn")» $CHG, выход №$_rxi перезапущен с новым конфигом и не поднялся: ${_rxl:-причина не названа}."
			fi
		done
		IFS=$_oifs
	done < "$TMPD/changed"
	return 0
}





ev() { [ -f "$ENODIA_DIR/notify-event.sh" ] && sh "$ENODIA_DIR/notify-event.sh" "$1" "$2" "$3" "$4" >/dev/null 2>&1; return 0; }
ev_log() { [ -f "$ENODIA_DIR/events.sh" ] && sh "$ENODIA_DIR/events.sh" add "$1" "$2" "$3" "$4" >/dev/null 2>&1; return 0; }


partial_note() {
	_partial_note="прочитано $N_READ, остальное не дошло — прежние серверы сохранены"
	say "  $_partial_note"
	ev_log subs-partial 300 "Подписка прочитана частично" "«$_lab»: $_partial_note"
}
update_fetch_failed() {
	say "  $1"
	SUMMARY="$SUMMARY«$_lab»: $1. "
	FAILED=$((FAILED+1))
	sub_info_put "$_t" fail
}
update_one() {
	_t="$1"
	_url=$(sub_url_of "$_t"); _lab=$(sub_label_of "$_t"); [ -n "$_lab" ] || _lab="$_t"



	case "$_url" in
		vpn://*)
			say "подписка «$_lab» ($_t): Amnezia Premium — спрашиваю о подписке"
			if [ ! -f "$ENODIA_DIR/premium.sh" ]; then
				say "  premium.sh не установлен — пропуск"; SUMMARY="$SUMMARY«$_lab»: нет premium.sh. "; FAILED=$((FAILED+1)); return 1
			fi
			_pmo=$(sh "$ENODIA_DIR/premium.sh" update "$_t" 2>&1 </dev/null); _pmr=$?
			_pmo=$(printf '%s\n' "$_pmo" | tail -n 1 | tr -d '\r\t')
			say "  $_pmo"
			if [ "$_pmr" = 0 ]; then SUMMARY="$SUMMARY«$_lab»: $_pmo. "; return 0; fi

			SUMMARY="$SUMMARY«$_lab»: не обновилась ($_pmo). "; FAILED=$((FAILED+1))
			return 1 ;;
	esac
	case "$_url" in http://*|https://*) : ;; *) update_fetch_failed 'нет ссылки в реестре'; return 1 ;; esac
	sub_host_public "$_url" || { update_fetch_failed 'ссылка ведёт на приватный адрес'; return 1; }
	SUB_FETCH_PARTIAL=0
	if [ -n "${2:-}" ]; then
		cp "$2" "$TMPD/body" || { update_fetch_failed 'не удалось прочитать скачанную подписку'; return 1; }
		if command -v sub_unpack_body >/dev/null 2>&1; then sub_unpack_body "$TMPD/body" || :; fi
	else
		say "подписка «$_lab» ($_t): скачиваю"
		SUB_FETCH_VIA=""
		if ! sub_fetch_tag "$_t" "$_url" "$TMPD/body" && [ "$SUB_FETCH_PARTIAL" = 0 ]; then
			update_fetch_failed 'не скачалась: недоступна или пуста'
			return 1
		fi




		sub_info_put "$_t" ok

		[ -n "$SUB_FETCH_VIA" ] && say "  (скачано напрямую через $SUB_FETCH_VIA — хост подписки маршрутизировался в туннель)"
	fi
	: > "$TMPD/keep"; : > "$TMPD/names"; : > "$TMPD/used"; : > "$TMPD/changed"; : > "$TMPD/xray-meta"; N_META_BAD=0
	stage_identities "$_t"
	N_NEW=0; N_CHG=0; N_SAME=0; N_DEL=0; N_SKIP=0; N_BAD=0; N_SPACE_STOP=""; ACT_GONE=""; HELD_GONE=""; HOME_GONE=""; BUSY_GONE=""; _pj_geo=0
	N_READ=0; N_PARTIAL=""; [ "$SUB_FETCH_PARTIAL" = 0 ] || N_PARTIAL=1
	N_NAME_BYTES=0; [ ! -f "$NAMES" ] || N_NAME_BYTES=$(wc -c < "$NAMES")
	DEL_FAILED=""


	if [ "$(head -c 3 "$TMPD/body" 2>/dev/null)" = "$(printf '\357\273\277')" ]; then
		tail -c +4 "$TMPD/body" > "$TMPD/body.no-bom" && mv "$TMPD/body.no-bom" "$TMPD/body"
	fi

	_head=$(head -c 400 "$TMPD/body" 2>/dev/null | tr -d ' \t\r\n' | cut -c1-1)
	_ok=1
	if [ ! -s "$TMPD/body" ]; then
		_ok=0
	elif [ "$_head" = "[" ] || [ "$_head" = "{" ]; then
		parse_json "$TMPD/body" "$_t" || _ok=0
	else
		if ! grep -q '://' "$TMPD/body" 2>/dev/null; then
			( b64_dec < "$TMPD/body"; echo "$?" > "$TMPD/body.status" ) | cat > "$TMPD/body.d" 2>/dev/null || rm -f "$TMPD/body.d" 2>/dev/null
			if [ -s "$TMPD/body.d" ] && grep -q '://' "$TMPD/body.d" 2>/dev/null; then
				mv "$TMPD/body.d" "$TMPD/body"
				if [ "$(cat "$TMPD/body.status" 2>/dev/null)" != 0 ]; then N_PARTIAL=1; SUB_FETCH_PARTIAL=1; fi
			else
				rm -f "$TMPD/body.d" 2>/dev/null
			fi
		fi
		parse_links "$TMPD/body" "$_t" || _ok=0
	fi
	if [ "$_ok" != 1 ]; then
		if [ -n "$N_PARTIAL" ]; then
			partial_note
			SUMMARY="$SUMMARY«$_lab»: $_partial_note. "
			FAILED=$((FAILED+1)); sub_info_put "$_t" fail
			return 1
		fi



		_why=""
		[ "$(wc -c < "$TMPD/body")" -lt 512 ] && _why=$(sed -n 's/.*"\(detail\|error\|message\)"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\2/p' "$TMPD/body" 2>/dev/null | head -1)
		say "  серверов не распознано${_why:+ — подписка ответила: $_why} — реестр конфигов НЕ трогаю"
		SUMMARY="$SUMMARY«$_lab»: не обновилась${_why:+ ($_why)}. "
		FAILED=$((FAILED+1))
		sub_info_put "$_t" fail
		return 1
	fi

	if [ -z "$N_SPACE_STOP" ] && ! sub_space "$((4+(N_NAME_BYTES+1023)/1024))"; then N_SPACE_STOP=$(sub_space_reason); fi
	[ -n "$N_SPACE_STOP$N_PARTIAL" ] || prune_stale "$_t"
	[ "$SUBS_LOCK_MINE" = 1 ] || return 1
	if [ "${N_META_BAD:-0}" = 0 ] && [ -s "$TMPD/xray-meta" ] && command -v xp_meta_publish >/dev/null 2>&1; then
		_meta_stage=$(cat "$TMPD/xray-meta") && xp_meta_publish "$_meta_stage"
	fi
	_names_failed=0
	if [ -s "$TMPD/names" ] || [ -z "$N_SPACE_STOP$N_PARTIAL" ]; then write_names "$_t" || _names_failed=1; fi
	_tot=$((N_NEW+N_CHG+N_SAME))
	say "  серверов $_tot (новых $N_NEW, изменено $N_CHG, снято $N_DEL, пропущено $((N_SKIP+N_BAD)))"
	CH_TOTAL=$((CH_TOTAL+N_NEW+N_CHG+N_DEL))
	SRV_TOTAL=$((SRV_TOTAL+_tot))



	_sumrec="«$_lab»: серверов $_tot (новых $N_NEW, изменено $N_CHG, снято $N_DEL)"
	if [ -n "$ACT_GONE" ]; then
		for _ag in $ACT_GONE; do
			say "  ВНИМАНИЕ: активный сервер «$_ag» исчез из подписки — конфиг ОСТАВЛЕН"
			ev "subs-active-gone" 21600 "Активный сервер исчез из подписки" \
				"Сервер «$_ag» больше не приходит в подписке «$_lab». Конфиг на роутере оставлен (несущую по расписанию не рвём) — выберите другой сервер в панели."
		done
	fi

	if [ -n "$HELD_GONE" ]; then
		for _hg in $HELD_GONE; do
			_hgd=$(disp_of "${_hg%%:*}"); _hgx=$(printf '%s' "${_hg#*:}" | sed 's/,/, №/g')
			say "  ВНИМАНИЕ: сервер «$_hgd» исчез из подписки — конфиг ОСТАВЛЕН: на нём выход №$_hgx"
			ev "subs-held-gone" 21600 "Сервер выхода исчез из подписки" \
				"Сервер «$_hgd» больше не приходит в подписке «$_lab», а на нём стоит выход №$_hgx. Конфиг на роутере оставлен (выход по расписанию не рвём) — выберите выходу другой сервер в «Дополнительных выходах»."
		done
	fi

	for _hm in $HOME_GONE; do
		say "  ВНИМАНИЕ: сервер «$(disp_of "$_hm")» исчез из подписки — конфиг ОСТАВЛЕН: он «дом» резерва, сторож вернётся на него"
	done
	AWG_LAGS=0
	drop_lock
	refresh_active "$_t"
	reup_exits
	take_lock || return 1



	_sumk=0; for _sk in $ACT_GONE $HELD_GONE $HOME_GONE $BUSY_GONE; do _sumk=$((_sumk+1)); done
	[ "$_sumk" = 0 ] || _sumrec="$_sumrec; занятых оставлено $_sumk"
	case "$AWG_LAGS" in
		1) _sumrec="$_sumrec; новый конфиг активного сервера не применён — работает прежний" ;;
		2) _sumrec="$_sumrec; новый конфиг активного сервера не применён, прежний не отвечает — роутер в прямом режиме" ;;
	esac
	if [ -n "$N_SPACE_STOP" ]; then
		_space_result="сохранено $_tot серверов; остальные не сохранены: $N_SPACE_STOP"
		say "  $_space_result"
		_sumrec="$_sumrec; $_space_result"
	fi
	if [ -n "$N_PARTIAL" ]; then partial_note; _sumrec="$_sumrec; $_partial_note"; fi
	[ "$_names_failed" = 0 ] || _sumrec="$_sumrec; не удалось сохранить имена серверов"
	if [ -n "$N_SPACE_STOP$N_PARTIAL" ] || [ "$_names_failed" = 1 ]; then
		FAILED=$((FAILED+1))
		sub_info_put "$_t" fail
		SUMMARY="$SUMMARY$_sumrec. "
		return 1
	fi
	if [ -n "$DEL_FAILED" ]; then
		FAILED=$((FAILED+1))
		sub_info_put "$_t" fail
		SUMMARY="$SUMMARY$_sumrec; не удалось снять устаревшие конфиги. "
		return 1
	fi
	SUMMARY="$SUMMARY$_sumrec. "
	return 0
}


sub_run_record() {

	_record=$(printf '%s' "${SUMMARY:-нет подписок}" | sub_sum_cut 1000)
	_run_ts=$(date +%s 2>/dev/null)
	case "$_run_ts" in ''|*[!0-9]*) _run_ts=1 ;; esac
	_run_prev=$(cut -f1 "$ENODIA_STATE/.subs-last" 2>/dev/null)
	if [ "$_run_prev" = "$_run_ts" ]; then _run_ts=$((_run_ts+1)); fi
	_run_published=0
	if [ ! -d "$ENODIA_STATE/.subs-last" ] &&
	   lbl_commit_out "$ENODIA_STATE/.subs-last" printf '%s\t%s\t%s\t%s\n' \
		"$_run_ts" "$([ "$FAILED" -gt 0 ] && echo fail || echo ok)" "$_record" "${RUN_GEO:-0}"; then
		_run_published=1
	else
		SUMMARY="Не удалось сохранить результат обновления подписок. $SUMMARY"
		_record=$(printf '%s' "$SUMMARY" | sub_sum_cut 1000)
		say "$_record"
	fi
	[ -z "$1" ] || printf 'relay-result\t%s\t%s\n' "${RUN_GEO:-0}" "$_record"
	[ "$_run_published" = 1 ]
}
cmd_update() {
	_one="$1"
	if [ -n "${3:-}" ] && [ "$(sub_url_revision "$(sub_url_of "$_one")")" != "$3" ]; then
		printf 'relay-result\t0\tСсылка подписки изменилась — скачайте подписку заново.\n'
		return 1
	fi
	if [ ! -f "$ENODIA_STATE/.subs" ]; then
		[ -z "$_one" ] && return 0
		SUMMARY="Подписка «$_one» не найдена в реестре."
		[ -z "${2:-}" ] || printf 'relay-result\t0\t%s\n' "$SUMMARY"
		return 1
	fi

	if ! sub_space 0; then
		SUMMARY="сохранено 0 серверов; остальные не сохранены: $(sub_space_reason)."
		FAILED=1
		say "$SUMMARY"
		sub_run_record "${2:-}"
		ev "subs-nospace" 21600 "Нет места для обновления подписок" "$SUMMARY"
		return 1
	fi
	mkdir -p "$CFGDIR" "$HY2DIR" 2>/dev/null
	CH_TOTAL=0; SRV_TOTAL=0; FAILED=0; DONE=0; SUMMARY=""; RUN_GEO=0



	sub_tags > "$TMPD/tags" 2>/dev/null
	while IFS= read -r _tg || [ -n "$_tg" ]; do
		case "$_tg" in ''|*[!a-z0-9-]*) continue ;; esac
		[ -n "$_one" ] && [ "$_one" != "$_tg" ] && continue
		update_one "$_tg" "${2:-}" && DONE=$((DONE+1))
		if [ "$SUBS_LOCK_MINE" != 1 ]; then
			say 'Идёт другая операция с подписками — повторите обновление.'
			[ -z "${2:-}" ] || printf 'relay-result\t0\tИдёт другая операция с подписками — повторите обновление.\n'
			return 1
		fi
	done < "$TMPD/tags"
	if [ -n "$_one" ] && [ "$DONE" = 0 ] && [ "$FAILED" = 0 ]; then
		SUMMARY="Подписка «$_one» не найдена в реестре."
		FAILED=1
	fi
	sub_run_record "${2:-}" || return 1
	if [ "$CH_TOTAL" -gt 0 ] && [ "$DONE" -gt 0 ]; then
		ev_log "subs-update" 300 "Подписки обновлены" "$SUMMARY"
	fi
	if [ -n "${2:-}" ] && [ "$DONE" = 0 ]; then return 1; fi
	if [ "$FAILED" -gt 0 ] && [ "$DONE" = 0 ]; then
		ev "subs-fail" 21600 "Подписки не обновились" "$SUMMARY"
		return 1
	fi
	return 0
}





cmd_client_json() {
	command -v sub_client_read >/dev/null 2>&1 || { printf '{"presets":{},"subs":{}}'; return 0; }
	_cjo=""
	for _cjt in $(sub_tags); do
		case "$_cjt" in ''|*[!a-z0-9-]*) continue ;; esac
		sub_client_read "$_cjt"
		_cjh=""


		[ -n "$SUB_CL_HWID" ] && _cjh="$(printf '%s' "$SUB_CL_HWID" | awk '{ n = length($0); k = int(n / 4); if (k > 4) k = 4; print substr($0, 1, k) "…" substr($0, n - k + 1) }')"
		_cju=$(printf '%s' "$SUB_CL_UA" | sed 's/\\/\\\\/g; s/"/\\"/g')
		_cjo="$_cjo${_cjo:+,}\"$_cjt\":{\"cl\":\"$SUB_CL\",\"ua\":\"$_cju\",\"hwon\":$SUB_CL_HWON,\"hw\":\"$_cjh\",\"src\":\"$SUB_CL_HWSRC\"}"
	done
	printf '{"presets":{"enodia":"%s","happ":"%s","v2rayng":"%s"},"subs":{%s}}' \
		"$(sub_client_ua enodia | sed 's/\\/\\\\/g; s/"/\\"/g')" "$(sub_client_ua happ | sed 's/\\/\\\\/g; s/"/\\"/g')" \
		"$(sub_client_ua v2rayng | sed 's/\\/\\\\/g; s/"/\\"/g')" "$_cjo"
}

cmd_fetch() {
	_t="$1"
	case "$_t" in ''|*[!a-z0-9-]*) echo "плохая метка подписки" >&2; return 1 ;; esac
	_url=$(sub_url_of "$_t")
	[ -z "${2:-}" ] || [ "$(sub_url_revision "$_url")" = "$2" ] || return 4
	case "$_url" in http://*|https://*) : ;; *) echo "подписка не найдена на роутере" >&2; return 1 ;; esac
	sub_host_public "$_url" || { echo "URL подписки ведёт на приватный/локальный адрес — отказ (SSRF)" >&2; return 1; }








	SUB_FETCH_PARTIAL=0
	sub_fetch_tag "$_t" "$_url" "$TMPD/body"; _fetched=$?
	if [ "$SUB_FETCH_PARTIAL" = 1 ]; then sub_info_put "$_t" fail; return 3; fi
	if [ "$_fetched" != 0 ]; then
		sub_info_put "$_t" fail
		echo "подписка недоступна или пустая" >&2; return 1
	fi
	sub_info_put "$_t" ok
	base64 < "$TMPD/body" | tr -d '\r\n'
}






cmd_parse() {
	[ -n "$1" ] || { echo "usage: subs-update.sh parse <ссылка>" >&2; return 1; }
	case "$1" in
		\{*)
			printf '%s\n' "$1" > "$TMPD/el.json" || return 1
			cmd_parse_json "$TMPD/el.json"; return ;;
	esac
	parse_any "$1" || { echo "не разобрал ссылку" >&2; return 1; }
	is_host "$P_HOST" && is_port "$P_PORT" || { echo "плохой адрес или порт в ссылке" >&2; return 1; }
	case "$P_PROTO" in
		awg) cat "$P_CONF" ;;
		hy2) emit_hy2 ;;
		*)   emit_cfg ;;
	esac
}


cmd_parse_json() {
	if ! xp_prepare "$1" "$TMPD/profile.json" "$(profile_xray_bin)"; then
		printf '%s\n' "$XP_REASON" >&2
		return 1
	fi
	[ "$XP_GEO_REMOVED" != 1 ] || xp_geo_notice >&2
	cat "$TMPD/profile.json"
}



cmd_name() {
	[ -n "$1" ] || { echo "usage: subs-update.sh name <ссылка>" >&2; return 1; }
	parse_any "$1" || { echo "не разобрал ссылку" >&2; return 1; }
	printf '%s\n' "$P_REMARK"
}

cmd_list() {
	[ -f "$ENODIA_STATE/.subs" ] || { echo "подписок нет"; return 0; }
	for _t in $(sub_tags); do
		_n=0; _nfam=""




		for _clf in $FAMS; do
			fam_set "$_clf"; _nf=0
			for _f in "$FAM_DIR"/sub-"$_t"-*."$FAM_EXT"; do
				[ -e "$_f" ] || continue
				[ "$(sub_owner_tag "$(basename "$_f" ".$FAM_EXT")")" = "$_t" ] && _nf=$((_nf+1))
			done
			_n=$((_n+_nf)); _nfam="$_nfam$TAB$_nf"
		done


		_kind=link; case "$(sub_url_of "$_t")" in vpn://*) _kind=premium ;; esac
		printf '%s\t%s\t%s%s\t%s\n' "$_t" "$(sub_label_of "$_t")" "$_n" "$_nfam" "$_kind"
	done
}









cmd_drop() {
	_dt="$1"
	case "$_dt" in ''|*[!a-z0-9-]*) echo "плохая метка подписки" >&2; return 1 ;; esac


	case "$(sub_url_of "$_dt")" in vpn://*)
		if [ -f "$ENODIA_DIR/premium.sh" ] && sh "$ENODIA_DIR/premium.sh" busy </dev/null >/dev/null 2>&1; then
			echo "идёт работа с Amnezia Premium"; return 3
		fi ;;
	esac
	_dkept=0
	for _dfam in $FAMS; do
		fam_set "$_dfam"
		_act=$(cat "$FAM_ACT" 2>/dev/null | tr -d ' \r\n"\\')
		_dhome=""; [ "$_dfam" != awg ] || _dhome=$(cat "$ENODIA_STATE/.failover-home" 2>/dev/null | tr -d ' \r\n"\\')
		for _f in "$FAM_DIR"/sub-"$_dt"-*."$FAM_EXT"; do
			[ -e "$_f" ] || continue
			_b=$(basename "$_f" ".$FAM_EXT")

			_do=$(sub_owner_tag "$_b"); [ "${#_dt}" -gt "${#_do}" ] && _do=$_dt
			[ "$_do" = "$_dt" ] || continue
			if [ "$_b" = "$_act" ] || { [ -n "$_dhome" ] && [ "$_b" = "$_dhome" ]; } || [ -n "$(held_by "$FAM_TNAME" "$_b")" ]; then
				_dd=$(awk -F"$TAB" -v n="$_b" '($1 "") == (n "") { print $2; exit }' "$NAMES" 2>/dev/null)
				if [ -n "$_dd" ] && [ -f "$ENODIA_DIR/cfg-names.sh" ]; then
					sh "$ENODIA_DIR/cfg-names.sh" set "$FAM_TNAME" "$_b" "$_dd" >/dev/null 2>&1 </dev/null
				fi
				printf '%s/%s\n' "$FAM_TNAME" "$_b"
				_dkept=$((_dkept+1))
				continue
			fi
			cfg_gone "$_f" "$_b" || return 4
		done
	done


	case "$(sub_url_of "$_dt")" in
		vpn://*) [ ! -f "$ENODIA_DIR/premium.sh" ] || sh "$ENODIA_DIR/premium.sh" drop "$_dt" "$_dkept" >/dev/null 2>&1 </dev/null ;;
	esac






	[ ! -f "$ENODIA_STATE/.subs" ] || ( umask 077; lbl_commit_out "$ENODIA_STATE/.subs" \
		awk -F"$TAB" -v t="$_dt" 'BEGIN { OFS = FS } ($1 "") == (t "") { $2 = "-" } { print }' "$ENODIA_STATE/.subs" ) 2>/dev/null
	return 0
}



cmd_vpn_json() {
	_vjb=$(vpn_body "$1"); [ -n "$_vjb" ] || return 1
	vpn_raw "$_vjb" || return 1
	for _vjf in "$_vd.un" "$_vd.bin"; do
		[ -s "$_vjf" ] && jf "$_vjf" '@' >/dev/null 2>&1 || continue
		( umask 077; lbl_commit_out "$2" cat "$_vjf" ) 2>/dev/null || return 1
		return 0
	done
	return 1
}




cmd_vpn_conf() {
	_vcb=$(vpn_body "$1"); [ -n "$_vcb" ] || return 1
	vpn_raw "$_vcb" || return 1
	if [ -n "${3:-}" ]; then
		_vck=$(head -n 1 "$3" 2>/dev/null | tr -d " \r\n$TAB")
		printf '%s' "$_vck" | grep -qE '^[A-Za-z0-9+/]{43}=$' || return 1
		printf 's#\\$WIREGUARD_CLIENT_PRIVATE_KEY#%s#g\n' "$_vck" > "$TMPD/key.sed" || return 1
		for _vcf in "$_vd.un" "$_vd.bin"; do
			[ ! -s "$_vcf" ] || lbl_commit_out "$_vcf" sed -f "$TMPD/key.sed" "$_vcf" 2>/dev/null || return 1
		done
		rm -f "$TMPD/key.sed"
	fi
	if ! { [ -s "$_vd.un" ] && vpn_from "$_vd.un"; }; then vpn_from "$_vd.bin" || return 1; fi
	awg_take "$_vd.fin" || return 1
	( umask 077; lbl_commit_out "$2" cat "$P_CONF" ) 2>/dev/null
}





cmd_put() {
	_put=$1; _pufam=$2; _pun=$3; _pus=$4
	case "$_put" in ''|*[!a-z0-9-]*) echo "плохая метка подписки"; return 1 ;; esac
	case "$_pufam" in xray|awg) ;; *) echo "плохое семейство конфига"; return 1 ;; esac
	printf '%s' "$_pun" | grep -qE '^sub-[a-z0-9-]{1,80}$' || { echo "плохое имя конфига"; return 1; }
	[ "$(sub_owner_tag "$_pun")" = "$_put" ] || { echo "имя «$_pun» не принадлежит подписке «$_put»"; return 1; }
	[ -s "$_pus" ] || { echo "нет конфига"; return 1; }
	_pud=$(san_txt "$5" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//'); [ -n "$_pud" ] || _pud=$_pun
	fam_set "$_pufam"


	case "${SUBS_PUT_WHY:-}" in premium)
		case "$(sub_url_of "$_put")" in vpn://*) ;; *) echo "подписки «$_put» уже нет — конфиг не разложен"; return 1 ;; esac ;;
	esac
	if name_elsewhere "$_pun"; then echo "имя «$_pun» занято конфигом другого протокола"; return 1; fi
	( umask 077; mkdir -p "$FAM_DIR" ) 2>/dev/null
	_puf="$FAM_DIR/$_pun.$FAM_EXT"
	( umask 077; lbl_commit_out "$_puf" cat "$_pus" ) 2>/dev/null || { echo "не удалось записать конфиг — нет места?"; return 1; }
	chmod 600 "$_puf" 2>/dev/null
	lbl_commit_out "$NAMES" lbl_without "$NAMES" "^$_pun$TAB" "$_pun$TAB$_pud" 2>/dev/null && chmod 600 "$NAMES" 2>/dev/null
	printf '%s\t%s\n' "$FAM_TNAME" "$_pun" > "$TMPD/changed"
	AWG_DEFER=0
	drop_lock
	refresh_active "$_put"
	reup_exits
	echo "конфиг «$_pud» на месте"

	[ "$AWG_DEFER" = 1 ] && return 4
	return 0
}



cmd_settle() {
	case "$1" in ''|*[!a-z0-9-]*) echo "плохая метка подписки"; return 1 ;; esac
	fam_set awg
	_sta=$(cat "$FAM_ACT" 2>/dev/null | tr -d ' \r\n"\\')
	[ -n "$_sta" ] || return 0
	AWG_DEFER=0
	refresh_awg "$1" "$_sta"
	[ "$AWG_DEFER" = 1 ] && return 4
	return 0
}


cmd_unput() {
	_unt=$1; _unfam=$2; _unn=$3
	case "$_unt" in ''|*[!a-z0-9-]*) echo "плохая метка подписки"; return 1 ;; esac
	case "$_unfam" in xray|awg) ;; *) echo "плохое семейство конфига"; return 1 ;; esac
	printf '%s' "$_unn" | grep -qE '^sub-[a-z0-9-]{1,80}$' || { echo "плохое имя конфига"; return 1; }
	[ "$(sub_owner_tag "$_unn")" = "$_unt" ] || { echo "имя «$_unn» не принадлежит подписке «$_unt»"; return 1; }
	fam_set "$_unfam"
	_unf="$FAM_DIR/$_unn.$FAM_EXT"
	_und=$(disp_of "$_unn")
	if [ -e "$_unf" ]; then
		[ "$_unn" != "$(cat "$FAM_ACT" 2>/dev/null | tr -d ' \r\n"\\')" ] || { echo "«$_und» — активный сервер: сперва выберите другой"; return 2; }
		if [ "$_unfam" = awg ] && [ "$_unn" = "$(cat "$ENODIA_STATE/.failover-home" 2>/dev/null | tr -d ' \r\n"\\')" ]; then
			echo "«$_und» — «дом» резерва: сторож вернётся на него; сперва выберите основным другой сервер"; return 2
		fi
		_unx=$(held_by "$FAM_TNAME" "$_unn")
		[ -z "$_unx" ] || { echo "на «$_und» стоит выход №$(printf '%s' "$_unx" | sed 's/,/, №/g') — сперва смените выходу сервер"; return 2; }
		cfg_gone "$_unf" "$_unn"
		case "$?" in
			0) : ;;
			2) echo "сервер «$_und» оставлен: занят выходом/дорогой или выбран для подключения"; return 2 ;;
			*) echo "не удалось удалить «$_und»"; return 1 ;;
		esac
	fi
	echo "сервер «$_und» убран"
}



delete_wire_take() {
	[ -n "$1" ] || return 0
	case "$1" in *[!0-9]*) return 1 ;; esac
	[ -n "${ENODIA_DELETE_WIRE_LOCK:-}" ] && lbl_lock_take "$ENODIA_DELETE_WIRE_LOCK" 'road\.sh' "$1" ||
		{ echo '[road] правила дорог сейчас пересобирает другая операция — повторите'; return 1; }
}
delete_saved_cfg() (   # kind, file, expected digest, wire lock pid, manual|prune
	_da_kind=$1; _da_name=$2; _da_expected=$3
	lbl_cfg_key "$_da_kind/$_da_name" || exit 1
	fam_set "$_da_kind"
	_da_cfg="$FAM_DIR/$_da_name.$FAM_EXT"
	[ -f "$_da_cfg" ] || { echo "нет конфига $_da_name"; exit 1; }
	lbl_cfg_matches "$_da_cfg" "$_da_expected" ||
		{ echo 'Конфиг изменился или его версия неизвестна. Обновите список серверов.'; exit 1; }
	_da_active=$(cat "$FAM_ACT" 2>/dev/null | tr -d ' \r\n"\\')
	_da_reserve=""
	_da_at=$(cat "$ENODIA_STATE/.transport" 2>/dev/null | tr -d ' \r\n')
	if [ "$_da_name" = "$_da_active" ]; then
		[ "$5" != prune ] || exit 2
		if [ "$_da_kind" = awg ]; then
			if [ "${_da_at:-awg}" = awg ] && [ ! -f "$ENODIA_STATE/.vpn-off" ]; then
				echo "нельзя удалить активный конфиг ($_da_name) — сначала переключитесь на другой"; exit 2
			fi

			_da_reserve=stop-selected-reserve
		elif [ "$_da_kind" = "$_da_at" ]; then
			case "$_da_kind" in
				xray) echo 'это активный конфиг при включённом Xray — сначала переключитесь на другой транспорт' ;;
				hy2) echo 'это активный конфиг при включённой Hysteria2 — сначала переключитесь на другой транспорт' ;;
			esac
			exit 2
		fi
	fi
	if [ "$_da_kind" = awg ]; then
		if [ "$_da_name" != "$_da_active" ] && [ "$_da_name" = "$(cat "$ENODIA_STATE/.failover-home" 2>/dev/null | tr -d ' \r\n')" ]; then
			echo "«$_da_name» — «дом» резерва: сторож вернётся на него; сперва выберите основным другой сервер"; exit 2
		fi
		if [ -f "$ENODIA_DIR/road.sh" ]; then
			_da_road=$(sh "$ENODIA_DIR/road.sh" serves awg "$_da_name" 2>/dev/null | tr -cd '0-9')
			[ -z "$_da_road" ] || { echo "конфиг $_da_name служит дорогой (выход №$_da_road) — сначала переключите дорогу его пассажиров на «напрямую»"; exit 2; }
		fi
		_da_holder=$(sh "$ENODIA_DIR/slots.sh" key-holder "$_da_name" main enabled "$_da_reserve" 2>/dev/null)
		case "$?" in
			0) echo "$_da_holder"; exit 2 ;;
			1) : ;;
			*) echo 'Не удалось проверить ключ работающего AmneziaWG — повторите удаление.'; exit 1 ;;
		esac
	fi

	if [ "$5" = prune ] || [ "$_da_kind" != awg ]; then
		_da_holder=$(held_by "$_da_kind" "$_da_name")
		[ -z "$_da_holder" ] || { echo "конфиг $_da_name держит выход №${_da_holder%%,*} — сначала удалите выход или смените его сервер"; exit 2; }
	fi
	_da_names="$ENODIA_STATE/.cfg-names"; _da_favs="$ENODIA_STATE/.server-favs"
	_da_names_stage="$_da_names.$$.delete.new"
	_da_favs_stage="$_da_favs.$$.delete.new"
	_da_sub_stage="$NAMES.$$.delete.new"
	_da_names_locked=0; _da_favs_locked=0
	delete_saved_cleanup() {
		rm -f "$_da_names_stage" "$_da_favs_stage" "$_da_sub_stage"
		[ "$_da_favs_locked" = 0 ] || lbl_lock_drop "$LBL_FAV_LOCK"
		[ "$_da_names_locked" = 0 ] || lbl_lock_drop "$LBL_CFG_NAMES_LOCK"
	}
	trap 'delete_saved_cleanup' EXIT
	trap 'exit 1' HUP INT TERM PIPE
	lbl_lock_take "$LBL_CFG_NAMES_LOCK" "$LBL_CFG_NAMES_HOLDERS" ||
		{ echo 'Имена серверов сейчас меняются — повторите удаление.'; exit 1; }
	_da_names_locked=1
	lbl_lock_take "$LBL_FAV_LOCK" "$LBL_FAV_HOLDERS" ||
		{ echo 'Избранное сейчас меняется — повторите удаление.'; exit 1; }
	_da_favs_locked=1
	lbl_stage_drop "$_da_names" "$_da_kind/$_da_name" "$_da_names_stage" &&
		lbl_stage_drop "$_da_favs" "$_da_kind/$_da_name" "$_da_favs_stage" ||
		{ echo 'Не удалось подготовить обновление имён и избранного.'; exit 1; }
	if ! name_elsewhere "$_da_name"; then
		lbl_stage_drop "$NAMES" "$_da_name" "$_da_sub_stage" ||
			{ echo 'Не удалось подготовить удаление имени сервера подписки.'; exit 1; }
	fi
	delete_wire_take "${4:-}" || exit 1
	lbl_cfg_matches "$_da_cfg" "$_da_expected" ||
		{ echo 'Конфиг изменился или его версия неизвестна. Обновите список серверов.'; exit 1; }

	{ rm -f "$_da_cfg" 2>/dev/null && [ ! -e "$_da_cfg" ]; } || { echo "не удалось удалить $_da_name"; exit 1; }
	_da_warn=0
	if [ -f "$ENODIA_DIR/server-checks-lib.sh" ]; then
		( . "$ENODIA_DIR/server-checks-lib.sh"; sc_drop "$_da_kind" "$_da_cfg" ) >/dev/null 2>&1
	fi
	if [ "$_da_name" = "$_da_active" ]; then
		if [ "$_da_kind" = awg ]; then
			sh "$ENODIA_DIR/switch-vpn.sh" clear-selection "$_da_name" >/dev/null 2>&1 || _da_warn=1
		else
			rm -f "$FAM_ACT" || _da_warn=1
		fi
	fi
	lbl_publish_drop "$NAMES" "$_da_sub_stage" || _da_warn=1
	lbl_publish_drop "$_da_names" "$_da_names_stage" || _da_warn=1
	lbl_publish_drop "$_da_favs" "$_da_favs_stage" || _da_warn=1
	if [ "$_da_kind" = awg ] && [ -f "$ENODIA_DIR/warp.sh" ]; then
		sh "$ENODIA_DIR/warp.sh" prune give >/dev/null 2>&1 || _da_warn=1
	fi
	[ "$_da_warn" = 0 ] || echo 'Конфиг удалён. Не удалось полностью обновить список серверов.'
	exit 0
)



take_lock() {
	if ! mkdir "$LOCK" 2>/dev/null; then
		_p=$(cat "$LOCK/pid" 2>/dev/null | tr -cd '0-9')
		if [ -n "$_p" ] && [ -d "/proc/$_p" ]; then
			say "уже идёт обновление подписок (pid $_p) — выхожу"
			return 1
		fi







		if [ -z "$_p" ]; then
			if unpublished_lock_live "$LOCK"; then
				say "лок обновления подписок свежий, но без pid — жду следующего запуска"
				return 1
			fi
		fi
		say "лок обновления подписок протух — перехватываю"
		rm -rf "$LOCK" 2>/dev/null; mkdir "$LOCK" 2>/dev/null || return 1
	fi
	echo "${1:-$$}" > "$LOCK/pid" 2>/dev/null || { rm -rf "$LOCK"; return 1; }
	SUBS_LOCK_MINE=1
	return 0
}
unpublished_lock_live() {
	_ul_time=$(date -r "$1" +%s 2>/dev/null)
	case "$_ul_time" in ''|*[!0-9]*) return 0 ;; esac
	[ "$(age_since "$_ul_time")" -lt 1800 ]
}
drop_lock() { [ "$SUBS_LOCK_MINE" != 1 ] || rm -rf "$LOCK" 2>/dev/null; SUBS_LOCK_MINE=0; }


take_job() {
	_sj_state_lock=$LOCK
	LOCK="$LOCK.run"
	take_lock; _sj_rc=$?
	LOCK=$_sj_state_lock
	[ "$_sj_rc" = 0 ] || return 1
	SUBS_LOCK_MINE=0; SUBS_JOB_MINE=1
}
subs_job_live() {
	[ -d "$LOCK.run" ] || return 1
	_sj_pid=$(cat "$LOCK.run/pid" 2>/dev/null | tr -cd '0-9')
	if [ -n "$_sj_pid" ]; then [ -d "/proc/$_sj_pid" ]; else unpublished_lock_live "$LOCK.run"; fi
}
drop_job() { [ "$SUBS_JOB_MINE" = 0 ] || rm -rf "$LOCK.run"; SUBS_JOB_MINE=0; }



subs_work_sweep() {
	command -v store_tmp_pid_sweep >/dev/null 2>&1 || return 0
	store_tmp_pid_sweep "${TMPD%.*}"
	store_tmp_pid_sweep "${TMPD%/*}/enodia-cgi-in"
	for _sw_dir in "${TMPD%/*}"/enodia-subs-relay.* "${TMPD%/*}"/enodia-subs-refresh.*; do
		_sw_token=${_sw_dir##*.}
		case "$_sw_token" in *[!A-Za-z0-9]*) continue ;; esac
		[ "${#_sw_token}" = 6 ] && [ -d "$_sw_dir" ] && [ ! -L "$_sw_dir" ] || continue
		if store_pid_live "$(cat "$_sw_dir/launch" 2>/dev/null)" ||
		   store_pid_live "$(cat "$_sw_dir/pid" 2>/dev/null)"; then continue; fi
		if [ -e "$_sw_dir/body" ] || store_tmp_dir_expired "$_sw_dir" 900; then rm -rf "$_sw_dir"; fi
	done
	return 0
}

refresh_path() {
	case "$1" in *[!A-Za-z0-9]*) return 1 ;; esac
	[ "${#1}" = 6 ] || return 1
	_refresh_dir="/tmp/enodia-subs-refresh.$1"
	[ -d "$_refresh_dir" ] && [ ! -L "$_refresh_dir" ]
}
refresh_status() {
	if refresh_path "$1"; then
		[ ! -s "$_refresh_dir/result" ] || { cat "$_refresh_dir/result"; return; }
		if pid_runs "$(cat "$_refresh_dir/pid" 2>/dev/null)" 'subs-import\.sh.*refresh-job'; then
			printf 'running\n'; return
		fi
		[ ! -s "$_refresh_dir/result" ] || { cat "$_refresh_dir/result"; return; }
	fi
	printf 'error\t0\t0\tОбновление подписки прервано.\n'
}
refresh_job() {
	refresh_path "$2" || return 1
	_refresh_ok=0; _refresh_state=refused; RUN_GEO=0
	SUMMARY='Уже идёт обновление подписок. Повторите после его завершения.'
	if take_job && take_lock; then
		SUMMARY=; FAILED=0; DONE=0; _refresh_state=done
		if cmd_update "$1" >/dev/null && [ "$FAILED" = 0 ] && [ "$DONE" -gt 0 ]; then _refresh_ok=1; fi
		[ -n "$SUMMARY" ] || SUMMARY='Нет подписок для обновления.'
	fi
	drop_lock; drop_job
	_refresh_msg=$(printf '%s' "${SUMMARY:-Нет результата обновления подписки.}" | sub_sum_cut 1000)
	( umask 077; lbl_commit_out "$_refresh_dir/result" printf '%s\t%s\t%s\t%s\n' \
		"$_refresh_state" "$_refresh_ok" "${RUN_GEO:-0}" "$_refresh_msg" )
}
import_body_run() {
	case "$1" in ''|*[!a-z0-9-]*) return 1 ;; esac
	[ -s "$2" ] || return 1
	if ! { take_job && take_lock; }; then
		printf 'relay-result\t0\tУже идёт обновление подписок. Повторите после его завершения.\n'
		return 1
	fi
	cmd_update "$1" "$2" "${3:-}"; _ibr_rc=$?
	drop_lock
	return "$_ibr_rc"
}


trim_log() {
	[ -f "$LOG" ] || return 0
	_sz=$(wc -c < "$LOG" 2>/dev/null); [ -n "$_sz" ] || return 0
	[ "$_sz" -lt 131072 ] && return 0
	tail -n 300 "$LOG" > "$LOG.new" 2>/dev/null && mv "$LOG.new" "$LOG" 2>/dev/null
}


if [ "$1" = running ]; then subs_job_live; exit $?; fi
if [ "$1" = refresh-status ]; then refresh_status "$2"; exit $?; fi
case "$1" in
	workspace-sweep) subs_work_sweep; exit $? ;;  # the relay CGI calls before allocating its body
	update|""|refresh-job|relay-job|import-body) subs_work_sweep ;;
esac




rm -rf "$TMPD" 2>/dev/null
( umask 077; mkdir "$TMPD" ) 2>/dev/null || { echo "не удалось создать каталог работы $TMPD" >&2; exit 1; }






SUBS_LOCK_MINE=0; SUBS_JOB_MINE=0
trap 'rm -rf "$TMPD" 2>/dev/null; drop_lock; drop_job' EXIT
trap 'exit 1' INT TERM HUP PIPE
trim_log

case "$1" in
	refresh-job) refresh_job "$2" "$3"; exit $? ;;
	relay-job)

		SUB_RELAY_PROGRESS="$3/progress"
		import_body_run "$2" "$3/body" "$4" > "$3/result" 2>&1; rc=$?
		rm -f "$3/body"
		printf '%s\n' "$rc" > "$3/exit.new" && mv -f "$3/exit.new" "$3/exit"
		exit "$rc" ;;
	import-body)
		import_body_run "$2" "$3" "${4:-}"; exit $? ;;
	update|"")
		take_job && take_lock || exit 0
		cmd_update "$2"; rc=$?
		drop_lock
		exit $rc ;;
	fetch) cmd_fetch "$2" "${3:-}" ;;
	registry-put|registry-del)
		case "$2" in ''|*[!a-z0-9-]*) exit 1 ;; esac
		take_job >/dev/null && take_lock >/dev/null || exit 2
		_reg_row=''
		if [ "$1" = registry-put ]; then
			_reg_row="$2$TAB$3$TAB$4"
		elif [ -f "$NAMES" ]; then

			lbl_commit_out "$NAMES" sub_names_keep_other "$2" "$NAMES" || exit 1
		fi
		( umask 077; lbl_commit_out "$ENODIA_STATE/.subs" lbl_without "$ENODIA_STATE/.subs" "^$2$TAB" "$_reg_row" )
		exit $? ;;
	names-replace)
		case "$2" in ''|*[!a-z0-9-]*) exit 1 ;; esac
		take_job >/dev/null && take_lock >/dev/null || exit 2
		lbl_commit_out "$NAMES" sub_names_from_form "$2" "$3" "$NAMES"
		exit $? ;;
	restore-lock|row-lock)
		case "$2" in ''|*[!0-9]*) exit 1 ;; esac
		case "$1" in restore-lock) _lease_proc='cgi-bin/backup' ;; row-lock) _lease_proc='cgi-bin/action|road\.sh|warp\.sh' ;; esac
		pid_runs "$2" "$_lease_proc" && ! subs_job_live && take_lock "$2" >/dev/null || exit 1
		SUBS_LOCK_MINE=0   # The caller now owns the lease.
		exit 0 ;;
	restore-unlock|row-unlock)
		[ -n "$2" ] && [ "$(cat "$LOCK/pid" 2>/dev/null)" = "$2" ] || exit 1
		SUBS_LOCK_MINE=1
		drop_lock
		exit 0 ;;
	list)  cmd_list ;;
	client-json) cmd_client_json ;;
	parse) cmd_parse "$2" ;;
	parse-json) cmd_parse_json "$2" ;;
	name)  cmd_name "$2" ;;
	vpn-json) cmd_vpn_json "$2" "$3" ;;
	vpn-conf) cmd_vpn_conf "$2" "$3" "$4" ;;
	delete-config)
		! subs_job_live && take_lock >/dev/null || { echo 'Идёт обновление подписок — повторите удаление.'; exit 1; }
		delete_saved_cfg "$2" "$3" "$4" "${5:-}" manual; exit $? ;;
	prune-sub)
		take_lock >/dev/null || exit 1
		delete_saved_cfg "$2" "$3" "$4" "${5:-}" prune; exit $? ;;
	settle) cmd_settle "$2"; exit $? ;;
	put|unput)

		take_job && take_lock || exit 1
		case "$1" in
			put) cmd_put "$2" "$3" "$4" "$5" "$6" ;;
			unput) cmd_unput "$2" "$3" "$4" ;;
		esac
		rc=$?
		drop_lock
		exit $rc ;;
	drop)


		take_job && take_lock || exit 1
		cmd_drop "$2"; rc=$?
		drop_lock
		exit $rc ;;
	*)
		echo "usage: subs-update.sh update [tag] | fetch <tag> | list | drop <tag> | parse <ссылка> | name <ссылка> | vpn-json <in> <out> | vpn-conf <in> <out> [key] | put <tag> <fam> <name> <src> <имя> | unput <tag> <fam> <name> | settle <tag>" >&2
		echo "       расписание — update-sched.sh set subs <off|6h|12h|daily|weekly>" >&2
		exit 1 ;;
esac
