#!/bin/sh













: "${ENODIA_STATE:=/data/usr/app/enodia-state}"



SUBS_STATE="$ENODIA_STATE"


if [ -f "$ENODIA_DIR/label-lib.sh" ]; then . "$ENODIA_DIR/label-lib.sh"; fi   # lbl_commit_out: a file replaced whole or not at all
command -v lbl_commit_out_as >/dev/null 2>&1 || { lbl_commit_out_as() { _lct=$1; _lcf=$2; shift 2; "$@" > "$_lct" && mv -f "$_lct" "$_lcf" && return 0; rm -f "$_lct"; return 1; }; lbl_commit_out() { _lcf=$1; shift; lbl_commit_out_as "$_lcf.$$.new" "$_lcf" "$@"; }; lbl_grep() { grep "$@" || [ "$?" -le 1 ]; }; lbl_without() { if [ -f "$1" ]; then lbl_grep -v -- "$2" "$1" || return 1; fi; [ -z "${3:-}" ] || printf '%s\n' "$3"; }; }   # write-blind: the shim of a missing library is the old line
if [ -f "$ENODIA_DIR/ip-lib.sh" ]; then . "$ENODIA_DIR/ip-lib.sh"; fi
command -v wan_iface >/dev/null 2>&1 || wan_iface() { ip route show default 2>/dev/null | awk '/^default/{d=""; for(i=1;i<=NF;i++) if($i=="dev") d=$(i+1); if(d!="" && d !~ /^(awg|xtun)/){print d; exit}}'; }

SUBS_TAB=$(printf '\t')





sub_ip_public() {
	case "$1" in
		*:*)
			_l6=$(printf '%s' "$1" | tr 'A-Z' 'a-z')
			case "$_l6" in
				*::ffff:*.*.*.*) sub_ip_public "${_l6##*:}"; return $? ;;   # v4-mapped
				::|::1|0:0:0:0:0:0:0:1) return 1 ;;                         # loopback/unspecified
				fe8*:*|fe9*:*|fea*:*|feb*:*) return 1 ;;                    # link-local fe80::/10
				f[cd]*:*) return 1 ;;                                       # ULA fc00::/7
			esac
			return 0 ;;
	esac
	case "$1" in
		127.*|10.*|169.254.*|192.168.*|0.*|255.255.255.255) return 1 ;;
		172.16.*|172.17.*|172.18.*|172.19.*|172.2[0-9].*|172.3[0-1].*) return 1 ;;
	esac
	return 0
}






sub_host_public() {
	_h=$(printf '%s' "$1" | sed -e 's|^[a-zA-Z][a-zA-Z0-9+.-]*://||' -e 's|[/?#].*$||' -e 's|^[^@]*@||' -e 's|\]:[0-9]*$|]|' -e 's|:[0-9]*$||' -e 's|^\[||' -e 's|\]$||')
	[ -n "$_h" ] || return 1
	case "$_h" in
		*:*)       _ip="$_h" ;;                       # IPv6-литерал (скобки уже сняты)
		*[!0-9.]*) _ip=$(nslookup "$_h" 2>/dev/null | awk '/^Name:/{f=1;next} f&&/Address/{x=$NF; if(x ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/){print x; exit}}') ;;
		*)         _ip="$_h" ;;
	esac
	[ -n "$_ip" ] || return 0
	sub_ip_public "$_ip"
}


SUB_MAXSIZE=${SUB_MAXSIZE:-4194304}









sub_ui_num() {
	case "$1" in ''|*[!0-9]*) printf '0'; return ;; esac
	[ "${#1}" -le 18 ] && printf '%s' "$1" || printf '0'
}





sub_userinfo_read() {
	SUB_UI_HAVE=0; SUB_UI_UP=0; SUB_UI_DOWN=0; SUB_UI_TOTAL=0; SUB_UI_EXP=0
	[ -s "$1" ] || return 1



	_uz=$(wc -c < "$1" 2>/dev/null); case "$_uz" in ''|*[!0-9]*) _uz=0 ;; esac
	[ "$_uz" -le 262144 ] || return 1



	_ui=$(grep -i '^subscription-userinfo:' "$1" 2>/dev/null | tail -1 | cut -d: -f2- | tr -d ' \r\n' | tr 'A-Z;' 'a-z ')
	[ -n "$_ui" ] || return 1
	SUB_UI_HAVE=1




	while [ -n "$_ui" ]; do
		_kv=${_ui%% *}; _ui=${_ui#"$_kv"}; _ui=${_ui# }
		case "$_kv" in
			upload=*)   SUB_UI_UP=$(sub_ui_num "${_kv#upload=}") ;;
			download=*) SUB_UI_DOWN=$(sub_ui_num "${_kv#download=}") ;;
			total=*)    SUB_UI_TOTAL=$(sub_ui_num "${_kv#total=}") ;;
			expire=*)   SUB_UI_EXP=$(sub_ui_num "${_kv#expire=}") ;;
		esac
	done
	return 0
}











sub_info_put() {
	_pt="$1"; _ps="$2"
	case "$_pt" in ''|*[!a-z0-9-]*) return 1 ;; esac
	_pf="$SUBS_STATE/.sub-info"
	_pok=0; _perr=0; _phv=0; _pup=0; _pdn=0; _ptt=0; _pex=0


	if [ -f "$_pf" ]; then
		while IFS="$SUBS_TAB" read -r _pk _a1 _a2 _a3 _a4 _a5 _a6 _a7 || [ -n "$_pk" ]; do
			[ "$_pk" = "$_pt" ] || continue
			_pok=$_a1; _perr=$_a2; _phv=$_a3; _pup=$_a4; _pdn=$_a5; _ptt=$_a6; _pex=$_a7
		done < "$_pf"
	fi


	case "$_pok"  in ''|*[!0-9]*) _pok=0  ;; esac
	case "$_perr" in ''|*[!0-9]*) _perr=0 ;; esac
	case "$_phv"  in 0|1) : ;; *) _phv=0  ;; esac
	case "$_pup"  in ''|*[!0-9]*) _pup=0  ;; esac
	case "$_pdn"  in ''|*[!0-9]*) _pdn=0  ;; esac
	case "$_ptt"  in ''|*[!0-9]*) _ptt=0  ;; esac
	case "$_pex"  in ''|*[!0-9]*) _pex=0  ;; esac
	_pnow=$(date +%s 2>/dev/null | tr -cd '0-9'); [ -n "$_pnow" ] || _pnow=0
	if [ "$_ps" = ok ]; then
		_pok=$_pnow; _perr=0
		_phv=${SUB_UI_HAVE:-0}; _pup=${SUB_UI_UP:-0}; _pdn=${SUB_UI_DOWN:-0}
		_ptt=${SUB_UI_TOTAL:-0}; _pex=${SUB_UI_EXP:-0}
	else
		_perr=$_pnow
	fi






	lbl_commit_out "$_pf" lbl_without "$_pf" "^$_pt$SUBS_TAB" \
		"$_pt$SUBS_TAB$_pok$SUBS_TAB$_perr$SUBS_TAB$_phv$SUBS_TAB$_pup$SUBS_TAB$_pdn$SUBS_TAB$_ptt$SUBS_TAB$_pex" 2>/dev/null
	return 0
}



sub_info_drop() {
	_dt="$1"; _df="$SUBS_STATE/.sub-info"
	case "$_dt" in ''|*[!a-z0-9-]*) return 1 ;; esac
	[ -f "$_df" ] || return 0
	lbl_commit_out "$_df" lbl_grep -v "^$_dt$SUBS_TAB" "$_df" 2>/dev/null
	return 0
}













SUB_UA_DEFAULT='enodia-panel/1.0'
sub_client_ua() {   # $1 client, $2 custom's own line → the User-Agent to send
	case "$1" in
		happ)    printf '%s' 'Happ/3.0' ;;
		v2rayng) printf '%s' 'v2rayNG/1.10.6' ;;
		custom)  printf '%s' "$2" ;;
		*)       printf '%s' "$SUB_UA_DEFAULT" ;;
	esac
}


sub_ua_ok()   { case "$1" in ''|-|*[!\ -~]*) return 1 ;; esac; [ "${#1}" -le 200 ]; }
sub_hwid_ok() { case "$1" in ''|-|*[!A-Za-z0-9._:+/=-]*) return 1 ;; esac; [ "${#1}" -ge 4 ] && [ "${#1}" -le 128 ]; }

sub_hwid_new() {
	_shn=$(tr -d '\n-' < /proc/sys/kernel/random/uuid 2>/dev/null)
	sub_hwid_ok "$_shn" || _shn=$(printf '%08x%08x' "$$" "$(date +%s 2>/dev/null)")
	printf '%s' "$_shn"
}

sub_client_read() {
	SUB_CL=enodia; SUB_CL_UA=''; SUB_CL_HWON=0; SUB_CL_HWID=''; SUB_CL_HWSRC=gen
	[ -f "$SUBS_STATE/.sub-client" ] || return 0
	while IFS="$SUBS_TAB" read -r _sck _scc _scu _sch _sci _scs || [ -n "$_sck" ]; do
		[ "$_sck" = "$1" ] || continue
		case "$_scc" in enodia|happ|v2rayng|custom) SUB_CL=$_scc ;; esac
		sub_ua_ok "$_scu" && SUB_CL_UA=$_scu
		[ "$SUB_CL" = custom ] && [ -z "$SUB_CL_UA" ] && SUB_CL=enodia   # a custom client without its line is no client
		sub_hwid_ok "$_sci" && SUB_CL_HWID=$_sci
		[ "$_sch" = 1 ] && [ -n "$SUB_CL_HWID" ] && SUB_CL_HWON=1
		[ "$_scs" = own ] && SUB_CL_HWSRC=own
	done < "$SUBS_STATE/.sub-client"
	return 0
}

sub_client_put() {
	case "$1" in ''|*[!a-z0-9-]*) return 1 ;; esac
	case "$2" in enodia|happ|v2rayng|custom) : ;; *) return 1 ;; esac
	_scu=-; if [ "$2" = custom ]; then sub_ua_ok "$3" || return 1; _scu=$3; fi
	_sci=-; if [ -n "$5" ] && [ "$5" != - ]; then sub_hwid_ok "$5" || return 1; _sci=$5; fi
	_sch=0; [ "$4" = 1 ] && _sch=1
	[ "$_sch" = 1 ] && [ "$_sci" = - ] && return 1   # «send a HWID» with none
	_scs=gen; [ "$6" = own ] && _scs=own
	( umask 077; lbl_commit_out "$SUBS_STATE/.sub-client" lbl_without "$SUBS_STATE/.sub-client" "^$1$SUBS_TAB" \
		"$1$SUBS_TAB$2$SUBS_TAB$_scu$SUBS_TAB$_sch$SUBS_TAB$_sci$SUBS_TAB$_scs" ) 2>/dev/null
}

sub_client_drop() {
	case "$1" in ''|*[!a-z0-9-]*) return 1 ;; esac
	[ -f "$SUBS_STATE/.sub-client" ] || return 0
	( umask 077; lbl_commit_out "$SUBS_STATE/.sub-client" lbl_grep -v "^$1$SUBS_TAB" "$SUBS_STATE/.sub-client" ) 2>/dev/null
	return 0
}









sub_get_once() {
	_gu="$1"; _go="$2"; shift 2
	SUB_FETCH_PARTIAL=0
	_hop=0
	while [ "$_hop" -le 3 ]; do



		rm -f "$_go" "$_go.hdr" 2>/dev/null
		sub_host_public "$_gu" || return 2
		_loc=$(curl -s --max-time 25 --max-filesize "$SUB_MAXSIZE" -A "$SUB_UA_DEFAULT" \
			"$@" -D "$_go.hdr" -o "$_go" -w '%{redirect_url}' "$_gu" 2>/dev/null)
		_grc=$?
		if [ "$_grc" != 0 ]; then
			if [ "$_grc" = 63 ] || [ -s "$_go" ]; then SUB_FETCH_PARTIAL=1; fi
			break
		fi
		[ -n "$_loc" ] || break
		if [ "$_hop" = 3 ]; then SUB_FETCH_PARTIAL=1; rm -f "$_go"; return 1; fi
		_gu="$_loc"; _hop=$((_hop+1))
	done


	if [ -s "$_go" ]; then
		_sz=$(wc -c < "$_go" 2>/dev/null); case "$_sz" in ''|*[!0-9]*) _sz=0 ;; esac
		[ "$_sz" -gt "$SUB_MAXSIZE" ] && { SUB_FETCH_PARTIAL=1; rm -f "$_go" 2>/dev/null; return 1; }
	fi
	[ -s "$_go" ]
}


sub_unpack_body() {
	[ "$(head -c 2 "$1" | base64 | tr -d '\r\n')" = H4s= ] || return 0
	if ! ( gunzip -c "$1" 2>/dev/null; echo "$?" > "$1.gz.status" ) | head -c "$((SUB_MAXSIZE+1))" > "$1.gz"; then
		SUB_FETCH_PARTIAL=1
		rm -f "$1" "$1.gz" "$1.gz.status"
		return 1
	fi
	if [ "$(wc -c < "$1.gz")" -gt "$SUB_MAXSIZE" ]; then
		SUB_FETCH_PARTIAL=1
		head -c "$SUB_MAXSIZE" "$1.gz" > "$1" || rm -f "$1"
	else
		[ "$(cat "$1.gz.status" 2>/dev/null)" = 0 ] || SUB_FETCH_PARTIAL=1
		mv -f "$1.gz" "$1" || { SUB_FETCH_PARTIAL=1; rm -f "$1"; }
	fi
	rm -f "$1.gz" "$1.gz.status"
	[ -s "$1" ]
}
















sub_fetch() {
	_u="$1"; _o="$2"
	[ -n "$_u" ] && [ -n "$_o" ] || return 1
	shift 2
	rm -f "$_o" "$_o.gz" "$_o.hdr" 2>/dev/null
	SUB_FETCH_VIA=""
	SUB_UI_HAVE=0; SUB_UI_UP=0; SUB_UI_DOWN=0; SUB_UI_TOTAL=0; SUB_UI_EXP=0
	sub_get_once "$_u" "$_o" "$@" || [ "$?" -ne 2 ] || return 1
	if [ ! -s "$_o" ] && [ "$SUB_FETCH_PARTIAL" = 0 ]; then




		_wan=$(wan_iface)
		if [ -n "$_wan" ]; then
			sub_get_once "$_u" "$_o" "$@" --interface "$_wan" || [ "$?" -ne 2 ] || return 1
			[ -s "$_o" ] && SUB_FETCH_VIA="$_wan"
		fi
	fi



	sub_userinfo_read "$_o.hdr"
	rm -f "$_o.hdr" 2>/dev/null
	[ -s "$_o" ] || { rm -f "$_o" 2>/dev/null; return 1; }
	sub_unpack_body "$_o"
}




sub_fetch_tag() {
	sub_client_read "$1"
	_sft_ua=$(sub_client_ua "$SUB_CL" "$SUB_CL_UA")
	if [ "$SUB_CL_HWON" = 1 ]; then sub_fetch "$2" "$3" -A "$_sft_ua" -H "x-hwid: $SUB_CL_HWID"
	else sub_fetch "$2" "$3" -A "$_sft_ua"; fi
}


sub_tags() { [ -f "$SUBS_STATE/.subs" ] && cut -d"$SUBS_TAB" -f1 "$SUBS_STATE/.subs" 2>/dev/null; }

sub_url_of()   { [ -f "$SUBS_STATE/.subs" ] && grep "^$1$SUBS_TAB" "$SUBS_STATE/.subs" 2>/dev/null | head -1 | cut -d"$SUBS_TAB" -f2; }
sub_label_of() { [ -f "$SUBS_STATE/.subs" ] && grep "^$1$SUBS_TAB" "$SUBS_STATE/.subs" 2>/dev/null | head -1 | cut -d"$SUBS_TAB" -f3-; }
sub_url_revision() { printf '%s' "$1" | sha256sum | cut -d' ' -f1; }
sub_names_from_form() {
	sub_names_keep_other "$1" "$3" || return 1
	printf '%s' "$2" | base64 -d 2>/dev/null | awk '{print}'
}





sub_owner_tag() {
	_b="$1"; _own=""; _ol=-1
	for _g in $(sub_tags); do
		case "$_b" in sub-"$_g"-*) _gl=${#_g}; [ "$_gl" -gt "$_ol" ] && { _own="$_g"; _ol=$_gl; } ;; esac
	done
	printf '%s' "$_own"
}









sub_names_keep_other() {
	_kt="$1"; _nf="${2:-$SUBS_STATE/.sub-names}"
	[ -f "$_nf" ] || return 0
	_tl=$(sub_tags 2>/dev/null | tr '\n' ' ')
	case " $_tl " in *" $_kt "*) : ;; *) _tl="$_tl $_kt" ;; esac

	while IFS= read -r _ln || [ -n "$_ln" ]; do
		[ -n "$_ln" ] || continue
		_nb=${_ln%%"$SUBS_TAB"*}; _own=""; _ol=-1
		for _g in $_tl; do
			case "$_nb" in sub-"$_g"-*) _gl=${#_g}; [ "$_gl" -gt "$_ol" ] && { _own="$_g"; _ol=$_gl; } ;; esac
		done
		[ "$_own" = "$_kt" ] && continue
		printf '%s\n' "$_ln"
	done < "$_nf"
	return 0
}










sub_sum_cut() {
	_sc=$(tr -d '\t\r\n')

	_sc="${_sc%"${_sc##*[! ]}"}"
	_sn=$(printf '%s' "$_sc" | wc -c)
	[ $((_sn)) -le "$1" ] && { printf '%s' "$_sc"; return 0; }
	_sc=$(printf '%s' "$_sc" | cut -c1-$(($1 - 4)))
	case "$_sc" in
		*'. «'*) _sc="${_sc%. «*}." ;;
		*' '*)  _sc="${_sc% *}" ;;
		*)      _sc='' ;;
	esac
	printf '%s …' "$_sc"
}
