#!/bin/sh

exec sh "$(dirname "$0")/subs-import.sh" "$@"
